import store from "../../store";

export const getProcessingPartner = (country) => {
  const groupState = store.getState();
  const groupSettings = groupState.user.groupIdSettings;
  return groupSettings?.processingPartner[country]
};
