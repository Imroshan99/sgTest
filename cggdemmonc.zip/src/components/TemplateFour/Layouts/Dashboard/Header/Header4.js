/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import PermIdentityOutlinedIcon from "@mui/icons-material/PermIdentityOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import { useDispatch, useSelector } from "react-redux";
import { useReducer, useState } from "react";
import UserMenu from "../../../user/UserMenu";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { getProcessingPartner } from "../../../../../services/utility/group";
import Badge from "@mui/material/Badge";
import SvgIcon from "@mui/material/SvgIcon";
import { ReactComponent as NotificationSvg } from "../../../../../assets/images/notification.svg";
import { ProfileAPI } from "../../../../../apis/ProfileAPI";
import useHttp from "../../../../../hooks/useHttp";
import NotificationMenu from "../../../user/NotificationMenu";

export default function Header4() {
  const AuthReducer = useSelector((state) => state.user);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const [notificationMenu, setNotificationMenu] = useState(false);
  const [anchorElNoti, setAnchorElNoti] = useState(null);
  const [notificationLoader, setNotificationLoader] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  console.log("RRRR",AuthReducer.notificationCount)
  console.log("RRRR Auth",AuthReducer)

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    firstName: "",
    lastName: "",
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    notificationList: [],
    alertList: [],
    newNotificationCount: "0",
  });
  const hookNotificationList = useHttp(ProfileAPI.notificationLists);
  const hookUpdateNotification = useHttp(ProfileAPI.updateNotification);


  const navigate = useNavigate();
  let dispatch = useDispatch();

  const handleCloseNotiMenu = () => {
    setAnchorElNoti(null);
    setNotificationMenu(false);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleOpenNotiMenu = (event) => {
    setAnchorElNoti(event.currentTarget);
    setNotificationMenu(true);
    async function fetch() {
      await getNotificationList();
      await updateNotificationHandler();
    }
    fetch();
  };

  const getNotificationList = async () => {
    let payload = {
      requestType: "NOTIFICATIONLISTS",
      userId: AuthReducer.userID,
    };
    setNotificationLoader(true);
    await hookNotificationList.sendRequest(payload, (data) => {
      if (data.status == "S") {
        const responseData = data.responseData.slice(0, 5);
        let notificationLists = [];
        let alertLists = [];
        responseData.filter((i) => {
          if (i.notificationName.search("ALERT_") !== -1) {
            alertLists.push(i);
          } else {
            notificationLists.push(i);
          }
        });
        setState({
          notificationList: notificationLists,
          alertList: alertLists,
        });
        dispatch({
          type: "SET_NOTIFICATION_COUNT",
          payload: data.newNotification,
        });
        setNotificationLoader(false);
      } else {
        // notification.error({ message: data.errorMessage });
        setNotificationLoader(false);
      }
    });
  };
  const updateNotificationHandler = async () => {
    let payload = {
      requestType: "UPDATENOTIFICATIONS",
      userId: AuthReducer.userID,
    };
    await hookUpdateNotification.sendRequest(payload, (data) => {
      if (data.status == "S") {
        dispatch({ type: "SET_NOTIFICATION_COUNT", payload: "0" });
        // setState({ newNotificationCount: "0" });
      }
    });
  };

  const handleCloseUserMenu = (e) => {
    setAnchorElUser(null);
    if (e === "Logout") {
      window.location.href = "/";
    }
  };
  return (
    <>
      <header className="classic">
        <div className="bg-white">
          <div className="container">
            <nav class="navbar navbar-expand-lg navbar-light ">
              <Link className="logo" to="/">
                <img
                  src={`images/${AuthReducer.groupId}/logo.png`}
                  height="48px"
                  alt="Logo"
                />
              </Link>
              {AuthReducer?.isLoggedIn && (
                <>
                  {/* <button
                    class="navbar-toggler"
                    type="button"
                    data-toggle="collapse"
                    data-target="#navbarNavAltMarkup"
                    aria-controls="navbarNavAltMarkup"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                  >
                    <span class="navbar-toggler-icon"></span>
                  </button> */}
                  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav ms-auto d-flex align-items-center">
                      <NavLink
                        className="nav-item navTitles"
                        to="/new-transaction"
                      >
                        New Transcation{" "}
                      </NavLink>
                      <NavLink
                        className="nav-item navTitles2"
                        to="/my-recipient"
                      >
                        Receivers
                      </NavLink>
                      {getProcessingPartner(AuthReducer.sendCountryCode) !== "LULU" && (
                        <NavLink
                          className="nav-item me-3 navTitles2"
                          to="/my-bank-accounts"
                        >
                          Bank Accounts
                        </NavLink>
                      )}
                      {/* <a class="nav-item" href="#">
                    <img src={require("../../../../../assets/images/flags/profile.png")} />
                  </a> */}
                  {/* <IconButton className="me-2" sx={{ p: 0 }}> */}
                  <IconButton className="me-2" onClick={handleOpenNotiMenu} sx={{ p: 0 }}>
                      <Badge
                        overlap="circular"
                        badgeContent={AuthReducer.notificationCount}
                        color="error"
                        invisible={
                          AuthReducer.notificationCount === "" ||
                          AuthReducer.notificationCount === "0"
                            ? true
                            : false
                        }
                      >
                        <Avatar>
                          <SvgIcon>
                            <NotificationSvg />
                          </SvgIcon>
                        </Avatar>
                      </Badge>
                    </IconButton>
                    {notificationMenu && (
                      <NotificationMenu
                        setIsModalVisible={setIsModalVisible}
                        state={state}
                        anchorElNoti={anchorElNoti}
                        setAnchorElNoti={setAnchorElNoti}
                        handleCloseNotiMenu={handleCloseNotiMenu}
                        notificationLoader={notificationLoader}
                      />
                    )}
                      
                    </div>
                  </div>
                  <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                        <Avatar
                          alt={AuthReducer.userFullName}
                        // {...stringAvatar(AuthReducer.userFullName)}
                        >
                          <PermIdentityOutlinedIcon />
                        </Avatar>
                      </IconButton>
                      <UserMenu
                        anchorElUser={anchorElUser}
                        handleCloseUserMenu={handleCloseUserMenu}
                      />
                </>
              )}
            </nav>
          </div>
        </div>
      </header>
    </>
  );
}
