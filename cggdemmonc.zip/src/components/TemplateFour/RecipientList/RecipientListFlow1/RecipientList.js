import React, { useState, useEffect, useReducer, Fragment } from "react";
import { Table, Modal, Input, Select } from "antd";
import { Row, Col } from "react-bootstrap";
import { DeleteFilled, EditFilled, InfoCircleFilled } from "@ant-design/icons";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import RecipientInfo2 from "../../RecipientInfo/RecipientInfoFlow2/RecipientInfo";
import RecipientInfo1 from "../../RecipientInfo/RecipientInfoFlow1/RecipientInfo";

import useHttp from "../../../../hooks/useHttp";
import AddRecipient from "../../AddRecipient/AddRecipientFlow1/AddRecipient";
import EditRecipient from "../../EditRecipient/EditRecipientFlow1/EditRecipient";
import Spinner from "../../../../reusable/Spinner";
import AddRecipientModal from "../../AddRecipient/Modal";
import CustomInput from "../../../../reusable/CustomInput";

const { Option } = Select;

function RecipientList(props) {
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const recipientListConfig =
    ConfigReducer.groupIdSettings.recipientModule.recipientList;
  const templateFlow =
    AuthReducer.groupIdSettings?.recipientModule?.RecipientInfo?.flow;

  const AddRecipientFlow =
    AuthReducer.groupIdSettings?.recipientModule?.AddRecipientForm?.flow;
  const [loading, setLoader] = useState(false);
  const [spinner, setSpinner] = useState(false);
  const [editRecipientModal, setEditRecipientModal] = useState(false);
  const [addRecipentModal, setAddRecipentModal] = useState(false);
  const [editRecipientData, setEditRecipientData] = useState();
  const [recipientListTable, setRecipientListTable] = useState(false);
  const [contentRender, setContentRender] = useState(false);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      receiverLists: [],
      filteredRecieverList: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      isModalVisible: false,
      modalRecipientsDetails: {},
      searchButtonStatus: true,
      searchInputValue: "",
      accountTypeFilter: "",
      stateFilter: "",
      filteredStateList: [],
    }
  );

  const hookGetReceiverLists = useHttp(ReceiverAPI.receiverLists);
  const hookViewRecipientsDetails = useHttp(ReceiverAPI.viewRecipientsDetails);
  const hookDeleteReceiver = useHttp(ReceiverAPI.deleteReceiver);

  useEffect(() => {
    getReceiverLists();
  }, []);
  useEffect(() => {
    receiverListFilter();
  }, [state.accountTypeFilter, state.stateFilter]);

  const accountType = (value) => {
    if (value == "S") {
      return "Savings Account";
    } else if (value == "NE") {
      return "NRE Account";
    } else {
      return "NRO Account";
    }
  };
  const afterClose = () => {
    setState({ modalRecipientsDetails: {} });
  };
  const getReceiverLists = () => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: state.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
    };

    setLoader(true);
    hookGetReceiverLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        let verifiedStatus = "";
        setRecipientListTable(true);
        let resData = [];
        let stateList = [];
        if (data.responseData[0].status == "V") {
          verifiedStatus = "Verified";
        } else {
          verifiedStatus = data.status;
        }
        data.responseData.forEach((detail, i) => {
          let data = {
            key: i,
            name: `${detail.firstName} ${detail.lastName}`,
            bankName: `${detail.bankName}`,
            accountNo: `${detail.accountNo}`,
            status: `${verifiedStatus}`,
            recordToken: `${detail.recordToken}`,
            nickName: `${detail.nickName}`,
            bankBranch: `${detail.bankBranch}`,
            city: `${detail.city}`,
            country: detail.country,
            // country:`${detail.countryCode}`,
            state: `${detail.state}`,
            accountType: accountType(detail.accountType),
          };

          resData.push(data);
          stateList.push(detail.state);
        });
        let newFilteredStateList = [...new Set(stateList)];
        setState({
          filteredStateList: newFilteredStateList,
          receiverLists: resData,
          filteredRecieverList: resData,
        });
        setContentRender(true);
      } else {
        setRecipientListTable(false);
        setContentRender(true);
      }
      setLoader(false);
    });
  };
  const onKeyPressEnterSearch = (e) => {
    if (e.code == "Enter") {
      receiverListFilter();
    }
  };

  const receiverListFilter = () => {
    let filteredRecieverList = state.receiverLists.filter((i) => {
      return (
        i.name.toLowerCase().search(state.searchInputValue.toLowerCase()) !== -1
      );
    });
    let reFilteredRecieverList = filteredRecieverList.filter((i) => {
      return i.accountType.search(state.accountTypeFilter) !== -1;
    });
    let reReFilteredRecieverList = reFilteredRecieverList.filter((i) => {
      return i.state.search(state.stateFilter) !== -1;
    });
    setState({ filteredRecieverList: reReFilteredRecieverList });
  };

  const viewDetailsHandlerClick = (row) => {
    setState({ isModalVisible: true });
    const payload = {
      requestType: "RECEIVERINFO",
      userId: state.userID,
      nickName: row.nickName,
      recordToken: row.recordToken,
    };

    setSpinner(true);
    hookViewRecipientsDetails.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setSpinner(false);
        setState({
          modalRecipientsDetails: data,
        });
      }
    });
  };

  const deleteReceiverHandler = async (row) => {
    Swal.fire({
      text: "Are you sure you want to delete this receiver?",
      showCancelButton: true,
      confirmButtonText: "Confirm",
      denyButtonText: `Cancel`,
      confirmButtonColor: "#FFFFFF",
      color: "#FFFFFF",
      background: "#003153",
      customClass: {
        confirmButton: "btn btn-primary text-white ",
        cancelButton: "btn btn-secondary",
      },
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        const payload = {
          requestType: "GETRECVLIST",
          userId: state.userID,
          nickName: row.nickName,
          recordToken: row.recordToken,
        };

        setLoader(true);
        hookDeleteReceiver.sendRequest(payload, function (data) {
          if (data.status == "S") {
            getReceiverLists();
          }
        });
      } else if (result.isDenied) {
        Swal.fire("Changes are not saved", "", "info");
      }
    });
  };

  const editReceiverHandler = (row) => {
    const payload = {
      requestType: "RECEIVERINFO",
      userId: state.userID,
      nickName: row.nickName,
      recordToken: row.recordToken,
    };

    setLoader(true);
    hookViewRecipientsDetails.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setEditRecipientData(data);
        AddRecipientFlow === "FLOW1"
          ? setEditRecipientModal(true)
          : setEditRecipientModal(true);
        // : navigate("/edit-recipient", { state: { editRecipientData: data } });
        setLoader(false);
      }
    });
  };

  return (
    <Fragment>
      {/* <Modal
        className="primary"
        centered
        visible={addRecipentModal}
        onCancel={() => setAddRecipentModal(false)}
        width={1000}
        footer={null}
      >
        <AddRecipient
          getReceiverLists={getReceiverLists}
          setAddRecipentModal={setAddRecipentModal}
        />
      </Modal> */}
      {addRecipentModal && (
        <AddRecipientModal
          visible={addRecipentModal}
          setVisible={setAddRecipentModal}
          accountsList={getReceiverLists}
        />
      )}

      <Modal
        className="primary"
        centered
        visible={editRecipientModal}
        onCancel={() => setEditRecipientModal(false)}
        width={1000}
        footer={null}
      >
        <EditRecipient
          getReceiverLists={getReceiverLists}
          editRecipientData={editRecipientData}
          setEditRecipientModal={setEditRecipientModal}
        />
      </Modal>

      <Spinner spinning={loading}>
        <div className="template2__main">
          <div className="RecipientListContainer">
            <Row className="d-flex mb-3">
              <Col md={4}>
                <CustomInput
                  showLabel={false}
                  placeholder="Search with Receiver Name"
                  type="text"
                  onKeyDown={onKeyPressEnterSearch}
                  onChange={(e) => {
                    setState({ searchInputValue: e.target.value });
                  }}
                />
              </Col>
              <Col md={6}>
                <button
                  // disabled={state.searchButtonStatus}

                  className="btn btn-secondary"
                  onClick={() => {
                    receiverListFilter();
                  }}
                >
                  Search
                </button>
              </Col>
            </Row>
            <Row className="mb-3">
              <Col className="d-flex align-items-center">
                <span>Filter</span>
                <CustomInput
                  type="select"
                  className="mx-3"
                  allowClear
                  showSearch
                  onChange={(value) => setState({ accountTypeFilter: value })}
                  placeholder="Select Account Type"
                >
                  <Option value="Savings Account">Savings Account</Option>
                  <Option value="NRE Account">NRE Account</Option>
                  <Option value="NRO Account">NRO Account</Option>
                </CustomInput>

                <CustomInput
                  allowClear
                  showSearch
                  type="select"
                  onChange={(value) => setState({ stateFilter: value })}
                  placeholder="Select State"
                >
                  {state.filteredStateList.map((state, i) => {
                    return (
                      <Option key={i} value={state}>
                        {state}
                      </Option>
                    );
                  })}
                </CustomInput>
              </Col>
              <Col className="text-end">
                <button
                  className="btn btn-primary mt-3"
                  onClick={() => setAddRecipentModal(true)}
                >
                  Add Receiver
                </button>
              </Col>
            </Row>

            {contentRender && recipientListTable && (
              <div className="RecpListTableContainer">
                <Row>
                  <div className="RecpListHeaderContainer">
                    <div className="RecpListHeaderInnerContainer">
                      <h5>All Receivers</h5>
                    </div>
                  </div>
                </Row>
                <Table
                  columns={[
                    {
                      title: "Name",
                      dataIndex: "name",
                      className: "w-auto",
                    },
                    {
                      title: "Account No",
                      dataIndex: "accountNo",
                    },
                    {
                      title: "Account Type",
                      dataIndex: "accountType",
                    },
                    {
                      title: "State",
                      dataIndex: "state",
                    },
                    {
                      title: "Country",
                      dataIndex: "country",
                    },
                    {
                      title: "",
                      dataIndex: "",
                      key: "y",
                      className: "border-bottom-0 tw-30 text-end",
                      render: (text, record, index) => {
                        return (
                          <div className="d-flex justify-content-end align-items-center">
                            <span
                              className="px-2 text-info-dark d-flex align-items-center"
                              i={index}
                              onClick={() => viewDetailsHandlerClick(text)}
                            >
                              <InfoCircleFilled className="me-1" />
                              <p className="m-0">More</p>
                            </span>
                            <span className="vl"></span>
                            <span
                              className="px-2 text-info-dark d-flex align-items-center"
                              i={index}
                              onClick={() => editReceiverHandler(text)}
                            >
                              <EditFilled className="me-1" />
                              <p className="m-0">Edit</p>
                            </span>
                            <span className="vl"></span>
                            <span
                              className="px-2 text-info-dark d-flex align-items-center"
                              i={index}
                              onClick={() => deleteReceiverHandler(text)}
                            >
                              <DeleteFilled className="me-1" />
                              <p className="m-0">Delete</p>
                            </span>
                          </div>
                        );
                      },
                    },
                  ]}
                  dataSource={state.filteredRecieverList}
                  pagination={false}
                />
              </div>
            )}
            {contentRender && !recipientListTable && (
              <div className="d-flex justify-content-center mt-5">
                <h3 className="text-white">No Recipients available</h3>
              </div>
            )}
          </div>
        </div>
        {templateFlow === "FLOW1" ? (
          <RecipientInfo1
            afterClose={afterClose}
            state={state}
            spinner={spinner}
            setState={setState}
          />
        ) : (
          <RecipientInfo2 state={state} setState={setState} />
        )}
      </Spinner>
    </Fragment>
  );
}

export default RecipientList;
