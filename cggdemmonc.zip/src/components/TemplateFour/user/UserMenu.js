import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { config } from "../../../config";
import useHttp from "../../../hooks/useHttp";
import { Spin } from "antd";
import { NavLink } from "react-router-dom";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { getProcessingPartner } from "../../../services/utility/group";

export default function UserMenu(props) {
  const AuthReducer = useSelector((state) => state.user);
  const templateFlow = AuthReducer.groupIdSettings?.kyc?.flow;
  return (
    <>
      <Menu
        anchorEl={props.anchorElUser}
        id="account-menu"
        open={Boolean(props.anchorElUser)}
        onClose={props.handleCloseUserMenu}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <div className="User-Menu">
          {[
             getProcessingPartner(AuthReducer.sendCountryCode) !== "LULU" && (
              <MenuItem
              key="menu2"
              onClick={props.handleCloseUserMenu}
              
              component={Link}
              to={"/my-bank-accounts"}
            >
              Account Summary
            </MenuItem>
              )
            ,
            <MenuItem
              key="menu3"
              onClick={props.handleCloseUserMenu}
              
              component={Link}
              to={"/profile"}
            >
              My Profile
            </MenuItem>,
            <MenuItem
              key="menu4"
              onClick={props.handleCloseUserMenu}
              
              component={Link}
              to={"/change-password"}
            >
              Change Password
            </MenuItem>,
            <MenuItem
              key="menu6"
              onClick={props.handleCloseUserMenu}
              
              component={Link}
              to={"/my-recipient"}
            >
              My Receivers
            </MenuItem>,
            <MenuItem
              key="menu7"
              onClick={props.handleCloseUserMenu}
              
              component={Link}
              to={"/my-transaction"}
            >
              Transaction Summary
            </MenuItem>,
            templateFlow === "FLOW1" && (
              getProcessingPartner(AuthReducer.sendCountryCode) !== "LULU" && (
              <MenuItem
                key="menu9"
                onClick={props.handleCloseUserMenu}
                
                component={Link}
                to={"/upload-doc"}
              >
                Upload Additional Document demo
              </MenuItem>
            )),

            // <MenuItem
            //   key="menu8"
            //   onClick={() => {
            //     props.handleCloseUserMenu();
            //     props.setIsModalVisible(true);
            //   }}
            //   
            // >
            //   Upload Additional Document
            // </MenuItem>,
            <MenuItem
              key="menu9"
              onClick={props.handleCloseUserMenu}
              
              component={Link}
              to={"/kyc"}
            >
              Kyc Update
            </MenuItem>,
            <MenuItem
            key="menu98"
            onClick={props.handleCloseUserMenu}
            
            component={Link}
            to={"/refer-and-earn"}
          >
            Refer & Earn
          </MenuItem>,
            <MenuItem
              key="menu99"
              onClick={() => props.handleCloseUserMenu("Logout")}
              
              component={Link}
              to={"/"}
            >
              Logout
            </MenuItem>,
            // <MenuItem
            //   key="menu8"
            //   onClick={props.handleCloseUserMenu}
            //   
            //   component={Link}
            //   to={"/feedback"}
            // >
            //   Feedback
            // </MenuItem>,
            // <MenuItem
            //   key="menu9"
            //   onClick={props.handleCloseUserMenu}
            //   
            //   component={Link}
            //   to={"/refer"}
            // >
            //   Refer
            // </MenuItem>,
          ]}
        </div>
      </Menu>
    </>
  );
}
