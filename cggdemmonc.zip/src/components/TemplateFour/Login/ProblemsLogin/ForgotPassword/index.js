import AuthTemplate from "../../../Layouts/Auth";
import ForgotPasswordFlowOne from "./ForgotPasswordFlowOne";

const ForgotPassword = (props) => {
  return (
    <>
      <ForgotPasswordFlowOne />
    </>
  );
};

export default ForgotPassword;
