import React, { useState } from "react";
import { DatePicker, Input, Select } from "antd";
import clsx from "clsx";

import TextField from "@mui/material/TextField";

const FloatInput = (props) => {
  let {
    label,
    value,
    placeholder,
    type = "text",
    required,
    inputClassName,
    children,
    onChange,
    size,
    onSelect,
    filterOption,
    disabled,
    reference,
  } = props;

  if (!placeholder) placeholder = label;

  //   const isOccupied = focus || (value && value.length !== 0);
  //   const labelClass = isOccupied ? "label as-label" : "label as-placeholder";
  //   const requiredMark = required ? <span className="text-danger">*</span> : null;

  // return (
  //   <div className="form-floating">
  //     <Input
  //       onChange={props.onChange}
  //       type={type}
  //       defaultValue={value}
  //       className="form-control"
  //       placeholder={placeholder}
  //     />
  //     <label for="floatingInput">Email address</label>
  //   </div>
  // );
  const clsList = clsx({ in__focus: value !== undefined && value !== "" ? true : false });
  // console.log("value", value);

  const renderInputTypeSwitch = (param) => {
    switch (param) {
      case "datepicker":
        return (
          <DatePicker
            placeholder=""
            className={`mui-datepicker w-100 ${clsList}`}
            defaultPickerValue={props.defaultPickerValue}
            disabledDate={props.disabledDate}
            onChange={props.onChange}
          />
        );

      case "select":
        return (
          <Select
            defaultValue={value}
            value={value}
            className={`mui-select ${clsList}`}
            onSelect={props.onSelect}
            onChange={props.onChange}
            filterOption={props.filterOption}
            // placeholder={placeholder}
            disabled={disabled}
            showSearch
          >
            {children}
          </Select>
        );

      case "password":
        return (
          <Input.Password
            placeholder=""
            defaultValue={value}
            value={value}
            className={`mui-password ${clsList}`}
            onChange={props.onChange}
            type={type}
            autoComplete="new-password"
          />
        );

      default:
        return (
          <Input
            onBlur={props.onBlur}
            onChange={props.onChange}
            onFocus={props.onFocus}
            type={type}
            defaultValue={value}
            value={value}
            className="form-control"
            placeholder={placeholder}
            disabled={disabled}
            autoComplete="none"
            ref={reference}
          />
        );
    }
  };

  return (
    <>
      {/* {type === "select" ? (
        <>
          <div className="form-floating">
            <label for="floatingInput">{placeholder}</label>
          </div>
        </>
      ) : (
        <> */}
      <div className="form-floating">
        {renderInputTypeSwitch(type)}
        <label for="floatingInput">{placeholder}</label>
      </div>
      {/* </>
      )} */}
    </>
  );
};

export default FloatInput;
