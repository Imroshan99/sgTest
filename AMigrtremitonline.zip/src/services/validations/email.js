export function validateEmailId(textbox) {
  if (!textbox == "") {
    var regexp = /^\S*$/;
    if (!regexp.test(textbox)) {
      return {
        status: "F",
        message: "Please input valid email without space.",
      };
    }
  }

  var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
  var emailId = textbox;
  if (reg.test(emailId) == false) {
    return {
      status: "F",
      message: "Please input your email in valid format",
    };
  }

  var validStr = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@.-_0123456789";
  var inputValue = textbox;
  for (let i = 0; i <= textbox.length - 1; i++) {
    if (validStr.indexOf(inputValue.charAt(i)) == -1) {
      return {
        status: "F",
        message: "Special charecters are not allowed, accepts only(@.-_)",
      };
    }
  }
  //   for (let i = 0; i <= textbox.length - 1; i++) {
  //     if (validStr.indexOf(inputValue.charAt(i)) == -1) {
  //       var dataArray = new Array();
  //       dataArray[0] = "context~";
  //       dataArray[1] = "char~" + escape(inputValue.charAt(i));
  //       return {
  //         status: "F",
  //         message: "Please input your email22.",
  //       };
  //       break;
  //     }
  //   }

  return {
    status: "S",
    message: "Success",
  };
}
