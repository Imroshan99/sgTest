export function checkPassword(inputPassword) {
  const strLen = inputPassword.length;
  if (inputPassword === "" || strLen < 1) {
    return {
      status: "F",
      message: "Please input your Password.",
    };
  }

  if (strLen < 10 || strLen > 20) {
    return {
      status: "F",
      message: "Password should be between 10 and 20 characters long.",
    };
  }

  const validStr = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$!";
  const charArray = inputPassword;

  for (let i = 0; i < strLen; i++) {
    if (validStr.indexOf(charArray[i]) === -1) {
      return {
        status: "F",
        message:
          "Password should be alphanumeric value with one upper case and have atleast one special character(@#$!)",
      };
    }
  }

  const PATTERN_1 = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,20}$/;
  if (!PATTERN_1.test(inputPassword)) {
    return {
      status: "F",
      message:
        "Password should be alphanumeric value with one upper case and have atleast one special character(@#$!)",
    };
  }

  //below regex pattern checks that the password should have atleast one special character and one capital letter and should be alphanumeric and cannot have 2 consecutive special charcters
  // var pattern = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*[^A-Za-z0-9]{2}).*/;
  // if (!pattern.test(inputPassword)) {
  //   return {
  //     status: "F",
  //     message:
  //       "Password should have atleast one special character, one capital letter, should be alphanumeric and cannot have 2 or more consecutive special charcters",
  //   };
  // }

  if (inputPassword.includes("@@") || inputPassword.includes("--")) {
    return {
      status: "F",
      message: "2 consecutive special charcters are not allowed",
    };
  }
  return {
    status: "S",
    message: "Success",
  };
}
