import React, { useEffect } from "react";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import PaymentSuccess from "../../../assets/images/click2remit/Paymentsuccess.svg";
// import icicilogo from "../../../assets/images/click2remit/icici-logo.png";
import { useLocation, useNavigate } from "react-router-dom";
import { BankAccountAPI } from "../../../apis/BankAccountAPI";
import useHttp from "../../../hooks/useHttp";
import { useSelector } from "react-redux";

const BeneAddSuccess = (props) => {
  const { state } = props;
  const location = useLocation();
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);
  const hookBankAccountList = useHttp(BankAccountAPI.bankAccountList);

  const checkRemitterAccount = () => {
    props.setState({ activeStepForm: 13 });
    // if (location?.state?.benificary) {
    //   navigate("/new-transaction");
    // } else {
    //   const payload = {
    //     requestType: "SENDERACCOUNTLIST",
    //     userId: AuthReducer.userID,
    //     fulName: AuthReducer.userFullName,
    //     countryCode: "US",
    //     favouriteFlag: "1",
    //     startIndex: "0",
    //     recordsPerRequest: "",
    //   };
    //   hookBankAccountList.sendRequest(payload, function (data) {
    //     if (data.status == "S") {
    //       navigate("/new-transaction");
    //     } else {
    //       props.setState({ activeStepForm: 13 });
    //     }
    //   });
    // }
  };
  return (
    <div className="container h-100">
      <div className="row h-100">
        <form>
          <div className="col-md-6 col-sm-12 col-lg-6 offset-md-3 align-self-center">
            <div className="CR-otp-form">
              <ul className="row">
                <li className="back-arrow-nav   d-xs-block d-done">
                  <img src={BackArrow} alt="" />
                </li>
                <li className="text-center">
                  <img src={PaymentSuccess} style={{ marginBottom: "30px" }} alt="" />
                </li>
                <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                  <h4 className="text-black text-center">Beneficiary added!</h4>
                </li>
                <li className="col-md-12 col-sm-12 col-lg-12">
                  <p className="text-center">New Beneficiary has been successfully added.</p>
                </li>
                <li className="col-md-12">
                  <ul className="text-center bg-rec-blue">
                    <li>
                      <h5 className="text-black ">
                        {`${state.beneficiaryDetails.firstName} ${
                          state.beneficiaryDetails.middleName
                            ? state.beneficiaryDetails.middleName
                            : ""
                        } ${state.beneficiaryDetails.lastName}`}{" "}
                      </h5>
                    </li>
                    <li>
                      <label className="font-10">NickName </label>
                      <p className="font-14 ">{state.beneficiaryDetails.nickname}</p>
                    </li>
                    <li>
                      <h6 className="text-black">
                        {" "}
                        {/* <img className="" src={icicilogo} height="24px" width="24px" alt="" /> */}
                        {state?.beneficiaryBankDetails?.bankName?.value}
                      </h6>
                      <p className="font-14 m-0">Savings • {state?.beneBankAndAcctNo?.accountNo}</p>
                    </li>
                  </ul>
                </li>
              </ul>

              <div className="bottom_panel">
                <div className="d-flex justify-content-between align-items-baseline">
                  <button
                    type="button"
                    className="btn btn-primary CR-primary-btn mb-3"
                    onClick={() => {
                      if (location.pathname === "/add-beneficiary") {
                        if (location?.state?.autoFill) {
                          navigate("/new-transaction", {
                            state: {
                              autoFillData: {
                                ...location?.state?.autoFillData,
                                recipient: state.autofillRecv,
                              },
                              autoFill: location?.state?.autoFill,
                            },
                          });
                        } else {
                          navigate("/my-beneficiary");
                        }
                      } else {
                        checkRemitterAccount();
                        // navigate("/new-transaction")
                      }
                    }}
                  >
                    Proceed
                  </button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BeneAddSuccess;
