import Main from "../Layouts/Main";

const InvalidOTPModal = () => {
  return(
    <>
      <div class="modal CR-OTP-modal  fade show" tabindex="-1">
        <div class="modal-dialog-centered " style={{margin:"0 auto", maxWidth:"500px"}}>
          <div class="modal-content">
            <div class="modal-body CR-OTP-modal-container">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              <h5>Invalid Otp</h5>
              <p class="error">This is you final attempt</p>
              <p>You have 2 attempts remaining. After which, you will not be able to sign in for 180 mins.</p>
              <div class="btn-modal-wrapper">
                <a href="#!" class="modal-btn">
                  {" "}
                  Got It
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-backdrop fade show"></div>
    </>
  );
};
export default InvalidOTPModal;
