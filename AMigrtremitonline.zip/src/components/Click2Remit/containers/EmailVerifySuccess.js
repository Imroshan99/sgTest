import React, { useEffect, useReducer, useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import PaymentSuccess from "../../../assets/images/click2remit/Paymentsuccess.svg";
import useHttp from "../../../hooks/useHttp";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { useLocation, useNavigate } from "react-router-dom";
import { notification } from "antd";
import PymentFailedsvg from '../../../assets/images/click2remit/Payment failed.svg';
import Spinner from "../../../reusable/Spinner";

const EmailVerifySuccess = () => {
  const hookVerifyEmailLink = useHttp(ProfileAPI.emailVerificationLink);

  const navigate = useNavigate();
  const location = useLocation();
  const [loader, setLoader] = useState(0);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    apiMessage: "",
    _stepBox:0,
  });
  useEffect(() => {
    setLoader((prevState) => prevState + 1);
    const queryParams = new URLSearchParams(location.search);
    const tokenID = queryParams.get("uid");
    let payload = {
      requestType: "VERIFICATIONEMAIL",
      verificationToken: tokenID,
      emailVeriFlag: true,
    };    
    hookVerifyEmailLink.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status == "S") {
        notification.success({
          message: data.message,
        });
        setState({apiMessage:data.message,_stepBox:1});
      } else {
        setState({apiMessage:data.errorMessage,_stepBox:2});
        notification.error({ message: data.errorMessage });
      }
    });
  }, []);
  return (
    <Main sidebar={false}>
      <div className="container h-100">
        <div className="row h-100">
          <form>
            <div className="col-md-6 col-sm-12 col-lg-6 offset-md-3 align-self-center">
              <div className="CR-otp-form">
                <Spinner spinning={loader === 0 ? false : true}>
                {state._stepBox===1 && <ul className="row">
                  <li className="back-arrow-nav d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>
                  <li className="text-center">
                    <img src={PaymentSuccess} style={{ marginBottom: "30px" }} alt="" />
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                    <h4 className="text-black text-center">Email Verification Successful</h4>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <p className="text-center">{state.apiMessage}</p>
                  </li>
                  <button onClick={()=>{navigate("/signin")}} className="btn btn-primary CR-primary-btn mb-3"
                  // style={{ width: "100px", margin: "0 !important" }}
                  >Go to Sign in</button>
                </ul>}
                {state._stepBox===2 && (<ul className="row">
                  <li className="back-arrow-nav d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>
                  <li className="text-center">
                    <img src={PymentFailedsvg} style={{ marginBottom: "30px" }} alt="" />
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                    <h4 className="text-black text-center">Email Verification Unsuccessful</h4>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <p className="text-center">{state.apiMessage}</p>
                  </li>
                  <button onClick={()=>{navigate("/")}} className="btn btn-primary CR-primary-btn  mb-3"
                  // style={{ width: "100px", margin: "0 !important" }}
                  >Go to Home</button>
                </ul>)}
                </Spinner>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Main>
  );
};

export default EmailVerifySuccess;
