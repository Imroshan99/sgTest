import VerifyEmailSvg from "../../../assets/images/click2remit/verify-email.svg";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import Main from "../Layouts/Main";
export default function VerifyEmail() {
  return (
    <Main>
        <div className="container h-100">
          <div className="row h-100">
            <div className="col-md-6 col-sm-12 col-lg-6 offset-md-3 align-self-center">
              <div className="CR-otp-form">
                <ul className="row d-flex flex-column align-items-center">
                  <li className="back-arrow-nav d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>
                  <li className="text-center">
                    <img
                      src={VerifyEmailSvg}
                      style={{ marginBottom: "30px" }}
                      alt=""
                    />
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                    <h4 className="text-black text-center">
                      Verify your email
                    </h4>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <p className="text-center">
                      An email has been sent to johndoe@email.com with a link to
                      verify your account.
                    </p>
                  </li>
                </ul>

                <div className="bottom_panel">
                  <div className="d-flex justify-content-between align-items-center">
                    <div
                      thref="#!"
                      className="Back_arrow d-flex align-items-center"
                    >
                      <img src={BackArrow} alt="" /> Back
                    </div>
                    <button
                      type="button"
                      className="btn btn-primary CR-primary-btn"
                      style={{ width: "100px", margin: "0 !important" }}
                    >
                      Confirm
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </Main>
  );
}
