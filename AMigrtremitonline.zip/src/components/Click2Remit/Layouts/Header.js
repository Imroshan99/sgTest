import { MenuOutlined } from "@ant-design/icons";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import { useSelector } from "react-redux";
import c2r_logo_via from "../../../assets/images/click2remit/C2R_via_logo.png";
import c2r_logo from "../../../assets/images/click2remit/C2R_logo_pre1.png";
import UserMenu from "../user/UserMenu";
import { useContext, useEffect, useState } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { MenuContext } from "../Context/MenuContext";

export default function Header(props) {
  const _menuContext = useContext(MenuContext);
  const navigate = useNavigate();
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);

  const [anchorElUser, setAnchorElUser] = useState(null);

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleCloseUserMenu = (e) => {
    setAnchorElUser(null);
    if (e === "Logout") {
      window.location.href = "/";
    }
  };

  const [dt, setDt] = useState(new Date());
  useEffect(() => {
    setDt(new Date());
  }, []);

  console.log("_menuContext.isVisible", _menuContext.isVisible);
  const onLogoClickHandler=()=>{
    if(!AuthReducer.isLoggedInDone){
      location.pathname == "/"
      ? window.location.reload()
      : AuthReducer.isLoggedIn
      ? navigate("/new-transaction")
      : navigate("/");
    }else{
    }
  }
  return (
    <>
      <header className="px-4  bg-white  sticky-top">
        <nav className="navbar navbar-default">
          <div className="container-fluid">
            <div className="navbar-header">
              <span
              onClick={onLogoClickHandler}
                className="navbar-brand"
              >
                {AuthReducer.sendCountryCode === "US" ? (
                  <img
                    className="img-responsive"
                    src={c2r_logo_via}
                    alt="Click 2 Remit"
                    width="300px"
                  />
                ) : (
                  <img
                    className="img-responsive"
                    src={c2r_logo}
                    alt="Click 2 Remit"
                    width="300px"
                  />
                )}
              </span>
            </div>

            <p className="CR-linktext mb-0 CR-font-14">
              {/* <div>My subheader {dt.toISOString()}</div> */}
              {AuthReducer.isLoggedIn ? (
                <>
                  <div
                    className="cr_mobile_menu"
                    onClick={() => {
                      _menuContext.toggleMenu(!_menuContext.isVisible);
                    }}
                  >
                    <MenuOutlined />
                  </div>
                  {/* <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                  <Avatar
                    alt={AuthReducer.userFullName}
                    // {...stringAvatar(AuthReducer.userFullName)}
                  >
                    <PermIdentityOutlinedIcon />
                  </Avatar>
                </IconButton>
                <UserMenu anchorElUser={anchorElUser} handleCloseUserMenu={handleCloseUserMenu} /> */}
                </>
              ) : (
                <>
                  <span
                    onClick={() => {
                      navigate("/help-support", { state: { sidebar: false } });
                    }}
                    className="CR-blue-link CR-font-12 me-2"
                  >
                    CONTACT US
                  </span>{" "}
                  {location.pathname !== "/create-account" && (
                    <>
                      |
                      <Link to="/create-account" className="CR-blue-link CR-font-12 mx-2">
                        SIGN UP
                      </Link>
                    </>
                  )}
                  {location.pathname !== "/signin" && (
                    <>
                      | <span className=" ms-2">Already have an account? </span>
                      <Link to="/signin" className="CR-blue-link CR-font-12 mx-2">
                        | SIGN IN
                      </Link>
                    </>
                  )}
                </>
              )}
            </p>
          </div>
        </nav>
      </header>

      <Outlet />
    </>
  );
}
