import c2r_logo_via from "../../../assets/images/click2remit/C2R_via_logo.png";

import { useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import ViaFooter from "./ViaFooter";
import { useEffect, useState } from "react";
import KotakFooter from "./KotakFooter";

export default function Footer(props) {
  const AuthReducer = useSelector((state) => state.user);
  const navigate = useNavigate();
  return (
    <>
      <footer
        style={{ backgroundColor: "#ECECEC" }}
        className={`CR-footer ${AuthReducer.isLoggedIn ? "footer-postlogin" : ""}`}
      >
        <div class="container p-4">
          {AuthReducer.sendCountryCode === "" && <KotakFooter />}
          {AuthReducer.sendCountryCode === "US" && <ViaFooter />}
        </div>

        {/* <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
          © 2020 Copyright:
          <a class="" href="https://mdbootstrap.com/">
            MDBootstrap.com
          </a>
        </div> */}
      </footer>
    </>
  );
}
