import React, { useState, useReducer, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Form, Input, notification, Spin } from "antd";
import { config } from "../../../config";
import { AuthAPI } from "../../../apis/AuthAPI";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";
import useHttp from "../../../hooks/useHttp";
import Back_arrow from "../../../assets/images/click2remit/Back_arrow.svg";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import Spinner from "../../../reusable/Spinner";
import { GuestAPI } from "../../../apis/GuestAPI";
import { Col, Row } from "react-bootstrap";
import logoRefreshCode from "../../../assets/images/svg/refreshCaptchaDark.svg";

function SetNewPassword(props) {
  const ConfigReducer = useSelector((state) => state);
  let navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [captchaID, setCaptchaID] = useState();
  const [captchaImg, setCaptchaImg] = useState();
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: ConfigReducer.clientId,
    groupId: ConfigReducer.groupId,
    twofa: ConfigReducer.twofa,
    sessionId: ConfigReducer.sessionId,
  });

  const hookResetPassword = useHttp(AuthAPI.resetPassword);
  const hookgetCaptcha = useHttp(GuestAPI.getCaptcha);
  const hookVerifyCaptcha = useHttp(GuestAPI.verifyCaptcha);
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    // alert(props.state.activeTab)
    getCaptcha();
  }, []);
  const getCaptcha = () => {
    let payload = {
      requestType: "GETCAPTCHA",
    };
    setLoader(true);
    hookgetCaptcha.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        setCaptchaID(data.id);
        setCaptchaImg(data.captchaImage);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const saveSignUpData = (value) => {
    form.setFields([{ name: "password", errors: [] }]);
    let captchaPayload = {
      requestType: "VERIFYCAPTCHA",
      id: captchaID,
      captchaResponse: value.captcha,
      emailId: props.state.emailId,
    };
    setLoader(true);
    hookVerifyCaptcha.sendRequest(captchaPayload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        const resetPasswordPayload = {
          requestType: "RESETPASSWORD",
          password: value.password,
          verifyType: "O",
          verifiedToken: props.state.verifiedToken,
        };

        setLoader(true);
        hookResetPassword.sendRequest(resetPasswordPayload, function (data) {
          setLoader(false);
          if (data.status == "S") {
            notification.success({ message: data.message });
            navigate("/signin");
          } else {
            notification.error({ message: data.errorMessage });
            let errors = [];
            data.errorList.forEach((error, i) => {
              if (error.field != "password") {
                notification.error({ message: error.error });
              }
              let errorData = {
                name: error.field,
                errors: [error.error],
              };
              errors.push(errorData);
            });

            if (errors.length > 0) form.setFields(errors);
          }
        });
      } else {
        form.setFieldsValue({ captcha: "" });
        form.setFields([{ name: "captcha", errors: ["Incorrect Captcha"] }]);
        getCaptcha();
      }
    });
  };

  return (
    <div className="container h-100 d-flex justify-content-center w-100">
      <Spinner spinning={loading}>
        <Form form={form} onFinish={saveSignUpData}>
          <div className="CR-otp-form-parent" style={{ minHeight: "0px" }}>
            <div className="CR-otp-form-child">
              <ul className="row d-flex flex-column align-items-center">
                <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                  <h4 className="text-black text-center">Set New Password</h4>
                </li>
                <li className="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="password"
                    label="Password"
                    type="text"
                    validationRules={[
                      {
                        min: 10,
                        max: 20,
                        message: "Password should be between 10 and 20 characters long.",
                      },
                    ]}
                    required
                  >
                    <FloatInput type="password" placeholder="Password" />
                  </CustomInput>
                </li>
                <li className="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="confirmPassword"
                    label="Confirm Password"
                    type="text"
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          if (!value || getFieldValue("password") === value) {
                            return Promise.resolve();
                          }
                          return Promise.reject("The two password that you entered do not match!");
                        },
                      }),
                    ]}
                    required
                  >
                    <FloatInput type="password" placeholder="Confirm Password" />
                  </CustomInput>
                </li>
                <Row className="mb-3">
                  <Col>
                    <img src={`data:image/jpeg;base64,${captchaImg}`} alt="captcha" />
                  </Col>
                  <Col className="d-flex align-items-center">
                    <div className="d-flex" style={{ cursor: "pointer" }} onClick={getCaptcha}>
                      <img src={logoRefreshCode} className="me-2" alt="refresh" />
                      {/* <ReloadOutlined /> */}
                      <p style={{ color: "black !important" }} className="mb-0 fw-600">
                        Refresh Code
                      </p>
                    </div>
                  </Col>
                </Row>
                <li className="col-md-12 col-sm-12 col-lg-12">
                  <CustomInput
                    showLabel={false}
                    name="captcha"
                    label="Captcha"
                    type="text"
                    required
                  >
                    <FloatInput placeholder="Captcha" />
                  </CustomInput>
                </li>
              </ul>
            </div>
            <div className="bottom_panel">
              <div className="d-flex justify-content-between align-items-center gap-3 gap-md-5">
                <div
                  className="Back_arrow d-flex align-items-center"
                  onClick={() =>
                    props.setState({
                      _isShowOTPBOX: true,
                      _isShowSuccessMessage: false,
                      _setNewPasswordBOX: false,
                    })
                  }
                >
                  <img src={Back_arrow} alt="backArrow" /> Back
                </div>
                <button htmlType="submit" style={{ maxWidth: "17rem" }} className="CR-primary-btn">
                  Submit
                </button>
              </div>
            </div>
          </div>
        </Form>
      </Spinner>
    </div>
  );
}

export default SetNewPassword;
