import React, { useState } from "react";
import Main from "../Layouts/Main";
import Chevronright from "../../../assets/images/click2remit/Chevronright.svg";
import emailsvg from "../../../assets/images/click2remit/email.svg";
import emailussvg from "../../../assets/images/click2remit/emailUs.svg";
import contactussvg from "../../../assets/images/click2remit/contactUs.svg";
import callsvg from "../../../assets/images/click2remit/call.svg";
import helpsvg from "../../../assets/images/click2remit/help.svg";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
const HelpSupport = () => {
  const location = useLocation();
  const [show, setShow] = useState(false);
  const [email, setEmail] = useState(false);
  const [faq, setFaq] = useState(false);
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);

  return (
    <Main sidebar={location?.state?.sidebar}>
      <div className="container h-100">
        <div className="row h-100 justify-content-center">
          <form>
            <div className={`align-self-center col-lg-7 col-md-7 col-sm-12  ${AuthReducer.isLoggedIn ? "":"mx-auto"} ` } style={{marginRight:"auto"}}>
              <div  className={`CR-default-box ${AuthReducer.isLoggedIn ?"CR-max-width-620":"ContactUs"}`}>
                <ul className="row CR-side-space">
                  <li className="back-arrow-nav d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>

                  <li className="col-md-12 col-sm-12 col-lg-12 ">
                    <h4 className="text-black CR-font-28 mb-1">Help and support</h4>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <p className="text-left">
                      You can reach a Kotak Click2Remit representative by phone, email or request a
                      call back from us using the Click2Call facility.
                    </p>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <ul className="row">
                      <li
                        onClick={() => setShow(!show)}
                        style={{ cursor: "pointer" }}
                        className="col-md-12 col-sm-12 col-lg-12 my-2"
                      >
                        <div className="align-items-start d-flex justify-content-start w-100 single-box shadow-none">
                          <div className="CR-icon-24 me-3">
                            <img src={contactussvg} width="100%" height="100%" />
                          </div>
                          <div className="d-flex justify-content-between flex-column w-100">
                            <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                              Contact us
                            </label>
                            <p className="CR-font-14 text-left mb-0">Available (24x7)</p>
                          </div>
                          {/* {show === false ? (
                            <span onClick={() => setShow(true)} className="chevron-bottom">
                              <img src={Chevronright} width="24px" height="24px" />
                            </span>
                          ) : (
                            <span onClick={() => setShow(false)} className="chevron-bottom uparrow">
                              <img src={Chevronright} width="24px" height="24px" />
                            </span>
                          )} */}
                          {!show && (
                            <span className="chevron-bottom">
                              <img src={Chevronright} width="24px" height="24px" />
                            </span>
                          )}
                          {show && (
                            <span className="chevron-bottom uparrow">
                              <img src={Chevronright} width="24px" height="24px" />
                            </span>
                          )}
                        </div>
                        {show && (
                          <div className="CR-margin-left">
                            <div
                              onClick={() => {
                                window.location.href = `tel:02266053825`;
                              }}
                              style={{ cursor: "pointer" }}
                              className="align-items-start d-flex justify-content-between w-100 sub-single-box"
                            >
                              <div className="d-flex justify-content-between flex-column CR-w-80">
                                <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                                  02266053825
                                </label>
                                {/* <p className="CR-font-14 text-left mb-0 CR-sub-text CR-opactiy-60">
                                  India (Local charges may apply)
                                </p> */}
                              </div>
                              <span>
                                <img src={callsvg} width="30px" height="30px" />
                              </span>
                            </div>
                            {/* <div className="align-items-start d-flex justify-content-between w-100 sub-single-box">
                              <div className="d-flex justify-content-between flex-column CR-w-80">
                                <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                                  +91 22 6600 6022
                                </label>
                                <p className="CR-font-14 text-left mb-0 CR-sub-text CR-opactiy-60">
                                  International
                                </p>
                              </div>
                              <span>
                                <img src={callsvg} width="30px" height="30px" />
                              </span>
                            </div> */}
                          </div>
                        )}
                      </li>
                      <li
                        onClick={() => setEmail(!email)}
                        style={{ cursor: "pointer" }}
                        className="col-md-12 col-sm-12 col-lg-12 my-2"
                      >
                        <div className="align-items-start d-flex justify-content-start w-100 single-box shadow-none">
                          <div className="CR-icon-24 me-3">
                            <img src={emailussvg} width="100%" height="100%" />
                          </div>
                          <div className="d-flex justify-content-between flex-column w-100 ">
                            <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                              Email us
                            </label>
                            <p className="CR-font-14 text-left mb-0">
                              Send your queries to our email ID
                            </p>
                          </div>
                          {!email && (
                            <span className="chevron-bottom">
                              <img src={Chevronright} width="24px" height="24px" />
                            </span>
                          )}
                          {email && (
                            <span className="chevron-bottom uparrow">
                              <img src={Chevronright} width="24px" height="24px" />
                            </span>
                          )}
                        </div>
                        {email && (
                          <div className="CR-margin-left">
                            <div
                              onClick={() => {
                                window.location.href = `mailto:click2remit@kotak.com`;
                              }}
                              className="align-items-start d-flex justify-content-between w-100 sub-single-box"
                            >
                              <div className="d-flex justify-content-between flex-column CR-w-80">
                                <span className="CR-font-16 CR-black-text CR-fw-600 text-left">
                                  click2remit@kotak.com
                                </span>
                              </div>
                              <span>
                                <img src={emailsvg} width="30px" height="30px" />
                              </span>
                            </div>
                          </div>
                        )}
                      </li>
                      <li
                        onClick={() => setFaq(!faq)}
                        style={{ cursor: "pointer" }}
                        className="col-md-12 col-sm-12 col-lg-12 my-2"
                      >
                        <div className="align-items-start d-flex justify-content-start w-100 single-box shadow-none">
                          <div className="CR-icon-24 me-3">
                            <img src={helpsvg} width="100%" height="100%" />
                          </div>
                          <div className="d-flex justify-content-between flex-column w-100 ">
                            <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                              FAQs
                            </label>
                            <p className="CR-font-14 text-left mb-0">
                              Answer to frequently asked questions
                            </p>
                          </div>
                          {!faq && (
                            <span className="chevron-bottom">
                              <img src={Chevronright} width="24px" height="24px" />
                            </span>
                          )}
                          {faq && (
                            <span className="chevron-bottom uparrow">
                              <img src={Chevronright} width="24px" height="24px" />
                            </span>
                          )}
                        </div>

                        {faq && (
                          <div className="CR-margin-left">
                            <div className="align-items-start d-flex justify-content-between w-100 sub-single-box">
                              <div className="d-flex justify-content-between flex-column CR-w-80">
                                FAQs
                              </div>
                            </div>
                          </div>
                        )}
                      </li>
                    </ul>
                  </li>
               {AuthReducer.isLoggedIn &&    <div className="bottom_panel">
                          <div className="d-flex justify-content-between align-items-baseline">
                            <span className="Back_arrow" onClick={()=>navigate("/new-transaction")}>
                              <img src={BackArrow} alt="" />
                              Back
                            </span>
                          </div>
                        </div>}
                </ul>

                {/* <!-- <div className="bottom_panel">
                                    <div className="d-flex justify-content-between align-items-baseline">
                                        <a thref="#!" className="Back_arrow"> <img src="images/Back_arrow.svg" alt="">
                                            Back</a>
                                        <button type="button" className="btn btn-primary CR-primary-btn mb-3" style="width:100px;margin: 0!important;">Confirm
                                            </button>
                                    </div>
                                </div> --> */}
              </div>
            </div>
          </form>
        </div>
      </div>
    </Main>
  );
};

export default HelpSupport;
