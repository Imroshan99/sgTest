import { Col, Row } from "react-bootstrap";
import vianex from "../../../../../assets/images/click2remit/vianex.png";
import facebookRecpt from "../../../../../assets/images/click2remit/facebookRecpt.png";
import trustwave_certificate from "../../../../../assets/images/click2remit/trustwave-certificate.png";
import digicert_certificate from "../../../../../assets/images/click2remit/digicert-certificate.png";
import twitterRecpt from "../../../../../assets/images/click2remit/twitterRecpt.png";
import receipt_background from "../../../../../assets/images/click2remit/receipt_background.png";
import c2r_logo_via from "../../../../../assets/images/click2remit/C2R_via_logo.png";
import c2r_logo from "../../../../../assets/images/click2remit/C2R_logo_pre1.png";
import c2r_logo_r from "../../../../../assets/images/click2remit/c2r-logo-r.png";
import background_r from "../../../../../assets/images/click2remit/background_r.svg";
import footervilogo from "../../../../../assets/images/click2remit/footervialogo.png";
import moment from "moment";

const C2RInvoice = (props) => {
  const data = props?.txnReceiptDetail;
  let sendCountry = data?.sendCountry?.split("-");
  let recvCountry = data?.recvCountry?.split("-");
  let sendCountryCode = sendCountry[0];
  let sendCurrencyCode = sendCountry[1];
  let recvCountryCode = recvCountry[0];
  let recvCurrencyCode = recvCountry[1];
  return (
    <div
      ref={props.pdfRef}
      style={{
        position: "absolute",
        marginTop: "-2000px",
        height: "850px",
        width: "604px",
        backgroundColor: "red",
      }}
    >
      <div
        style={{
          fontFamily: '"avenir", Helvetica, Arial, sans-serif',
          height: "100%",
          lineHeight: "1.5",
          padding: 0,
          margin: 0,
          background: "#ECECEE",
        }}
      >
        <table
          cellPadding={0}
          cellSpacing={0}
          style={{
            background: "#ffffff",
            borderCollapse: "collapse",
            borderBottom: "5px solid #ffffff",
            height: "100%",
            margin: "0 auto",
            maxWidth: "600px",
            width: "100%",
          }}
        >
          <tbody>
            <tr>
              <td width={100}></td>
              <td width={300}></td>
              <td width={100}></td>
              <td width={100}></td>
            </tr>
            <tr>
              <td
                style={{
                  height: "100px",
                  backgroundColor: "#ECECEE",
                  border: "none",
                  width: "100%",
                  padding: "25px 1px",
                }}
                valign="top"
                colSpan={5}
              >
                <img
                  style={{ display: "block", textAlign: "center", width: "100%" }}
                  src={c2r_logo_r}
                />
              </td>
            </tr>
            <tr>
              <td
                style={{
                  backgroundColor: "#ffe0e2",
                  border: "none",
                  width: "100%",
                  padding: "15px 51px 15px",
                  color: "#331114",
                  fontSize: "14px",
                  lineHeight: "1.5",
                  height: "75px",
                }}
                valign="top"
                colSpan={5}
              >
                <p style={{ padding: 0, margin: 0 }}>
                  Dear <strong style={{ color: "#0c5fa3" }}>{data.customerName}</strong>,
                </p>
                <strong>Thank you for sending money with Viamericas.</strong>
              </td>
            </tr>
            <tr>
              <td
                style={{
                  background:
                    "transparent linear-gradient(288deg,#f73636,#f79498) 0 0 no-repeat padding-box",
                  border: "none",
                  width: "100%",
                  padding: "10px 51px",
                  color: "#ffffff",
                  fontSize: "14px",
                  lineHeight: "1.5",
                  height: "10px",
                }}
                valign="top"
                colSpan={5}
              >
                <p style={{ margin: 0, padding: 0, fontWeight: "bold" }}>
                  Transaction NO.:{" "}
                  <span style={{ fontWeight: "normal" }}>{data?.txnRefNumber}</span>
                </p>
              </td>
            </tr>
            <tr>
              <td
                style={{
                  backgroundColor: "#ececed",
                  border: "none",
                  width: "100%",
                  padding: "15px 51px",
                  color: "#331114",
                  fontSize: "14px",
                  lineHeight: 2,
                  height: "100px",
                }}
                valign="top"
                colSpan={5}
              >
                <h2
                  style={{
                    margin: "0 0 5px",
                    fontWeight: "bold",
                    textTransform: "uppercase",
                    color: "#0c5fa3",
                    fontSize: "18px",
                  }}
                >
                  Transaction Details
                </h2>
                <p style={{ margin: 0, padding: 0, fontWeight: "bold" }}>
                  Transaction Date:{" "}
                  {/* <span style={{ color: "#0c5fa3" }}>{data?.bookingDate?.split(" ")[0]}</span> */}
                  <span style={{ color: "#0c5fa3" }}>{moment(data?.bookingDate?.split(" ")[0]).format('DD-MM-YYYY')}</span>
                </p>
                <p style={{ margin: 0, padding: 0, fontWeight: "bold" }}>
                  Funds Available on:{" "}
                  {/* <span style={{ color: "#0c5fa3" }}>{data?.expDeliveryDate?.split(" ")[0]}</span>{" "} */}
                  <span style={{ color: "#0c5fa3" }}>{moment(data?.expDeliveryDate?.split(" ")[0]).format('MM-DD-YYYY')}</span>
                  {/* <span style={{ fontWeight: "normal" }}>/ Maybe available sooner</span> */}
                </p>
                <p style={{ margin: 0, padding: 0, fontWeight: "bold" }}>
                  Payer Network: <span style={{ color: "#0c5fa3" }}>Kotak Mahindra Bank Ltd.</span>
                </p>
                <p style={{ margin: 0, padding: 0, fontWeight: "bold" }}>
                Folio Number:  <span style={{ color: "#0c5fa3" }}>{data.viaFolio}</span>
                </p>
              </td>
            </tr>
            {/* <tr>
              <td
                style={{
                  backgroundColor: "#ececed",
                  border: "none",
                  width: "100%",
                  padding: "15px 51px",
                  color: "#331114",
                  fontSize: "14px",
                  lineHeight: "1.5",
                }}
                valign="top"
                colSpan={5}
              ></td>
            </tr> */}
            {/* <tr>
                      <td
                        style={{
                          width: "100%",
                          height:"10px",
                          backgroundColor: "transparent",
                          color: "#ffffff",
                          lineHeight: "1.5",
                          fontSize: "20px",
                          fontWeight: "bold",
                        }}
                        valign="top"
                        colSpan={5}
                      >
                        <div
                          style={{
                            backgroundColor: "#0c5fa3",
                            borderRadius: "6px",
                            color: "#ffffff",
                            textAlign: "center",
                            padding: "20px",
                            fontSize: "20px",
                            fontWeight: "bold",
                            letterSpacing: "1px",
                            margin: "0 auto",
                          }}
                        >
                          <a
                            href
                            style={{
                              textDecoration: "none",
                              color: "#ffffff",
                              backgroundColor: "#0c5fa3",
                              fontSize: "20px",
                              fontWeight: "bold",
                            }}
                          >
                            {" "}
                            Track your transaction
                          </a>
                        </div>
                      </td>
                    </tr> */}
            <tr>
                                  <td
                        style={{
                          border: "none",
                          padding: "20px 10px 0 30px",
                          width: "50%",
                          backgroundColor: "#ececed",
                          color: "#77777a",
                          fontSize: "14px",
                          lineHeight: "1.5",
                          // height: "100%",
                          height:"100px"
                        }}
                        valign="top"
                      >
                        <div style={{ backgroundColor: "#ececed", padding: "51px 20px" }}>
                          <h3
                            style={{
                              textTransform: "uppercase",
                              color: "#0c5fa3",
                              fontSize: "14px",
                              margin: "0 0 5px",
                            }}
                          >
                            Sender Information
                          </h3>
                          <strong>{data.customerName}</strong>
                          <p style={{ padding: 0, margin: 0, fontWeight: "normal" }}>
                            {data.customerAddress1}
                          </p>
                          <p style={{ padding: 0, margin: 0, fontWeight: "normal" }}>
                            {data.customerCity} - {data.customerState}
                          </p>
                          <p style={{ padding: 0, margin: 0, fontWeight: "normal" }}>
                            {data.customerMobileNo}
                          </p>
                          <p style={{ padding: 0, margin: 0, fontWeight: "normal" }}>
                            {data.sendCountry}
                          </p>
                        </div>
                      </td>
                      <td
                        style={{
                          border: "none",
                          padding: "20px 0 0 10px",
                          width: "50%",
                          backgroundColor: "#ececed",
                          color: "#77777a",
                          fontSize: "14px",
                          lineHeight: "1.5",
                          height: "100px",
                        }}
                        valign="top"
                      >
                        <div style={{ backgroundColor: "#ececed", padding: "51px 20px" }}>
                          <h3
                            style={{
                              textTransform: "uppercase",
                              color: "#0c5fa3",
                              fontSize: "14px",
                              margin: "0 0 5px",
                            }}
                          >
                            Recipient Information
                          </h3>
                          <strong>{data.receiverName}</strong>
                          <p style={{ padding: 0, margin: 0, fontWeight: "normal" }}>
                            {data.recvAddress}
                          </p>
                          <p style={{ padding: 0, margin: 0, fontWeight: "normal" }}>
                            {data.recvCity} - {data.recvState}
                          </p>
                          <p style={{ padding: 0, margin: 0, fontWeight: "normal" }}>
                            {data.recvMobileNo}
                          </p>
                          <p style={{ padding: 0, margin: 0, fontWeight: "normal" }}>
                            {data.recvCountry}
                          </p>
                        </div>
                      </td>
                    </tr>
            <tr style={{ backgroundImage: `url(${background_r})` }}>
              <td
                style={{
                  backgroundColor: "rgb(228 228 228 / 75%)",
                  border: "none",
                  width: "100%",
                  padding: "15px 51px",
                  color: "#331114",
                  fontSize: "14px",
                  lineHeight: "1.5",
                  height: "100% !important",
                }}
                valign="top"
                colSpan={5}
              >
                <p style={{ margin: 0, padding: 0, fontWeight: "bold", color: "#0c5fa3" }}>
                  Exchange Rate: 1 {sendCurrencyCode} = {data.exRate} {recvCurrencyCode}
                </p>
                <p style={{ margin: 0, padding: 0, fontSize: "18px", fontWeight: "bold" }}>
                  Transfer Amount:{" "}
                  <span style={{ color: "#0c5fa3" }}>
                    {data.amountPayable} {sendCurrencyCode}
                  </span>
                </p>
                <p style={{ margin: 0, padding: 0, fontSize: "18px", fontWeight: "bold" }}>
                  Transfer Amount to Recipient:{" "}
                  <span style={{ color: "#0c5fa3" }}>
                    {data.recvAmount} {recvCurrencyCode}
                  </span>
                </p>
              </td>
            </tr>
            {/* <tr>
              <td
                style={{ backgroundColor: "#ffffff", padding: "20px 0", border: "none" }}
                colSpan={5}
              />
            </tr> */}
          </tbody>
        </table>
        {/* fix for Gmail auto-resize */}
      </div>
    </div>
  );
};
export default C2RInvoice;
