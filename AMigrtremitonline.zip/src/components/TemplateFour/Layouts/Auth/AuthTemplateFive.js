import React from "react";
import signinRightImg from "../../../../assets/images/banners/signin-right-img.svg";

const AuthTemplateFive = (props) => {
  return (
    <div className="auth_temp5 container-fluid p-0 m-0 h-100">
      {/* {state._isShowOTPBOX && <OTPBox state={state} setState={setState} storeLoginData={storeLoginData} otpType={state.otpType} useFor="login" appState={props.appState} />} */}

      <div className="row m-auto  h-100">
        <div className="col-md-8  bg-signIn-image-mob-1">
          {/* bg-light text-dark shadow-md rounded   */}
          <div className="row h-100 justify-content-center align-items-center">
            <div className="col-12 col-md-6 col-xxl-4 ">
              <div className="card">
                <div class="card-body">{props.children}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-4   d-none d-md-block d-lg-block d-xl-block"></div>
      </div>
    </div>
  );
};

export default AuthTemplateFive;
