/* eslint-disable jsx-a11y/alt-text */
import { Card } from "react-bootstrap";

export default function DashboardBody(props) {
  
  return (
    <div className="main_section container ">
      <h1 className="page-title mb-3">{props.pageTitle}</h1>
      <Card className="w-100">
        <Card.Body>{props.children}</Card.Body>
      </Card>
    </div>
  );
}
