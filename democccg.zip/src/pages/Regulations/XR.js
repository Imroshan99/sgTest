import { Button } from "antd/lib/radio";


export default function Regulations() {
  return (
    <div>
      <p>
        XMonies is a remittance platform of XeOPAR Fintech Pvt Ltd. XeOPAR
        Fintech Pvt Ltd is registered with Ministry of Corporate Affairs (MCA) -
        India under Companies Act 2013 on 24 August 2014.
      </p>
      <p>
        <strong className="reg_title_color">
          Reserve Bank Of India (RBI) - India
        </strong>
      </p>
      <p>
        XeOPAR Fintech Pvt Ltd is authorized and has received FFMC License from
        RBI, India
      </p>
      <p>FFMC License Number: DEL.FFMC/849/2019</p>
      <p>
        <strong className="reg_title_color">
          Financial Conduct Authority - UK
        </strong>
      </p>
      <p>
        XeOPAR Fintech is an agent of Rational Foreign Exchange Limited,
        authorised by the Financial Conduct Authority (FRN: 507958) under the
        Payment
      </p>
      <p>Services Regulations 2017, for the provision of payment services.</p>
      <p>
        XeOPAR performs all the Money transfer activity in UK under its
        compliance partner - Rational Foreign Exchange Limited
      </p>
     
    </div>
  );
}
