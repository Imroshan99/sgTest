import React, {
  useEffect,
  useState,
  useReducer,
  Fragment,
  useLayoutEffect,
} from "react";
import "./App.css";
import Log from "./services/utility/log";
import { BrowserRouter as Router, useLocation } from "react-router-dom";
import { useIdleTimer } from "react-idle-timer";
import { useDispatch, useSelector } from "react-redux";
import "sweetalert2/src/sweetalert2.scss";
import "./assets/scss/home.scss";
import { GuestAPI } from "./apis/GuestAPI";
import Swal from "sweetalert2";
import { AuthAPI } from "./apis/AuthAPI";
import { config } from "./config";
import moment from "moment";
import jwt_decode from "jwt-decode";
import { GroupSettings } from "./GroupSettings";
import remit from "./services/remit";
import { encrypt, decrypt, publickey } from "./helpers/makeHash";
import useHttp from "./hooks/useHttp";
import log from "./services/utility/log";
import { getSessionStorage } from "./services/utility/storage";
import {
  setClientId,
  setGroupId,
  setGroupIdSettings,
  setIsLoggedIn,
  setPublicKey,
  setRecvCountryCode,
  setRecvCurrencyCode,
  setSendCountryCode,
  setSendCurrencyCode,
  setSessionId,
  setToken,
  setTokenExpiredAt,
  setTokenExpiredMinute,
  setTwofa,
  setUserId,
  setUserLastActivitiyAt,
} from "./reducers/userReducer";

// const TemplateTwo = React.lazy(() => import("./components/TemplateTwo"));
const TemplateFour = React.lazy(() => import("./components/TemplateFour"));

// disable consolelog for production
// console.log = function () {};

// import("./services/strings/KCB").then((math) => {
//   log.message(math.add(16, 26));
// });

function App(props) {
  var tokenInterval;
  const AuthReducer = useSelector((state) => state.user);
  const websiteSettings = useSelector((state) => state.user.groupIdSettings);

  const dispatch = useDispatch();

  const [isLoadGroupConfgAPI, setLoadGroupConfgAPI] = useState(false);
  const [groupConfigErrorMessage, setGroupConfigErrorMessage] = useState("");

  const [handleOnActionCount, setHandleOnActionCount] = useState(0);

  // const [state, setState] = useReducer(
  //   (state, newState) => ({ ...state, ...newState }),
  //   {
  //     userLastActivitiyAt: new Date(),
  //     publicKey: "",
  //     accessToken: "",
  //     isLoggedIn: false,
  //     tokenExpiredAt: new Date(),
  //     tokenExpiredMinute: 4,
  //   }
  // );

  const hookRefreshToken = useHttp(AuthAPI.refreshToken);

  useEffect(() => {
    if (websiteSettings) {
      // Disable right click
      document.addEventListener("contextmenu", (e) => {
        if (!websiteSettings.settings.rightClick) {
          e.preventDefault();
        }
      });

      // Disable select text
      document.addEventListener("selectstart", (e) => {
        if (!websiteSettings.settings.selectText) {
          e.preventDefault();
        }
      });
    }
  }, [websiteSettings]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(async () => {
    log.message("before service key func");
    // await getServiceKeyHandler();
    await getGroupConfigHandler();
    log.message("after group config");
  }, []);

  // Store Access Token when change
  // useEffect(() => {
  //   dispatch(setToken(state.accessToken));
  // }, [state.accessToken]);

  useEffect(() => {
    if (AuthReducer.isLoggedIn) {
      tokenInterval = setInterval(async function () {
        var end = moment(AuthReducer.userLastActivitiyAt); // expired time
        var start = moment(AuthReducer.tokenExpiredAt);
        if (end.diff(start, "minutes") == AuthReducer.tokenExpiredMinute) {
          let accessToken = await manageRefreshToken("USEEFFECT");
          log.message("call interval", accessToken);
        }
      }, 1000);

      if (!websiteSettings.settings.refreshPage) {
        const unloadCallback = (event) => {
          event.preventDefault();
          event.returnValue = "There is pending work. Sure you want to leave?";
          return "";
        };

        window.addEventListener("beforeunload", unloadCallback);
        return () => window.removeEventListener("beforeunload", unloadCallback);
      }
    }
  }, [AuthReducer.isLoggedIn]);

  //get Group Config from API
  const getGroupConfigHandler = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const demoCountry = urlParams.get("demo");
    let groupId = "CGPN";
    if (demoCountry !== null && demoCountry.toUpperCase() === "AE") {
      groupId = "HDFC";
    }
    const payloadGroupConfig = {
      url: remit.HOST,
    };

    await GuestAPI.groupConfig(payloadGroupConfig)
      .then((res_) => {
        const res = {
          status: 200,
          data: {
            clientId: groupId,
            groupId: groupId,
            colors: {
              "--bs-danger": "#dc3545",
              "--bs-warning": "#ffc107",
              "--bs-success": "#198754",
              "--bs-secondary": "#1f65a7",
              "--bs-light": "#f8f9fa",
              "--bs-dark": "#212529",
              "--bs-primary": "#173c79",
              "--bs-info": "#0dcaf0",
              "--bs-primary-rgb": "23, 60, 121",
              "--bs-primary-light": "#e3eeff",
            },
            twofa: false,
          },
        };
        if (res.status >= 200 && res.status <= 400) {
          if (res.data.groupId) {
            setGroupConfigErrorMessage("");

            if (res.data.colors != null) {
              for (var i = 0; Object.keys(res.data.colors).length > i; i++) {
                getComputedStyle(document.documentElement).getPropertyValue(
                  Object.keys(res.data.colors)[i]
                );
                document.documentElement.style.setProperty(
                  Object.keys(res.data.colors)[i],
                  res.data.colors[Object.keys(res.data.colors)[i]]
                );
              }
            }

            log.message("In Group Config func");
            saveConfig(res.data);
            setLoadGroupConfgAPI(true);
          } else {
            throw new Error("Group config not define.");
          }
        } else {
          throw new Error("CORS error");
        }
      })
      .catch((error) => {
        console.log("errrr =>", error.message);
        setGroupConfigErrorMessage(error.message);
      });
    // .catch((error) => log.message(error));
  };

  // Get Service Key from API
  const getServiceKeyHandler = async () => {
    await GuestAPI.serviceKey()
      .then((res) => {
        savePublicKey(res.data.key);
      })
      .catch((error) => log.message(error));
  };

  let isTokenRefreshing = false;

  const manageRefreshToken = async (callFrom = "DEFAULT") => {
    var end = moment(AuthReducer.tokenExpiredAt).add(
      AuthReducer.tokenExpiredMinute,
      "minutes"
    ); // expired time

    var start = moment(new Date());
    if (AuthReducer.isLoggedIn) {
      if (end.diff(start, "minutes") <= 1) {
        if (!isTokenRefreshing) {
          isTokenRefreshing = true;

          let refreshTokenData = {
            requestType: "REFRESHTOKEN",
            userId: AuthReducer.userID,
            token: AuthReducer.accessToken,
          };

          hookRefreshToken
            .sendRequest(refreshTokenData, function (res) {
              var jwtDecoded = jwt_decode(res.token);
              log.message("jwtDecoded.refreshAt", jwtDecoded.refreshAt);
              dispatch(setToken(res.token));
              dispatch(setTokenExpiredAt(new Date()));
              dispatch(setTokenExpiredMinute(jwtDecoded.refreshAt - 1));
              let newToken = res.token;
              isTokenRefreshing = false;
              log.message("return with new token", newToken);
              return newToken;
            })
            .catch((error) => {
              log.message(error);
              dispatch(setIsLoggedIn(false));
              clearInterval(tokenInterval);
              log.message("return clearInterval and no token");
              return false;
            });
        }
      } else {
        log.message("return with old token");
        return AuthReducer.accessToken;
      }
    } else {
      log.message("return with no token");
      return false;
    }
  };

  const manageAuth = (type, data) => {
    if (type === "logintoken") {
      //store this data in redux state

      var jwtDecoded = jwt_decode(data.token);
      dispatch(setToken(data.token));
      dispatch(setIsLoggedIn(true));
      dispatch(setTokenExpiredAt(new Date()));
      dispatch(setTokenExpiredMinute(jwtDecoded.refreshAt - 1));
    }
  };

  const handleOnIdle = (event) => {
    log.message("user is idle", "last active == " + getLastActiveTime());
    log.message("handle on idle triggered");
    if (AuthReducer.isLoggedIn) {
      Swal.fire({
        title: "Alert",
        text: "Your session has been expired.Please login again to continue.",
        icon: "warning",
        confirmButtonColor: "#2dbe60",
        allowOutsideClick: false,
        preConfirm: () => {
          if (AuthReducer.isLoggedIn) {
            window.location.href = "/signin";
            return false;
          }
        },
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = "/signin";
        }
      });
    }
  };

  const handleOnActive = (event) => {
    log.message("user is active", "time remaining == " + getRemainingTime());
  };

  const handleOnAction = async (event) => {
    log.message("handle on action triggered", event.type);
    var currentTime = new Date();

    dispatch(setUserLastActivitiyAt(currentTime));

    if (AuthReducer.isLoggedIn) {
      var end = moment(AuthReducer.tokenExpiredAt).add(
        AuthReducer.tokenExpiredMinute,
        "minutes"
      ); // expired time
      log.message("token exipire at ===>", end.format("HH.mm"));

      var start = moment(currentTime);
      log.message(
        "Differenc in handleONacton : ",
        end.diff(start, "minutes") + " " + start
      );
      log.message("Remaining seconds ===>", end.diff(start, "seconds"));
      if (end.diff(start, "minutes") <= 1) {
        if (handleOnActionCount === 0) {
          setHandleOnActionCount(1);
          var accessToken = await manageRefreshToken("handleOnAction");
          log.message("handleOnAction accessToken", accessToken);
          setTimeout(() => {
            setHandleOnActionCount(0);
          }, 5000);
        }
      }
    }
    // log.message('user did something', getRemainingTime())
  };

  const { getRemainingTime, getLastActiveTime } = useIdleTimer({
    timeout: 1000 * 60 * 9, //added 8 minute for idle 60 * 8
    onIdle: handleOnIdle,
    onActive: handleOnActive,
    onAction: handleOnAction,
    debounce: 500,
  });

  const saveConfig = (data) => {
    const dataGroupSeetings = GroupSettings[data.groupId];

    // for refesh page true
    if (dataGroupSeetings.settings.refreshPage) {
      dispatch(setUserId(getSessionStorage("userID")));
      dispatch(setIsLoggedIn(getSessionStorage("isLoggedIn")));
    }
    dispatch(setGroupIdSettings(dataGroupSeetings));
    dispatch(setClientId(data.clientId));
    dispatch(setGroupId(data.groupId));
    dispatch(setSendCountryCode(dataGroupSeetings.default.sendCountryCode));
    dispatch(setSendCurrencyCode(dataGroupSeetings.default.sendCurrencyCode));
    dispatch(setRecvCountryCode(dataGroupSeetings.default.recvCountryCode));
    dispatch(setRecvCurrencyCode(dataGroupSeetings.default.recvCurrencyCode));
    dispatch(setTwofa(data.twofa ? "Y" : "N"));
    // dispatch(setTwofa("Y"));
    dispatch(setSessionId(config.sessionId));
  };

  const savePublicKey = (pubKey) => {
    dispatch(setPublicKey(pubKey));
  };

  if (groupConfigErrorMessage !== "") {
    return (
      <>
        <h2 className="text-center mt-5">{groupConfigErrorMessage}</h2>
      </>
    );
  }
  if (isLoadGroupConfgAPI) {
    return (
      // basename="new-ui"
      <Router>
        <ScrollToTop />
        {/* {AuthReducer.groupIdSettings.template === "TEMPLATE_TWO" && (
          <TemplateTwo
            state={state}
            manageRefreshToken={manageRefreshToken}
            manageAuth={manageAuth}
          />
        )} */}
        {/* <button onClick={manageRefreshToken}>Refresh</button> */}
        {AuthReducer.groupIdSettings.template === "TEMPLATE_FOUR" && (
          <TemplateFour
            manageRefreshToken={manageRefreshToken}
            manageAuth={manageAuth}
          />
        )}
      </Router>
    );
  } else {
    return <Fragment></Fragment>;
  }
}

const ScrollToTop = function () {
  const { pathname } = useLocation();
  useLayoutEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "auto",
    });
  }, [pathname]);

  return null;
};

export default App;
