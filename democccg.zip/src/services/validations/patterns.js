/* eslint-disable no-template-curly-in-string */

import REGEX from "../../constants/REGEX";
import { VM__ONLY_ALPHABETS, VM__ONLY_ALPHANUMERIC, VM__ONLY_NUMBER_ALLOWED } from "../../constants/VALIDATION_MSG";

export const ONLY_NUMBER_ALLOWED_PATTERN = {
    pattern: REGEX.ONLY_NUMBER,
    message: VM__ONLY_NUMBER_ALLOWED,
};

export const ONLY_ALPHANUMERIC_PATTERN = {
    pattern: REGEX.ONLY_ALPHANUMERIC,
    message: VM__ONLY_ALPHANUMERIC,
};

export const ONLY_ALPHABETS_PATTERN = {
    pattern: REGEX.ONLY_ALPHABETS,
    message: VM__ONLY_ALPHABETS,
};