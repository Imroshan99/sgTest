/* eslint-disable no-template-curly-in-string */
//  "${label} Please enter only numeric values."
export const VM__ONLY_NUMBER_ALLOWED = "Please enter only numeric values.";
export const VM__ONLY_ALPHANUMERIC = "Only alphanumeric characters are allowed.";
export const VM__ONLY_ALPHABETS = "Only alphabets characters are allowed.";