const REGEX = {
    ONLY_NUMBER: /^[0-9\b]+$/,
    ONLY_ALPHABETS: /^[A-Z]+$/,
    ONLY_ALPHANUMERIC: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/, //Ex : ABC5565, 5655ASDFSD
    NO_SPECIAL_CHARS: /^[a-zA-Z0-9]+$/, //this allow only Ex: ABCxyz565
    VALID_PERSON_NAME: /^[A-Za-z. ]+$/, //this allow only Ex: Venu K. Verma
  };
  
  export default REGEX;