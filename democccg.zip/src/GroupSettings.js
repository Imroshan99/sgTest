export const GroupSettings = {
  XR: {
    title: "XMONIES",
    template: "TEMPLATE_FOUR",
    default: {
      sendModeCode: "CIP",
      programCode: "FER",
      sendCountryCode: "GB",
      sendCurrencyCode: "GBP",
      recvCountryCode: "",
      recvCurrencyCode: "",
    },
    theme: {
      favIcon: "", //favicon
      logo: "", // logo
      banner: "", //home page banner
      Auth: "AuthTemp1",
      Header: "Header4",
    },
    bankAccount: {
      addBankAccount: {
        flow: "FLOW1",
      },
      bankAccountList: {
        flow: "FLOW1",
      },
      viewBankDetails: {
        flow: "FLOW1",
      },
    },

    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      flow: "FLOW3",
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        flow: "FLOW2",
        columns: {
          // status: "DISABLED", //disable status column
        },
      },
      RecipientInfo: {
        flow: "FLOW2",
      },
      AddRecipientForm: {
        flow: "FLOW2",
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
        modal: {
          modal: true,
        },
      },
    },
    sendMoneyModule: {
      flow: "FLOW2",
      transactionList: {
        flow: "FLOW1",
      },
    },
    profileModule: {
      flow: "FLOW2",
      twoFA: "N",
      // addressApi : 'ADDRESSNOW',
      inputFields: {},
    },
    kyc: {
      flow: "FLOW2",
      inputFields: {
        ssn: { hidden: true },
      },
    },
    changePasswordForm: {
      flow: "FLOW2",
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    settings: {
      rightClick: true,
      selectText: true,
    },
  },

  ISG: {
    title: "ICICI Singapore Remit",
    template: "TEMPLATE_FOUR",
    default: {
      sendModeCode: "CIP",
      programCode: "FER",
      sendCountryCode: "SG",
      sendCurrencyCode: "SGD",
      recvCountryCode: "",
      recvCurrencyCode: "",
    },
    theme: {
      favIcon: "", //favicon
      logo: "", // logo
      banner: "", //home page banner
      Auth: "AuthTemp1",
      Header: "Header4",
    },

    bankAccount: {
      addBankAccount: {
        flow: "FLOW1",
      },
      bankAccountList: {
        flow: "FLOW1",
      },
      viewBankDetails: {
        flow: "FLOW1",
      },
    },

    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      flow: "FLOW3",
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        flow: "FLOW1",
        columns: {
          // status: "DISABLED", //disable status column
        },
      },
      RecipientInfo: {
        flow: "FLOW2",
      },
      AddRecipientForm: {
        flow: "FLOW2",
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
        modal: {
          modal: true,
        },
      },
    },
    sendMoneyModule: {
      flow: "FLOW2",
      transactionList: {
        flow: "FLOW1",
      },
      trackTransfer: {
        flow: "FLOW1",
      },
      repeatTranscation: {
        flow: "FLOW1",
      },
    },
    profileModule: {
      flow: "FLOW3",
      twoFA: "N",
      // addressApi : 'ADDRESSNOW',
      inputFields: {},
    },
    kyc: {
      flow: "FLOW2",
      inputFields: {
        ssn: { hidden: true },
      },
    },
    changePasswordForm: {
      flow: "FLOW1",
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    changeEmail: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    contact: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    feedback: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    raiseIssue: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    settings: {
      rightClick: true,
      selectText: true,
      refreshPage: false,
    },
  },

  CGPN: {
    title: "United Remit",
    template: "TEMPLATE_FOUR",
    default: {
      sendModeCode: "ACH",
      programCode: "FER",
      sendCountryCode: "US",
      sendCurrencyCode: "USD",
      recvCountryCode: "",
      recvCurrencyCode: "",
    },
    theme: {
      favIcon: "", //favicon
      logo: "", // logo
      banner: "", //home page banner
      Auth: "AuthTemp1",
      Header: "Header4",
    },

    bankAccount: {
      addBankAccount: {
        flow: "FLOW1",
      },
      bankAccountList: {
        flow: "FLOW1",
      },
      viewBankDetails: {
        flow: "FLOW1",
      },
    },

    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      flow: "FLOW3",
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        flow: "FLOW1",
        columns: {
          // status: "DISABLED", //disable status column
        },
      },
      RecipientInfo: {
        flow: "FLOW2",
      },
      AddRecipientForm: {
        flow: "FLOW2",
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
        modal: {
          modal: true,
        },
      },
    },
    sendMoneyModule: {
      flow: "FLOW3",
      transactionList: {
        flow: "FLOW1",
      },
      trackTransfer: {
        flow: "FLOW1",
      },
      repeatTranscation: {
        flow: "FLOW1",
      },
    },
    profileModule: {
      flow: "FLOW3",
      twoFA: "N",
      // addressApi : 'ADDRESSNOW',
      inputFields: {},
    },
    kyc: {
      flow: "FLOW3",
      inputFields: {
        ssn: { hidden: true },
      },
    },
    changePasswordForm: {
      flow: "FLOW1",
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    changeEmail: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    contact: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    feedback: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    raiseIssue: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    settings: {
      rightClick: true,
      selectText: true,
      refreshPage: false,
    },
    // proccessingPartner for sending country
    processingPartner: {
      US: "VIAMERICAS",
      AE: "LULU",
    },
  },

  HDFC: {
    title: "CSB Remit",
    template: "TEMPLATE_FOUR",
    default: {
      sendModeCode: "CIP",
      programCode: "FER",
      sendCountryCode: "US",
      sendCurrencyCode: "USD",
      recvCountryCode: "",
      recvCurrencyCode: "",
    },
    theme: {
      favIcon: "", //favicon
      logo: "", // logo
      banner: "", //home page banner
      Auth: "AuthTemp1",
      Header: "Header1",
    },

    bankAccount: {
      addBankAccount: {
        flow: "FLOW1",
      },
      bankAccountList: {
        flow: "FLOW1",
      },
      viewBankDetails: {
        flow: "FLOW1",
      },
    },

    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      flow: "FLOW3",
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        flow: "FLOW1",
        columns: {
          // status: "DISABLED", //disable status column
        },
      },
      RecipientInfo: {
        flow: "FLOW2",
      },
      AddRecipientForm: {
        flow: "FLOW2",
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
        modal: {
          modal: true,
        },
      },
    },
    sendMoneyModule: {
      flow: "FLOW3",
      transactionList: {
        flow: "FLOW1",
      },
      trackTransfer: {
        flow: "FLOW1",
      },
      repeatTranscation: {
        flow: "FLOW1",
      },
    },
    profileModule: {
      flow: "FLOW3",
      twoFA: "N",
      // addressApi : 'ADDRESSNOW',
      inputFields: {},
    },
    kyc: {
      flow: "FLOW1",
      inputFields: {
        ssn: { hidden: true },
      },
    },
    changePasswordForm: {
      flow: "FLOW1",
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    changeEmail: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    contact: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    feedback: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    raiseIssue: {
      flow: "FLOW1",
      acive: true,
      // inputFields: {
      //   ssn: { hidden: true },
      // },
    },
    settings: {
      rightClick: true,
      selectText: true,
      refreshPage: false,
    },
    // proccessingPartner for sending country
    processingPartner: {
      US: "VIAMERICAS",
      AE: "LULU",
    },
  },
};
