import React, { useEffect, useReducer, useState } from "react";

import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import { BankAccountAPI } from "../../../../apis/BankAccountAPI";
import moment from "moment";
import { Link, useLocation, useNavigate } from "react-router-dom";

import { achBankAccountAPI } from "../../../../apis/achBankAccountAPI";
import { Modal, notification } from "antd";
import { ViAmericaPlaidAPI } from "../../../../apis/ViAmericaApi/PlaidAPI";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { VIAmericaTransactionAPI } from "../../../../apis/ViAmericaApi/TranscationAPI";
import { getProcessingPartner } from "../../../../services/utility/group";
import { TransactionAPI } from "../../../../apis/TransactionAPI";

const Plaid = (props) => {
  const navigate = useNavigate();
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);
  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    bankAccountList: [],
    newBankAccountList: [],
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    emailId: "",
    callViaAddAchBnk: false,
  });
  const [redirectUrl, setRedirectUrl] = useState("");
  const [isPlaidModal, setIsPlaidModal] = useState(false);

  // const hookBankAccountList = useHttp(BankAccountAPI.bankAccountList);
  const hookBankAccountList = useHttp(achBankAccountAPI.bankAccountList);
  const hookGetAchAccountLists = useHttp(TransactionAPI.getAchAccountLists);
  const hookViaGetFundingAcct = useHttp(ViAmericaPlaidAPI.viaGetFundingAcct);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookCreateLinkToken = useHttp(ViAmericaPlaidAPI.createLinkToken);
  const hookAddBankAccount = useHttp(achBankAccountAPI.addBankAccount);
  const hookViaAddACHBankAccount = useHttp(VIAmericaTransactionAPI.ViaAddACHBankAccount);
  // const hookViewBankAccountDetails = useHttp(BankAccountAPI.viewBankAccountDetails);
  // const hookDeleteBankAccountDetails = useHttp(BankAccountAPI.deleteBankAccountDetails);

  useEffect(() => {
    accountsList();
    getUserProfile();
    // viaGetFundingAcct();
  }, []);
  useEffect(() => {
    if (state.callViaAddAchBnk) {
      ViaAddACHBankAccount();
    }
  }, [state.callViaAddAchBnk]);
  useEffect(() => {
    // Create IE + others compatible event handler

    var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
    var eventer = window[eventMethod];
    var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
    eventer(
      messageEvent,
      function (e) {
        if (e.data.data == "PLAID_FAIL") {
          setRedirectUrl("");
        } else if (e.data.data == "PLAID_SUCCESS") {
          setRedirectUrl("");
          // viaGetFundingAcct();
          // accountsList();
          setState({ callViaAddAchBnk: true });
        }
      },
      false
    );

    // setInterval(function() {
    //   console.log("parent received message!:  ", e.data);
    // },1000);
  }, []);
  const ViaAddACHBankAccount = () => {
    let payload = {
      requestType: "ADDVIAACHBANK",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      currencyCode: AuthReducer.sendCurrencyCode,
    };

    setLoader((prevState) => prevState + 1);
    hookViaAddACHBankAccount.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      props.setVisible(false);
      if (data.status === "S") {
        notification.success({ message: data.message });
        accountsList();
      } else {
        accountsList();
        if (!data.message && !data.errorMessage) {
          notification.error({
            message: "Via add ach bank account failed.",
          });
        }
      }
    });
  };
  const getUserProfile = async (cb) => {
    let payload = {
      requestType: "USERPROFILE",
      userId: AuthReducer.userID,
    };
    setLoader(true);
    hookGetProfile.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        setState({ emailId: data.emailId });
      }
    });
  };
  const viaGetFundingAcct = () => {
    const payload = {
      requestType: "GETFUNDINGACCOUNT",
      emailId: state.emailId,
      userId: state.userID,
      loginToken: window.sessionStorage.getItem("loginTokenId"),
      idSenderGlobal: window.sessionStorage.getItem("idSenderGlobal"),
    };
    setLoader(true);
    hookViaGetFundingAcct.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        // let demmy=[{
        //   BankName: "Chase",
        //   idPayment: "22129",
        //   LoginRequired: false,
        //   mask: "1111",
        //   name: "Plaid Saving"
        // }, {
        //   BankName: "Chase",
        //   idPayment: "22128",
        //   LoginRequired: false,
        //   mask: "0000",
        //   name: "Plaid Checking"
        // }]
        const bankList = JSON.parse(data.message);
        // bankList.forEach((dataV) => {
        //   addACHAccount(dataV);
        // });
        Promise.all(bankList.map((dataV) => addACHAccount(dataV))).then((data) => {
          // do something with the data
          alert("Done");
        });
        // addACHAccount(JSON.parse(data.message)[0]);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const addACHAccount = async (data) => {
    let formData = {
      requestType: "addACHAccount",
      userId: AuthReducer.userID,
      routingNumber: "000910000",
      nickname: `${data.name.replaceAll(" ", "").toUpperCase()}${data.mask}`, //BankName+maskAcctno
      accountHolder: data.name,
      bankName: data.BankName,
      accountNo: data.mask,
      accountType: "S",
      countryCode: AuthReducer.sendCountryCode,
      currencyCode: AuthReducer.sendCurrencyCode,
      processType: "ACH",
      idPayment: data.idPayment ? data.idPayment : "43200",
      // accountid: data.accountid,
      // public_token: data.accessToken,
    };
    setLoader(true);
    hookAddBankAccount.sendRequest(formData, function (res) {
      setLoader(false);
      // setIsModalVisible(false);
      if (res.status === "S") {
        notification.success({ message: res.message });
        accountsList();
      } else {
        // notification.error({ message: res.errorMessage });
      }
    });
  };

  // const accountsList = (nickName) => {
  //   const payload = {
  //     requestType: "SENDERACCOUNTLIST",
  //     userId: state.userID,
  //     countryCode: AuthReducer.sendCountryCode,
  //     favouriteFlag: "1",
  //     startIndex: "0",
  //     recordsPerRequest: "50",
  //   };
  //   setLoader(true);
  //   hookBankAccountList.sendRequest(payload, function (data) {
  //     setLoader(false);
  //     if (data.status === "S") {
  //       if (nickName) {
  //         let newBankAcct = data.responseData.filter((i) => {
  //           return i.nickName == nickName;
  //         });
  //         if (location?.state?.autoFill) {
  //           navigate("/new-transaction", {
  //             state: {
  //               autoFillData: {
  //                 ...location?.state?.autoFillData,
  //                 sourceAccount: newBankAcct[0].nickName,
  //               },
  //               autoFill: location?.state?.autoFill,
  //             },
  //           });
  //         }
  //       } else {
  //         let resData = [];
  //         data.responseData.forEach((detail, i) => {
  //           let data1 = {
  //             key: i,
  //             nickName: `${detail.nickName}`,
  //             aCHAccId: `${detail.aCHAccId}`,
  //             recordToken: `${detail.recordToken}`,
  //             bankName: `${detail.bankName}`,
  //             accountNo: `${detail.accountNo}`,
  //             routingNumber: `${detail.routingNumber}`,
  //             dateAdded: moment(detail.createdDate).format("MM-DD-YYYY"),
  //             status: detail.recordStatus.toUpperCase() === "R" ? "Verified" : "Pending",
  //           };
  //           resData.push(data1);
  //         });
  //         setState({
  //           bankAccountList: resData,
  //           newBankAccountList: resData,
  //         });
  //       }
  //     }
  //   });
  // };
  const accountsList = (nickName) => {
    let viaPayload={};
    if (getProcessingPartner(AuthReducer.sendCountryCode) === "VIAMERICAS") {
      viaPayload = {
        clientId: "VIAMERICAS",
        requestType:"VIAMERICAS"
      };
    }else{
      viaPayload = {
        requestType:"ACHACCOUNTLISTS"
      };
    }
    const payload = {
      ...viaPayload,
      // requestType: "ACHACCOUNTLISTS",
      countryCode: AuthReducer.sendCountryCode,
      startIndex: "0",
      recordsPerRequest: "15",
      // recvNickName: state.nickName,
      // statusFlag: "R",
      // isSameBank: "Y",
      userId: state.userID,
    };
    setLoader(true);
    hookGetAchAccountLists.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        if (nickName) {
          let newBankAcct = data.responseData.filter((i) => {
            return i.nickName == nickName;
          });
          // if (location?.state?.autoFill) {
          //   navigate("/new-transaction", {
          //     state: {
          //       autoFillData: {
          //         ...location?.state?.autoFillData,
          //         sourceAccount: newBankAcct[0].nickName,
          //       },
          //       autoFill: location?.state?.autoFill,
          //     },
          //   });
          // }
           navigate("/new-transaction", {
              state: {
                fromPageState: {
                  ...location?.state?.fromPageState,
                  sourceAccount: newBankAcct[0].nickName,
                }
              },
            });
        } else {
          let resData = [];
          data.responseData.forEach((detail, i) => {
            let data1 = {
              key: i,
              nickName: `${detail.nickName}`,
              aCHAccId: `${detail.aCHAccId}`,
              recordToken: `${detail.recordToken}`,
              bankName: `${detail.bankName}`,
              accountNo: `${detail.accountNo}`,
              routingNumber: `${detail.routingNumber}`,
              dateAdded: moment(detail.createdDate).format("MM-DD-YYYY"),
              status: detail.recordStatus.toUpperCase() === "R" ? "Verified" : "Pending",
            };
            resData.push(data1);
          });
          setState({
            bankAccountList: resData,
            newBankAccountList: resData,
          });
        }
      }
    });
  };
  const createLinkToken = () => {
    const payload = {
      requestType: "VIALINKTOKENCREATE",
      userId: AuthReducer.userID,
      emailId: state.emailId,
      method: "POST",
      loginToken: window.sessionStorage.getItem("loginTokenId"),
      idSenderGlobal: window.sessionStorage.getItem("idSenderGlobal"),
    };
    setLoader(true);
    hookCreateLinkToken.sendRequest(payload, function (res) {
      setLoader(false);
      if (res.status === "S") {
        setIsPlaidModal(true);
        setRedirectUrl(res.linkToken);
      } else {
        notification.error({ message: res.errorMessage });
      }
    });
  };
  return (
    <div className="text-center py-5">
      <button
        type="button"
        onClick={() => {
          createLinkToken();
        }}
        className="btn btn-secondary "
      >
        Connect with PLAID
      </button>

      {redirectUrl !== "" && (
        <Modal
          className="CR_jumio_modal"
          // width="auto"
          visible={isPlaidModal}
          footer={null}
          // closable={false}
          // maskClosable={false}
          // onOk={handleOk}
          onCancel={() => setIsPlaidModal(false)}
        >
          <iframe
            title="plaid"
            src={redirectUrl}
            width="100%"
            height="500px"
            allow="camera;fullscreen;accelerometer;gyroscope;magnetometer"
            allowfullscreen
          ></iframe>
        </Modal>
      )}
    </div>
  );
};

export default Plaid;
