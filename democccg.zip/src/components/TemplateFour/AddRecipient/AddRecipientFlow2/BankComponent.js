import { useSelector } from "react-redux";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Radio, Select, Space } from "antd";
import CustomInput from "../../../../reusable/CustomInput";
import {
    ONLY_ALPHABETS_PATTERN,
    ONLY_ALPHANUMERIC_PATTERN,
    ONLY_NUMBER_ALLOWED_PATTERN,
} from "../../../../services/validations/patterns";

const { Option } = Select;
const accountTypeObj = [
    {
        label: "Saving",
        value: "S",
    },
    {
        label: "Current",
        value: "C",
    },
];
export default function BankComponent(props) {
    const {
        getBankList,
        onChangeIFSCCode,
        onSelectBank,
        onSelectCity,
        onSelectBranch,
        state,
        setState,
        recvCountryCode,
    } = props;
    const ConfigReducer = useSelector((state) => state.user);
    const AddRecipientFormConfig =
        ConfigReducer.groupIdSettings.recipientModule.AddRecipientForm;
    const _recvCountryCode = recvCountryCode
        ? recvCountryCode
        : ConfigReducer.recvCountryCode;

    const getValidationPattern = (validation) => {
        if (validation === "N") return ONLY_NUMBER_ALLOWED_PATTERN;
        if (validation === "A") return ONLY_ALPHABETS_PATTERN;
        if (validation === "AN") return ONLY_ALPHANUMERIC_PATTERN;
    };

    const renderInputTypes = (data) => {
        if (data.columnName === "accountNo") {
            return (
                <div className="row">
                    <div className="col-12 col-md-6">
                        <CustomInput
                            className="form-item"
                            label={data.label}
                            showLabel={false}
                            name={data.columnName}
                            type="password"
                            placeholder={`Enter your ${data.label}`}
                            autoComplete="new-password"
                            min={parseInt(data.minLenth)}
                            max={parseInt(data.maxLenth)}
                            maxLength={parseInt(data.maxLenth)}
                            validationRules={[getValidationPattern(data.validation)]}
                            onPaste={(e) => {
                                e.preventDefault();
                                return false;
                            }}
                            onCopy={(e) => {
                                e.preventDefault();
                                return false;
                            }}
                            visibilityToggle={false}
                            required={data.isMandatory}
                        />
                    </div>
                    <div className="col-12 col-md-6">
                        <CustomInput
                            className="form-item"
                            label={`Confirm ${data.label}`}
                            showLabel={false}
                            name="accConNum"
                            type="text"
                            placeholder={`Enter your Confirm ${data.label}`}
                            maxLength={parseInt(data.maxLenth)}
                            required={data.isMandatory}
                            validationRules={[
                                ({ getFieldValue }) => ({
                                    validator(rule, value) {
                                        if (!value || getFieldValue(data.columnName) === value) {
                                            return Promise.resolve();
                                        }
                                        return Promise.reject(
                                            `The confirmed ${data.label} does not match the ${data.label} you entered.`
                                        );
                                    },
                                }),
                            ]}
                            onPaste={(e) => {
                                e.preventDefault();
                                return false;
                            }}
                            onCopy={(e) => {
                                e.preventDefault();
                                return false;
                            }}
                        />
                    </div>
                </div>
            );
        }
        if (data.columnName === "accountType") {
            return (
                <CustomInput
                    name={data.columnName}
                    className="form-item"
                    type="select"
                    label={data.label}
                    showLabel={false}
                    placeholder={`Select ${data.label}`}
                    labelInValue
                    required={data.isMandatory}
                >
                    {accountTypeObj.map((item) => (
                        <Option value={item.value}>{item.label}</Option>
                    ))}
                </CustomInput>
            );
        }

        if (data.columnName === "bankName") {
            return (
                <CustomInput
                    name={data.columnName}
                    className="form-item"
                    type="select"
                    label={data.label}
                    showLabel={false}
                    placeholder={`Select ${data.label}`}
                    labelInValue
                    onChange={onSelectBank}
                    required={data.isMandatory}
                >
                    {state.bankLists.map((bank, i) => {
                        return (
                            <Option key={i} value={bank.bankName}>
                                <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                                    {bank.bankName}
                                </span>
                            </Option>
                        );
                    })}
                </CustomInput>
            );
        }

        return (
            <CustomInput
                name={data.columnName}
                className="form-item"
                type="text"
                label={data.label}
                showLabel={false}
                placeholder={`Enter ${data.label}`}
                labelInValue
                min={parseInt(data.minLenth)}
                max={parseInt(data.maxLenth)}
                validationRules={[getValidationPattern(data.validation)]}
                // onChange={onSelectBank}
                required={data.isMandatory}
            />
        );
    };
    const renderBankFields = state.bankMappingLists.map((i) => {
        let col = i.columnName === "accountNo" ? "col-md-12" : "col-md-4";
        return (
            <>
                <div className={`col-12 ${col}`}>
                    <label className="form-label">
                        <span className="red_ast">*</span>
                        {i.label}
                    </label>
                    {renderInputTypes(i)}
                    {/* <Form.Item
            name={i.columnName}
            rules={[
              {
                required: i.isMandatory,
                message: `${i.label} is required`,
              },
              {
                min: Number(i.minLenth),
                max: Number(i.maxLenth),
                message: `${i.label} should be min ${i.minLenth} & max ${i.maxLenth}`,
              },
              getValidationPattern(i.validation),
            ]}
          >
            
            {/* {i.columnName == "accountType" ? (
                <>
                  <Select size="large" placeholder={i.label}>
                    <Option value={"S"}>Saving</Option>
                    <Option value={"C"}>Current</Option>
                  </Select>
                </>
              ) : (
                <Input size="large" placeholder={i.label} />
              )} */}
                    {/* </Form.Item> */}
                </div>
            </>
        );
    });

    if (_recvCountryCode === "NP_") {
        return (
            <>
                <Col md={3}>
                    <div className="">
                        <label className="form-label">
                            <span className="red_ast">*</span>Bank Name
                        </label>

                        <CustomInput
                            name="bankName"
                            className="form-item"
                            type="select"
                            label="Bank Name"
                            showLabel={false}
                            placeholder="Select Bank"
                            labelInValue
                            onChange={onSelectBank}
                            required
                        >
                            {state.bankLists.map((bank, i) => {
                                return (
                                    <Option key={i} value={bank.bankName}>
                                        <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                                            {bank.bankName}
                                        </span>
                                    </Option>
                                );
                            })}
                        </CustomInput>
                    </div>
                </Col>

                <Col md={3}>
                    <label className="form-label">
                        <span className="red_ast">*</span>Bank Code
                    </label>
                    <CustomInput
                        name="bankCode"
                        type="text"
                        className="form-item"
                        label="Bank Code"
                        showLabel={false}
                        placeholder="Bank Code"
                    />
                </Col>
            </>
        );
    }

    if (_recvCountryCode === "IN") {
        return (
            <>
                {AddRecipientFormConfig.recipientBankBranchRadio && (
                    <Col md={12}>
                        <label className="form-label">
                            <span className="red_ast">*</span>Receipent's bank Branch
                        </label>
                        <Form.Item className="form-item">
                            <Radio.Group name="isIFSC">
                                <Space direction="Horizontaly">
                                    <Radio
                                        value="Y"
                                        onClick={(e) => {
                                            setState({ isSelectedIFSC: true });
                                        }}
                                    >
                                        IFSC
                                    </Radio>
                                    <Radio
                                        value="N"
                                        onClick={() => {
                                            setState({ isSelectedIFSC: false });
                                            getBankList();
                                        }}
                                    >
                                        LOCATION
                                    </Radio>
                                </Space>
                            </Radio.Group>
                        </Form.Item>
                    </Col>
                )}

                {state.isSelectedIFSC ? (
                    <Col md={12}>
                        <div className="">
                            <label className="form-label">
                                <span className="red_ast">*</span>IFSC Code
                            </label>

                            <CustomInput
                                className="form-item"
                                label="Confirm Account Number"
                                showLabel={false}
                                name="IFSCCode"
                                type="text"
                                placeholder="Enter your IFSC Code"
                                min={11}
                                max={11}
                                maxLength={11}
                                onChange={onChangeIFSCCode}
                                required
                            />

                            <p className="text-primary">{state.bankAddress}</p>
                        </div>
                    </Col>
                ) : (
                    <>
                        <Col md={3}>
                            <div className="">
                                <label className="form-label">
                                    <span className="red_ast">*</span>Bank Name
                                </label>

                                <CustomInput
                                    name="banckName"
                                    className="form-item"
                                    type="select"
                                    label="Bank Name"
                                    showLabel={false}
                                    placeholder="Select Bank"
                                    labelInValue
                                    onChange={onSelectBank}
                                    required
                                >
                                    {state.bankLists.map((bank, i) => {
                                        return (
                                            <Option key={i} value={bank.bankName}>
                                                <span
                                                    bankCode={bank.bankCode}
                                                    isSameBank={bank.isSameBank}
                                                >
                                                    {bank.bankName}
                                                </span>
                                            </Option>
                                        );
                                    })}
                                </CustomInput>
                            </div>
                        </Col>
                        <Col md={3}>
                            <div className="">
                                <label className="form-label">
                                    <span className="red_ast">*</span>City
                                </label>
                                <CustomInput
                                    className="form-item"
                                    label="City"
                                    showLabel={false}
                                    type="select"
                                    name="cityName"
                                    placeholder="Select City"
                                    showSearch
                                    onChange={onSelectCity}
                                    required
                                >
                                    {state.cityLists.map((city, i) => {
                                        return (
                                            <Option key={i} value={city.city}>
                                                {city.city}
                                            </Option>
                                        );
                                    })}
                                </CustomInput>
                            </div>
                        </Col>
                        <Col md={3}>
                            <div className="">
                                <label className="form-label">
                                    <span className="red_ast">*</span>Branch
                                </label>

                                <CustomInput
                                    className="form-item"
                                    label="Branch"
                                    showLabel={false}
                                    type="select"
                                    name="branch"
                                    placeholder="Select Branch"
                                    showSearch
                                    onChange={onSelectBranch}
                                    required
                                >
                                    {state.branchLists.map((branch, i) => {
                                        return (
                                            <Option key={i} value={JSON.stringify(branch)}>
                                                {branch.branchName}
                                            </Option>
                                        );
                                    })}
                                </CustomInput>
                            </div>
                        </Col>
                        <Col md={3}>
                            <label className="form-label">
                                <span className="red_ast">*</span>Branch Code
                            </label>
                            <CustomInput
                                name="branchCode"
                                type="text"
                                className="form-item"
                                label="Branch Code"
                                showLabel={false}
                                readOnly={true}
                                placeholder="Branch Code"
                            />
                        </Col>
                    </>
                )}
            </>
        );
    }

    return <>{renderBankFields}</>;
}