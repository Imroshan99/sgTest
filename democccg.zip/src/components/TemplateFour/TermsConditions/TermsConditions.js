import React, { useEffect } from "react";
import { Link, useOutletContext } from "react-router-dom";

const TermsConditions = () => {
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Terms and Conditions");
  }, []);
  return (
    <div>
      <section className="section">
        <div className="container">
          <h5 className="mt-1 mb-3">Terms and Conditions</h5>
          <p className="text-3 text-muted">
            1.1. Please read the Terms and Conditions carefully. The access and use of the Website
            means that you agree to accept and abide by the Terms and Conditions. In case you do not
            agree to accept and abide by the Terms and Conditions, please do not access or use this
            Website or any pages thereof and please do not avail of any of the Facilities, products
            or services offered on or through the Website.
          </p>{" "}
          <p className="text-3 text-muted">
            1.2. ‘United Remit’ is a proprietary online remittance tracking channel of ‘United
            Remit’. and the term ‘United Remit’ appearing on the website and any other places refer
            to the online remittance offering of ‘United Remit’.
          </p>
          <p className="text-3 text-muted">
            {" "}
            1.3. Please note that by clicking on "Sign Up" it will be deemed that you have read and
            understood the Terms and Conditions and that you agree to accept and abide by the Terms
            and Conditions.
          </p>
          <p className="text-3 text-muted">
            {" "}
            1.4. ‘United Remit’, may in its discretion alter, add to or delete the Terms and
            Conditions from time to time without any prior notice but the same shall be communicated
            to you on best effort basis. It is also your responsibility to ensure that periodically
            on every occasion that you access or use the Website or any Facility, product or service
            displayed or offered on the Website that you return to this page and review the Terms
            and Conditions for any alterations, additions or deletions. Unless otherwise specified
            by ‘United Remit’ all alterations, additions and deletions shall take effect
            automatically and be binding on and from the day they are posted on the Website. By
            continuing to access or use the Website or any Facilities, products or services offered
            on the Website, you will be deemed to have agreed to accept and be bound by such
            altered, added to or deleted Terms and Conditions. If you do not agree to the
            alterations, additions or deletions, you should discontinue accessing or using the
            Website or availing of any Facilities, products or services on the Website (other than
            those which have already been availed of by you prior to such alterations, additions or
            deletions).{" "}
          </p>
          <p className="text-3 text-muted">
            1.5. I(We) hereby authorize ‘United Remit’, hereinafter called COMPANY(S), to initiate
            debit and credit entries to my(our) Checking/Savings Account at the depository financial
            institution, hereafter called DEPOSITORY, and to debit/credit the same to such account.
            I(We) acknowledge that the origination of ACH transactions to my(our) account must
            comply with the provisions of U.S. law.
          </p>
          <h5 className="mt-1 mb-3">2. DEFINITIONS AND INTERPRETATIONS:</h5>
          <p className="text-3 text-muted">
            2.1. In these Terms and Conditions (including the Introduction above), unless the
            context otherwise requires, the following words and phrases shall have the meanings
            assigned to them hereunder- - ‘United Remit’ Online" Means the online remittance
            tracking channel of ‘United Remit’ ‘United Remit’ means a company incorporated under the
            Companies Act 1997 carrying on the business remittance within meaning of Bank and
            Financial Institution Act, 2073 (2017)and Registered Office is located at Lalitpur 2,
            Chaudhary House, Sanepa, Lalitpur, Bagmati, Nepal. "Alerts" means notices relating to
            various matters issued or to be issued by ‘United Remit’. "Call Centre" means the call
            centre which may be set up by ‘United Remit’ or a Service Provider to assist Visitors in
            connection with the Website including the Facilities displayed or offered thereon and
            any transactions entered into or proposed to be entered into by the Visitors in respect
            of such Facilities. "Registered User" means any Visitor who avails of remittance
            facility from ‘United Remit’ by successfully completing the registration and creating a
            User ID. "Registered User account" means an online account created by the Registered
            User for availing for remittance tracking service. "Registered User ID or User ID" means
            the user identification chosen by the Registered User and registered with ‘United Remit’
            Website which, along with the Registered User Password, will enable the Registered User
            to - avail of Facilities and enter into transactions in respect of the Facilities,
            access one or more Customer Accounts, download application forms for Facilities,
            register a change in address, change in nominee details, payments, payment of dues, and
            do such other acts as the ‘United Remit’ Website may permit. "Registered user Password"
            means the password chosen by the Registered User and registered with the ‘United Remit’
            Website which, along with the Registered User ID, will enable the registered user to -
            avail of Facilities and enter into transactions in respect of the Facilities offered on
            the Website, access Registered User Accounts, download application forms for Facilities,
            register a change in address, and do such other acts as the ‘United Remit’ Website may
            permit. "Facility or Remittance tracking facility" means any present and future service
            or facility displayed or offered on or through the ‘United Remit’ Website and includes
            remittance tracking facilities "Service Provider" means a Person who provides a service
            to ‘United Remit’ in order to enable ‘United Remit’ to operate and/or maintain the
            Website, provide any feature on the Website or provide any Facility which is provided
            under ‘United Remit’. "the Terms and Conditions" means the terms and conditions set out
            above and below and also all other terms and conditions contained elsewhere on the
            Website from time to time. "Visitor" means any person who accesses or visits the
            Website, whether or not such person has registered himself as a Registered User. The
            term "Visitor" includes every Registered User. "The Website" means the Website of
            ‘United Remit’ maintained at  <Link to={"/"}>{window.location.hostname}</Link>
             (example) , and includes the pages of the Website and any applets, software and content
            contained in the Website. "Beneficiary or Recipient" means a person whose details have
            been provided by the Registered User to ‘United Remit’ for transfer of funds. "Referrer"
            means an individual who may be a Registered User who refers/recommends to another
            individual the services offered by ‘United Remit’ irrespective of whether the concerned
            individual avails the Facility. "Alliance partner" means any person other than ‘United
            Remit’. who displays its content or offers on the Website. "Referrer" means an
            individual who may be a Registered User who refers/recommends to another individual the
            services offered by ‘United Remit’ irrespective of whether the concerned individual
            avails the Facility. "Beneficiary's bank or Recipient's bank" means the bank in Nepal
            with whom the Beneficiary holds an account "ACH Transfer" means the Facility available
            to Registered Users in USA whereby based on the instruction of the Registered User,
            funds are directly debited from the Registered Users local account via Automated
            Clearing House. "Automated Clearing House" means the electronic fund transfer system run
            by the National Automated Clearing House Association in USA.{" "}
          </p>
          <h5 className="mt-1 mb-3">3. WEBSITE:</h5>
          <p className="text-3 text-muted">
            3.1. Information and Facilities on the Website may be displayed and offered in a phased
            manner at the discretion of ‘United Remit’. ‘United Remit’ shall have the right to from
            time to time in its discretion, introduce new information and Facilities and add to,
            modify, suspend or withdraw any information or Facility or the terms thereof in whole or
            in part without any prior notice.{" "}
          </p>
          <p className="text-3 text-muted">
            3.2. If any of the Terms and Conditions are not acceptable to you or you disagree with
            any material on the Website, your sole and exclusive remedy is to discontinue using the
            Website.
          </p>
          <h5 className="mt-1 mb-3">4. ELIGIBLE USERS: </h5>
          <p className="text-3 text-muted">
            4.1. In order to access and use the Website and avail of any Facility you must be an
            individual of at-least eighteen (18) years of age who can enter into legally binding
            contracts under applicable law. If you do not qualify, please do not access or use the
            Website or the Facility.{" "}
          </p>
          <p className="text-3 text-muted">
            4.2. Usage of the Website and the Facilities by any Visitor or Registered User is
            subject to domestic laws of Nepal and the country of residence of such Visitor or User.
            All Visitors and Registered Users understand that by accessing, using and availing of
            the Website and the Facilities, they are confirming that they are fully aware of the
            laws in Nepal and/or their country of residence relating to the Facilities offered by
            ‘United Remit’. All Visitors and Registered Users agree that they shall be solely and
            absolutely responsible to ensure that the usage of the Website and Facilities offered
            thereon; is in conformity with the laws of the land to which they are subject to.
            ‘United Remit’ shall not be liable for any loss or damage incurred by them on account of
            violation/noncompliance with any of the laws in Nepal or elsewhere in the world.
          </p>
          <h5 className="mt-1 mb-3">
            5. REGISTRATION INFORMATION (IDS AND PASSWORDS) AND SECRECY:
          </h5>
          <p className="text-3 text-muted">
            5.1. Only limited access to the Website is available to non-registered Visitors.
            Non-registered Visitors are not permitted to avail of the Facilities. In order to obtain
            increased access to the Website and in order to avail of the Facilities you are required
            to register on the Website as a Registered User. The Registered User agrees that he
            shall not register more than once on the Website for availing of the Facility
          </p>{" "}
          <p className="text-3 text-muted">
            {" "}
            5.2. You agree - to provide true, accurate, current and complete information about
            yourself as prompted by the registration form on the Website, and to from time to time
            maintain and update this information to keep it true, accurate, current and complete at
            all times. You shall indemnify ‘United Remit’ for any losses caused to ‘United Remit’
            due to any information provided by you being untrue, inaccurate, not current or
            incomplete in any respect, and ‘United Remit’ shall not be responsible for any losses
            sustained by you due to any information provided by you to ‘United Remit’, being untrue,
            inaccurate, not current or incomplete in any respect. If any information provided by you
            is untrue, inaccurate, not current or incomplete, ‘United Remit’, has the right to
            terminate your registration and refuse you access to or use of the Website or any
            Facilities. ‘United Remit’ may request the Registered User at any time for any
            additional information and/or proof of authenticity of any information. The continued
            use of the Facility or access to the Website by the Registered User including completion
            of any pending transactions may be subject to receipt of such additional information or
            proof and/or verification of such proof thereof.
          </p>{" "}
          <p className="text-3 text-muted">
            {" "}
            5.3. Subject to the other Terms and Conditions, upon registration as a Registered User
            the Website will register your Registered User ID and Registered User Password.{" "}
          </p>{" "}
          <p className="text-3 text-muted">
            5.4. You will be solely and absolutely responsible for maintaining the secrecy and
            confidentiality of all your IDs and passwords and you will be fully and absolutely
            responsible and liable for all transactions and activities that occur under your ID and
            password including any unauthorised use or misuse of your ID and/or password. You will
            be responsible and liable if any third party gains access to the Website or any Facility
            through the use of your ID or password, and you hereby agree to indemnify ‘United Remit’
            and hold ‘United Remit’ harmless against any liability, costs, damages, claims, suits
            and proceedings based upon or relating to such unauthorised access and use. Without
            prejudice to the aforesaid, you agree to - immediately notify ‘United Remit’ via e-mail
            or Registered Post AD, or through the Call Centre, of any suspected loss, theft,
            unauthorised usage of the ID or password, any other breach of security, or any receipt
            by you of confirmation of a transaction, fund or securities transfer or other activity
            which you did not authorise; or any inaccurate information in your account balances or
            transaction history and ensure that you logout from your account at the end of each
            session.
          </p>{" "}
          <p className="text-3 text-muted">
            {" "}
            5.5. Any transaction or activity pursuant to use of your ID or Password shall be deemed
            to be your transaction or activity and ‘United Remit’ shall have no obligation to verify
            the authenticity of any such transaction or activity. ‘United Remit’, shall not be
            responsible for any mistake or error made by you in keying in the transaction or
            activity as to the nature of the transaction / activity, with respect to any facts or
            figures or otherwise.
          </p>{" "}
          <p className="text-3 text-muted">
            {" "}
            5.6. If you forget your ID, you can send a written request to ‘United Remit’ at the
            address provided on the Website giving your date of birth and some other identifying
            details acceptable to ‘United Remit’. On ‘United Remit’ being satisfied of your identity
            (which satisfaction shall be entirely at the discretion of '‘United Remit’), ‘United
            Remit’ shall send the ID to your e-mail address registered with ‘United Remit’. You
            shall be responsible for continuing to maintain this e-mail address. ‘United Remit’,
            shall not be liable if it declines to furnish the ID by reason of it not being satisfied
            as to your identity
          </p>{" "}
          <p className="text-3 text-muted">
            {" "}
            5.7. If you forget your password, ‘United Remit’ may, subject to verification and
            satisfaction to the Registered User s identity, generate a new password for you which
            shall be communicated to you at the e-mail address provided by you. For your security
            reasons you must change this password as soon as it is received by you, and until then
            this password shall be deemed to be your password and you will be responsible and liable
            for all transactions pursuant thereto. Upon generation of the new password, ‘United
            Remit’ shall discontinue the use of the old password. However, you shall be responsible
            and liable for all transactions that are carried out by the use of the old Password,
            till the time of discontinuation of the old password.
          </p>{" "}
          <p className="text-3 text-muted">
            {" "}
            5.8. Notwithstanding anything stated elsewhere in the Terms and Conditions, and despite
            correct use of your ID and Password, ‘United Remit’ shall be entitled in its sole
            discretion (but shall not be bound) to seek offline and/or additional written or other
            confirmation from you of any instruction, transaction or activity as ‘United Remit’ may
            deem fit and Registered User shall be obliged to provide the same to continue availing
            Facilities on the Website.
          </p>{" "}
          <p className="text-3 text-muted">
            {" "}
            5.9. In the event that the certifying authorities and other infrastructure contemplated
            under the Information Technology (IT) Bill in 2017 or any other law for the time being
            in force, for ensuring secure electronic records and secure digital signatures is
            notified by the concerned authorities and the infrastructure to enable the same is in
            place, ‘United Remit’ shall have the right to require you to communicate instructions
            and authorise and execute transactions and other activities by means of such secure
            electronic records and secure digital signatures in addition to, or in place of, the use
            of password(s).
          </p>
          <h5 className="mt-1 mb-3">6. USE OF INFORMATION:</h5>
          <p className="text-3 text-muted">
            6.1 Each Visitor and the Registered User irrevocably and unconditionally authorises
            ‘United Remit’ and its partners to access all information relating to his or her access
            and use of the Website and Facilities, including personally identifiable information,
            and/or the transactions entered into by the Visitor/Registered User through the Website.
            Subject to the ‘United Remit’. Privacy Policy, all information submitted on or via the
            Website shall be deemed to be and remain the property of ‘United Remit’. and its
            partners and Service Providers and ‘United Remit’. and its partners and Service
            Providers shall be free to use, for any purpose, any ideas, concepts, know-how or
            techniques contained in or derived from any information the Visitor/registered User may
            provide to or through the Website. ‘United Remit’ and its partners and Service Providers
            shall not be subject to any obligations of confidentiality regarding submitted
            information except as otherwise expressly agreed by it directly with the Visitor.
            ‘United Remit’ shall be deemed to acquire from the Visitor a non-exclusive, world-wide,
            perceptual, irrevocable, royalty free license to use, adapt, reproduce, modify, publish,
            translate, create derivative works from, distribute, perform or display any ideas,
            concepts, know-how or techniques contained in or derived from any information provided
            by the Visitor to or through the Website.
          </p>
          <h5 className="mt-1 mb-3">7. CONDUCT OF VISTORS, REGISTERED USERS AND CUSTOMERS:</h5>
          <p className="text-3 text-muted">
            7.1. You shall not - restrict or inhibit any other person from accessing, using and
            enjoying the Website or the Facilities; use the Website for any purpose that is unlawful
            in any jurisdiction or not permitted by the Terms and Conditions; modify, copy,
            distribute, transmit, display, perform, publish, license, create derivative works from,
            transfer or sell any information, designs, logos, trademarks, software, Facilities,
            products or services obtained on or through the Website, except as permitted by the
            copyright owner or other right holder thereof; post or transmit any unlawful,
            fraudulent, libelous, defamatory, obscene, pornographic, profane, threatening, abusive,
            hateful, offensive, or otherwise objectionable information or statement of any kind
            including, without limitation, any information or statement constituting or encouraging
            conduct that would constitute a criminal offence, give rise to civil liability, or
            otherwise violate any local, state, national, foreign or other law; post or transmit any
            advertisements, solicitations, chain letters, pyramid schemes, investment opportunities
            or schemes or other unsolicited commercial communication (except as otherwise expressly
            permitted by ‘United Remit’) or engage in spamming or flooding; post or transmit any
            information or software which contains a virus, Trojan horse, worm or other harmful
            component; upload, post, publish, transmit, reproduce or distribute in any way,
            information, software or other material obtained on or through the Website which is
            protected by copyright or other proprietary right, or derivative works with respect
            thereto, except as permitted by the copyright owner or other right holder thereof;
            upload, post, publish, reproduce, transmit or distribute in any way any component of the
            Website itself or derivative works with respect thereto, except as permitted by ‘United
            Remit’ or the copyright owner or other right holder thereof, the Website being
            copyrighted under the relevant laws; attempt to de-compile or reverse engineer any of
            the software available on the Website. You shall not make any attempt to hack into the
            Website or otherwise attempt to subvert any firewall or other security measure of the
            Website and if you become aware of any shortcoming in the security on the Website you
            shall forthwith inform ‘United Remit’ of the same in writing.
          </p>
          <p className="text-3 text-muted">
            7.2. If the Website contains bulletin boards, chat rooms, access to mailing lists or
            other message or communication facilities (collectively, "Forums"), you agree to use the
            Forums only to send and receive messages and material that are proper and related to the
            particular Forum
          </p>
          <p className="text-3 text-muted">
            7.3. You shall use any software provided on, by or through the Website only for the
            purposes for which it has been provided to you and for no other purpose.
          </p>
          <h5 className="mt-1 mb-3">8. OTHER TERMS:</h5>
          <p className="text-3 text-muted">
            8.1. '‘United Remit’ shall not be under any duty to assess the prudence or otherwise of
            any instruction or transaction given or entered into by you.
          </p>
          <p className="text-3 text-muted">
            8.2. ‘United Remit’ shall be entitled, in its sole and absolute discretion, to refuse
            all or any of your instructions without assigning any reason.
          </p>
          <p className="text-3 text-muted">
            8.3. You cannot cancel any instructions once provided, save and except as specifically
            detailed on the Website. Additionally, when you place a request to cancel an instruction
            or a transaction that has been authorised by you, such cancellation is not guaranteed by
            ‘United Remit’ save and except as specifically detailed on the Website. Such instruction
            or transaction will only be cancelled if your request for cancellation is received and
            acted upon before the instruction or transaction has been executed.
          </p>
          <p className="text-3 text-muted">
            8.4. ‘United Remit’ shall have the right to, and you hereby authorise ‘United Remit’ to,
            verify any information provided by you.
          </p>
          <p className="text-3 text-muted">
            8.5. ‘United Remit’ shall endeavour to take reasonable measures, which may include
            encryption, to ensure that your personal information is not disclosed to any person
            except to ‘United Remit’ & its authorized Service Providers and such other persons to
            whom the information may be provided as per ‘United Remit’s' Privacy Policy. However,
            the Internet is an open system and ‘United Remit’ cannot, and does not, guarantee that
            the personal information which you furnish will not be intercepted or accessed by others
            and decrypted. ‘United Remit’, ‘United Remit’ and its Service Providers shall not be
            liable or responsible should any confidential or other information provided by or
            pertaining to you (included credit card numbers, bank account numbers, passwords,
            personal identification numbers, IDs, transaction details, etc.) be intercepted and
            subsequently used by an unintended recipient.
          </p>
          <h5 className="mt-1 mb-3">9. DISCLAIMERS:</h5>
          <p className="text-3 text-muted">
            9.1. Access and use of the Website and the Facilities is entirely at your own risk. The
            Website, including any content or information on it, any related or linked site and all
            Facilities, products and services displayed, provided, availed of, licensed or purchased
            on, through or via the Website are provided "as is," without any representation or
            warranty of any kind, either express or implied, including without limitation, any
            representation or warranty for accuracy, continuity, uninterrupted access, timeliness,
            sequence, quality, performance, fitness for any particular purpose or completeness.
            Specifically, ‘United Remit’ disclaims any and all warranties including, but not limited
            to - any warranties concerning the availability, accuracy, usefulness, or correctness,
            currency or completeness of information, Facilities, products or services and any
            warranties of title, warranty of non-infringement, freedom from computer virus,
            warranties of merchantability or fitness for a particular purpose, other than those
            warranties which are incapable of exclusion, restriction or modification under the laws
            applicable to the Terms and Conditions. ‘United Remit’ has not verified and shall not be
            liable or responsible for any content or other information on the Website or on
            web-sites linked to or with ‘United Remit’. ‘United Remit’ does not, in any way, certify
            or warrant the performance, operation, content or availability of the Website or such
            other websites. Although ‘United Remit’ adopts security measures which it considers
            appropriate for the Website, it does not assure or guarantee that no person will
            overcome or subvert the security measures and gain unauthorised access to the Website or
            any Customer Accounts. ‘United Remit’ shall not be responsible or liable if any
            unauthorised person hacks into or gains access to the Website, any Facility or your
            accounts; and you shall be liable and responsible for the same.
          </p>
          <p className="text-3 text-muted">
            9.2. This disclaimer of liability applies also to any damage or injury caused by any
            failure of performance, error, omission, interruption, deletion, defect, delay in
            operation or transmission, computer virus, communication line failure, theft or
            destruction or unauthorized access to, alteration of, or use of record, whether for
            breach of contract, tortuous behaviour, negligence, or under any other cause of action
          </p>
          <p className="text-3 text-muted">
            9.3. The information and views contained herein are based on information available and
            believed to be correct to the best of our knowledge. Although due care has been
            exercised to verify the accuracy of the information, ‘United Remit’ and its information
            suppliers do not assume responsibility for the accuracy or for any loss arising out of
            any information contained herein. This is neither a solicitation to invest in any
            product nor to avail of a particular service.
          </p>
          <p className="text-3 text-muted">
            9.4. ‘United Remit’, does not warrant or makes any representations regarding the use or
            the results of the use of any product, service and /or Facility in terms of its
            compatibility, correctness, accuracy, reliability or otherwise. You assume total
            responsibility and risk for your access and use of the Website, all site related
            services and all Facilities, products and services mentioned or advertised on or
            accessed or availed on or through the Website.
          </p>
          <p className="text-3 text-muted">
            9.5. You acknowledge that any warranty that is provided in connection with any of the
            Facilities, products or services described on the Website are provided solely by the
            owner, advertiser, manufacturer, provider or supplier of that Facility, product or
            service, and not by ‘United Remit’ or the Website (except where ‘United Remit’ or
            ‘United Remit’ are expressly stated to be owner, advertiser, manufacturer, provider and
            supplier thereof).
          </p>
          <p className="text-3 text-muted">
            9.6. ‘United Remit’ operates and offers the Website strictly on a no-liability basis and
            ‘United Remit’ shall not be liable to you or any other third party for any direct,
            indirect, incidental, special, exemplary, punitive, consequential or other damages
            (including without limitation loss of profits, loss or corruption of data, loss of
            goodwill, work stoppage, computer failure or malfunction, or interruption of business)
            under any contract, negligence, strict liability or other law or theory arising out of
            or in connection with the Website, or any Facilities, products or services mentioned or
            advertised on or accessed or availed on or through the Website or any contract or
            transaction entered into or executed in pursuance thereof (however arising, including
            negligence) or resulting from the use of or inability to use, access or avail of the
            Website, any Facility, service or product or out of any breach of any warranty. Under no
            circumstances shall ‘United Remit’, or its alliance partner, be liable for any damages
            whatsoever whether such damages are direct, indirect, incidental consequential and
            irrespective of whether any claim is based on loss of revenue, investment, production,
            goodwill, profit, interruption of business or any other loss of any character or nature
            whatsoever and whether sustained by you or any other person.
          </p>
          <p className="text-3 text-muted">
            9.7. The Registered User/Visitor/Referrer shall ensure that he shall not be in violation
            of any data protection laws in force at the time of referring any person for the service
            to ‘United Remit’ or at the time registering for the Facility (as the case may be).
          </p>
          <p className="text-3 text-muted">
            9.8. If any disclaimers or limitation of liability in the Terms and Conditions are held
            to be unenforceable, the maximum liability of ‘United Remit’ to you shall not exceed the
            amount of fees paid by you to ‘United Remit’ for the Facilities, products or services
            that you have ordered or availed of on or through the Website.
          </p>
          <p className="text-3 text-muted">
            9.9. Delays in the Transactions and Non-Liability for Damages While ‘United Remit’ shall
            endeavor that your instructions and your transactions pursuant to Facilities provided by
            ‘United Remit’ are communicated, carried out and/or performed promptly, ‘United Remit’
            does not guarantee that any instructions will definitely be communicated or carried out
            or that any transactions will definitely be performed; and ‘United Remit’, shall not be
            responsible for any delay in communicating, carrying out or performance of any
            instructions or transactions due to any reason whatsoever, including by reason of
            failure of operational systems for reasons including but not limited to virus attacks,
            natural calamity, floods, fire and other natural disasters, legal restraints, faults in
            the telecommunication network or network failure, software or hardware error, labour
            problem, strike or any other reason beyond the control of ‘United Remit’.
          </p>
          <p className="text-3 text-muted">
            9.10. ‘United Remit’, shall not be responsible for any inability to access the Website
            or any use or misuse of the Website.
          </p>
          <p className="text-3 text-muted">
            9.11. Any search results displayed by or on the Website are automated and cannot be
            screened. Accordingly, ‘United Remit’ assumes no responsibility for the accuracy or
            otherwise of any search results or of the content of any site included in the search
            results or otherwise linked to the Website.
          </p>
          <p className="text-3 text-muted">
            9.12. ‘United Remit’ shall not be responsible for any unauthorised interception of
            e-mail to or from you & ‘United Remit’.
          </p>
          <p className="text-3 text-muted">
            9.13. To the extent possible, the disclaimers, limitations on liability and indemnities
            available to ‘United Remit’ under the Terms and Conditions shall mutatis mutandis extend
            and be available also to ‘United Remit’ and its / their respective directors, officers,
            employees, agents, successors, assigns, consultants, sponsors, affiliates, content
            providers and everyone involved in creating, producing, delivering or managing the
            Website (or any part thereof) or any Facility. However, this clause shall not protect
            the aforesaid Persons or extend to their obligations and liabilities under the SLAs,
            contracts and other covenants based on which the business alliance of ‘United Remit’ is
            forged.
          </p>
          <p className="text-3 text-muted">
            9.14. A possibility exists that the Website could include inaccuracies or errors.
            Additionally, a possibility exists that unauthorised additions, deletions or alterations
            could be made by third parties to the Website. Although ‘United Remit’ and its Service
            Providers attempt to ensure the integrity of the Website, they make no guarantee
            whatsoever as to its sequence, timeliness, completeness, correctness or accuracy. In the
            event that such an inaccuracy or incompleteness arises, please inform ‘United Remit’ so
            that it can be corrected.
          </p>
          <p className="text-3 text-muted">
            <p className="text-3 text-muted">9.15. Links from the Web Site –</p> 9.15.1. Clicking on
            certain portions or links within the Web Site might take you to other websites without
            any intimation or indication of doing or having done so. The linked Websites are not
            under the control of ‘United Remit’. ‘United Remit’ assumes no responsibility whatsoever
            for such other websites whether as to content, availability, performance or otherwise.
            ‘United Remit’ also does not represent or warrant that these links shall operate
            satisfactorily. ‘United Remit’ provides these links only as a convenience and links to
            external web sites do not constitute an endorsement by ‘United Remit’ of such other
            sites, the sponsors of such sites or the content, products, advertising or other
            materials presented on or by such sites. ‘United Remit’ shall not be responsible or
            liable, directly or indirectly, for any damage or loss caused or alleged to be caused by
            or in connection with the access or use of such other websites or reliance on or
            availing of any content, goods or services available on such other sites.
          </p>
          <h5 className="mt-1 mb-3">10. TERMS OF SUPPLY OF FACILITIES - GENERAL:</h5>
          <p className="text-3 text-muted">
            10.1. ‘United Remit’ offers its Facilities strictly on a no liability basis.
            Accordingly, while ‘United Remit’, shall endeavour to offer such Facilities as per their
            terms, no claim shall lie against ‘United Remit’ and ‘United Remit’, shall not be liable
            to you or to any Person, in the event of non-provision of any Facility or delay or
            omission to do any act pursuant to any Facility provided by ‘United Remit’ or on any
            other account whatsoever. You should avail of Facilities provided by ‘United Remit’ only
            if you are agreeable to the above.
          </p>
          <p className="text-3 text-muted">
            10.2. In order to avail of specific Facilities, you may have to agree to other terms and
            conditions in addition to the Terms and Conditions and may also have to execute
            agreements, powers of attorney or other writings and abide by the specified procedures.
          </p>
          <p className="text-3 text-muted">
            10.3. If you wish to avail of a Facility, you may be asked by the ‘United Remit’ to
            supply certain information, including but not limited to credit or debit card or other
            payment mechanism information. You agree that all information you provide to ‘United
            Remit’ will be accurate, complete and current. You agree not to hold ‘United Remit’
            liable for any loss or damage of any sort incurred as a result of any such dealings with
            any Service Provider.
          </p>
          <p className="text-3 text-muted">
            10.4. You hereby authorize ‘United Remit’ to call you at any time during the business
            hours, through any of its authorised representatives for providing information
            pertaining to ‘United Remit’ Online Money Transfer facility. ‘United Remit’, its
            affiliates, subsidiaries, employees, officers, directors and agents, expressly disclaim
            any liability or responsibility from contacting you via telephone, emails, SMS, letters
            or any other mode as the Bank may deem fit, to provide various information on ‘United
            Remit’ Online Money Transfer facility. 'You further agree to authorize ‘United Remit’,
            its Subsidiaries, Affiliates, Agents to contact you at any time during the business
            hours for product updates, marketing promotions, or any special offers available from
            time to time on its NRI Products & Services, via telephone, email, SMS, letters or any
            other mode as the Bank may deem fit. Further, ‘United Remit’ ,its affiliates,
            subsidiaries, employees, officers, directors and agents, expressly disclaim any
            liability or responsibility from any contact made with you via the aforesaid mediums.'
          </p>
          <p className="text-3 text-muted">
            10.5. Prices and availability of Facilities displayed or offered on or through the
            Website are subject to change without prior notice. Nothing contained in this Website
            constitutes an offer, promise or commitment to grant or provide any Facility on any
            specific terms or otherwise and the sanction or grant of any Facility is not guaranteed
            and is in the absolute discretion of ‘United Remit’. While ‘United Remit’ endeavors to
            post accurate and updated information on the Website, you verify the same before taking
            any action or entering into any transaction. ‘United Remit’ will not be liable for any
            lack of availability of any Facilities you may order or seek to avail of through the
            Website.
          </p>
          <p className="text-3 text-muted">
            10.6. You agree to pay all charges incurred by users of your ID and password and credit
            card or other payment mechanism at the prices in effect when such charges are incurred.
            You also will be responsible for paying any applicable taxes, and
            shipping/transportation and handling charges relating to purchases through the Website.
          </p>
          <p className="text-3 text-muted">
            10.7. The records of access, instructions, transactions and other activities maintained
            by ‘United Remit’ through its own or a third party's computer systems or on tape or
            other recording or storage device or otherwise shall be admissible in evidence, shall
            not be challenged by you and shall be accepted as genuine, accurate, conclusive and
            binding for all purposes including the recording of the time thereof.
          </p>
          <p className="text-3 text-muted">
            10.8. Facilities are offered only to persons who are residents or citizens of states and
            countries where ‘United Remit’ can offer and provide such Facilities. By offering
            Facilities on this Web Site, ‘United Remit’ meaning ‘United Remit’. or any other Service
            Providers (as the case may be) are not attempting to offer or provide Facilities outside
            their authorized states or country.
          </p>
          <p className="text-3 text-muted">
            10.9. ‘United Remit’ shall try to ensure that all information that is provided on the
            Website with respect to the Facilities, products and services that are offered by the
            suppliers and the customised news are accurate and up to date. However, ‘United Remit’
            does not guarantee the timeliness, accuracy, completeness, reliability or content of the
            information and any changes that are made with respect to the same.
          </p>
          <p className="text-3 text-muted">
            10.10. Alerts - '‘United Remit’ and/or its Service Providers shall endeavour to ensure
            that Alerts are communicated to you in accordance with your instructions in this regard.
            However, neither ‘United Remit’ nor the Service Providers would be responsible or liable
            for non-dispatch or delay in dispatch of the Alerts by ‘United Remit’ and/or the Service
            Providers or any delay in receipt or non-receipt of the Alerts for any reason
            whatsoever. Under no circumstances shall ‘United Remit’ and/or the Service Providers be
            liable for any costs, damages or other amount whatsoever for such non-dispatch or delay
            in dispatch or any non-receipt or delay in receipt of the Alerts. Non- receipt of Alerts
            will not discharge or reduce your liability to pay any amount to ‘United Remit’ which
            would have been payable in the event of proper receipt of the Alerts.
          </p>
          <h5 className="mt-1 mb-3">11. REMITTANCE TRACKING FACILITY</h5>
          <p className="text-3 text-muted">
            11.1. Subject to the relevant regulatory approvals, terms and conditions imposed while
            granting the necessary approvals and other terms of this Facility, this Facility, on it
            being made available, enables you to remit or send foreign currency (i.e. currency which
            is not Nepali currency) from a country outside Nepal to an account in Nepal, either
            after conversion into Nepali Rupees or other permissible foreign currency. This facility
            is a technology platform for a facility that enables remitting funds from outside Nepal
            into Nepal. The facility is offered by ‘United Remit’. ‘United Remit’ is responsible for
            acting on the remittance requests, collecting money in foreign currency in case of ACH
            Transfer and receiving money in foreign currency in case of Online Transfer and Smart
            Wire, converting it into NPR or the permissible foreign currency as applicable and
            remitting it to the Beneficiary in Nepal as instructed by the Registered User or
            remitter of funds i.e. you. The foreign exchange conversion rate shown for the
            calculation on the Website is only indicative except when specified as fixed rate to
            help you to arrive at an approximate INR amount that the Beneficiary will receive. It is
            in no way guarantees or represents, the foreign exchange conversion rate that will
            actually be applied to the foreign exchange sent by you (the remitter). ‘United Remit’
            will apply the foreign exchange conversion rates prevailing on the day of conversion and
            no further communication / confirmation from the Registered User or remitter shall be
            required for this. By using ‘United Remit’ Facilities for remittances, the Registered
            User gives the express, irrevocable authority to ‘United Remit’ & ‘United Remit’. to
            convert the funds at the prevailing exchange rates applicable on the date of conversion
            (which shall be normally within 1-2 working days of receipt of clear funds into the
            account of ‘United Remit’ with full details of the Registered User or remitter and
            Beneficiary) and disburse the converted amount or foreign currency amount as per the
            instructions provided by the Registered User or remitter through the Website.
          </p>
          <p className="text-3 text-muted">
            11.2. You should pay the foreign currency as per the instructions stated on the Website
            by acceptable mode as mentioned on the Website. ‘United Remit’ will process your
            remittance request only after receipt of proper confirmation that the foreign currency
            amount said to have been remitted by you has been received in the designated account of
            ‘United Remit’ in 'clear funds'. Thereafter, after deducting the appropriate
            charges/fees, the money will be transmitted by ‘United Remit’ to the bank account in
            Nepal designated by you i.e. Beneficiary s account. If it comes to the notice of ‘United
            Remit’ that you had insufficient funds in the account from which you requested the
            remittance of money, ‘United Remit’ may cancel the requested remittance transaction and
            you the Registered User shall bear full liability and responsibility for the same. In
            the event the above is learnt by ‘United Remit’ after the Recipient of the remittance
            has en-cashed the DD or otherwise received the remittance, you i.e. the Registered User
            will be liable to reimburse ‘United Remit’. of the amount remitted and any other charges
            and costs incurred by ‘United Remit’. You agree to pay to ‘United Remit’. such amount
            immediately upon first demand along with interest @ 2% per month from the date of the
            remittance by ‘United Remit’. till the receipt of funds by the Bank from you. You also
            agree to pay for all costs associated with the recovery of amounts owed to ‘United
            Remit’. or its Service Providers, including reasonable attorney's fees and court fees.
            ‘United Remit’ shall also be entitled to inform any credit bureau or any other person or
            entity if you fail to pay/reimburse such amount or any part thereof to the Bank.
          </p>
          <p className="text-3 text-muted">
            11.3. While it shall be ‘United Remit’s' endeavour to adhere to the time schedule
            indicated by it on the Website, ‘United Remit’ will not be responsible or liable for any
            changes in the time schedule for execution of your instructions or remittance / credit
            of funds for any reason. Nothing provided on the Website should be construed as advice
            of any nature and you are advised to consult professionals in this regard prior to
            taking any decision. Further, this Facility does not, in any way, solicit or encourage
            you to enter into any such transaction. ‘United Remit’ shall not, under any
            circumstances, be responsible for any loss suffered due to any fraud or other actions of
            the Registered User. Further, this Facility is offered subject to the applicable laws of
            any other country, including the country from which the funds are to be remitted, and it
            shall be your responsibility to ensure that these laws are adhered to. ‘United Remit’
            accepts no liability whatsoever, direct or indirect for non-compliance with the laws of
            any country other than that of Nepal. The mere fact that the Website can be accessed or
            used or any Facility can be availed of in a country other than Nepal would not mean that
            the laws of such country would be applicable. In the event the person to whom the funds
            are remitted requires a transaction confirmation letter, or the funds are for any reason
            required to be redirected to another account / location, or any other additional service
            is required, the Bank shall levy additional charges and remit the amount after deducting
            such additional charges applicable at the time of such request.
          </p>
          <p className="text-3 text-muted">
            11.4. ‘United Remit’ shall in no way be held responsible and/or be liable for any
            queries, errors, disputes or delays in messaging, money transmission, currency
            conversion, conversion rates offered, payment to the beneficiaries of the remittances or
            any other query, claim or dispute. ‘United Remit’ will, however, assist you in
            contacting the Bank to facilitate resolution of such queries, claims and disputes to the
            best of ‘United Remit’s ability.
          </p>
          <p className="text-3 text-muted">
            11.5. You agree to abide the provisions applicable under Foreign Exchange (Regulation)
            Act, 2019. You shall not undertake any transaction which contravene or evade any
            provisions of Foreign Exchange (Regulation) Act, 2019 or of any rule, regulation,
            notification, direction or order made thereunder.
          </p>
          <p className="text-3 text-muted">
            11.6. The above terms and conditions are in addition to the additional terms and
            conditions relating to the Facility appearing elsewhere on this Website or otherwise now
            or hereafter agreed or deemed to be agreed by you.
          </p>
          <p className="text-3 text-muted">
            11.7. ‘United Remit’ shall be entitled to have more than one promotional offer in
            existence and applicable at any given time. However, a Registered User shall be entitled
            to avail of only one offer per transaction. It shall be entirely at the discretion of
            ‘United Remit’ to consider any exceptions to the above.
          </p>
          <h5 className="mt-1 mb-3">12. FEES AND CHARGES:</h5>
          <p className="text-3 text-muted">
            12.1. ‘United Remit’ may set its own fees and charges for Facilities and may revise the
            same at any time and the availability of Facilities displayed or offered on or through
            the Website are subject to change without prior notice.
          </p>
          <p className="text-3 text-muted">
            12.2. When a Registered User makes a request to use the Facility using Smart Wire or
            Online Transfer option, such Registered User will be requesting the Registered User's
            local financial institution to initiate a wire transfer or transfer through internet
            banking to ‘United Remit’ correspondent bank to fund the remittance ‘United Remit’. is
            not responsible in any manner for any fees or charges, if any, that may be imposed by
            any such financial institution(s) or any other third parties in connection with such
            transfer. When a Registered User makes a request to use the Facility using the ACH
            Transfer option, ‘United Remit’. is not responsible in any manner for fees or charges,
            if any, that may be imposed on the Registered User by the Registered User's financial
            institution in connection with the ACH debit processed as part of such transfer
          </p>
          <p className="text-3 text-muted">
            12.3. Neither the Registered User nor the Beneficiary will be entitled to any interest
            for the period during which the funds to be remitted are with ‘United Remit’, are in the
            course of remittance, or for any other period.
          </p>
          <p className="text-3 text-muted">
            12.4. Registered User agrees that any return of funds will be done on best effort basis
            and at sole discretion of ‘United Remit’ Such return of funds whether pre or post
            conversion will be charged by ‘United Remit’. and charges of the correspondent bank/s
            involved in routing such return will also be applicable. Such charges will be deducted
            from the remittance amount and will be borne by the Registered User or remitter.
          </p>
          <h5 className="mt-1 mb-3">13. PROPRIETARY AND INTELLECTUAL PROPERTY RIGHTS:</h5>
          <p className="text-3 text-muted">
            ‘United Remit’ brand name, logo, service mark and contents are the property of ‘United
            Remit’. The content and/or information on the Website including but not limited to any
            text, images, illustrations, audio clips, video clips and screens appearing on the
            Website are owned by ‘United Remit’; except contents, promotional advertisements
            displayed on Website by Alliance Partner/s. All rights on the Website are reserved and
            you may not download and/or save a copy of the Website or any part thereof including any
            of the screens or part thereof and/or reproduce, store it in a retrieval system or
            transmit it in any form or by any means - electronic, electrostatic, magnetic tape,
            mechanical printing, photocopying, recording or otherwise including the right of
            translation in any language without the express permission of ‘United Remit’ (except as
            otherwise provided on the Website or in the Terms and Conditions for any purpose) or use
            it in any manner that is likely to cause confusion or deception among persons or in any
            manner disparages or discredits ‘United Remit’ Nepal or Service Providers,. However, you
            may print a copy of the information on this Site for your personal use or records. This
            Site is for your personal use. If you make other use of this Site, except as otherwise
            provided above, you may violate copyright and other laws of Nepal and other countries,
            and may be subject to penalties. ‘United Remit’ does not grant any license or other
            authorization or user of its trademarks, registered trademarks, service marks, or other
            copyrightable material or other intellectual property by placing them on the Website.
          </p>
          <h5 className="mt-1 mb-3">14. AUTHORITY TO ‘United Remit’:</h5>
          <p className="text-3 text-muted">
            You irrevocably and unconditionally authorise ‘United Remit’, to access all information
            relating to you (including personal information and information relating to access and
            use of the Website and Facilities by you and the transactions entered into by you).
            Subject to the privacy statement, all information submitted on or via the Website shall
            be deemed to be and remain the property of ‘United Remit’; and ‘United Remit’ shall be
            free to use, for any purpose, any ideas, concepts, know-how or techniques contained in
            any information you may provide to or through the Website. ‘United Remit’ shall not be
            subject to any obligations of confidentiality regarding submitted information except as
            otherwise expressly agreed by it directly with you. ‘United Remit’ shall be deemed to
            acquire from you a nonexclusive, world-wide, perceptual, irrevocable, royalty free
            licence to use, adapt, reproduce, modify, publish, translate, create derivative works
            from, distribute, perform or display any ideas, concepts, know-how or techniques
            contained in any information provided by you to or through the Website.{" "}
          </p>
          <h5 className="mt-1 mb-3">15. NO AGENCY: </h5>
          <p className="text-3 text-muted">
            The Terms and Conditions and your use of or access to the Website or any Facilities are
            not intended to create an agency, partnership, joint-venture or employer-employee
            relationship between you and the Website, ‘United Remit’. or its Service Provider,
            except where otherwise specifically agreed or appointed.
          </p>
          <h5 className="mt-1 mb-3">16. NO OBLIGATION FOR MAINTENANCE:</h5>
          <p className="text-3 text-muted">
            ‘United Remit’ has no obligation to monitor the functioning of the Website. However, you
            acknowledge and agree that ‘United Remit’ has the right to monitor the functioning of
            the Website electronically or otherwise from time to time and to disclose any
            information as necessary or appropriate to satisfy any law, regulation or other
            governmental request, to operate the Website properly or to protect itself or its
            Service Providers, Alliance Partners, Visitors, Registered Users. ‘United Remit’ will
            not intentionally monitor or disclose any private electronic-mail message to any third
            party unless required by law. ‘United Remit’ reserves the right to refuse to post or to
            remove any information or materials, in whole or in part, that, in its sole discretion,
            which are unacceptable, undesirable, inappropriate or in violation of the Terms and
            Conditions.
          </p>
          <h5 className="mt-1 mb-3">17. INDEMNITY:</h5>
          <p className="text-3 text-muted">
            You agree to defend, indemnify and hold ‘United Remit’, its directors, officers,
            employees, Affiliates Partners, and Content and Service Providers harmless from any and
            all claims, liabilities, damages, costs, expenses and proceedings, including reasonable
            attorneys' fees, arising in any way from your use of the Website or the placement or
            transmission of any message, information, software or other materials through the
            Website by you or users of your ID and password or related to any violation of the Terms
            and Conditions by you or users of your ID and password, and any claims dispute or
            differences between you and any supplier.
          </p>
          <h5 className="mt-1 mb-3">18. TERMINATION:</h5>
          <p className="text-3 text-muted">
            18.1 Termination by ‘United Remit’ - You acknowledge and agree that ‘United Remit’ may,
            without notice, suspend or terminate your User ID, Password or Account or deny you
            access to all or part of the Website or any Facilities without prior notice if you
            engage in any conduct or activities that ‘United Remit’ in its sole discretion believes
            violate any of the Terms and Conditions, violate the rights of ‘United Remit’, or is
            otherwise inappropriate for continued access, or if ‘United Remit’ learns of your death,
            bankruptcy or lack of legal capacity or of circumstances which impact your credit
            worthiness (which shall be determined at the sole discretion of ‘United Remit’) or for
            any other reason which ‘United Remit’ thinks fit and proper. You acknowledge and agree
            that ‘United Remit’ may in its sole discretion deny you access through ‘United Remit’ to
            any materials stored on the Internet, or to access third party services, Facilities,
            merchandise or information on the Internet through the Website, and ‘United Remit’ shall
            have no responsibility to notify you or third-party providers of Facilities, services,
            merchandise or information nor any responsibility for any consequences resulting from
            lack of notification.
          </p>
          <p className="text-3 text-muted">
            18.2 Termination by You - You may request for termination of this Facility at any time
            by giving a written notice of at least fifteen (15) days to ‘United Remit’. The
            termination shall take effect on the completion of the fifteenth day from the date of
            receipt of the notice by ‘United Remit’. Provided however that you will remain
            responsible for any transactions entered into by you and all obligations incurred by you
            until the time of such termination. You acknowledge that termination of this Facility by
            you would not imply deletion of any data, transactions or other information provided by
            you to ‘United Remit’.
          </p>
          <h5 className="mt-1 mb-3">19. GOVERNING LAW & JURISDICTION:</h5>
          <p className="text-3 text-muted">
            19.1 The Website, the Terms and Conditions, all transactions entered into on or through
            the Website and the relationship between you and ‘United Remit’ shall be governed by and
            construed in accordance with the laws of Nepal and no other nation, without regard to
            the laws relating to conflicts of law.
          </p>
          <p className="text-3 text-muted">
            19.2 You and ‘United Remit’ agree that all claims, differences and disputes arising
            under or in connection with or pursuant to the Website, the Terms and Conditions, any
            transactions entered into on or through the Website or the relationship between you and
            ‘United Remit’ shall be subject to the exclusive jurisdiction of the competent courts
            located in the city of Kathmandu, Nepal and you hereby accede to and accept the
            jurisdiction of such courts. Provided that, notwithstanding what is stated above, if
            ‘United Remit’ so thinks fit ‘United Remit’ may institute proceedings against you in any
            other court or tribunal having jurisdiction.
          </p>
          <p className="text-3 text-muted">
            19.3 ‘United Remit’, and its Service Providers, accepts no liability whatsoever, direct
            or indirect for noncompliance with the laws of any country other than that of Nepal. The
            mere fact that the Website can be accessed or used or any facility can be availed of in
            a country other than Nepal would not mean that the laws of such country would be
            applicable.
          </p>
          <p className="text-3 text-muted">
            19.4 Subject to the other Terms and Conditions and applicable law, the Website and the
            Facilities are offered both to residents of Nepal, to non-residents and Person of
            Nepalese Origin(PIO)/Overseas Citizen of Nepal (OCI). Provided however, that the
            Facilities are not available to foreign residents including non-resident Nepal ("NRN's")
            in foreign jurisdictions where the Website or Facilities cannot be offered without prior
            legal or regulatory compliance. It shall be the sole responsibility of foreign residents
            including NRNs in foreign jurisdictions to verify whether the Website and the Facilities
            can be accessed and utilised in their respective jurisdictions.
          </p>
          <h5 className="mt-1 mb-3">20. COMPLIANCE WITH LAWS:</h5>
          <p className="text-3 text-muted">
            The Facilities offered by ‘United Remit’ are subject to applicable law and regulations
            and would be modified / discontinued based on the prevailing law / regulation at any
            point of time and ‘United Remit’ or ‘United Remit’. shall be under no liability or
            obligation to continue implementation of the said Facilities till such time the terms
            are modified by the Parties as per the prevailing/ amended law at that point of time. In
            the event, that the Facilities cannot be continued without total compliance of the
            prevailing law at any point of time, implementation of the Facilities shall be deemed to
            be terminated forthwith from the date when the amended law restricting / prohibiting the
            Facilities comes into force
          </p>
          <h5 className="mt-1 mb-3">21. NO WAIVER:</h5>
          <p className="text-3 text-muted">
            The failure or delay of ‘United Remit’ to exercise or enforce any right or provision of
            the Terms and Conditions shall not constitute a waiver of such right or provision. No
            waiver on the part of ‘United Remit’ shall be valid unless it is in writing signed by
            ‘United Remit’
          </p>
          <h5 className="mt-1 mb-3">22. SEVERABILITY:</h5>
          <p className="text-3 text-muted">
            If any provision of the Terms and Conditions shall be held to be invalid or
            unenforceable by reason of any law or any rule, order, judgment, decree, award or
            decision of any court, tribunal or regulatory or self-regulatory agency or body, such
            invalidity or unenforceability shall attach only to such provision or condition, and you
            should endeavour to give effect to the parties' intentions as reflected in the provision
            to the extent possible, The validity of the remaining provisions and conditions shall
            not be affected thereby and these Terms shall be carried out as if any such invalid or
            unenforceable provision or condition was not contained herein.
          </p>
          <h5 className="mt-1 mb-3">23. LIMITATION:</h5>
          <p className="text-3 text-muted">
            Notwithstanding any statute or law to the contrary, but to the extent permitted by law,
            any claim or cause of action arising out of or related to access or use of the Website
            or any Facility or the Terms and Conditions must be filed within three (3) months after
            such claim or cause of action arose failing which it shall be forever barred.
          </p>
          <h5 className="mt-1 mb-3">24. NOTICES:</h5>
          <p className="text-3 text-muted">
            24.1 ‘United Remit’ may give notice to you by e-mail, letter, telephone or any other
            means as may deem fit to the address last given by you. Notices under the Terms and
            Conditions may be given by you in writing by delivering them by hand or by sending them
            by post to the address mentioned on the Website. ‘United Remit’ shall not be bound to,
            act upon notices and instructions given by you to by e-mail, letter, telephone or any
            other means as ‘United Remit’ may deem fit.
          </p>
          <p className="text-3 text-muted">
            24.2 In addition, ‘United Remit’ may (but shall not be bound to) also publish notices of
            general nature, which are applicable to all Visitors or Registered Users in a newspaper
            circulating in Nepal or on its Website. Such notices will have the same effect as a
            notice served individually to each Visitor or Registered User (including you).
          </p>
          <p className="text-3 text-muted">
            24.3 Documents which may be sent by electronic communication between the parties may be
            in the form of an electronic mail, an electronic mail attachment, or in the form of an
            available download from the Website of ‘United Remit’ shall be deemed to have duly
            communicated and delivered any communication or document to you if such communication or
            document is sent via electronic mail (email) to the e-mail address provided by you to
            ‘United Remit’. ‘United Remit’ shall also be entitled to act on the basis of any
            instructions received or purported to be received by ‘United Remit’ from you by e-mail
            or other electronic means or via the internet. ‘United Remit’ shall also be entitled
            (but not bound) to act upon fax instructions and communications after making basic due
            diligence.
          </p>
          <h5 className="mt-1 mb-3">25. MISCELLANEOUS:</h5>
          <p className="text-3 text-muted">
            25.1 The clause headings in the Terms and Conditions are only for convenience and do not
            affect the meaning of any provision and shall not be taken into account in interpreting
            or limiting the scope of the provisions of the Terms and Conditions.
          </p>
          <p className="text-3 text-muted">
            25.2 ‘United Remit’ may sub-contract or employ agents to carry out any functions or
            services relating to the Website or any of its obligations under the Terms and
            Conditions.
          </p>
          <p className="text-3 text-muted">
            25.3 ‘United Remit’ may from time to time send by e-mail or otherwise, information
            relating to products and services offered by it or the or any other entities, the
            Facilities, general information related to financial and other services, advertisements
            of various products and services etc. to you.
          </p>
          <p className="text-3 text-muted">
            25.4 You must at your own cost: (a) provide for your own access to the World Wide Web
            and pay any service fees, telephone charges and online service usage associated with
            such access, and (b) provide all equipment necessary for you to make such connection to
            the World Wide Web, including a computer and modem.
          </p>
          <p className="text-3 text-muted">
            25.5 In the case of joint accounts which are held by you along with one or more others,
            each account holder may not be authorised to act independently. For the joint accounts,
            you must be the first joint account holder and the User ID and the Password may be
            issued only to you. The other joint account holders shall be deemed to have given
            his/her/their consent to such arrangement. All correspondence will be addressed to you
            as the first joint account holder only. All the Terms and Conditions and all
            transactions arising in the joint accounts from the use of any Facility shall be binding
            on all the joint account holders, jointly and severally.
          </p>
          <p className="text-3 text-muted">
            25.6 The content presented at the Website may vary depending upon your browser
            limitations. The conditions stated in these Terms and Conditions are in addition to the
            other terms and conditions stated elsewhere in the Website. BY ACCESSING AND / OR USING
            THIS WEBSITE OR PORTION / PAGE THEREOF AND / OR ANY FACILITIES YOU AGREE TO THE TERMS
            AND CONDITIONS
          </p>
        </div>
      </section>
    </div>
  );
};

export default TermsConditions;
