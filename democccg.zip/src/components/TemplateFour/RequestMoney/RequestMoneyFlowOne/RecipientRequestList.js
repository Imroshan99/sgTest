import React, { useState, useEffect, useReducer, Fragment } from "react";
import { Form, Input, Tabs, Select, notification, Spin, Table } from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { Link, useNavigate, useOutletContext } from "react-router-dom";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import Swal from "sweetalert2";
import { config } from "../../../../config";
import { useSelector } from "react-redux";

import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
// import RecipientInfo from "./RecipientInfo";
import useHttp from "../../../../hooks/useHttp";
import moment from "moment";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import RecipientRequestNickNameForm from "../../Recipient/RecipientFlow2/RecipientRequestNickNameForm";

function RecipientRequestList(props) {
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const { setTitle } = useOutletContext();
  const navigate = useNavigate();
  // console.log(ConfigReducer)
  const recipientListConfig = ConfigReducer?.groupIdSettings?.recipientModule?.recipientList;
  const [loading, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    recipientRequestLists: [],
    userID: AuthReducer.userID,
  });

  const hookRecipientRequestLists = useHttp(ReceiverAPI.recipientRequestLists);
  const hookRecipientRequestApprove = useHttp(ReceiverAPI.recipientRequestApprove);

  useEffect(async () => {
    // if(AuthReducer.isLoggedIn) {
    setTitle('Recipient Requests')
    recipientRequestListsHandler();
    // }
  }, []);

  const recipientRequestListsHandler = () => {
    const payload = {
      requestType: "RECREQLIST",
      userId: AuthReducer.userID,
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
      favouriteFlag: "",
    };
    setLoader(true);

    hookRecipientRequestLists.sendRequest(payload, (res) => {
      setLoader(false);

      if (res.status === "S") {
        setState({
          recipientRequestLists: res.responseData,
        });
      } else {
        setState({
          recipientRequestLists: [],
        });
      }
    });
  };

  const onNickNameChangeHandler = (nickNameData, recordToken) => {
    // console.log(e, recordToken);
    const __recipientRequestLists = [...state.recipientRequestLists];
    const recordIndex = __recipientRequestLists.findIndex(
      (item) => item.recordToken === recordToken
    );
    __recipientRequestLists[recordIndex].nickName = nickNameData;
    console.log("a", __recipientRequestLists);
    setState({
      recipientRequestLists: __recipientRequestLists,
    });
  };

  const recipientRequestApproveHandler = (record, flag) => {
    // console.log("table record : ", record.nickName);
    setLoader(true);
    const newNickName = record.nickName;
    const payload = {
      requestType: "RECREQAPPROVE",
      userId: AuthReducer.userID,
      rmId: record.rmId,
      aprroveFlag: flag,
      recordToken: record.recordToken,
      nickName: newNickName,
    };
    hookRecipientRequestApprove.sendRequest(payload, (res) => {
      setLoader(false);
      if (res.status === "S") {
        notification.success({ message: res.message });
        if (flag === "Y") {
          navigate("/new-transaction", {
            state: {
              fromPage: "RECIPIENT_REQUEST_LIST",
              sendAmount: record.sendAmount,
              nickName: newNickName,
              record: record,
            },
          });
        } else {
          recipientRequestListsHandler();
        }
      } else {
        notification.error({ message: res.errorMessage });
      }
    });
    // console.log('record state : ', state.recipientRequestLists);
  };

  return (
    <Fragment>
      <Spin spinning={loading}>
        <div className="recipient-requests">
          <div className="T3_container">
            {
              <Table
                columns={[
                  {
                    title: "Name",
                    dataIndex: "name",
                    render: (text, record, index) => {
                      return `${record.recvFirstName} ${record.recvLastName}`;
                    },
                  },
                  {
                    title: "Nick Name",
                    dataIndex: "nickName",
                    editable: true,
                    // onCell :''

                    render: (text, record, index) => {
                      return (
                        <RecipientRequestNickNameForm
                          key={index}
                          record={record}
                          nickNameHandler={onNickNameChangeHandler}
                        />
                        // <Form.Item
                        //   name="nickName"
                        //   style={{
                        //     margin: 0,
                        //   }}
                        //   //                     validateStatus="error"
                        //   // help="Should be combination of numbers & alphabets"
                        //   rules={[
                        //     {
                        //       required: true,
                        //       message: `Please Input `,
                        //     },
                        //   ]}
                        // >
                        //   <Input
                        //     size="large"
                        //     placeholder="Nick Name"
                        //     defaultValue={record.nickName}
                        //     onChange={(e) =>
                        //       onNickNameChangeHandler(e, record.recordToken)
                        //     }
                        //   />
                        // </Form.Item>
                      );
                    },
                  },
                  {
                    title: "Bank Name",
                    dataIndex: "bankName",
                    render: (text, record, index) => {
                      return <>{record.bankName}<br />{record.accountNo}</>;
                    },
                  },
                  {
                    title: "Amount",
                    dataIndex: "sendAmount",
                    render: (text, record, index) => {
                      return <>{record.sendCurrencyCode} {record.sendAmount}</>;
                    },
                  },
                  // {
                  //   title: "Bank Code",
                  //   dataIndex: "bankCode",
                  // },
                  {
                    title: "Country",
                    dataIndex: "countryName",
                  },
                  {
                    title: "Date",
                    dataIndex: "registrationDate",
                    render: (text, record, index) => {
                      return moment(record.registrationDate).format("DD/MM/YYYY");
                    },
                  },
                  {
                    title: `Status `,
                    dataIndex: "status",
                    className: `${recipientListConfig?.columns?.status == "DISABLED" || "hide__column"
                      }`,
                  },

                  {
                    title: "",
                    dataIndex: "",
                    key: "y",
                    render: (text, record, index) => {
                      return (
                        <>
                          <span className="px-2">
                            <CheckCircleIcon
                              color="success"
                              i={index}
                              onClick={() => recipientRequestApproveHandler(record, "Y")}
                            />
                          </span>
                          <span>
                            <CancelIcon
                              color="error"
                              i={index}
                              onClick={() => recipientRequestApproveHandler(record, "N")}
                            />
                          </span>
                        </>
                      );
                    },
                  },
                ]}
                dataSource={[...state.recipientRequestLists]}
                pagination={false}
              />
            }
          </div>
        </div>
      </Spin>
    </Fragment>
  );
}

export default RecipientRequestList;
