import React from "react";
import mobileImage from "../../../../assets/images/banners/mobileImage-signIn.svg";

const AuthTemplateTwo = (props) => {
  return (
    <div className="container-fluid p-0 m-0  h-100 auth_temp2">
      {/* {state._isShowOTPBOX && <OTPBox state={state} setState={setState} storeLoginData={storeLoginData} otpType={state.otpType} useFor="login" appState={props.appState} />} */}

      <div className="row m-0 h-100 bg-light">
        <div className="col-md-4  ">
          {/* bg-light text-dark shadow-md rounded   */}
          <div className="row justify-content-center align-items-center h-100">
            <div className="col-md-12">
            {/* <div className="pt-5 ml-sm-2  ">{props.children}</div> */}
            <div className="card signIn-box">
                <div class="card-body">{props.children}</div>
              </div>
            </div>

          </div>
        </div>
   
        <div className="col-md-8 col-sm-24 h-100 bg-gradient-blue-violet order-xs-2 order-sm-1 order-md-2 px-100">
          <div className="row h-100 justify-content-center align-items-center">
            <div className="col-12 col-md-8 col-lg-8 col-xl-6">
              <div className="w-100 h-100 text-center">
                <img src={mobileImage}  className="w-100" alt="Mobile Banner" />
              </div>
              <div className="mt-5">
                <h2 className="w-100 mx-auto text-center text-white">
                  Fast, Efficient and Productive
                </h2>
                <div className="w-100 text-center text-white">
                  In this kind of post, the bloggerintroduces a person they’ve
                  interviewed and provides some background information about the
                  intervieweeand their work following this is a transcript of
                  the interview.
                </div>
              </div>
            </div>
          </div>

          {/* <ExchangeRate /> */}
        </div>
      </div>
    </div>
  );
};

export default AuthTemplateTwo;
