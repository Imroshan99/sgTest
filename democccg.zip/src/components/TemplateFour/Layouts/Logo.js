import { useSelector } from "react-redux";
import { getProcessingPartner } from "../../../services/utility/group";

const Logo = () => {

    const AuthReducer = useSelector((state) => state.user);

    const proccessingPartner = getProcessingPartner(AuthReducer.sendCountryCode)

    // if via partner
    if (proccessingPartner === 'VIAMERICAS') {
        return <img
            src={`images/${AuthReducer.groupId}/powered_by_viamericas.png`}
            height="68px"
            alt="Logo"
        />
    }
    return <img
        src={`images/${AuthReducer.groupId}/logo.png`}
        height="68px"
        alt="Logo"
    />
}

export default Logo;