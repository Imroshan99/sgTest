import React, { useEffect } from "react";
import { useOutletContext, Link } from "react-router-dom";
import { Button } from "react-bootstrap";

const ReferAFriend = () => {
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Refer A Friend");
  }, []);
  return (
    <div>
      <section className="section">
        <div className="container">
          <h4 className="mt-1 mb-3">How it Works</h4>
          <h6 className="mt-1 mb-3">Refer your friends & family and Cash reward</h6>
          <p className="text-3 text-muted">Refer your friends & family and get rewarded with Cash when your referral make first transaction with us. The rewarded cash that you can redeem in your next transaction.</p>
          <h6 className="mt-1 mb-3">How does it work</h6>
          <p className="text-3 text-muted">Steps to get rewarded:</p>
          <ol className="text-3 text-muted">
            <li>Go to My Account. Select Refer a Friend</li>
            <li>Send your referral link to your friend</li>
            <li>Ask you friend to sign-up with the referral link shared by you.</li>
            <li>You can check status of referral sign-up & transaction</li>
            <li>You get rewarded as your referral make first transaction</li>
            <li>Use these referral rewards earned in you next transaction</li>
          </ol>
          <h6 className="mt-1 mb-3">Get Bonus Referral reward</h6>
          <p className="text-3 text-muted">The more you refer, the more you rewarded. For every 5 new users, you get bonus reward added to your account.</p>
          <h6 className="mt-1 mb-3">Start Now to get Rewarded</h6>
          <div className="d-grid">
            <Link to={"/signin"}>
              <button className="btn btn-primary text-white">Start Referring</button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ReferAFriend;
