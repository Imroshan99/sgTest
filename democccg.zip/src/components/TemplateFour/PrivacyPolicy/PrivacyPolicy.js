import React, { useEffect } from "react";
import { Link, useOutletContext } from "react-router-dom";

const PrivacyPolicy = () => {
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Privacy Policy");
  }, []);
  return (
    <div>
      <section className="section">
        <div className="container">
          <p className="text-3 text-muted">
            United Remit recognizes the expectations of its customers with regard to privacy,
            confidentiality and security of their personal information that resides with the Bank &
            its products. Keeping personal information of customers secure and using it solely for
            activities related to the Bank and preventing any misuse thereof is a top priority of
            the Bank. In this Policy, personal information means any information that relates to a
            natural person, which either directly or indirectly, in combination with other
            information available or likely to be available with the Bank, is capable of identifying
            such person. Applicability
          </p>
          <p className="text-3 text-muted">
            This Policy is applicable to personal information collected by the Bank directly from
            the customer or through the Bank's online portals (In this case United Remit),
            electronic communications as also any information collected by the Bank's server from
            the customer's browser. Information
          </p>
          <p className="text-3 text-muted">
            The Bank collects, retains and uses personal information only when it reasonably
            believes that it is for a lawful purpose and that it will help administer its business
            or provide products, services, and other opportunities to the visitor / customer. The
            Bank collects three types of information: personal, sensitive personal data or
            information and non-personal. Personal Information
          </p>
          <p className="text-3 text-muted">
            Any information that relates to a natural person, either directly or indirectly, in
            combination with other information available is capable of identifying such person;
            Information including but not limited to name, address, telephone number, e-mail,
            occupation, etc. Sensitive Personal Data or Information
          </p>
          <ul className="text-3 text-muted">
            <li>
              Sensitive personal data or information of a person means such personal information
              which consists of information relating to passwords, financial information such as
              Bank account or credit card or debit card or other payment instrument details, sexual
              orientation, physical physiological and mental health condition, medical records and
              history, biometric information, details of nominees and national identifiers including
              but not limited to: passport number etc. For customers enrolled in services provided
              by the Bank, such as online bill payment, personal information about the transaction
              is collected.
            </li>
            <li>
              Any information that is freely available or accessible in public domain or furnished
              under the Right to or any other law for the time being in force shall not be regarded
              as sensitive personal data or information for the purpose of these rules.
            </li>
            <li>
              The information you provide online is held by the Bank business that maintains your
              account or is processing your application for a new product or service.
            </li>
            <li>
              Please note that the Internet is an open system and United Remit cannot, and does not,
              guarantee that the personal information which the Registered User furnishes will not
              be intercepted or accessed by others and decrypted. United Remit, its affiliates and
              partners, and its and their respective directors, employees, agents and
              representatives shall not be liable or responsible should any confidential or other
              information provided by or pertaining to the Visitor (including credit card numbers,
              bank account numbers, passwords, personal identification numbers, IDs, transaction
              details, etc.) be intercepted and subsequently used by an unintended recipient. Non
              personal information
            </li>
          </ul>
          <p className="text-3 text-muted">
            This information includes the IP address of the device used to connect to the Bank's
            website along with other information such as browser details, operating system used, the
            name of the website that redirected the visitor to the Bank's website, etc. Also, when
            you browse our site or receive one of our emails, the Bank and our affiliated companies,
            use cookies and/or pixel tags to collect information and store your online preferences.
            Choice:
          </p>
          <p className="text-3 text-muted">
            Consent will be obtained from you when your information is collected by the Bank (In
            this case United Remit), in a manner recognized by law. Also, you will be informed of
            the choices you have for providing your personal information. Only information required
            for legal purposes or for providing services will be collected. Visitors authorize
            United Remit to exchange, share, part with all information related to the details and
            transaction history of the Visitor United Remit as affiliates / banks / financial
            institutions / credit bureaus / agencies/participation in any telecommunication or
            electronic clearing network as may be required by law, customary practice, credit
            reporting, statistical analysis and credit scoring, verification or risk management and
            shall not hold United Remit liable for use or disclosure of this information.
          </p>
          <h6 className="mt-1 mb-3">Accuracy:</h6>
          <p className="text-3 text-muted">
            The Bank has processes in place to ensure that the personal information residing with it
            is complete, accurate and current. If at any point of time, there is a reason to believe
            that personal information residing with the Bank is incorrect, the customer may inform
            the Bank in this regard. The Bank will correct the erroneous information as quickly as
            possible.
          </p>
          <h6 className="mt-1 mb-3">Purpose and Usage:</h6>
          <p className="text-3 text-muted">
            United Remit uses the information collected and appropriately notifies you to manage its
            business and offer an enhanced, personalized online experience on its website. Further,
            it enables the Bank (& United Remit) to:
            <ul>
              <li>Process applications, requests and transactions.</li>
              <li>Maintain internal records as per regulatory guidelines.</li>
              <li>Provide services to customers, including responding to customer requests.</li>
              <li>Comply with all applicable laws and regulations.</li>
              <li>Recognize the customer when he conducts online banking.</li>
              <li>Understand the needs and provide relevant product and service offers.</li>
            </ul>
          </p>
          <h6 className="mt-1 mb-3">Disclosure / Sharing</h6>
          <p className="text-3 text-muted">
            United Remit does not disclose sensitive personal data or information of a customer
            except as directed by law or as per mandate received from the customer. No specific
            information about customer accounts or other personally identifiable data is shared with
            non-affiliated third parties unless any of the following conditions is met:
            <ul>
              <li>To help complete a transaction initiated by the customer.</li>
              <li>
                To perform support services through an outsourced entity provided it conforms to the
                Privacy Policy of the Bank.
              </li>
              <li>The disclosure is necessary for compliance of a legal obligation.</li>
              <li>The information is shared with Government agencies mandated under law.</li>
              <li>The information is shared with any third party by an order under the law.</li>
            </ul>
          </p>
          <h6 className="mt-1 mb-3">Security</h6>
          <p className="text-3 text-muted">
            The security of personal information is a priority and is protected by maintaining
            physical, electronic, and procedural safeguards that meet applicable laws. Employees are
            trained in the proper handling of personal information. The Bank has internal corporate
            policy and procedures such as Grievance Redressal, Incident Management, Third Party
            Management, etc., which are available to our employees. When other companies are used to
            provide services on behalf of the Bank, it is ensured that such companies protect the
            confidentiality of personal information they receive in the same manner the Bank
            protects. Retention
          </p>
          <p className="text-3 text-muted">
            Information may be retained for a duration, required by regulatory clauses or as long as
            required to achieve the identified (and notified) purpose: Contact Information
          </p>
          <h6 className="mt-1 mb-3">Notice of change</h6>
          <p className="text-3 text-muted">
            The Company may, from time to time, change this Policy. The effective date of this
            Policy, as stated below, indicates the last time this Policy was revised or materially
            changed.
          </p>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPolicy;
