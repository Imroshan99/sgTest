import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import ProfileFlowOne from "./ProfileFlowOne/Profile";
import ProfileFlowTwo from "./ProfileFlowTwo/Profile";
import ProfileFlowThree from "./ProfileFlowThree/Profile";
import { useOutletContext } from "react-router-dom";
import { useEffect } from "react";

const Profile = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.profileModule?.flow;

  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("My Profile");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <ProfileFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
      {templateFlow === "FLOW2" && (
        <ProfileFlowTwo
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
      {templateFlow === "FLOW3" && (
        <ProfileFlowThree
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default Profile;
