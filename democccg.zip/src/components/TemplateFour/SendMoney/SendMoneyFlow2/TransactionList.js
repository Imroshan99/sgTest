import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
  createRef,
} from "react";
import {
  Table,
  Spin,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
} from "antd";
import { SearchOutlined } from "@ant-design/icons";
import IconButton from "@mui/material/IconButton";

import CancelIcon from "@mui/icons-material/Cancel";
import RepeatIcon from "@mui/icons-material/Repeat";
import ReceiptIcon from "@mui/icons-material/Receipt";

import { Link } from "react-router-dom";
import Swal from "sweetalert2";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import DefaultLayout from "../../layout/DefaultLayout";

import { TransactionAPI } from "../../../../apis/TransactionAPI";
import moment from "moment";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { Tooltip } from "@mui/material";
import useHttp from "../../../../hooks/useHttp";
import Invoice from "./Invoice";

const XrPdf = React.lazy(() => import("../sendmoney/BankThankYou/XrPdf"));
const KcbPdf = React.lazy(() => import("../sendmoney/BankThankYou/KcbPdf"));

const { Option } = Select;
const { RangePicker } = DatePicker;

export default function TransactionList(props) {
  const invRef = createRef();

  const AuthReducer = useSelector((state) => state.user);
  const [loading, setLoader] = useState(false);
  const [listType, setListType] = useState(null);
  const [fdateRange, setFdateRange] = useState([]);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      transactionLists: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,

      _invoiceTxnRefNumber: "",
      _invoiceData: [],
      pdfDetails: "",
    }
  );

  const hookGetTransactionLists = useHttp(TransactionAPI.transactionLists);
  const hookGetTxnStatement = useHttp(TransactionAPI.txnStatement);
  const hookGetTransactionReceiptDetails = useHttp(
    TransactionAPI.transactionReceiptDetails
  );
  const hookCancelTransaction = useHttp(TransactionAPI.cancelTransaction);

  const pdfRef = useRef(null);

  useEffect(async () => {
    getTransactionList(null);
  }, []);

  useEffect(async () => {
    if (state._invoiceTxnRefNumber !== "") {
      // alert("invoice download" + state._invoiceTxnRefNumber);
      html2canvas(invRef.current, { useCORS: true }).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF();
        pdf.addImage(imgData, "JPEG", 0, 0);
        pdf.save(state._invoiceTxnRefNumber + ".pdf");
      });
    }
  }, [state._invoiceTxnRefNumber]);

  const getTransactionList = (isFav) => {
    let transactiondata = {
      requestType: "TRANSACTIONLIST",
      bookingDateFrom: fdateRange.length == 2 ? fdateRange[0] : "",
      bookingDateTo: fdateRange.length == 2 ? fdateRange[1] : "",
      favouriteFlag: isFav,
      recordsPerRequest: "",
      recvNickName: "",
      startIndex: "-1",
      status: "",
      txnRefNo: "",
      userId: state.userID,
    };

    hookGetTransactionLists.sendRequest(transactiondata, function (data) {
      let resData = [];
      if (data.responseData) {
        data.responseData.forEach((detail, i) => {
          let data = {
            key: i,
            date_sent: `${moment(detail.bookingDate).format("DD-MMM-YYYY")}`,
            sent_to: `${detail.receiverName}`,
            amount_debited: `${detail.amount}`,
            amount_deliverd: `${detail.recvAmount}`,

            c_promocode_rate: `${detail.category_promoCodeRate}`,
            rate: `${detail.exchangeRate}`,

            track_id_ref_no: `${detail.txnRefNo}`,
            rgtn: `${detail.rgtn}`,
            txn_status: `${detail.txnStatus}`,
            date_delivered: `${
              detail.txnCompletedDate != ""
                ? moment(detail.txnCompletedDate).format("DD-MMM-YYYY")
                : ""
            }`,
            bookingDate: detail.bookingDate,
            bookingDateTZ: detail.bookingDateTZ,
          };

          resData.push(data);
        });
        setState({ transactionLists: resData });
      } else {
        setState({ transactionLists: resData });
      }
    });
  };

  const txnStatement = () => {
    let payload = {
      requestType: "TXNSTATEMENT",
      txnRefNo: "",
      recvNickName: "",
      status: "",
      bookingDateFrom: fdateRange.length == 2 ? fdateRange[0] : "",
      bookingDateTo: fdateRange.length == 2 ? fdateRange[1] : "",
      favouriteFlag: "",
      userId: state.userID,
    };

    hookGetTxnStatement.sendRequest(payload, function (data) {
      if (data.status == "S") {
        notification.success({ message: data.message });
      } else {
        notification.success({ message: data.errorMessage });
      }
    });
  };

  const onClickViewAndDownload = (txnRefno) => {
    const payload = {
      requestType: "TXNDETAILS",
      rgtn: "",
      txnRefNo: txnRefno,
      userId: state.userID,
    };

    hookGetTransactionReceiptDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        // setState({
        //   _invoiceTxnRefNumber: data.txnRefNumber,
        //   _invoiceData: data,
        // });
        // downloaTxnDetail(data);
        // downloaTxnDetail(data);
        setState({ pdfDetails: data });
        downloadPdf();
      }
    });
  };

  var searchInput;
  const getColumnSearchProps = (dataIndex) => ({
    filterDropdown: ({
      setSelectedKeys,
      selectedKeys,
      confirm,
      clearFilters,
    }) => (
      <div className="custom-filter-dropdown">
        <Input
          ref={(node) => {
            searchInput = node;
          }}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) =>
            setSelectedKeys(e.target.value ? [e.target.value] : [])
          }
          onPressEnter={() => handleSearch(selectedKeys, confirm)}
        />
        <button
          className="btn btn-primary text-white"
          onClick={() => handleSearch(selectedKeys, confirm)}
        >
          Search
        </button>
        <button onClick={() => handleReset(clearFilters)} className="btn">
          Reset
        </button>
      </div>
    ),
    filterIcon: (filtered) => (
      <SearchOutlined style={{ color: filtered ? "#1890ff" : undefined }} />
    ),
    onFilter: (value, record) =>
      record[dataIndex].toString().toLowerCase().includes(value.toLowerCase()),
    onFilterDropdownVisibleChange: (visible) => {
      if (visible) {
        setTimeout(() => searchInput.select());
      }
    },
  });

  const handleSearch = (selectedKeys, confirm) => {
    confirm();
  };

  const handleReset = (clearFilters) => {
    clearFilters();
  };

  const onCancelTranscationHandler = (rgtn) => {
    // alert(rgtn);
    const payloadCancelTrn = {
      requestType: "CANCELTRANSACTIONS",
      rgtn: rgtn,
      userId: state.userID,
      // txnRefNo: txnRefno,
    };

    hookCancelTransaction.sendRequest(payloadCancelTrn, function (data) {
      if (data.status == "S") {
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            getTransactionList(null);
          }
        });
      }
    });
  };

  const columns = [
    { title: "Date Sent", dataIndex: "date_sent" },
    {
      title: "Sent To",
      dataIndex: "sent_to",
      ...getColumnSearchProps("sent_to"),
    },
    { title: "Amount Debited", dataIndex: "amount_debited" },
    { title: "Amount Deliverd", dataIndex: "amount_deliverd" },
    { title: "Category / Promocode Rate", dataIndex: "c_promocode_rate" },
    { title: "Rate", dataIndex: "rate" },
    {
      title: "Track Id/Ref No",
      dataIndex: "track_id_ref_no",
      ...getColumnSearchProps("track_id_ref_no"),
    },
    {
      title: "Status",
      dataIndex: "txn_status",
      ...getColumnSearchProps("txn_status"),
    },
    { title: "Date Delivered", dataIndex: "date_delivered" },
    {
      title: "Action",
      dataIndex: "",
      width: "30%",
      align: "right",
      render: (text, record, index) => {
        // console.log("record", record);

        let diffTime = moment(new Date()).diff(new Date(record.bookingDate));

        let duration = moment.duration(diffTime);
        let asMinutes = duration.asMinutes();
        // console.log(duration.asMinutes());
        return (
          <>
            {asMinutes <= 30 && (
              <Tooltip title="Cancel Transcation">
                <IconButton
                  color="error"
                  component="span"
                  onClick={() => {
                    onCancelTranscationHandler(record.rgtn);
                  }}
                >
                  <CancelIcon />
                </IconButton>
              </Tooltip>
            )}
            <Tooltip title="Repeat Transcation">
              <Link
                className="text-primary mx-2 my-2"
                to={{
                  pathname: "/repeat-transaction",
                }}
                state={{ rgtn: record.rgtn, txnRefNo: record.track_id_ref_no }}
              >
                <RepeatIcon />
              </Link>
            </Tooltip>
            <Tooltip title="View and Download Invoice">
              <button
                className="text-primary my-2"
                onClick={() => onClickViewAndDownload(record.track_id_ref_no)}
              >
                <ReceiptIcon />
              </button>
            </Tooltip>
          </>
        );
      },
    },
  ];

  const onClickSearch = () => {
    if (listType == "favourite") {
      getTransactionList("1");
    } else if (listType == "statement") {
      txnStatement();
    } else {
      getTransactionList(null);
    }
  };

  const downloadPdf = () => {
    html2canvas(pdfRef.current, {
      windowWidth: "800px",
      scale: 1,
    }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      pdf.addImage(imgData, "JPEG", 0, 0);
      // pdf.output('dataurlnewwindow');
      pdf.save(`txn-details-pdf.pdf`);
    });
  };

  const downloaTxnDetail = (txnReceiptDetail) => {
    var doc = new jsPDF();
    doc.setFontSize(14);
    doc.text(10, 25, `Your transaction is successful.`);

    doc.setTextColor(0, 0, 0);
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.1);
    doc.line(10, 40, 200, 40);

    doc.text(10, 49, "Transfer tracking number:");
    doc.text(70, 49, txnReceiptDetail.txnRefNumber);
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.05);
    doc.line(10, 55, 200, 55);

    doc.text(10, 62, "Sender details");
    doc.text(10, 70, "Name:");
    doc.text(25, 70, txnReceiptDetail.customerName);
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.05);
    doc.line(10, 78, 200, 78);

    doc.text(10, 87, "Recipient Details");
    doc.text(10, 97, "Name:");
    doc.text(25, 97, txnReceiptDetail.receiverName);
    doc.text(10, 107, "Bank Account Name:");
    doc.text(60, 107, txnReceiptDetail.recvBankName);
    doc.text(10, 117, "Account Number:");
    doc.text(60, 117, txnReceiptDetail.recvAccNumber);
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.05);
    doc.line(10, 122, 200, 122);

    doc.autoTable({ html: ".table" });
    // doc.text(10, 128, "Payment Details");
    var finalY = doc.lastAutoTable.finalY || 15;
    // doc.autoTable({
    //   startY: finalY + 122,
    //   // head: [['ID', 'Name', 'Email', 'Country', 'IP-address']],
    //   body: [
    //     [
    //       "Transfer tracking number:",
    //       txnReceiptDetail.txnRefNumber,
    //       "Initiated at:",
    //       txnReceiptDetail.bookingDate,
    //     ],
    //     [
    //       "Payment Mode:",
    //       "Debit Card",
    //       "Applied Exchange Rate:",
    //       "1 GBP = 18.71 INR",
    //     ],
    //     [
    //       "Transfer Amount:",
    //       `${txnReceiptDetail.amountPayable} GBP`,
    //       "Transfer Fees:",
    //       `${txnReceiptDetail.totalFee} GBP`,
    //     ],
    //     ["Promo Code:", "", "M21 Reward:", "0.00 GBP or INR"],
    //     [
    //       "Receiver Gets:",
    //       `${txnReceiptDetail.recvAmount} INR`,
    //       "Estimated Time of Arrival:",
    //       txnReceiptDetail.expDeliveryDate,
    //     ],
    //     ["Purpose of payment:", txnReceiptDetail.purposeDesc, "", ""],
    //   ],
    // });

    // doc.text(10, 195, "Kindly note:");
    // doc.setFontSize(12);
    // doc.text(
    //   10,
    //   203,
    //   `• The Tracking number ${txnReceiptDetail.txnRefNumber} is unique and is valid only for this transoction.`
    // );
    // doc.text(
    //   10,
    //   210,
    //   "   DO NOT PRECEDE the Tracking Number with any other comment when checking the status."
    // );
    // doc.text(
    //   10,
    //   220,
    //   "• Timelines exclude Saturday and Sunday and bank holidays in the UK, USA and India."
    // );
    // doc.text(10, 230, "• Terms & Conditions apply. ");
    // doc.text(10, 240, "• Need Help, Click here");

    doc.save(`${txnReceiptDetail.txnRefNumber}.pdf`);
  };

  const PdfPage = () => {
    const pdfAuthGroupId = useSelector((state) => state.user);
    switch (pdfAuthGroupId.groupId) {
      case "MF":
        return <KcbPdf pdfRef={pdfRef} pdfDetails={state.pdfDetails} />;
      case "KCB":
        return <KcbPdf pdfRef={pdfRef} pdfDetails={state.pdfDetails} />;
      case "XR":
        return <XrPdf pdfRef={pdfRef} pdfDetails={state.pdfDetails} />;
      default:
        return <KcbPdf pdfRef={pdfRef} pdfDetails={state.pdfDetails} />;
    }
  };

  return (
    <Fragment>
      <div>
        <PdfPage />
      </div>

      <div className="p-2 inner_title_wrapper">
        <div className="container">
          <h2 className="mb-0 inner_title">My Transactions</h2>
        </div>
      </div>
      {/* <div
        style={{
          opacity: 0,
          position: "absolute",
          width: 0,
          height: 0,
          overflow: "hidden",
        }}
      >
        <Invoice
          ref={invRef}
          _invoiceTxnRefNumber={state._invoiceTxnRefNumber}
        />
      </div> */}
      <Spin spinning={loading} delay={100}>
        <DefaultLayout
          accessToken={props.appState.accessToken}
          isLoggedIn={props.appState.isLoggedIn}
          publicKey={props.appState.publicKey}
        >
          <div className="card p-4 mb-4">
            <div className="row d-flex justify-content-center align-items-center">
              <div className="col col-md-4 col-sm-4 col-lg-4">
                <Select
                  size="large"
                  className="w-100"
                  placeholder="Select"
                  defaultValue="all"
                  onChange={(v) => setListType(v)}
                >
                  <Option value="all">All</Option>
                  <Option value="favourite">Favourites</Option>
                  <Option value="statement">Statements</Option>
                </Select>
              </div>
              <div className="col col-md-4 col-sm-4 col-lg-4">
                <RangePicker
                  allowClear
                  size="large"
                  format="YYYY-MM-DD"
                  onChange={(value, dateString) => {
                    value !== null
                      ? setFdateRange(dateString)
                      : setFdateRange([]);
                  }}
                />
              </div>
              <div className="col col-md-4 col-sm-4 col-lg-4">
                <button
                  className="btn btn-primary text-white"
                  onClick={onClickSearch}
                >
                  {listType == "statement" ? "Send To Email" : "Submit"}
                </button>
              </div>

              {listType == "statement" && (
                <div className="col col-md-12 col-sm-12 col-lg-12">
                  <h3>Receive an e-statement on your registered Email ID </h3>
                  <p>
                    Choose a date range you wish to receive an e-statement for.
                    A request will be placed and you will receive the
                    e-statement within 24 hours.
                  </p>
                </div>
              )}
            </div>
          </div>

          {listType != "statement" && (
            <div className="card rounded p-4 mb-4">
              <div className="d-flex justify-content-end">
                <Link
                  to={"/new-transaction"}
                  className="btn btn-primary text-white mb-3"
                >
                  New Transaction
                </Link>
              </div>
              {
                <Table
                  columns={columns}
                  dataSource={state.transactionLists}
                  pagination={state.transactionLists.length > 10}
                />
              }
            </div>
          )}
        </DefaultLayout>
      </Spin>
    </Fragment>
  );
}
