import * as React from "react";
import Typography from "@mui/material/Typography";
import {
  Form,
  Input,
  Select,
  Spin,
  Space,
  Radio,
  Row,
  Col,
  Button,
} from "antd";
import { EditOutlined } from "@ant-design/icons";
import { Link } from "react-router-dom";

export default function Receiver(props) {
  const editTransaction = () => {
    props.setState({ activeStep: 0 });
  };

  return (
    <React.Fragment>
      <h4>
        Receiver Details
        <button
          onClick={editTransaction}
          className="btn btn-light btn-sm btn-flex  ms-3"
        >
          <EditOutlined className="me-1" />
          Edit
        </button>
      </h4>
      <br />
      <div className="row mb-5">
        <div className="col col-xs-12 col-sm-12">
          <div className="row d-flex justify-content-between bottom_border mb-3">
            <div className="col d-block">
              <p className="">
                <strong>Sending To:</strong>
              </p>
            </div>
            <div className="col text-end ">
              <p className="">{props.state.receiverName}</p>
            </div>
          </div>
          <div className="row d-flex justify-content-between bottom_border mb-3">
            <div className="col d-block">
              <p className="">
                <strong>Delivery Option:</strong>
              </p>
            </div>
            <div className="col text-end ">
              <p className="">{props.state.deliveryOption}</p>
            </div>
          </div>
          <div className="row d-flex justify-content-between bottom_border mb-3">
            <div className="col d-block">
              <p className="">
                <strong>Account Details:</strong>
              </p>
            </div>
            <div className="col text-end ">
              <p className="">
                {props.state.receiverBankName} {props.state.receiverBankCode}
              </p>
            </div>
          </div>
          <div className="row d-flex justify-content-between">
            <div className="col d-block">
              <p className="">
                <strong>Bank Branch:</strong>
              </p>
            </div>
            <div className="col text-end ">
              <p className="">{props.state.receiverBankBranch}</p>
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-6">
          <button
            className="btn btn-primary-light me-2"
            onClick={() => props.setState({ activeStep: 0 })}
          >
            Back
          </button>
        </div>
        <div className="col-6 text-end">
          <button
            htmlType="submit"
            className="btn btn-primary"
            onClick={() => props.setState({ activeStep: 2 })}
          >
            Proceed
          </button>
        </div>
      </div>
    </React.Fragment>
  );
}
