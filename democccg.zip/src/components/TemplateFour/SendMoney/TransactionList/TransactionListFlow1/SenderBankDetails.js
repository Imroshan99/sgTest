import { Modal } from "antd";
import React from "react";

const SenderBankDetails = (props) => {
  const { state, setState } = props;
  return (
    <Modal
      centered
      title="Partner Account Details"
      visible={state.isSenderBankModalVisible}
      onCancel={() => setState({ isSenderBankModalVisible: false })}
      footer={null}
    >
      {state.senderBankDetails?.map((bankDetails, index) => {
        return (
          <div className="row" key={index}>
            <div className="col-md-6 mb-3">
              LP Bank:
              <br />
              {bankDetails?.bank_name}
            </div>
            <div className="col-md-6 mb-3">
              Branch:
              <br />
              {bankDetails?.bank_branch}
            </div>
            <div className="col-md-6 mb-3">
              IBAN:
              <br />
              {bankDetails?.iban}
            </div>
            <div className="col-md-6 mb-3">
              Account:
              <br />
              {bankDetails?.bank_account_name}
            </div>
            <div className="col-md-6 mb-3">
              Account no:
              <br />
              {bankDetails?.bank_account_no}
            </div>
          </div>
        );
      })}
    </Modal>
  );
};

export default SenderBankDetails;
