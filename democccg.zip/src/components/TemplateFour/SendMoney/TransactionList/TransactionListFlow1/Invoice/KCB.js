import React from "react";
import { useSelector } from "react-redux";

function KCBInvoice(props) {
  const AuthReducer = useSelector((state) => state.user);
  const txnReceiptDetail = props.pdfDetails;

  return (
    <div ref={props.pdfRef}>
      <div className="row">
        <div className="col-md-10">
          <section className="bg-light p-3 mt-3">
            <div>
              <img
                src={require("../../../../../../assets/images/logos/" +
                  AuthReducer.groupId +
                  "_logo.png")}
                height="48px"
              />
            </div>
            <p className="mt-3">
              Money transfer request to KCB Account authorized. <br />
              Transaction Status- Transaction Booked Successfully and awaiting
              payment. <br />
              Your KCB Transaction No. (KCBTN) :
              <b>{txnReceiptDetail.txnRefNumber}</b>
            </p>
            <p className="mt-3">
              <table className="table">
                <tbody>
                  <tr>
                    <td>
                      <strong>Transaction Number</strong>
                    </td>
                    <td>{txnReceiptDetail.txnRefNumber}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Date of Booking:</strong>
                    </td>
                    <td>{txnReceiptDetail.bookingDate}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Transfer Amount:</strong>
                    </td>
                    <td>{`${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Name:</strong>
                    </td>
                    <td>{txnReceiptDetail.receiverName}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Bank Branch:</strong>
                    </td>
                    <td>{txnReceiptDetail.recvBankBranchName}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Account Number:</strong>
                    </td>
                    <td>{txnReceiptDetail.recvAccNumber}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Send Mode:</strong>
                    </td>
                    <td>{txnReceiptDetail.sendModeCode}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Transaction Status:</strong>
                    </td>
                    <td>{txnReceiptDetail.transactionStatus}</td>
                  </tr>
                </tbody>
              </table>
            </p>
            <p>
              <strong>KCB Remit Payment Policy &amp; Error Resolution</strong>
              <br />
              You have a right to dispute errors in your transaction. If you
              think there is an error, contact us within 180 days at
              ContactNumber or EmailID. You can also contact us for a written
              explanation of your rights. You can cancel the transfer request
              within 30 minutes of instructing us using the Cancel option. The
              option will not be available after 30 minutes of placing the
              transfer request. <br />
              For questions or complaints about KCB Remit Online, contact:
            </p>

            <p>
              <strong>Department of Financial Services</strong>
              <br />
              (800) 342-3736 (Monday through Friday, 8:30 AM to 4:30 PM). <br />
              (Local calls can be made to (212) 480-6400 <br />
              <strong>Consumer Financial Protection Bureau</strong> <br />
              855-411-2372 <br />
              855-729-2372 (TTY/TDD) <br />
              www.consumerfinance.gov <br />
            </p>
            <p>
              If you think there has been an error or problem with your
              remittance transfer: <br />
              Error Resolution &amp; Cancellation: <br />
              Call us at ContactNumber <br />
              Write to us at: <br />
              KCB Kenya Address or <br />
              E-mail us at EmailID <br />
              You must contact us within 180 days of the date we promised to you
              that funds would be made <br />
              available to the recipient. When you do, please tell us: <br />
              <ol>
                <li>Your name and login ID</li>
                <li>
                  The error or problem with the transfer, and why you believe it
                  is an error or problem
                </li>
                <li>The Remittance Transaction Reference</li>
              </ol>
              Number We will determine whether an error occurred within 90 days
              after you contact us and we will correct any error promptly. We
              will tell you the results within three business days after
              completing our investigation. If we decide that there was no
              error, we will send you a written explanation. You may ask for
              copies of any documents we used in our investigation. <br />
              What to do if you want to cancel a remittance transfer: <br />
              You have the right to cancel a remittance transfer instruction. In
              order to cancel, you can cancel the instruction by logging into
              your KCB Remit account and using the 'Cancel' option. You can also
              contact us at the phone number within 30 minutes of payment for
              the transfer. When you contact us, you must provide us with
              information to help us identify the transfer you wish to cancel
              including the amount and the reference number under which the
              funds were sent. Upon cancellation of the transfer instruction, we
              will not debit your US account registered with us.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

export default KCBInvoice;
