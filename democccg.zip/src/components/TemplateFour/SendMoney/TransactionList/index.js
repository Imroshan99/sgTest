import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import TransactionListFlow1 from "./TransactionListFlow1/TransactionList";
import Dashboard from "../../Layouts/Dashboard";
import { useOutletContext } from "react-router-dom";

const TransactionList = (props) => {
  const AuthReducer = useSelector((state) => state.user);

  const templateFlow =
    AuthReducer.groupIdSettings?.sendMoneyModule?.transactionList?.flow;
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("My Transactions");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <TransactionListFlow1
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default TransactionList;
