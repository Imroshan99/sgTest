import axios from "axios";
import { config } from "../config";
// import { AuthService } from "../services/AuthService";

export const achBankAccountAPI = {
  //get bank names for dropdown
  getBankNames: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/usr/acc/get-bank-name-lists`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },

   //get routing number for bankname
   getBankRoutingNumber: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/usr/acc/get-routing-number`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },

  checkDuplicateBankAccount: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/usr/acc/check-duplicate-ach-account`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },

  checkAchAccountNickName: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/usr/acc/check-ach-account-nickname`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },

  addBankAccount: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/usr/acc/add-ach-bank-accounts`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },

  
  bankAccountList: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/usr/acc/ach-account-lists`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  viewBankAccountDetails: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/usr/acc/ach-account-details`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  deleteBankAccountDetails: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/usr/acc/delete-ach-account`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
};
