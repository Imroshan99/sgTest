/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/alt-text */
import PermIdentityOutlinedIcon from "@mui/icons-material/PermIdentityOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import { useSelector } from "react-redux";
import { useState } from "react";
import UserMenu from "../../../user/UserMenu";
import { Container, Nav, Navbar } from "react-bootstrap";
import { Link, NavLink, useNavigate } from "react-router-dom";
export default function Header6() {
  const AuthReducer = useSelector((state) => state.user);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const navigate = useNavigate();

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleCloseUserMenu = (e) => {
    setAnchorElUser(null);
    if (e === "Logout") {
      window.location.href = "/";
    }
  };
  return (
    <>
      <header className="header-bgdark-svg">
        {/* <svg className="bgdark-svg"
         viewBox="0 0 1512 266"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M0 0H1512V216C1512 243.614 1489.61 266 1462 266H50C22.3858 266 0 243.614 0 216V0Z"
            fill="#1E1E2D"
          />
        </svg> */}

        <svg className="bgdark-svg" viewBox="0 0 1512 369" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 0h1512l-33.11 253.273c-3.12 23.894-22.85 42.161-46.91 43.448L98.248 368.053c-25.887 1.385-48.539-17.246-52.176-42.913L0 0Z" fill="#1E1E2D" />
        </svg>

        <div className="container pt-3">
          <Navbar expand="lg">
            <Container>
              <Link className="logo" to="/">
                <img src={require("../../../../../assets/images/logos/" + AuthReducer.groupId + "_logo.png")} height="48px" alt="Logo" />
              </Link>
              {AuthReducer?.isLoggedIn && (
                <>
                  <Navbar.Toggle aria-controls="basic-navbar-nav" />
                  <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ms-auto d-flex align-items-center">
                      <NavLink className="nav-item navTitles" to="/new-transaction">
                        New Transcation
                      </NavLink>
                      <NavLink className="nav-item navTitles2" to="/my-recipient">
                        Receivers
                      </NavLink>
                      <NavLink className="nav-item navTitles2 me-3" to="/my-bank-accounts">
                        Bank Accounts
                      </NavLink>
                      {/* <a class="nav-item" href="#">
                      <img src={require("../../../../../assets/images/flags/profile.png")} />
                    </a> */}
                      <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                        <Avatar
                          alt={AuthReducer.userFullName}
                          // {...stringAvatar(AuthReducer.userFullName)}
                        >
                          <PermIdentityOutlinedIcon />
                        </Avatar>
                      </IconButton>
                      <UserMenu anchorElUser={anchorElUser} handleCloseUserMenu={handleCloseUserMenu} />
                    </Nav>
                  </Navbar.Collapse>
                </>
              )}
            </Container>
          </Navbar>
          <hr />
        </div>
      </header>
    </>
  );
}
//till
