import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import useHttp from "../../../../../hooks/useHttp";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";

const SofortTrnStatusLink = ({ loginId, rgtn }) => {
  const navigate = useNavigate();

  const [sofortPayBtn, setSofortPayBtn] = useState(true);
  const [transcationIntervalId, setTranscationIntervalId] = useState();
  const [sofortBtnLoader, setSofortBtnLoader] = useState(false);

  const AuthReducer = useSelector((state) => state.user);
  const hookGetTxnSofortStatus = useHttp(TransactionAPI.getTxnSofortStatus);

  useEffect(() => {
    getTxnSofortStatusHandler();
  }, []);

  const getTxnSofortStatusHandler = () => {
    const payload = {
      requestType: "GETTXNSOFORTSTATUS",
      userId: AuthReducer.userID,
      loginId: loginId,
      rgtn: rgtn,
    };

    hookGetTxnSofortStatus.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setSofortPayBtn(data.statusFlag === "true");
      } else {
        setSofortPayBtn(true);
      }
    });
  };

  const getSofortTranscationDetails = async () => {
    try {
      const payload = {
        groupId: "XR",
        userId: AuthReducer.userID,
        loginId: loginId,
        rgtn: rgtn,
      };
      setSofortBtnLoader(true);
      const response = await TransactionAPI.sofortTransaction(payload, "");
      const data = response.data;
      if (data.status == "S") {
        return {
          tranId: data.tranId,
          redirectUrl: data.redirectUrl,
        };
      }
    } catch (error) {
      setSofortBtnLoader(false);
    }
  };

  const onSofortClickHandler = async () => {
    clearInterval(transcationIntervalId);
    const sofortResponse = await getSofortTranscationDetails();

    //Open SOFORT external URL
    window.open(sofortResponse.redirectUrl);
    let transcationInterval = setInterval(() => {
      const SOFORT_TRANS_STATUS = window.localStorage.getItem(
        sofortResponse.tranId
      );
      if (SOFORT_TRANS_STATUS) {
        clearInterval(transcationInterval);
        if (SOFORT_TRANS_STATUS === "SUCCESS") {
          Swal.fire({
            title: "Success",
            text: "Transaction Successfull",
            icon: "success",
            confirmButtonColor: "#2dbe60",
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              navigate("/");
            }
          });
        }
        if (SOFORT_TRANS_STATUS === "FAILED") {
          Swal.fire({
            title: "Failed",
            text: "Payment through Sofort has failed. Click here to try again with Sofort.",
            icon: "error",
            showCancelButton: true,
            confirmButtonColor: "#2dbe60",
            confirmButtonText: "Retry",
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              // setSofortBtnLoader(false);
              onSofortClickHandler();
            }
          });
        }
        if (SOFORT_TRANS_STATUS === "TIMEOUT") {
          Swal.fire({
            title: "Timeout",
            text: "Transaction timeout",
            icon: "error",
            confirmButtonColor: "#2dbe60",
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              setSofortBtnLoader(false);
            }
          });
        }
      }
    }, 2000);

    setTranscationIntervalId(transcationInterval);
  };

  return (
    <>
      {sofortPayBtn && (
        <button
          className="btn btn-sm btn-info px-3 my-2"
          onClick={onSofortClickHandler}
        >
          Click here to retry with SOFORT
        </button>
      )}
    </>
  );
};

export default SofortTrnStatusLink;
