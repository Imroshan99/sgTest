import React, { useEffect, useReducer, useState } from "react";
import {
  Form,
  Input,
  Radio,
  Tabs,
  Select,
  notification,
  Button,
  Spin,
  AutoComplete,
} from "antd";
import { Row, Col, Container } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { useSelector } from "react-redux";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import useHttp from "../../../../hooks/useHttp";
import CustomInput from "../../../../reusable/CustomInput";
import { inputValidations } from "../../../../services/validations/validations";


const { TabPane } = Tabs;
const { Option } = Select;
export default function AddRecipientStep1(props) {
  // const [ifscAddress, setIfscAddress] = useState("");
  // const [ifscCode, setIfscCode] = useState("");
  // const [showIfscAddress, setShowIfscAddress] = useState(false);
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const AddRecipientFormConfig =
    ConfigReducer.groupIdSettings.recipientModule.AddRecipientForm;
  const location = useLocation();
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AddRecipientFormConfig?.twoFA
        ? AddRecipientFormConfig.twoFA
        : AuthReducer.twofa,
      // twofa:   AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      nationalities: [],
      stateCities: [],
      branch: "",
      _showOTPBOX: false,
      showConfirmAddRecipient: false,
      isConfirmAddRecipient: false,
      formData: {},
      verificationToken: "",
      isOTPVerfied: false,
      isModalVisible: false,
      otpType: "RA",
      branchCode: "",
      bankBranch: "",
      bankAddress: "",
      bankState: "",
      bankCity: "",
      bankName: "",
      isSameBank: "N",
      bankCode: "",
      bankId: "",
      bankCountry: "",
      isSelectedIFSC: false,
      bankLists: [],
      cityLists: [],
      branchLists: [],
      phoneCodes: [],
      occupationLists: [],
      relationshipLists: [],
      deliveryOptionsList: [],
      deliveryOption: "",
      accountNumber: "",
      accountType: "",
      stateLists: [],
      dob: "",
      redirectPage: "",
      redirectPageState: [],
      selectedBranch: {},
    }
  );
  // const hookGetNationality = useHttp(GuestAPI.getNationality);
  const hookGetCountryPhoneCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetRelationshipLists = useHttp(GuestAPI.relationshipLists);
  const hookGetDeliveryOptions = useHttp(GuestAPI.deliveryOptions);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetBankBranchData = useHttp(GuestAPI.bankBranchData);
  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookGetBankStateCities = useHttp(ReceiverAPI.bankStateCities);
  const hookGebankBranches = useHttp(ReceiverAPI.bankBranches);
  const hookGetBankBranchState = useHttp(GuestAPI.getBankBranchState);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getDeliveryOptions();
    getCoutryCodes();
    getRelationshipLists();
    getStateLists();
    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
  }, []);
  useEffect(async () => {
    if (!state.isSelectedIFSC) {
      getBankList();
    }
  }, [state.isSelectedIFSC]);

  const getCoutryCodes = async () => {
    const payload = {
      requestType: "COUNTRYPHONECODE",
    };
    props.setLoader(true);
    hookGetCountryPhoneCodes.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ phoneCodes: data.responseData });
        props.setLoader(false);
      }
    });
  };
  const getRelationshipLists = async () => {
    let payload = {
      requestType: "RELAIONSHIPLISTS",
    };
    props.setLoader(true);
    hookGetRelationshipLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ relationshipLists: data.responseData });
      }
      props.setLoader(false);
    });
  };
  const getDeliveryOptions = async () => {
    let payload = {
      requestType: "RECVMODE",
      countryCode: AuthReducer.recvCountryCode,
    };
    props.setLoader(true);
    hookGetDeliveryOptions.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ deliveryOptionsList: data.responseData });
        props.setLoader(false);
      }
    });
  };
  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.recvCountryCode,
      keyword: "",
    };
    props.setLoader(true);
    hookGetBankBranchState.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        props.setLoader(false);
      }
    });
  };
  const onChangeIFSCCode = async (e) => {
    // setIfscCode(e.target.value);
    if (e.target.value.length == 11) {
      // props.setLoader(true);state
      const payload = {
        requestType: "BANKBRANCHDATA",
        branchCode: e.target.value,
      };
      props.setLoader(true);
      hookGetBankBranchData.sendRequest(payload, function (data) {
        props.setIfscCodeValidator(data);
        if (data.status == "S") {
          props.newForm.setFieldsValue({
            bankName: data.bankName,
            cityName: data.bankCity,
            bankState: data.bankState,
            branch: data.branchName,
          });
          props.setLoader(false);
          // props.setLoader(false);
          notification.success({ message: data.message });
          // setShowIfscAddress(true);
          props.setIfscBranchName(data);
          // setIfscAddress(data.bankAddress);
          setState({
            branch: data,
            branchCode: data.branchCode,
            bankBranch: data.bankBranch,
            bankAddress: data.bankAddress,
            bankState: data.bankState,
            bankCity: data.bankCity,
            bankName: data.bankName,
            bankId: data.bankId,
            bankCountry: data.bankCountry,
          });
        } else {
          props.setLoader(false);
          props.newForm.setFieldsValue({
            bankName: "",
            cityName: "",
            bankState: "",
            branch: "",
          });
          // notification.error({ message: res.data.errorMessage });
          // setShowIfscAddress(false);
          props.newForm.setFields([
            { name: "IFSCCode", errors: [data.errorMessage] },
          ]);
          setState({
            branch: "",
            branchCode: "",
            bankBranch: "",
            bankAddress: "",
            bankState: "",
            bankCity: "",
            bankName: "",
            bankId: "",
            bankCountry: "",
          });
        }
      });
    } else {
      setState({
        branch: "",
        branchCode: "",
        bankBranch: "",
        bankAddress: "",
        bankState: "",
        bankCity: "",
        bankName: "",
        bankId: "",
        bankCountry: "",
      });
    }
  };
  const getBankList = async (e) => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.recvCountryCode,
      userId: state.userID,
    };
    props.setLoader(true);
    hookGetBankLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
        props.setLoader(false);
      }
    });
  };
  const onSelectBank = async (row) => {
    const bankName = row.value;
    let bankCode = row.label.props.bankCode;
    let isSameBank = row.label.props.isSameBank;
    setState({
      bankName: bankName,
      bankCode: bankCode,
      isSameBank: isSameBank,
    });
    // form1.setFieldsValue({ cityName: undefined, branch: undefined });
    const payload = {
      requestType: "BankStateCities",
      countryCode: AuthReducer.recvCountryCode,
      state: "",
      bankName: bankName,
      search: "",
    };
    props.setLoader(true);
    hookGetBankStateCities.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
        props.setLoader(false);
      }
    });
  };
  const onSetectCity = async (cityName) => {
    setState({ bankCity: cityName });
    const payload = {
      requestType: "BANKBRANCHES",
      countryCode: AuthReducer.recvCountryCode,
      bankCode: state.bankCode,
      bankName: state.bankName,
      cityCode: "",
      stateCode: "",
      city: cityName,
      keyword: "",
    };
    props.setLoader(true);
    hookGebankBranches.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          branchLists: data.responseData,
        });
        props.setLoader(false);
      }
    });
  };
  const onSetectBranch = async (value) => {
    let branch = state.branchLists.find((i) => {
      if (i.branchName == value) {
        return i;
      }
    });
    props.setState({ selectedBranch: branch });
    props.newForm.setFieldsValue({ bankState: branch.bankState });
    setState({
      branchCode: branch.branchCode,
      bankBranch: branch.branchName,
      bankAddress: branch.bankAddress,
      bankState: branch.bankState,
      bankCity: branch.bankCity,
      bankName: branch.bankName,
      bankId: branch.bankId,
      bankCountry: branch.bankCountry,
    });
  };
  const onChangeDeliveryOptionHandler = (value) => {
    let bankName = value;
    setState({
      deliveryOption: value,
      bankName: bankName,
    });
  };
  const onChangeAccountNumberHandler = (value) => {
    setState({
      accountNumber: value.target.value,
    });
  };
  const onChangeAccountTypeHandler = (value) => {
    setState({
      accountType: value.target.value,
    });
  };
  let onFinish = (value) => {
    if (props.activeTab == 1) {
      if (props.ifscCodeValidator.status == "S") {
        let finalValue = {
          ...value,
          ...props.ifscBranchName,
        };
        props.saveFormDataHandler(finalValue);
        props.setAddRecipentModalSetp2(false);
      } else {
        props.newForm.setFields([
          { name: "IFSCCode", errors: [props.ifscCodeValidator.errorMessage] },
        ]);
      }
    } else {
      let finalValue = { ...value, ...props.state.selectedBranch };
      props.saveFormDataHandler(finalValue);
      props.setAddRecipentModalSetp2(false);
    }
  };
  let activeTabHandler = (key) => {
    if (key !== props.activeTab) {
      // setIfscAddress("");
      props.newForm.resetFields();
    }
    props.setActiveTab(key);
  };
  return (
    <div className="AddReceipentStep1">
      <Form form={props.newForm} onFinish={onFinish}>
        <div className="row mb-3">
          <div className="col-12 col-md-3">
            <label>Delivery Options</label>
          </div>
          <div className="col-12 col-md-6">
            <CustomInput className="mb-0" name="deliveryOption" label="Delivery Options" showLabel={false} type="select" required placeholder="Select Delivery Options" onChange={onChangeDeliveryOptionHandler}>
              {state.deliveryOptionsList.map((value, i) => {
                return (
                  <Option key={i} value={value.recvModeCode}>
                    {value.recvMode}
                  </Option>
                );
              })}
            </CustomInput>
             
          </div>
        </div>
      </Form>
      <div>
        <label>Do you know the IFSC of beneficiary bank?</label>
        <Tabs defaultActiveKey={props.activeTab} onChange={activeTabHandler}>
          <TabPane tab="Yes" key="1">
            {props.activeTab == 1 && (
              <Form form={props.newForm} autoComplete="none" onFinish={onFinish}>
                <Row>
                  <Col md={6}>
                    <CustomInput className="mb-0" name="IFSCCode" min={11} max={11} label="Receivers IFSC Code" onChange={onChangeIFSCCode} autoComplete="off" placeholder="Enter Your IFSC Code" required />
                     
                  </Col>
                </Row>
                <Row>
                  <Col sm={12} md={6}>
                    <div>
                      <CustomInput name="bankName" label="Bank Name">
                        <AutoComplete disabled showSearch labelInValue placeholder="Bank Name" onChange={onSelectBank}></AutoComplete>
                      </CustomInput>
                   
                    </div>
                  </Col>
                  <Col sm={12} md={6}>
                    <div>
                      <CustomInput name="bankState" label="Bank Branch State">
                        <AutoComplete disabled showSearch placeholder="Bank Branch State"></AutoComplete>
                      </CustomInput>
                    
                    </div>
                  </Col>
                </Row>
                <Row>
                  <Col sm={12} md={6}>
                    <div>
                      <CustomInput name="cityName" label="City">
                        <AutoComplete disabled showSearch onSelect={onSetectCity} placeholder="City"></AutoComplete>
                      </CustomInput>

                      
                    </div>
                  </Col>
                  <Col sm={12} md={6}>
                    <div>
                      <CustomInput name="branch" label="Branch">
                        <AutoComplete disabled autoComplete="off" showSearch onSelect={onSetectBranch} placeholder="Branch"></AutoComplete>
                      </CustomInput>
                     
                    </div>
                  </Col>
                </Row>
                <div className="row">
                  <div className="col-12 col-md-6">
                    <div>
                      <CustomInput
                        name="accountNo"
                        label="Account Number"
                        autoComplete="off"
                        type="password"
                        className="input_account_no"
                        onChange={onChangeAccountNumberHandler}
                        placeholder="Enter your Account Number"
                        inputValidations={[...inputValidations.accountNumber(AuthReducer.recvCountryCode)]}
                        onPaste={(e) => {
                          e.preventDefault();
                          return false;
                        }}
                        onCopy={(e) => {
                          e.preventDefault();
                          return false;
                        }}
                        visibilityToggle={false}
                        required
                      />
                     
                    </div>
                  </div>
                  <div className="col-12 col-md-6">
                    <div>
                      <CustomInput
                        name="accConNum"
                        className="input_account_no"
                        placeholder="Enter your Confirm Account Number"
                        label="Confirm Account Number"
                        required
                        validationRules={[
                          ...inputValidations.accountNumber(AuthReducer.recvCountryCode),
                          ({ getFieldValue }) => ({
                            validator(rule, value) {
                              if (!value || getFieldValue("accountNo") === value) {
                                return Promise.resolve();
                              }
                              return Promise.reject("The two account number that you entered do not match!");
                            },
                          }),
                        ]}
                        onPaste={(e) => {
                          e.preventDefault();
                          return false;
                        }}
                        onCopy={(e) => {
                          e.preventDefault();
                          return false;
                        }}
                      />
                      
                    </div>
                  </div>
                </div>
                <Row>
                  <Col>
                    <CustomInput name="accountType" label="Account Type" required>
                      <Radio.Group className="d-flex" onChange={onChangeAccountTypeHandler}>
                        <Radio value={"S"}>Savings Account</Radio>
                        <Radio value={"NE"}>NRE</Radio>
                        <Radio value={"NO"}>NRO</Radio>
                      </Radio.Group>
                    </CustomInput>
                    
                  </Col>
                  <Col className="d-flex justify-content-end align-items-center">
                    <button className="btn btn-light text-primary m-w-100" type="submit">
                      Next
                    </button>
                  </Col>
                </Row>
              </Form>
            )}
          </TabPane>
          <TabPane tab="No" key="2">
            {props.activeTab == 2 && (
              <Form form={props.newForm} onFinish={onFinish} autoComplete="off">
                <div className="Modal-Bottom-Content-Container-2">
                  <Row>
                    <Col sm={12} md={6}>
                      <div>
                        <CustomInput name="bankName" label="Bank Name" type="select" showSearch labelInValue placeholder="Select Bank" onChange={onSelectBank} required>
                          {state.bankLists.map((bank, i) => {
                            return (
                              <Option key={i} value={bank.bankName}>
                                <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                                  {bank.bankName}
                                </span>
                              </Option>
                            );
                          })}
                        </CustomInput>
                         
                      </div>
                    </Col>
                    <Col sm={12} md={6}>
                      <div>
                        <CustomInput name="bankState" showSearch placeholder="Select State" type="select" label="Bank Branch State" required>
                          {state.stateLists.map((state, i) => {
                            return (
                              <Option key={i} value={state.stateCode}>
                                {state.state}
                              </Option>
                            );
                          })}
                        </CustomInput>
                         
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm={12} md={6}>
                      <div>
                        <CustomInput name="cityName" howSearch onSelect={onSetectCity} placeholder="Select City" type="select" required label="City">
                          {state.cityLists.map((city, i) => {
                            return (
                              <Option key={i} value={city.city}>
                                {city.city}
                              </Option>
                            );
                          })}
                        </CustomInput>
                        
                       
                      </div>
                    </Col>
                    <Col sm={12} md={6}>
                      <div>
                        <CustomInput name="branch" autoComplete="off" showSearch onSelect={onSetectBranch} placeholder="Select Branch" type="select" label="Branch" required>
                          {state.branchLists.map((branch, i) => {
                            return (
                              <Option key={i} value={branch.branchName}>
                                {branch.branchName}
                              </Option>
                            );
                          })}
                        </CustomInput>
                         
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm={12} md={6}>
                      <div>
                        <CustomInput
                          name="accountNo"
                          autoComplete="off"
                          type="password"
                          label="Account Number"
                          className="input_account_no"
                          onChange={onChangeAccountNumberHandler}
                          placeholder="Enter your Account Number"
                          required
                          onPaste={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCopy={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          visibilityToggle={false}
                          validationRules={[...inputValidations.accountNumber(AuthReducer.recvCountryCode)]}
                        />
                         
                      </div>
                    </Col>
                    <Col sm={12} md={6}>
                      <div>
                        <CustomInput
                          name="accConNum"
                          className="input_account_no"
                          placeholder="Enter your Confirm Account Number"
                          label="Confirm Account Number"
                          required
                          onPaste={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCopy={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          validationRules={[
                            ...inputValidations.accountNumber(AuthReducer.recvCountryCode),
                            ({ getFieldValue }) => ({
                              validator(rule, value) {
                                if (!value || getFieldValue("accountNo") === value) {
                                  return Promise.resolve();
                                }
                                return Promise.reject("The two account number that you entered do not match!");
                              },
                            }),
                          ]}
                        />
                         
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <div className="Account-Type-Container">
                        <CustomInput name="accountType" label="Account Type" required>
                          <Radio.Group onChange={onChangeAccountTypeHandler} className="d-flex">
                            <Radio value={"S"}>Savings Account</Radio>
                            <Radio value={"NE"}>NRE</Radio>
                            <Radio value={"NO"}>NRO</Radio>
                          </Radio.Group>
                        </CustomInput>
                         
                      </div>
                    </Col>
                    <Col className=" d-flex justify-content-end align-items-center">
                      <button className="btn btn-light text-primary m-w-100" type="submit">
                        Next
                      </button>
                    </Col>
                  </Row>
                </div>
              </Form>
            )}
          </TabPane>
        </Tabs>
      </div>
    </div>
  );
}
