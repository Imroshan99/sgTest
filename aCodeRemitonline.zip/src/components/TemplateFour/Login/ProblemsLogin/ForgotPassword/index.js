
import AuthTemplate from "../../../Layouts/Auth";
import ForgotPasswordFlowOne from "./ForgotPasswordFlowOne";

const ForgotPassword = (props) => {
  return (
    <>
      <AuthTemplate>
        <ForgotPasswordFlowOne />
      </AuthTemplate>
    </>
  );
};

export default ForgotPassword;
