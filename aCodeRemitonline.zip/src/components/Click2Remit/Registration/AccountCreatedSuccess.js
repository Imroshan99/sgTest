import React from 'react'
import Main from '../Layouts/Main'
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import PaymentSuccess from "../../../assets/images/click2remit/Paymentsuccess.svg";

const AccountCreatedSuccess = () => {
  return (
    //  <Main>
        
            <div className="container h-100">
                <div className="row h-100">
                    <form>
                        <div className="col-md-6 col-sm-12 col-lg-6 offset-md-3 align-self-center">
                            <div className="CR-otp-form">

                                <ul className="row">
                                    <li className="back-arrow-nav   d-xs-block d-done">
                                        <img src={BackArrow} alt="" />

                                    </li>
                                    <li className="text-center">
                                        <img src={PaymentSuccess} style={{marginBottom: "30px" }}alt="" />
                                    </li>
                                    <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                                        <h4 className="text-black text-center">Account created</h4>
                                    </li>
                                    <li className="col-md-12 col-sm-12 col-lg-12">
                                        <p className="text-center">Your account has been successfully created.</p>
                                    </li>

                                </ul>

                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
         
    //  </Main>
  )
}

export default AccountCreatedSuccess