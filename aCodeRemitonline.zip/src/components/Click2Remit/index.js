import React, { useState } from "react";
import "./style.scss";
import { Helmet } from "react-helmet";
import { Outlet, Route, Routes, useLocation } from "react-router-dom";

import { useSelector } from "react-redux";
import Header from "./Layouts/Header";
import CreateAccount from "./Registration/CreateAccount";
import Login from "./Login/Login";
import CreatePassword from "./Registration/CreatePassword";
import RegisterSuccess from "./Registration/RegisterSuccess";
import EmailVerifySuccess from "./containers/EmailVerifySuccess";
import VerifyOtp from "./containers/VerifyOtp";
import InvalidOTPModal from "./containers/InvalidOTPModal";
import AccountCreatedSuccess from "./Registration/AccountCreatedSuccess";
import BeneAddSuccess from "./Beneficairy/BeneAddSuccess";
import BeneficiaryFailedAdded2 from "./Beneficairy/BeneficiaryFailedAdded2";
import BeneficiaryAddedSuccess2 from "./Beneficairy/BeneficiaryAddedSuccess2";
import BranchDetails from "./BankAccounts/BranchDetails";
import DeleteMsg from "./BankAccounts/DeleteMsg";
import HelpSupport from "./Pages/HelpSupport";
import Licence from "./Pages/Licence";
import ManageRemitterAccounts from "./BankAccounts/ManageRemitterAccounts";
import ProfileDetails from "./Profile/ProfileDetails";
import ReviewRemitterAccountDetails from "./BankAccounts/ReviewRemitterAccountDetails";
import SelectBeneDetails from "./Beneficairy/SelectBeneDetails";
import SelectRemitterAccount from "./BankAccounts/SelectRemitterAccount";
import TermsandConditions from "./Pages/TermsandConditions";
import Transactions from "./BankAccounts/Transactions";
import FindIfsc from "./Beneficairy/IFSC/FindIfsc";
import SendMoney from "./Pages/SendMoney";
import AddBeneficiaryDetails from "./Beneficairy/AddBeneficiaryDetails";
import CreateRemitterAccount from "./BankAccounts/CreateRemitterAccount";
import ReviewBeneficiaryDetails from "./Beneficairy/ReviewBeneficiaryDetails";
import ManageBeneficiaries from "./Beneficairy/ManageBeneficiaries";
import ViewBeneficiaryDetails from "./Beneficairy/ViewBeneficiaryDetails";
import EditBeneficiaryDetails from "./Beneficairy/EditBeneficiaryDetails";
import EditRemitter from "./BankAccounts/EditRemitter";
import NewTransaction from "./user/sendmoney/NewTransaction";
import RemitterAccountDetails from "./BankAccounts/RemitterAccountDetails";
import TranctionAction from "./user/sendmoney/TranctionAction";
import KycPage from "./Pages/KYC";
import ForgotPassword from "./Pages/ForgotPassword";
import { PublicRoute } from "../../Routes/PublicRoute";
import { PrivateRoute } from "../../Routes/PrivateRoute";
import Beneficiary from "./Beneficairy/Beneficiary";
import ResetPassword from "./Profile/ResetPassword";
import LandingPage from "./Pages/LandingPage";
import SamplePage from "./SamplePage";
import UserDocUpload from "./Pages/UserDocUpload";
import MenuContextProvider from "./Context/MenuContext";
import UnlockAccount from "./Pages/UnlockAccount";
import ForgotUserID from "./Pages/ForgotUserID";
import PlaidFail from "./Pages/PlaidFail";
import PlaidSuccess from "./Pages/PlaidSuccess";
import JumioFail from "./Pages/JumioFail";
import JumioSuccess from "./Pages/JumioSuccess";
import Disclaimer from "./Pages/Disclaimer";
import PrivacyPolicy from "./Pages/PrivacyPolicy";
import ViaTermsCondition from "./Pages/ViaTermsCondition";
import GeneralTermsCondition from "./Pages/GeneralTermsCondition";

// export function TestNew() {
//   const [dt, setDt] = useState(new Date())
//   useEffect(()=> {
//     setDt(new Date())
//   }, [])
//   return (
//     <>
//       <div>My subheader {dt.toISOString()}</div>
//       <Outlet />
//     </>
//   );
// }

export default function Click2Remit({ state, manageRefreshToken, manageAuth }) {
  const AuthReducer = useSelector((state) => state.user);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const _title = AuthReducer.groupIdSettings?.title;

  const aciveEmail = AuthReducer.groupIdSettings?.title;
  const aciveContact = AuthReducer.groupIdSettings?.contact?.acive;
  const aciveFeedback = AuthReducer.groupIdSettings?.feedback?.acive;
  const aciveRaiseIssue = AuthReducer.groupIdSettings?.raiseIssue?.acive;

  const handleMobileMenu = () => {
    setShowMobileMenu((showMobileMenu) => !showMobileMenu);
  };

  return (
    <>
      <MenuContextProvider>
        <Helmet>
          <title>{_title}</title>
          <meta name="description" content={_title} />
          <link
            rel="icon"
            type="image/png"
            sizes="16x16"
            href={`images/${AuthReducer.groupId + "/c2rIco.ico"}`}
          />
        </Helmet>
        <Routes>
          {/* open routes start*/}

          <Route
            // element={<Header showMobileMenu={showMobileMenu} handleMobileMenu={handleMobileMenu} />}
            element={<Header />}
          >
            <Route path="/test" element={<SamplePage />} />
            <Route path="/create-account" element={<CreateAccount />} />
            <Route path="/terms-and-condition" element={<TermsandConditions />} />
            <Route path="/help-support" element={<HelpSupport />} />
            <Route path="/licence" element={<Licence />} />
            {/* open routes end */}
            <Route
              path="/"
              element={
                <PublicRoute>
                  <LandingPage appState={state} />
                </PublicRoute>
              }
            />

            <Route
              path="/forgot-password"
              element={
                <PublicRoute>
                  <ForgotPassword appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />
            <Route
              path="/forgot-userid"
              element={
                <PublicRoute>
                  <ForgotUserID appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />
            <Route
              path="/email-authentication"
              element={
                <PublicRoute>
                  <EmailVerifySuccess appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />
            <Route
              path="/unlock-account"
              element={
                <PublicRoute>
                  <UnlockAccount appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />
            <Route
              path="/signin"
              element={
                <PublicRoute>
                  <Login appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />
            <Route
              path="/disclaimer"
              element={
                <PublicRoute>
                  <Disclaimer appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />
            <Route
              path="/privacy-policy"
              element={
                <PublicRoute>
                  <PrivacyPolicy appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />
            <Route
              path="/terms-and-conditions"
              element={
                <PublicRoute>
                  <ViaTermsCondition appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />
            <Route
              path="/terms-conditions"
              element={
                <PublicRoute>
                  <GeneralTermsCondition appState={state} manageAuth={manageAuth} />
                </PublicRoute>
              }
            />

            {/* private routes  */}
            <Route
              path="/select-bene-details"
              element={
                <PrivateRoute>
                  <SelectBeneDetails />
                </PrivateRoute>
              }
            />
            <Route
              path="/user-doc-upload"
              element={
                <PrivateRoute>
                  <UserDocUpload />
                </PrivateRoute>
              }
            />
            <Route
              path="/reset-password"
              element={
                <PrivateRoute>
                  <ResetPassword />
                </PrivateRoute>
              }
            />
            <Route
              path="/manage-remitter-accounts"
              element={
                <PrivateRoute>
                  <ManageRemitterAccounts />
                </PrivateRoute>
              }
            />
            <Route
              path="/profile"
              element={
                <PrivateRoute>
                  <ProfileDetails />
                </PrivateRoute>
              }
            />
            <Route
              path="/select-remitter-account"
              element={
                <PrivateRoute>
                  <SelectRemitterAccount />
                </PrivateRoute>
              }
            />
            <Route
              path="/transactions"
              element={
                <PrivateRoute>
                  <Transactions />
                </PrivateRoute>
              }
            />
            <Route
              path="/add-beneficiary"
              element={
                <PrivateRoute>
                  <Beneficiary />
                </PrivateRoute>
              }
            />
            <Route
              path="/find-ifsc"
              element={
                <PrivateRoute>
                  <FindIfsc />
                </PrivateRoute>
              }
            />
            <Route
              path="/new-transaction"
              element={
                <PrivateRoute>
                  <TranctionAction />
                </PrivateRoute>
              }
            />
            <Route
              path="/kyc"
              element={
                <PrivateRoute>
                  <KycPage />
                </PrivateRoute>
              }
            />
            <Route
              path="/my-beneficiary"
              element={
                <PrivateRoute>
                  <ManageBeneficiaries />
                </PrivateRoute>
              }
            />
            <Route
              path="/view-beneficiary"
              element={
                <PrivateRoute>
                  <ViewBeneficiaryDetails />
                </PrivateRoute>
              }
            />
            <Route
              path="/edit-beneficiary"
              element={
                <PrivateRoute>
                  <EditBeneficiaryDetails />
                </PrivateRoute>
              }
            />
            <Route
              path="/remitter-account-details"
              element={
                <PrivateRoute>
                  <RemitterAccountDetails appState={state} />
                </PrivateRoute>
              }
            />
            <Route
              path="/edit-remitter"
              element={
                <PrivateRoute>
                  <EditRemitter appState={state} />
                </PrivateRoute>
              }
            />
            {/* private routes  */}
          </Route>
          <Route
            path="/plaid-fail"
            element={
              <PublicRoute>
                <PlaidFail appState={state} manageAuth={manageAuth} />
              </PublicRoute>
            }
          />
          <Route
            path="/plaid-success"
            element={
              <PublicRoute>
                <PlaidSuccess appState={state} manageAuth={manageAuth} />
              </PublicRoute>
            }
          />
          <Route
            path="/jumio-fail"
            element={
              <PublicRoute>
                <JumioFail appState={state} manageAuth={manageAuth} />
              </PublicRoute>
            }
          />
          <Route
            path="/jumio-success"
            element={
              <PublicRoute>
                <JumioSuccess appState={state} manageAuth={manageAuth} />
              </PublicRoute>
            }
          />
        </Routes>
      </MenuContextProvider>
    </>
  );
}
