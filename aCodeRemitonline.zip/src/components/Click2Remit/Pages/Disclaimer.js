import c2r_logo from "../../../assets/images/click2remit/C2R_logo_pre1.png";

export default function Disclaimer() {
  return (
    <>
      <body className="disclaimer">
        <table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td
              align="center"
              valign="top"
              style={{
                borderTop: "1px solid #656565",
                borderBottom: "1px solid #656565",
                borderLeft: "1px solid #656565",
                borderRight: "1px solid #656565",
              }}
            >
              <table border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td
                    align="center"
                    valign="top"
                    className="outerpadding"
                    style={{ paddingTop: "20px" }}
                  >
                    <table width="560" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td
                          align="center"
                          valign="top"
                          style={{ paddingBottom: "20px", textAlign: "left" }}
                        >
                          <img
                            src={c2r_logo}
                            width="300px"
                            height="58.9px"
                            style={{ display: "block !important" }}
                            className="toplogo1"
                            border="0"
                          />
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td align="center" valign="top" class="outerpadding">
                    <table width="560" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td
                          align="center"
                          valign="top"
                          style={{
                            paddingBottom: "30px",
                            paddingLeft: "15px",
                            paddingRight: "15px",
                          }}
                        >
                          <table
                            width="560"
                            border="0"
                            align="center"
                            cellpadding="0"
                            cellspacing="0"
                          >
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "12px",
                                  paddingTop: "10px",
                                }}
                              >
                                This Website is owned and maintained by Kotak Mahindra Bank Limited
                                (referred to as "Bank" hereafter) for your personal information,
                                communication, education, and use. The Website may contain links to
                                other websites, having further linked websites, operated by parties
                                other than the Bank ("Linked Websites").{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                The use of Website is governed by the following terms and conditions
                                and other terms and conditions/policies as indicated on this Website
                                ("T &amp; C") and all the applicable laws as also any separate terms
                                and conditions for certain sections as may be applicable and in the
                                event of any conflict such specific terms and conditions shall
                                prevail. Any or all users of this system and files are being tracked
                                and by accessing and using Website you agree to accept, without
                                limitation or qualification, all the T & C. The Content
                                (information, material, news items, data, Money Market movements
                                etc.) of the Website including the T & C are subject to change at
                                the sole discretion of the Bank, without prior notice.{" "}
                              </td>
                            </tr>

                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                Bank owns all the right, title and interest including the copyright
                                in respect of all the Content including various logos, trademarks,
                                service marks etc., unless indicated otherwise. You may use/download
                                the Content only for non-commercial and personal use, provided you
                                retain all copyright and other proprietary notices contained
                                therein. You shall not, however, reproduce, distribute,
                                redistribute, modify, transmit, reuse, report, or use the Content
                                for public or commercial purposes without Bank's written permission.
                                You shall not use the Content for illegal purpose.{" "}
                              </td>
                            </tr>

                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                Products and services offered on the Website are available only in
                                restricted geographical regions as indicated. This Website does not
                                offer any products or services to citizens of or in the
                                jurisdictions whose laws conflict with, differ from, or provide
                                higher requirements than those necessitated by, the laws of the
                                Republic of India.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                The development of the Website with respect to the Content and
                                software made available and products and services ("Products")
                                offered through it, is a continuous and an on-going process and
                                Products are provided on "best effort basis". Bank makes all
                                attempts to keep the Products updated and accurate, but Products may
                                not be up to date. Bank makes no warranty or representation, express
                                or implied, including, but not limited to any warranties or
                                representations as to the accuracy, reliability or completeness of
                                the Products and/or fitness for a particular purpose, and/or
                                non-infringement with respect to the Website and/or Linked Websites
                                and/or the Products.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                Any Content on Website must not be construed as investment advice,
                                and you should exercise due caution and/or seek independent advice
                                before entering into any investment or financial obligation based on
                                the Content. The contents displayed or the products/services offered
                                on the Linked Websites or any quality of the same are not endorsed,
                                verified or monitored by Bank in any way. Bank makes no
                                representation or warranty, express or implied, of any kind
                                whatsoever, pertaining to the Linked Websites.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                Though the Bank will take steps to prevent introduction of virus and
                                other such destructive materials on the Website, it does not
                                represent, warrant or guarantee that the Website or the Content
                                downloaded from the Website or Linked Websites do not contain such
                                virus or destructive materials. Bank is not liable for any damage or
                                harm attributable to such virus or destructive materials. The Bank
                                does not warrant that the Website or functions thereof will be
                                uninterrupted or free of any error or defect. Bank shall not be
                                liable to you or any third party (whether or not the access is
                                authorised) for any cost, loss, damage or the like,
                                incurred/suffered, directly or indirectly, due to:{" "}
                              </td>
                            </tr>

                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto, sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      Use of the Websites or Products in violation of the applicable
                                      terms and conditions of such usage or the applicable laws or
                                      otherwise failure to abide by such terms and conditions or
                                      laws.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto, sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      Any action based on the Content or any use or application of
                                      the same or any error or omission relating to the transmission
                                      of the Content. .
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto, sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      (i) Bank's Failure to act upon your instructions, (ii) Non
                                      availability of the Internet Services in the desired manner,
                                      (iii) loss of any instruction in any communication channel or
                                      of any stored data/instructions; due to any reasons beyond the
                                      control of the Bank at the relevant point of time, including
                                      any problems and difficulties arising due to power and
                                      electricity failure, computer errors, programming errors,
                                      software or hardware errors, computer breakdown,
                                      non-availability of Internet connection, communication
                                      problems between the Bank's server and User's computer
                                      network, shutting down of the Bank's server, non-availability
                                      of links, corruption of the computer software, problems in the
                                      telecommunication network and any other technology related
                                      problems, natural calamities/disasters, legal restraints,
                                      industrial disputes or any other reason beyond the control of
                                      the Bank.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto, sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      Any unauthorised transaction through this Website due to your
                                      fraudulent or negligent usage.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20">
                                      &bull;
                                    </td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto, sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      Any unauthorised/fraudulent/erroneous use of or hacking or
                                      intrusion into the computer network of the Bank by any third
                                      party due your negligent or fraudulent conduct, or if the Bank
                                      has taken due and reasonable care to avoid such hacking or
                                      intrusion
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>
                            <tr>
                              <td align="center" valign="top">
                                <table
                                  width="560"
                                  align="center"
                                  border="0"
                                  cellpadding="0"
                                  cellspacing="0"
                                >
                                  <tr>
                                    <td align="center" valign="top" width="20"></td>
                                    <td
                                      align="center"
                                      valign="top"
                                      style={{
                                        fontFamily: "Roboto, sans-serif",
                                        fontSize: "14px",
                                        lineHeight: "24px",
                                        color: "#323232",
                                        textAlign: "left",
                                        paddingBottom: "10px",
                                      }}
                                    >
                                      You or any third party accessing the Website irrevocably
                                      agrees to the exclusive jurisdiction of the courts at Mumbai
                                      in relation any matter connected or related to use or access
                                      of the Website and waives any objection to any proceedings on
                                      grounds of venue or on the grounds that the proceedings have
                                      been brought in an inconvenient forum. The governing law in
                                      such legal proceedings referred to above shall be the laws of
                                      the Republic of India.
                                    </td>
                                  </tr>
                                </table>
                              </td>
                            </tr>

                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "8px",
                                }}
                              >
                                <strong> Additional Disclaimer </strong>
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                This communication is confidential and privileged and is directed to
                                and for the use of the addressee only.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                The recipient acknowledges that Kotak Mahindra Bank Limited may be
                                unable to exercise control or ensure or guarantee the integrity of
                                the text of the email message and the text is not warranted as to
                                completeness and accuracy.{" "}
                              </td>
                            </tr>
                            <tr>
                              <td
                                align="center"
                                valign="top"
                                style={{
                                  fontFamily: "Roboto, sans-serif",
                                  fontSize: "14px",
                                  lineHeight: "24px",
                                  color: "#323232",
                                  textAlign: "left",
                                  paddingBottom: "10px",
                                }}
                              >
                                Copyright Kotak Mahindra Bank Ltd. All rights reserved.{" "}
                              </td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </body>
    </>
  );
}
