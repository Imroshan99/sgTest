import React, { useEffect, useReducer, useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import Chevronright from "../../../assets/images/click2remit/Chevronright.svg";
import Addsvg from "../../../assets/images/click2remit/Add.svg";
import Bank1png from "../../../assets/images/click2remit/bank-1.png";
import { useSelector } from "react-redux";
import useHttp from "../../../hooks/useHttp";
import Spinner from "../../../reusable/Spinner";
import { BankAccountAPI } from "../../../apis/BankAccountAPI";
import moment from "moment";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "antd";
const SelectRemitterAccount = (props) => {
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);
  //    const [tableRender, settableRender] = useState(false);
  const [loader, setLoader] = useState(false);
  //  const [contentRender, setContentRender] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    bankAccountList: [],
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
  });

  const hookBankAccountList = useHttp(BankAccountAPI.bankAccountList);

  const hookViewBankAccountDetails = useHttp(BankAccountAPI.viewBankAccountDetails);
  const hookDeleteBankAccountDetails = useHttp(BankAccountAPI.deleteBankAccountDetails);

  useEffect(() => {
    accountsList();
  }, []);
  const accountsList = () => {
    const payload = {
      requestType: "SENDERACCOUNTLIST",
      userId: state.userID,
      //  fulName: state.fullName,
      countryCode: "GB",
      favouriteFlag: "1",
      startIndex: "0",
      recordsPerRequest: "",
    };
    setLoader(true);
    hookBankAccountList.sendRequest(payload, function (data) {
      if (data.status == "S") {
        // settableRender(true);
        let resData = [];
        data.responseData.forEach((detail, i) => {
          let newData = {
            key: i,
            accountHolderName: `${detail.accountHolderName}`,
            sendAccId: `${detail.sendAccId}`,
            recordToken: `${detail.recordToken}`,
            bankName: `${detail.bankName}`,
            accountNo: `${detail.accountNo}`,
            bankClearingCode: `${detail.sortCode}`,
            dateAdded: moment(detail.createdDate).format("MM-DD-YYYY"),
            status: detail.accountStatus,
          };
          resData.push(newData);
          console.log(newData, "resdata");
        });
        setState({
          bankAccountList: resData,
        });
        console.log(state, "shubhh");
        console.log(state.bankAccountList, "blist");
        setLoader(false);
        //    setContentRender(true);
      } else {
        setLoader(false);
        // settableRender(false);
        //    setContentRender(true);
      }
    });
  };
  return (
    <div className="container h-100">
      <div className="row h-100 justify-content-center">
        <form>
          <div className="align-self-center col-lg-7 col-md-7 col-sm-12 mx-auto">
            <div className="CR-default-box CR-max-width-620">
              <ul className="row CR-side-space">
                <li
                  className="back-arrow-nav d-xs-block d-done"
                  onClick={() => props.setState({ activeStepForm: 14 })}
                >
                  <img src={BackArrow} alt="" />
                </li>

                <li className="col-md-12 col-sm-12 col-lg-12 ">
                  <h4 className="text-black CR-font-28 mb-1">Select remitter account</h4>
                </li>
                <li className="col-md-12 col-sm-12 col-lg-12">
                  <p className="text-left">Select a remitter account to transfer money.</p>
                </li>
                <Spinner spinning={loader}>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <ul className="row">
                      {/* <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                        <div className="align-items-start d-flex justify-content-start w-100 single-box">
                          <div className="CR-bank-logo me-3">
                            <img src={Bank1png} width="100%" height="100%" />
                          </div>
                          <div className="d-flex justify-content-between flex-column CR-w-80">
                            <label className="CR-font-16 CR-black-text CR-fw-600 text-left">John Thomas Doe</label>
                            <p className="CR-font-14 text-left CR-fw-500 mb-0">
                              HSBC UAE <span>&#8226;</span>
                            </p>
                          </div>
                          <a href="/#" className="">
                            <img src={Chevronright} width="24px" height="24px" />
                          </a>
                        </div>
                      </li> */}
                      {state.bankAccountList.map((item, key) => {
                        //  console.log(item,'accno');
                        return (
                          <>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2" key={key}>
                              <div className="align-items-start d-flex justify-content-start w-100 single-box">
                                {/* <div className="CR-bank-logo me-3">
                                  <img src={Bank1png} width="100%" height="100%" />
                                </div> */}
                                <div className="d-flex justify-content-between flex-column CR-w-80">
                                  <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                                    {item.accountHolderName}
                                  </label>
                                  <p className="CR-font-14 text-left CR-fw-500 mb-0">
                                    {item.bankName} <span>&#8226;</span> {item.accountNo}
                                  </p>
                                </div>
                                <Link className="">
                                  <img src={Chevronright} width="24px" height="24px" />
                                </Link>
                              </div>
                            </li>
                          </>
                        );
                      })}

                      {/* <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-start d-flex justify-content-start w-100 single-box">
                            <div className="CR-bank-logo me-3">
                              <img src={Bank1png} width="100%" height="100%" />
                            </div>
                            <div className="d-flex justify-content-between flex-column CR-w-80">
                              <label className="CR-font-16 CR-black-text CR-fw-600 text-left"> </label>
                              <p className="CR-font-14 text-left CR-fw-500 mb-0">
                                HSBC UAE <span>&#8226;</span> 32165498710111
                              </p>
                            </div>
                            <a href="/#" className="">
                              <img src={Chevronright} width="24px" height="24px" />
                            </a>
                          </div>
                        </li> */}

                      {/* <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-start d-flex justify-content-start w-100 single-box">
                            <div className="CR-bank-logo me-3">
                              <img src={Bank1png} width="100%" height="100%" />
                            </div>
                            <div className="d-flex justify-content-between flex-column CR-w-80">
                              <label className="CR-font-16 CR-black-text CR-fw-600 text-left">John Thomas Doe</label>
                              <p className="CR-font-14 text-left CR-fw-500 mb-0">
                                HSBC UAE <span>&#8226;</span> 32165498710111
                              </p>
                            </div>
                            <a href="/#" className="">
                              <img src={Chevronright} width="24px" height="24px" />
                            </a>
                          </div>
                        </li> */}
                    </ul>
                  </li>
                </Spinner>

                <li className="col-md-12 col-sm-12 col-lg-12 text-start mb-5 mt-3">
                  <Button
                    type="button"
                    onClick={() => {
                      navigate("/remitter-account");
                    }}
                    className="CR-blue-link CR-font-14 CR-fw-500"
                  >
                    <img src={Addsvg} width="16px" height="16px" className="me-2" />
                    ADD NEW REMITTER ACCOUNT
                  </Button>
                </li>
              </ul>

              {/* <!-- <div className="bottom_panel">
                                    <div className="d-flex justify-content-between align-items-baseline">
                                        <a thref="#!" className="Back_arrow"> <img src="images/Back_arrow.svg" alt="">
                                            Back</a>
                                        <button type="button" className="btn btn-primary CR-primary-btn mb-3" style="width:100px;margin: 0!important;">Confirm
                                            </button>
                                    </div>
                                </div> --> */}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SelectRemitterAccount;
