import {
  AppstoreOutlined,
  CalendarOutlined,
  LinkOutlined,
  TransactionOutlined,
  HomeFilled,
  UserOutlined,
  LogoutOutlined,
} from "@ant-design/icons";
import { Menu } from "antd";
import { useContext } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { MenuContext } from "../Context/MenuContext";
function getItem(label, key, icon, children) {
  return {
    key,
    icon,
    children,
    label,
  };
}

const MenuPathNames = {
  NEW_TRANSACTION: "/new-transaction",
  TRANSACTIONS: "/transactions",
  MY_BENEFICIARY: "/my-beneficiary",
  PROFILE: "/profile",
  RESET_PASSWORD: "/reset-password",
  REMITTER_ACCOUNTS: "/manage-remitter-accounts",
  HELP_SUPPORT: "/help-support",
  KYC: "/kyc",
  DOC_UPLOAD: "/user-doc-upload",
};

const items = [
  getItem(
    <Menu.Item key={MenuPathNames.NEW_TRANSACTION}>
      <Link to={MenuPathNames.NEW_TRANSACTION}>Home</Link>
    </Menu.Item>,
    MenuPathNames.NEW_TRANSACTION,
    <HomeFilled />,
  ),
  getItem(
    <Link to={MenuPathNames.TRANSACTIONS}>Transactions</Link>,
    MenuPathNames.TRANSACTIONS,
    <TransactionOutlined />,
  ),

  getItem(
    <Menu.Item key={MenuPathNames.MY_BENEFICIARY}>
      <Link to={MenuPathNames.MY_BENEFICIARY}>Manage Beneficiary</Link>
    </Menu.Item>,
    MenuPathNames.MY_BENEFICIARY,
    <AppstoreOutlined />,
  ),
  getItem("Profile", "sub1", <UserOutlined />, [
    getItem(
      <Menu.Item key={MenuPathNames.PROFILE}>
        <Link to={MenuPathNames.PROFILE}>Profile Details</Link>
      </Menu.Item>,
      MenuPathNames.PROFILE,
    ),

    getItem(
      <Menu.Item key={MenuPathNames.REMITTER_ACCOUNTS}>
        <Link to={MenuPathNames.REMITTER_ACCOUNTS}>Manage Remitter Accounts</Link>
      </Menu.Item>,
      MenuPathNames.REMITTER_ACCOUNTS,
    ),
    getItem(
      <Menu.Item key={MenuPathNames.RESET_PASSWORD}>
        <Link to={MenuPathNames.RESET_PASSWORD}>Reset Password</Link>
      </Menu.Item>,
      MenuPathNames.RESET_PASSWORD,
    ),
    getItem(
      <Menu.Item key={MenuPathNames.HELP_SUPPORT}>
        <Link to={MenuPathNames.HELP_SUPPORT}>Help and Support</Link>
      </Menu.Item>,
      MenuPathNames.HELP_SUPPORT,
    ),
    getItem(
      <Menu.Item key={MenuPathNames.KYC}>
        <Link to={MenuPathNames.KYC}>KYC</Link>
      </Menu.Item>,
      MenuPathNames.KYC,
    ),
    getItem(
      <Menu.Item key={MenuPathNames.DOC_UPLOAD}>
        <Link to={MenuPathNames.DOC_UPLOAD}>Doc Upload</Link>
      </Menu.Item>,
      MenuPathNames.DOC_UPLOAD,
    ),
  ]),
  // getItem('Navigation Three', 'sub4', '55', [
  //   getItem('Option 9', '9'),
  //   getItem('Option 10', '10'),
  //   getItem('Option 11', '11'),
  //   getItem('Option 12', '12'),
  // ]),
  getItem(
    <a href="/" rel="noopener noreferrer" style={{ color: "#ED535B" }}>
      Logout
    </a>,
    "link",
    <LogoutOutlined style={{ color: "#ED535B" }} />,
  ),
];

export default function SidebarMenu() {
  const location = useLocation();
  const _menuContext = useContext(MenuContext);

  return (
    <>
      <div className={`CR__sidebar_menu ${_menuContext.isVisible ? "visible" : ""}`}>
        <Menu
          style={{
            width: 250,
          }}
          selectedKeys={[location.pathname]}
          defaultSelectedKeys={["1"]}
          defaultOpenKeys={["sub1"]}
          mode={"inline"}
          theme={"light"}
          items={items}
          onClick={() => {
            _menuContext.toggleMenu(!_menuContext.isVisible);
          }}
        />
      </div>
      <div
        class={`layout-overlay ${_menuContext.isVisible ? "visible" : ""}`}
        onClick={() => {
          _menuContext.toggleMenu(!_menuContext.isVisible);
        }}
      ></div>
    </>
  );
}
