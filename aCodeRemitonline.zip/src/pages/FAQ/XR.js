import { useState } from "react";
import { Button } from "antd";
import { Link } from "react-router-dom";

export default function FAQ(props) {
  const [showMore, setShowMore] = useState(false);
  return (
    <>
      <p>Q. What is XMONIES?</p>
      <p>
        XMONIES is Peer-to-peer (Personalized) online, realtime remittance
        platform provided by XeOPAR Fintech Private Limited. The platform is
        Customer Centric which provides full transparency to its users with
        realtime time exchange rates, same day delivery without any hidden
        charges and no minimum amount threshold.
      </p>
      <p>
        Q. Which currencies can you use to make a remittance? <br />
        Currently you can make a remittance from United Kingdom (GBP) to India
        (INR).
      </p>
      <p>Other currencies shall be live soon.</p>
      <p>Q. Who can you send money to using XMONIES?</p>
      <p>
        You can only send money to your own account or to a family member's
        account using XMONIES.
      </p>
      <p>
        Q. Why should you use XMONIES Remittance Services for Money Transfers?
      </p>
      <p>
        XMONIES Transfers enable you to send money to your own bank account and
        your loved ones quickly, safely, and conveniently from UK to other
        countries. Our cutting-edge remittance service is Customer Centric and
        enables small and medium transfers with realtime time exchange rates,
        same day delivery without any hidden charges and no minimum amount
        threshold.
      </p>
      <p>
        We understand Value for money and sets us apart from traditional money
        transfer such as cheques, money transfer agents and wire transfers.
      </p>
      <p>
        Enjoy peace of mind with our &quot;always there&quot; customer support
        via phone, chat, and e-mail.
      </p>
      {showMore && (
        <div>
          <p>Q. Are XMONIES Money Transfers safe?</p>
          <p>
            XMONIES, Money Transfers platform does not share the personal
            information provided by you with any third party (unless, of course,
            we are required to do so by law!). For details, read our{" "}
            <Link to={"/privacy-policy"}>Privacy Policy</Link> Moreover, XMONIES
            Money Transfer service lets you put in money into your XMONIES pull
            account either by a local wire transfer via your bank account or an
            Online Transfer that directly debits your local bank account. This
            money is then used by you to either remit money to your loved ones
            in India or to pay for purchases made on India websites. When you
            put in money in your XMONIES pull account either by wire transfer or
            online transfer, you will be reassured to know that no debit appears
            in your bank account unless you have personally authorized it. All
            transactions are carried out across secure encrypted lines and
            state-of-the-art firewalls and international money transfer
            compliances and security standards, which have been put through
            extensive security tests to ensure that the integrity of the
            security system cannot be compromised.
          </p>
          <p>Q. What is the XMONIES Transaction Number or XRTN?</p>
          <p>
            XMONIES Transaction Number or XRTN is the unique number displayed on
            your screen at the time of booking your remittance. It is reference
            number for your transaction. You can know the exact status of your
            transfer by simply clicking on your XRTN on our Online Status
            Tracker. Whether you are sending an email or chatting with us online
            about your money transfer, you always need to quote your XRTN. While
            sending a wire transfer to the recipient's bank via your local bank,
            you need to fill in your XRTN on the Remittance Confirmation Page.
            On completion of a transaction at XMONIES, you must submit a
            printout of this page to your bank. This step is required by your
            local bank to process your money transfer.
          </p>
          <p>
            Q. Is there a limit on the number of beneficiaries that you can
            remit money to?
          </p>
          <p>
            No. You can send money to as many recipients as you wish. XMONIES
            has an Address Book tool in which you can store your receivers'
            details.
          </p>
          <p>
            Q. Do you or your beneficiary need to open any special bank account?
          </p>
          <p>
            No. You can continue using your existing bank account for the money
            transfer.
          </p>
          <p>Getting Started</p>
          <p>
            Q. Do I need to sign up for an account to send money through
            XMONIES? Do I need to pay any fees to sign up for a XMONIES account?
          </p>
          <p>
            To send money through XMONIES, you need to first join us by
            registering on our website - Registration is absolutely free. After
            creating an account, XMONIES stores your relevant details and your
            receivers' information in your user profile. You can easily send
            money later without re-entering payment and recipient information.
            All information stored in your account is secure and will not be
            shared or made available to anyone else.
          </p>
          <p>
            Q. How long will it take to complete the registration? Do I have to
            wait to start using the service once I enroll?{" "}
          </p>
          <p>
            It takes about 2 minutes or less to complete the registration form.
            No, there is no waiting time. Once you complete the registration
            process, you can immediately begin using the service.
          </p>
          <p>Q. What is XMONIES’s privacy policy?</p>
          <p>
            Click here to read our{" "}
            <Link to={"/privacy-policy"}>Privacy Policy</Link>.
          </p>
          <p>
            Q. What is XMONIES’s User agreement? Click here to read our User
            Agreement. (link)
          </p>
          <p>Sending and Receiving Money</p>
          <p>Q. What are the sending options available to me?</p>
          <p>
            CIP/Internet Transfer - Internet Bank Transfer is the easiest way to
            send money electronically to most banks. You can simply transfer the
            funds by logging into your local Internet banking service.
          </p>
          <p>
            Wire transfer - A Wire Transfer to XEOPAR usually enables you to
            transfer money from your existing overseas bank account to India in
            48 hours. XEOPAR provides you with a unique tracking number to help
            you track the status of your transaction at any point of time.
          </p>
          <p>Q. What are the receiving options available to my recipients?</p>
          <p>
            Direct Deposit - All remittances can be directly deposited to the
            account of the beneficiary specified by you as soon as XMONIES
            receives your fund. You can also transfer money into your own bank
            account in India.
          </p>
          <p>
            Q. What is an indicative rate? At what rate will my money actually
            be paid out?
          </p>
          <p>
            The actual conversion rate of XMONIES is the rate applied while
            booking the transaction without any hidden chares.
          </p>
          <p>Q. What is a fixed exchange rate?</p>
          <p>
            To safeguard yourself from any fluctuations in currency rat XMONIES
            we provide realtime exchange rates while booking the transaction.
            The money will be paid out to the receivers account at the booked
            XMONIES rate only irrespective of any fluctuations in actual rates.
            However, you should complete the transfer within same working day
            itself or else transfer will be auto cancelled. Your transaction
            could be delayed because of the following reasons: You do not send
            the money into our pull account for the purpose of transfer. You do
            not submit adequate KYC documents or answer our KYC call for the
            purpose of verification. We are unable to trace your funds due to
            wrong trace number. In such a case you would have to re-book a
            transfer with the same amount at the prevailing rate.
          </p>
          <p>Q. How do I use the exchange rate calculator?</p>
          <p>
            The exchange rate calculator is used for informational purposes
            only. The rates in this calculator do not represent the actual rate
            that will be applied to your transaction. This calculator provides
            an approximation. To view exchange rate calculator, <Link to="/">click here</Link>.
            
          </p>
          <p>Q. When will a transaction be processed?</p>
          <p>
            XMONIES can only begin processing your transaction request once the
            money is received in our pull account in the sending country. We
            shall pay out the money same working day itself. However, if you are
            a new user, then it can take some delays due to KYC verification.
            Also take into account that all days must be bank working days in
            the sending country and in India. Cut Off Timing : 1st Day of
            transaction will be considered, if bank transfer from your account
            to XMONIES account happens before the below mentioned cut off
            timings
          </p>
          <p>Country Time UK 3pm GMT Monday To Friday</p>
          <p>* Excluding Bank Holidays in all countries</p>
          <p>
            *Booking date will not be considered as the first transaction date.
          </p>
          <p>Q. What is the KYC (Know your customer) process for XMONIES?</p>
          <p>
            When you do a transaction with XMONIES for the first time a KYC
            verification as per the FCA guidelines and user needs to furnish the
            upload the details such as Address proofs, Rent agreement, Company
            Letter, Electricity\Utility bill, Bank Statement, Driving License,
            Id proof, Passport Driving License.
          </p>
          <p>Q. What does 'delivery date' mean?</p>
          <p>
            This is the date the funds should be available to the beneficiary
            for the XMONIES transaction. We cannot always guarantee the
            availability of funds on a particular date because of the
            differences in time zones, holiday lists and general processing
            schedules of different countries. The delivery date indicated by us
            for the transaction should be considered only as an estimate rather
            than the actual date for availability of funds. We advise you to
            check the XMONIES Status Tracker to confirm that your funds have
            been received by the beneficiary. Please Note: XMONIES can only
            begin processing your transaction request once the money is received
            in our account in the sending country.
          </p>
          <p>Q. On what holidays will the remittances not be processed?</p>
          <p>
            Remittances will not be processed on weekends and on the following
            bank holidays.
          </p>
          <p>(Holiday list to be shown)</p>
          <p>Q. How will I know when my recipient has received the money?</p>
          <p>
            XMONIES provides this information to you via email notifications and
            on the XMONIES Status Tracker. We will send a series of email
            notifications informing you of the status of your transaction. The
            first email is sent shortly after you submit a XMONIES transaction.
            The second email is sent when your payment has been cleared and
            XMONIES assigns responsibility of your transaction to our partner in
            the recipient's country. Upon completion of the transaction, you
            will receive another email informing you that your recipient has
            received the funds.
          </p>
          <p>Q. How do I repeat a remittance which I had done before? </p>
          <p>
            To avoid the painstaking process of booking a transfer with the same
            details again XMONIES has introduced the repeat a remittance
            feature, wherein a list of remittances done in the past is displayed
            and to repeat the transfer you have to just click on the button next
            to it.
          </p>
          <p>Q. How do I unlock my account?</p>
          <p>
            At XMONIES, we have created an account unlock option on the login
            page. This will help you to unlock your account instantly. You can
            unlock your account only once in 24 hours. Alternatively please
            email an 'unlock request' to customer support’s email address from
            your registered ID. For more details, contact our customer support
            team by clicking here.
          </p>
          <p>
            Q. What if I am having problems signing in to my XMONIES account?
          </p>
          <p>
            In case you cannot log-in to your valid XMONIES account, please
            contact our customer support team for assistance. For details
            contact our Customer Support:
          </p>
          <p>Toll Free and email address to be shown here</p>:
          <p>Q. How do I change my XMONIES account settings?</p>
          <p>
            After logging into your XMONIES account, click on the Account
            Settings link in the My Profile section. Make the required changes
            and save them.
          </p>
          <p>Q. How do I add a receiver?</p>
          <p>
            After logging into your XMONIES account, click on the My Receivers
            tab. Enter the required details of the new receiver here and save
            them.
          </p>
          <p> Q. How do I close my XMONIES account?</p>
          <p>
            If you wish to close your XMONIES account, please contact our
            customer support team to understand the closure process. For details
            contact our Customer Support:
          </p>
          <p>Toll Free and email address to be shown here:</p>
          <p>Q. How do I change my XMONIES account password?</p>
          <p>
            After logging into your XMONIES account, click on the Change
            Password link in the My Profile section of the menu. Make the
            required changes and save it.
          </p>
          <p>Q. What if I forget my XMONIES account password? </p>
          <p>
            Click on the Forgot Password link in the login box on the home page.
            Enter the requested details and you will receive an email with a new
            password. Use this password to log in again. When you access your
            account, change the password according to your preference.
          </p>
          <p>
            Q. I want to block my account as I believe that my password has been
            leaked/ compromised?
          </p>
          <p>
            We advise you to frequently change your password and maintain total
            secrecy about your login details to prevent fraudulent misuse of
            your XMONIES account. In case you need to block your account, just
            send an email to customer support from the email ID you had earlier
            registered with us.
          </p>
          <p>Q. What is the exchange rate applied on my remittance?</p>
          <p>
            At XMONIES we provide realtime exchange rates while booking the
            transaction. The money will be paid out to the receivers account at
            the booked. XMONIES rate only irrespective of any fluctuations in
            actual rates. However, you should complete the transfer within same
            working day itself or else transfer will be auto cancelled At
          </p>
          <p>Q. How can I view the Exchange Rate for the day?</p>
          <p>
            You can view the exchange rate for the day by using the online
            exchange rate calculator on our website. <Link to={"/"}>Click here</Link> for today's
            exchange rates.
          </p>
          <p>Q. What is the transfer fee for sending money to India?</p>
          <p>The transfer fee is calculated realtime.</p>
          <p>Q. Is there any additional fees?</p>
          <p>NO</p>
        </div>
      )}
      <button
        className="showmore-button"
        onClick={() => setShowMore(!showMore)}
      >
        {showMore ? "View Less" : "View More"}
      </button>
    </>
  );
}
