import React, { useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import editsvg from "../../../assets/images/click2remit/Edit.svg";
import { useSelector } from "react-redux";
import useHttp from "../../../hooks/useHttp";
import { BankAccountAPI } from "../../../apis/BankAccountAPI";
import { notification } from "antd";
import { useLocation, useNavigate } from "react-router-dom";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import Spinner from "../../../reusable/Spinner";

const ReviewRemitterAccountDetails = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const [loader, setLoader] = useState(false);
  const { state } = props;
  const location = useLocation();

  //  const [form] = Form.useForm();

  const navigate = useNavigate();
  const hookCheckDuplicateReceiver = useHttp(ReceiverAPI.checkDuplicateReceiver);
  const hookAddBankAccount = useHttp(BankAccountAPI.addBankAccount);

  const submitHandler = () => {
    console.log(state.remitterAccountDetails.firstName, "dede");
    let formData = {
      requestType: "SENDERACCOUNTADD",
      userId: AuthReducer.userID,
      countryCode: "GB",
      currencyCode: "GBP",
      accountHolder: state.addRemitterDetails.fullName,

      bankCode: state.addRemitterDetails.bankSortCode,
      bankNumber: "",
      bankName: state.addRemitterDetails.bankName.value,
      accountNo: state.addRemitterDetails.accountNo,
      accountType: state.addRemitterDetails.accountType.value,
      accCurrencyCode: "GBP",
      sortCode: "787887",
      bankCountry: "GB",
      ifsc: "",
      nickName: state.addRemitterDetails.nickName,
      branchCode: "",
      bankBranch: "",
      bankCity: "",
      bankState: "",
      isDefaultAcc: "",
      tncAgree: "",
      processType: "",
      routingNumber: "",
      processingPartner: "",
      processingMode: "",
      remark: "",
      isSwiftCodeValid: "",
      noOfAttempts: "",
      transitNumber: "",
      swiftCode: "",
      iban: "",
      bsbCode: "",
    };
    setLoader(true);
    hookAddBankAccount.sendRequest(formData, function (data) {
      if (data.status == "S") {
        notification.success({ message: data.message });
        props.setState({ activeStepForm: 15 });
        setLoader(false);
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
      }
      //  afterClose();
    });
  };
  return (
    <Spinner spinning={loader}>
      <div className="container h-100">
        <div className="row h-100 justify-content-center">
          <form>
            <div className="align-self-center col-lg-7 col-md-7 col-sm-12 mx-auto">
              <div className="CR-default-box CR-max-width-620">
                <ul className="row CR-side-space">
                  <li className="back-arrow-nav   d-xs-block d-done">
                    <img src={BackArrow} alt="" />
                  </li>

                  <li className="col-md-12 col-sm-12 col-lg-12 ">
                    <h4 className="text-black CR-font-28 mb-1">Review remitter account details</h4>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12">
                    <p className="text-left CR-font-16">Check your remitter details.</p>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                      <p className="mb-0">Personal information</p>
                      <span onClick={() => props.setState({ activeStepForm: 13 })} className="">
                        <img src={editsvg} width="17px" height="17px" className="me-1" />
                        EDIT
                      </span>
                    </div>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <ul className="row">
                      <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                        <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                          <label className="CR-font-16 text-left">Name</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                            {state.addRemitterDetails.fullName}
                          </p>
                        </div>
                      </li>
                      <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                        <div className="align-items-center d-flex justify-content-between">
                          <label className="CR-font-16 text-left">Nick name</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                            {state.addRemitterDetails.nickName}
                          </p>
                        </div>
                      </li>
                    </ul>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                      <p className="mb-0">Bank details</p>
                      <span onClick={() => props.setState({ activeStepForm: 13 })} className="">
                        <img src={editsvg} width="17px" height="17px" className="me-1" />
                        EDIT
                      </span>
                    </div>
                  </li>
                  <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                    <ul className="row">
                      <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                        <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                          <label className="CR-font-16 text-left">Bank name</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                            {state.addRemitterDetails.bankName.value}
                          </p>
                        </div>
                      </li>
                      <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                        <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                          <label className="CR-font-16 text-left">Account number</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                            {state.addRemitterDetails.accountNo}
                          </p>
                        </div>
                      </li>
                      <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                        <div className="align-items-center d-flex justify-content-between">
                          <label className="CR-font-16 text-left">Account type</label>
                          <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                            {state.addRemitterDetails.accountType.label}
                          </p>
                        </div>
                      </li>
                    </ul>
                  </li>
                </ul>

                <div className="bottom_panel">
                  <div className="d-flex justify-content-between align-items-baseline">
                    <span
                      onClick={() => props.setState({ activeStepForm: 13 })}
                      className="Back_arrow"
                    >
                      {" "}
                      <img src={BackArrow} alt="" />
                      Back
                    </span>
                    <button
                      type="button"
                      className="btn btn-primary CR-primary-btn mb-3"
                      style={{ width: "100px", margin: "0 !important" }}
                      onClick={() => {
                        submitHandler();
                      }}
                    >
                      Proceed
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </Spinner>
  );
};

export default ReviewRemitterAccountDetails;
