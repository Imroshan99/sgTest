import Back_arrow from "../../../assets/images/click2remit/Back_arrow.svg";
import C2R_mobile from "../../../assets/images/click2remit/C2R-mobile.svg";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";
import { config } from "../../../config";
import { Form, Input, Modal, notification } from "antd";
import { useEffect, useReducer, useRef, useState } from "react";
import moment from "moment";
import { useSelector } from "react-redux";
import { decrypt, encrypt, publickey } from "../../../helpers/makeHash";
import { GuestAPI } from "../../../apis/GuestAPI";
import useHttp from "../../../hooks/useHttp";
import { AuthAPI } from "../../../apis/AuthAPI";
import Spinner from "../../../reusable/Spinner";
import { ViAmericaAuthAPI } from "../../../apis/ViAmericaApi/Auth";
import { useLocation, useNavigate } from "react-router-dom";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import OtpInput from "react-otp-input";

export default function ViaVerifyOTP(props) {
  const OtpInputFocus = useRef(null);
  const AuthReducer = useSelector((state) => state.user);

  const [form] = Form.useForm();
  const navigate = useNavigate();
  const location = useLocation();
  const hookViaVerifyOTP = useHttp(ViAmericaAuthAPI.viaVeirfyOTP);
  const hookReSendOTP = useHttp(GuestAPI.reSendOTP);
  const hookUpdateKycStatus = useHttp(ProfileAPI.updateKycStatus);
  const hookCrnDetails = useHttp(AuthAPI.crnDetails);
  const hookViaSendOTP = useHttp(ViAmericaAuthAPI.viaSendOTP);

  const [loader, setLoader] = useState(false);
  const [reverseTimer, setReverseTimer] = useState("2m 00s");
  const [intervalID, setInterID] = useState();
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    isModalVisible: false,
    OTPErrorMsg: "",

    OTPValue: "",
    _otpErrMsg: false,
    _showOtpErrMsg: false,
    _OTPErrMessage: "Please Enter Complete OTP",
    otpType: "",
    accountNo: "",
  });
  const otpInputStyle = {
    height: "56px",
    gap: "11px",
    width: "47px",
    borderRadius: "8px",
    backgroundColor: "#f0f8ff",
    border: "1px solid #d3dfeb",
    fontSize: "1.5rem",
    fontColor: "black",
    fontWeight: "700",
    textAlign: "center",
  };
  const onlyNumberKey = (val) => {
    var rgx = /^[0-9]*$/;
    return val.match(rgx);
  };

  useEffect(() => {
    reverseTimerOnLoad();
  }, []);
  useEffect(() => {
    if (state._showOtpErrMsg) {
      if (state.OTPValue.length === 6) {
        setState({ _otpErrMsg: false });
      } else if (state.OTPValue.length !== 0) {
        setState({ _otpErrMsg: true });
      }
    }
  }, [state.OTPValue]);
  // useEffect(() => {
  //   if (state.box1 || state.box2 || state.box3 || state.box4 || state.box5 || state.box6) {
  //     let OTPValue = `${state.box1}${state.box2}${state.box3}${state.box4}${state.box5}${state.box6}`;
  //     setState({
  //       OTPValue: OTPValue,
  //     });
  //   }
  // }, [state.box1, state.box2, state.box3, state.box4, state.box5, state.box6]);
  // useEffect(() => {
  //   if (props?.saveReceiver) {
  //     props.saveReceiver();
  //   }
  // }, [props?.state?.verificationToken]);
  const reverseTimerOnLoad = () => {
    clearInterval(intervalID);

    let validityAuctionEndTime = moment().add(2, "minutes");
    const second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;

    let countDown = new Date(`${validityAuctionEndTime}`).getTime();

    let letintervalID = setInterval(function () {
      let now = new Date().getTime(),
        distance = countDown - now;

      var getDay = Math.floor(distance / day);

      var getHour = Math.floor((distance % day) / hour);

      var getMinute = Math.floor((distance % hour) / minute);

      var secound = Math.floor((distance % minute) / second);
      let getSecound = secound > 9 ? secound : 0 + secound;

      let cDay = getDay !== 0 ? `${getDay}d` : "";
      let cHour = getHour !== 0 ? `${getHour}h` : "";
      let cMinute = getMinute !== 0 ? `${getMinute}m` : "";
      let cSecound = getSecound !== 0 ? `${getSecound}s` : "";
      let timer = `${cDay} ${cHour} ${cMinute} ${cSecound}`;

      if (distance <= 0) {
        clearInterval(intervalID);
      } else {
        setReverseTimer(timer);
      }
    }, second);
    setInterID(letintervalID);
  };
  const submitHandler = (value) => {
    form.setFields([{ name: "otp", errors: [] }]);
    const optData = {
      requestType: "VIAVERIFYOTP",
      userId: AuthReducer.userID
        ? AuthReducer.userID
        : props?.state?.userId
        ? props?.state?.userId
        : props?.state?.loginData?.userId,
      otp: state.OTPValue,
      otpType: "SEND",
      eventId: props.state.eventId,
    };

    // const optData = {
    //   requestType: "VIAVERIFYOTP",
    //   userId: props.state.loginData.userId,
    //   otp: state.OTPValue,
    //   otpType: props.otpType, //MAIL, LOGINMFA, SMS
    // };

    setLoader(true);
    hookViaVerifyOTP
      .sendRequest(optData, function (res) {
        // clearInterval(intervalID);
        setLoader(false);
        // clearInterval(intervalID);
        if (res.status == "S") {
          notification.success({
            message: res.message,
          });
          if (props.state._isViaSendOTP) {
            props.submitHandler(props.state.onFinishData);
          } else if (props?.useFor == "receiver") {
            props.setReviewPage(true);
            props.saveReceiver();
          } else if (props.useFor === "edit_receiver") {
            props.setState({ _isShowOTPBOX: false });
            props.editReceiver();
          } else {
            updateKycStatus();
          }
          clearInterval(intervalID);
        } else {
          setState({
            isModalVisible: true,
            OTPErrorMsg: res.errorMessage,
            _OTPErrMessage: res.errorMessage,
            _otpErrMsg: true,
            _showOtpErrMsg: true,
          });
          notification.error({ message: res.errorMessage });
          form.setFields([{ name: "otp", errors: [res.errorMessage] }]);
          let errors = [];
          res.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {
        setLoader(false);
      });
  };
  const updateKycStatus = () => {
    let payload = {
      requestType: "UPDATEKYCSTATUS",
      userId: props.state.loginData.userId,
      isMobileVerified: "Y",
      isEmailVerified: "",
    };
    hookUpdateKycStatus.sendRequest(payload, function (data) {
      if (data.status == "S") {
        getCRNDetails();
        // netverifyCallbackResponse(decodeData);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const getCRNDetails = () => {
    let payload = {
      requestType: "CRNDETAILS",
      crnNumber: props.state.emailId, //"dummy crnNumber": "100881179",LOGINID
      bankAcctStatusCode: "Y",
      apiType: "LOGIN",
    };
    setLoader((prevState) => prevState + 1);
    hookCrnDetails.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        notification.success({
          message: `WELCOME ${props.state.loginData.firstName} ${props.state.loginData.lastName}`,
        });
        navigate("/new-transaction");
      } else {
        notification.error({ message: data.errorMessage ? data.errorMessage : "Access restricted. Please reach us at click2remit@kotak.com or 02266053825 for more information " });
      }
    });
  };
  const onClickResedOTP = (data) => {
    const payload = {
      requestType: "VIASENDOTP",
      userId: AuthReducer.userID
        ? AuthReducer.userID
        : props?.state?.userId
        ? props?.state?.userId
        : props?.state?.loginData?.userId,
      otpType: "SEND",
      optionID: props?.useFor == "login" ? "phone" : "email", //pass email or phone
    };

    setLoader(true);
    hookViaSendOTP
      .sendRequest(payload, function (dataV) {
        setLoader(false);
        if (dataV.status == "S") {
          notification.success({ message: dataV.message });
          props.setState({ eventId: dataV.eventId });
          setState({ _showOtpErrMsg: "", OTPValue: "" });
          // props.setState({ verificationToken: dataV.verificationToken });
          // setVerificationToken(decodeData.verificationToken);
          clearInterval(intervalID);
          setTimeout(() => {
            reverseTimerOnLoad();
          }, 200);
        } else {
          notification.error({
            message: dataV.errorMessage ? dataV.errorMessage : "Via send OTP failed",
          });

          let errors = [];
          dataV.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {});
  };
  return (
    <div className="container h-100 d-flex justify-content-center w-100">
      {/* <div className="row h-100">
          <div className="col-md-6 col-sm-12 col-lg-6 offset-md-3 align-self-center w-100">
            <div className="CR-otp-form"> */}
      <Form
        form={form}
        onFinish={(values) => {
          if (state.OTPValue.length === 6) {
            submitHandler(values);
          } else {
            setState({ _otpErrMsg: true });
            setState({ _showOtpErrMsg: true });
          }
        }}
      >
        <Spinner spinning={loader}>
          <div className="CR-otp-form-parent">
            <div className="CR-otp-form-child">
              <ul className="row d-flex flex-column align-items-center">
                <li className="back-arrow-nav d-xs-block d-done">
                  <img src={Back_arrow} alt="" />
                </li>
                <li className="text-center d-sm-done d-xs-block">
                  <img src={C2R_mobile} style={{ marginBottom: "30px" }} alt="" />
                </li>
                <li className="col-md-12 col-sm-12 col-lg-12 mb-4">
                  <h4
                    style={{ color: "#331114", fontWeight: "700", fontSize: "28px" }}
                    className="text-center"
                  >
                    OTP Verification
                  </h4>
                </li>
                <li className="col-md-12 col-sm-12 col-lg-12">
                  {props?.useFor == "login" ? (
                    <>
                      <p className="text-center">
                        A 6 digit OTP will be sent to your registered mobile number.
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="text-center">
                        Enter the one time password (OTP) sent to <br />
                        your registered Email ID.
                        <br />
                        {/* {props.saveReceiver &&
                          `+${props?.state?.beneficiaryDetails?.mobileCountryCode} ${props?.state?.beneficiaryDetails?.mobileNo}.`}
                        {props.editProfile &&
                          `+${props.state.profileValues.mobileCountryCode} ${props.state.profileValues.mobileNo}.`}
                        {props?.state?.personalDetails?.mobileCountryCode &&
                          `+${props?.state?.personalDetails?.mobileCountryCode} ${props?.state?.personalDetails?.mobileNo}.`} */}
                      </p>
                    </>
                  )}
                </li>
                <li className="col-md-12 col-sm-12 col-lg-12">
                  <div className="otp-box-input">
                    <OtpInput
                      shouldAutoFocus
                      ref={OtpInputFocus}
                      value={state.OTPValue}
                      onChange={(otp) => {
                        setState({ OTPValue: otp });
                        if (otp.length == 6) {
                          setState({ _showOtpErrMsg: "" });
                        }
                      }}
                      numInputs={6}
                      isInputNum={true}
                      inputStyle={otpInputStyle}
                      separator={<span>&nbsp;&nbsp;&nbsp;</span>}
                    />
                  </div>
                  {state._otpErrMsg && state._showOtpErrMsg && (
                    <div
                      style={{ color: "red" }}
                      className="d-flex justify-content-center mt-3 text-center"
                    >
                      {reverseTimer.trim() == "" ? "" : state._OTPErrMessage}
                    </div>
                  )}
                  {/* <CustomInput
                    showLabel={false}
                    name="otp"
                    label="OTP"
                    type="text"
                    min={6}
                    max={6}
                    validationRules={[
                      {
                        min: 6,
                        max: 6,
                        message: "Please enter 6 digit OTP",
                      },
                      {
                        pattern: /^[0-9\b]+$/,
                        message: "Only Numbers allowed",
                      },
                    ]}
                    required
                  >
                    <FloatInput placeholder="OTP" />
                  </CustomInput> */}
                  {/* <input
                    type="password"
                    className="form-control"
                    id="floatingPassword"
                    placeholder="Password"
                  /> */}
                </li>
                <li className="text-center" style={{ marginTop: "40px" }}>
                  <div className="d-flex justify-content-center align-items-center">
                    <a onClick={onClickResedOTP} className="resendotp">
                      Resend OTP
                    </a>
                  </div>
                  <p className="mt-2 text-center">
                    {reverseTimer.trim() == "" ? (
                      <small>OTP expired.</small>
                    ) : (
                      <small>OTP will expire in {reverseTimer}</small>
                    )}
                  </p>
                  {/* <a href="#!" className="resendotpcount">
                      Resend <br />
                      45s
                    </a> */}
                </li>
              </ul>
            </div>
            <div className="bottom_panel-otp-box p-0">
              <div className="d-flex justify-content-between align-items-center w-100">
                <div
                  className="Back_arrow d-flex align-items-center"
                  onClick={() => {
                    if (props?.useFor == "login") {
                      props.setState({ _showSignInForm: true });
                    } else if (props?.useFor == "receiver") {
                      props.setReviewPage(true);
                    } else if (props.useFor === "edit_receiver") {
                      props.setState({ _isShowOTPBOX: false });
                    }
                  }}
                >
                  <img src={Back_arrow} alt="backArrow" /> Back
                </div>
                <button
                  htmlType="submit"
                  className="btn btn-primary CR-primary-btn"
                  style={{ width: "100px", margin: "0 !important" }}
                >
                  Confirm
                </button>
              </div>
            </div>
          </div>
        </Spinner>
      </Form>
      {/* </div>
          </div>
        </div> */}

      {state.isModalVisible && (
        <>
          <div class="modal CR-OTP-modal fade show" tabindex="-1">
            <div class="modal-dialog-centered " style={{ margin: "0 auto", maxWidth: "500px" }}>
              <div class="modal-content">
                <div class="modal-body CR-OTP-modal-container">
                  <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    onClick={() => setState({ isModalVisible: false })}
                  ></button>
                  <h5>Invalid Otp</h5>
                  {/* <p class="error">This is you final attempt</p> */}
                  <p>{state.OTPErrorMsg}</p>
                  <div class="btn-modal-wrapper">
                    <a onClick={() => setState({ isModalVisible: false })} class="modal-btn">
                      Got It
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-backdrop fade show"></div>
        </>
      )}
    </div>
  );
}
