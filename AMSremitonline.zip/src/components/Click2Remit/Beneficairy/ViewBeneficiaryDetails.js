import React, { useEffect, useReducer } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { BankAccountAPI } from "../../../apis/BankAccountAPI";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import bank1png from "../../../assets/images/click2remit/bank-1.png";
import { notification } from "antd";
import useHttp from "../../../hooks/useHttp";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import Main from "../Layouts/Main";
import EditBeneficiaryDetails from "./EditBeneficiaryDetails";
import { useState } from "react";
import Spinner from "../../../reusable/Spinner";
import Swal from "sweetalert2";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import VerifyOtp from "../containers/VerifyOtp";

const ViewBeneficiaryDetails = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const location = useLocation();
  const receiverData = location?.state?.receiverData;
  const navigate = useNavigate();

  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    receiverInfo: {},
    viewBeneficiaryComponent: true,
    _isShowOTPBOX: false,
    verificationToken: "",
  });
  const hookDeleteReceiver = useHttp(ReceiverAPI.deleteReceiver);
  const hookSendOtp = useHttp(ProfileAPI.sendOTP);

  const deleteBeneficiary = () => {
    setState({
      isModalVisible: false,
    });
    const payload = {
      requestType: "GETRECVLIST",
      userId: AuthReducer.userID,
      nickName: receiverData.nickName,
      recordToken: receiverData.recordToken,
    };

    setLoader(true);
    hookDeleteReceiver.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        navigate("/my-beneficiary");
        notification.success({
          message: "Beneficiary Deleted Successfully",
        });
      } else {
        Swal.fire("Changes are not saved", "", "info");
      }
    });
  };
  const sendOTPforDelete = () => {
    setState({
      isModalVisible: false,
    });
    const payload = {
      requestType: "SENDOTP",
      otpType: "DR",
      userId: AuthReducer.userID,
      otpOption: "SM",
      otpService: "EMAIL",
    };
    setLoader(true);
    hookSendOtp.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        notification.success({ message: "OTP has been sent to your registered email address." });
        setState({
          verificationToken: data.verificationToken,
          _isShowOTPBOX: true,
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  return (
    <Main>
      <Spinner spinning={loader}>
        {state._isShowOTPBOX ? (
          <VerifyOtp
            setLoader={setLoader}
            useFor="delete_beneficiary"
            deleteBeneficiary={deleteBeneficiary}
            state={state}
            setState={setState}
            receiverData={receiverData.accountNo}
          />
        ) : state.viewBeneficiaryComponent ? (
          <>
            <div className="container h-100">
              <div className="row h-100 justify-content-center">
                <form>
                  <div className="align-self-center col-lg-7 col-md-7 col-sm-12  " style={{marginRight:"auto"}}>
                    <div className="CR-default-box CR-max-width-620">
                      <ul className="row CR-side-space">
                        <li className="back-arrow-nav   d-xs-block d-done">
                          <img src={BackArrow} alt="" />
                        </li>

                        <li className="col-md-12 col-sm-12 col-lg-12 ">
                          <h4 className="text-black CR-font-28 mb-1">Beneficiary details</h4>
                        </li>
                        {/* <li className="col-md-12 col-sm-12 col-lg-12">
                  <p className="text-left CR-font-16">Check your remitter details.</p>
                </li> */}
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-start d-flex justify-content-start w-100 single-box">
                            {/* <div className="CR-bank-logo me-3">
                              <img src={bank1png} width="100%" height="100%" />
                            </div> */}
                            <div className="d-flex justify-content-between flex-column CR-w-80">
                              <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                                {`${receiverData.firstName} ${receiverData.middleName} ${receiverData.lastName}`}
                              </label>
                              <p className="CR-font-14 text-left CR-fw-500 mb-0">
                                {receiverData.nickName}
                              </p>
                            </div>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                            <p className="mb-0">Personal information</p>
                            {/* <a onClick={() => props.setState({ activeStepForm: 13 })} className="">
                      <img src={editsvg} width="17px" height="17px" className="me-1" />
                      EDIT
                    </a> */}
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <ul className="row">
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Name</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.firstName}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Nick name</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.nickName}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Relationship</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.relationship}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Mobile number</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.mobileNo}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between">
                                <label className="CR-font-16 text-left">Email address</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.emailId}
                                </p>
                              </div>
                            </li>
                          </ul>
                        </li>

                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                            <p className="mb-0">Residential details</p>
                            {/* <a onClick={() => props.setState({ activeStepForm: 13 })} className="">
                      <img src={editsvg} width="17px" height="17px" className="me-1" />
                      EDIT
                    </a> */}
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <ul className="row">
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <div>
                                  <label className="CR-font-16 text-left">Address line 1</label>
                                </div>
                                <div className="col-6 w-50 d-flex justify-content-end">
                                  <p
                                    style={{ lineBreak: "anywhere" }}
                                    className="CR-font-16 text-right CR-black-text CR-fw-500"
                                  >
                                    {receiverData.address1}
                                  </p>
                                </div>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <div className="col-4">
                                  <label className="CR-font-16 text-left">Address line 2</label>
                                </div>
                                <div className="col-6 w-50 d-flex justify-content-end">
                                  <p
                                    style={{ lineBreak: "anywhere" }}
                                    className="CR-font-16 text-right CR-black-text CR-fw-500"
                                  >
                                    {receiverData.address2}
                                  </p>
                                </div>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Zipcode</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.zipcode}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">State</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.state}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between">
                                <label className="CR-font-16 text-left">City/District</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.city}
                                </p>
                              </div>
                            </li>
                          </ul>
                        </li>

                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                            <p className="mb-0">Bank details</p>
                            {/* <a onClick={() => props.setState({ activeStepForm: 13 })} className="">
                      <img src={editsvg} width="17px" height="17px" className="me-1" />
                      EDIT
                    </a> */}
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <ul className="row">
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Bank name</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.bankName}
                                </p>
                              </div>
                            </li>
                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                              <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                                <label className="CR-font-16 text-left">Account number</label>
                                <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                                  {receiverData.maskedAccountNo}
                                </p>
                              </div>
                            </li>
                            {/* <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                      <div className="align-items-center d-flex justify-content-between">
                        <label className="CR-font-16 text-left">Account type</label>
                       
                      </div>
                    </li> */}
                          </ul>
                        </li>
                      </ul>

                      <div className="bottom_panel d-flex align-items-center justify-content-center gap-3 gap-md-5">
                        <div className="bottom_panel_container">
                          <span
                            onClick={() => {
                              if (location?.state?.fromPage) {
                                navigate(location.state.fromPage);
                              } else {
                                navigate("/my-beneficiary");
                              }
                            }}
                            className="Back_arrow"
                          >
                            {" "}
                            <img src={BackArrow} alt="" />
                            Back
                          </span>
                          <button
                            type="button"
                            className=" CR-primary-btn"
                            onClick={() => setState({ isModalVisible: true })}
                          >
                            Delete
                          </button>
                          <button
                            type="button"
                            style={{ maxWidth: "17rem" }}
                            className=" CR-primary-btn "
                            onClick={() => {
                              setState({ viewBeneficiaryComponent: false });
                            }}
                          >
                            edit
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </>
        ) : (
          <EditBeneficiaryDetails receiverData={receiverData} setState={setState} />
        )}
      </Spinner>
      {state.isModalVisible && (
        <>
          <div class="modal fade show" tabindex="-1">
            <div class="modal-dialog-centered " style={{ margin: "0 auto", maxWidth: "500px" }}>
              <div class="modal-content">
                <div class="modal-body">
                  <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                    onClick={() => setState({ isModalVisible: false })}
                  ></button>
                  <h5>Delete beneficiary?</h5>
                  {/* <p class="error">This is you final attempt</p> */}
                  <p>Are you sure you want to delete this beneficiary account?</p>
                  <div class="btn-modal-wrapper">
                    <span
                      onClick={() => setState({ isModalVisible: false })}
                      class="text-dark p-2"
                      style={{ marginRight: "5px" }}
                    >
                      CANCEL
                    </span>
                    <span onClick={sendOTPforDelete} class="modal-btn1">
                      DELETE
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-backdrop fade show"></div>
        </>
      )}
    </Main>
  );
};

export default ViewBeneficiaryDetails;
