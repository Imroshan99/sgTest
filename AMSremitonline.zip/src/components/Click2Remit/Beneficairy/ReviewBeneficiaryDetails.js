import React, { useReducer, useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import editsvg from "../../../assets/images/click2remit/Edit.svg";
import useHttp from "../../../hooks/useHttp";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import { useSelector } from "react-redux";
import { notification } from "antd";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import Spinner from "../../../reusable/Spinner";
import { useLocation } from "react-router-dom";
import { ViAmericaAuthAPI } from "../../../apis/ViAmericaApi/Auth";
import ViaVerifyOTP from "../containers/ViaVerifyOTP";

const ReviewBeneficiaryDetails = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const [reviewPage, setReviewPage] = useState(true);
  const { state } = props;
  const location = useLocation();
  const hookSendOtp = useHttp(ProfileAPI.sendOTP);
  const hookAddReceiver = useHttp(ReceiverAPI.addReceiver);
  const hookAddReceiverSecound = useHttp(ReceiverAPI.addReceiverSecond);
  const hookGetReceiverLists = useHttp(ReceiverAPI.receiverLists);
  const hookViaSendOTP = useHttp(ViAmericaAuthAPI.viaSendOTP);

  const [states, setStates] = useReducer((state, newState) => ({ ...state, ...newState }), {
    eventId: "",
  });

  const [loader, setLoader] = useState(0);
  const submitHandler = () => {
    // if(AuthReducer.regCountryCode==="US"){
    //   saveReceiver();

    // }else{
    // if (state.twofa === "Y") {
    const payload = {
      requestType: "VIASENDOTP",
      userId: AuthReducer.userID,
      otpType: "SEND",
      optionID: "email", //pass email or phone
      // otpType: "MAIL", //MAIL,LOGINMFA, SMS
      // phone: `+1${state.mobileNo}`,
      // phone: `+449923894533`,
      // emailId: state.beneficiaryDetails.email,
    };
    setLoader((prevState) => prevState + 1);
    hookViaSendOTP.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status == "S") {
        notification.success({ message: "OTP has been sent to your registered email address." });
        // props.setState({
        //   verificationToken: data.verificationToken,
        // });
        setStates({ eventId: data.eventId });
        setReviewPage(false);
      } else {
        // if (state.twofa === "Y") {
        notification.error({
          message: data.errorMessage ? data.errorMessage : "Via send OTP failed",
        });
      }
    });
    // }
  };
  const saveReceiver = async (verificationToken) => {
    let formData = {
      requestType: "RECEIVERADD",
      clientId: AuthReducer.regCountryCode === "US" ? "VIAMERICAS" : "",
      receiverType: "INDIVIDUAL",
      firstName: state.beneficiaryDetails.firstName.trim(),
      middleName: state.beneficiaryDetails.middleName
        ? state.beneficiaryDetails.middleName.trim()
        : "",
      lastName: state.beneficiaryDetails.lastName.trim(),
      nickName: state.beneficiaryDetails.nickname.trim(),
      accountNo: state?.beneBankAndAcctNo?.accountNo,
      relationship: state?.beneficiaryDetails?.relationship,
      gender: "",
      dob: "",
      address1: state.beneficiaryResidentialDetails.address1.trim(),
      address2: state.beneficiaryResidentialDetails.address2.trim(),
      // address3: state.beneficiaryResidentialDetails.address3
      //   ? state.beneficiaryResidentialDetails.address3.trim()
      //   : "",
      zipcode: state.beneficiaryResidentialDetails.zipcode,
      state: state.beneficiaryResidentialDetails.state,
      stateOther: "",
      city: state.beneficiaryResidentialDetails.city,
      nationality: "",
      cityOther: "",
      emailId: state.beneficiaryDetails.email,
      mobileCountryCode: state.beneficiaryDetails.mobileCountryCode,
      mobileNo: state.beneficiaryDetails.mobileNo,
      phoneNo: "",
      altPhone: "",
      fax: "",
      recvMode: "DC",
      accountHolderName: `${state.beneficiaryDetails.firstName.trim()} ${state.beneficiaryDetails.lastName.trim()}`,
      accountType: "S",
      bankName: props.state.beneficiaryBankDetails.bankName
        ? props.state.beneficiaryBankDetails.bankName
        : props.state.beneBankName,
      branchCode: state.beneficiaryBankDetails?.branchCode,
      bankBranch: state.beneficiaryBankDetails?.branchName,
      bankAddress: state.beneficiaryBankDetails?.bankAddress,
      bankState: state.beneficiaryBankDetails?.bankState,
      bankCity: state.beneficiaryBankDetails?.bankCity,
      nearestBranchCode: "",
      nearestBranch: "",
      recvUniqueIdType: "",
      recvUniqueIdValue: "",
      interBankCode: "",
      interBank: "",
      interAccountNo: "",
      interAccountType: "",
      interBranchCode: "",
      interBankBranch: "",
      interBankAddress: "",
      interBankCountry: "",
      recvCountry: AuthReducer.recvCountryCode,
      recvCurrency: AuthReducer.recvCurrencyCode,
      purpose: "",
      purposeCode: "",
      remark: "",
      isSameBank: "N",
      twofa: "N", //N
      // viamfa:"Y",
      // otpOption:"email",
      // otpFlag: "Y",
      // verifiedToken:verificationToken,
      verifiedToken: "",
      recvAddressCountryCode: "IN",
      userId: AuthReducer.userID,
    };
    if (AuthReducer.regCountryCode === "US") {
      setLoader((prevState) => prevState + 1);
      hookAddReceiverSecound.sendRequest(formData, function (data) {
        setLoader((prevState) => prevState - 1);
        if (data.status == "S") {
          if (location?.state?.pathname == "/new-transaction") {
            getReceiverLists();
          }
          notification.success({ message: data.message });
          props.setState({ activeStepForm: 12 });
          if (state.redirectPage === "NEW_TRANSACTION") {
            // navigate("/new-transaction", { state: state.redirectPageState });
          } else {
            // navigate("/my-recipient");
          }
        } else {
          props.setState({ activeStepForm: 11 });
          setReviewPage(true);
          notification.error({ message: data.errorMessage });
          let errors = [];
          data.errorList.forEach((error, i) => {
            notification.error({ message: error.error });
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          // if (errors.length > 0) form.setFields(errors);
        }
      });
    } else {
      setLoader((prevState) => prevState + 1);
      hookAddReceiver.sendRequest(formData, function (data) {
        setLoader((prevState) => prevState - 1);
        if (data.status == "S") {
          notification.success({ message: data.message });
          props.setState({ activeStepForm: 12 });
          // props.getReceiverLists();
          // props.setAddRecipentModal(false);
          // newForm.resetFields();
          // newForm1.resetFields();
          // setAddRecipentModalStep(true);
        } else {
          notification.error({ message: data.errorMessage });
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          // if (errors.length > 0) newForm.setFields(errors);
          // if (errors.length > 0) newForm1.setFields(errors);
        }
      });
    }
  };
  const getReceiverLists = () => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: AuthReducer.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
    };
    setLoader(true);
    hookGetReceiverLists.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        let newReceiver = data.responseData.filter((i) => {
          return i.nickName == state.beneficiaryDetails.nickname.toUpperCase();
        });

        let newRecv = JSON.stringify(newReceiver[0]);
        props.setState({ autofillRecv: newRecv });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  return (
    <>
      {reviewPage ? (
        <div className="container h-100">
          <div className="row h-100 justify-content-center">
            <div className="align-self-center col-lg-7 col-md-7 col-sm-12 " style={{marginRight:"auto"}}>
              <div className="CR-default-box CR-max-width-620">
                <Spinner spinning={loader === 0 ? false : true}>
                  <ul className="row CR-side-space">
                    <li className="back-arrow-nav   d-xs-block d-done">
                      <img src={BackArrow} alt="BackArrow" />
                    </li>

                    <li className="col-md-12 col-sm-12 col-lg-12 ">
                      <h4 className="text-black CR-font-28 mb-1">Review beneficiary details</h4>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12">
                      <p className="text-left CR-font-16">Check your beneficiary details.</p>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                      <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                        <p className="mb-0">Personal information</p>
                        <span
                          className="editcolor"
                          onClick={() => props.setState({ activeStepForm: 7 })}
                        >
                          <img src={editsvg} width="17px" height="17px" className="me-1" />
                          EDIT
                        </span>
                      </div>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                      <ul className="row">
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">Name</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {`${state.beneficiaryDetails.firstName} ${
                                state.beneficiaryDetails.middleName
                                  ? state.beneficiaryDetails.middleName
                                  : ""
                              } ${state.beneficiaryDetails.lastName}`}
                            </p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">Nick name</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {state.beneficiaryDetails.nickname}
                            </p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">Relationship</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {state.beneficiaryDetails.relationship}
                            </p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">Mobile number</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {state.beneficiaryDetails.mobileNo}
                            </p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left"> Email address</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {state.beneficiaryDetails.email}
                            </p>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                      <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                        <p className="mb-0">Residential details</p>
                        <span
                          className="editcolor"
                          onClick={() => props.setState({ activeStepForm: 8 })}
                        >
                          <img src={editsvg} width="17px" height="17px" className="me-1" />
                          EDIT
                        </span>
                      </div>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                      <ul className="row">
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <div className="col-4">
                              <label className="CR-font-16 text-left">Address line 1</label>
                            </div>
                            <div className="col-6 w-50 d-flex justify-content-end">
                              <p
                                style={{ lineBreak: "anywhere" }}
                                className="CR-font-16 text-right CR-black-text CR-fw-500"
                              >
                                {state.beneficiaryResidentialDetails.address1}
                              </p>
                            </div>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <div className="col-4">
                              <label className="CR-font-16 text-left">Address line 2</label>
                            </div>
                            <div className="col-6 w-50 d-flex justify-content-end">
                              <p
                                style={{ lineBreak: "anywhere" }}
                                className="CR-font-16 text-right CR-black-text CR-fw-500"
                              >
                                {state.beneficiaryResidentialDetails.address2}
                              </p>
                            </div>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">Zipcode</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {state.beneficiaryResidentialDetails.zipcode}
                            </p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">State</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {state.beneficiaryResidentialDetails.state}
                            </p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">City/District</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {state.beneficiaryResidentialDetails.city}
                            </p>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                      <div className="align-items-center cr_greyTitle d-flex justify-content-between">
                        <p className="mb-0">Bank details</p>
                        <span
                          className="editcolor"
                          onClick={() => props.setState({ activeStepForm: 9 })}
                        >
                          <img src={editsvg} width="17px" height="17px" className="me-1" />
                          EDIT
                        </span>
                      </div>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                      <ul className="row">
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">Bank name</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {props.state.beneficiaryBankDetails.bankName
                                ? props.state.beneficiaryBankDetails.bankName
                                : props.state.beneBankName}
                            </p>
                          </div>
                        </li>
                        <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                          <div className="align-items-center d-flex justify-content-between CR-border-bottom">
                            <label className="CR-font-16 text-left">Account number</label>
                            <p className="CR-font-16 text-right CR-black-text CR-fw-500">
                              {state?.beneBankAndAcctNo?.accountNo}
                            </p>
                          </div>
                        </li>
                      </ul>
                    </li>
                  </ul>

                  <div className="bottom_panel">
                    <div className="d-flex justify-content-between align-items-center gap-3 gap-md-5">
                      <span
                        className="Back_arrow d-flex align-items-center"
                        onClick={() => props.setState({ activeStepForm: 9 })}
                      >
                        {" "}
                        <img src={BackArrow} alt="" />
                        Back
                      </span>
                      <button
                        style={{ maxWidth: "17rem" }}
                        type="button"
                        onClick={submitHandler}
                        className="CR-primary-btn "
                      >
                        Proceed
                      </button>
                    </div>
                  </div>
                </Spinner>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <ViaVerifyOTP
          setReviewPage={setReviewPage}
          saveReceiver={saveReceiver}
          state={states}
          setState={setStates}
          useFor="receiver"
        />
      )}
    </>
  );
};

export default ReviewBeneficiaryDetails;
