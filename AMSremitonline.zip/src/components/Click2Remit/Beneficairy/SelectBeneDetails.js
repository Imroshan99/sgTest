import React, { useEffect, useReducer, useState } from "react";
import Main from "../Layouts/Main";
import BackArrow from "../../../assets/images/click2remit/Back_arrow.svg";
import Chevronright from "../../../assets/images/click2remit/Chevronright.svg";
// import icicilogopng from "../../../assets/images/click2remit/icici-logo.png";
import Addsvg from "../../../assets/images/click2remit/Add.svg";
import { useSelector } from "react-redux";
import useHttp from "../../../hooks/useHttp";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import { useLocation, useNavigate } from "react-router-dom";
import Spinner from "../../../reusable/Spinner";
const SelectBeneDetails = () => {
  const AuthReducer = useSelector((state) => state.user);
  const hookGetReceiverLists = useHttp(ReceiverAPI.receiverLists);
  const navigate = useNavigate();
  const [loader, setLoader] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    receiverLists: [],
  });
  useEffect(() => {
    getReceiverLists();
  }, []);
  const getReceiverLists = (data) => {
    const payload = {
      requestType: "GETRECVLIST",
      userId: AuthReducer.userID,
      favouriteFlag: "",
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
    };
    setLoader(true);
    hookGetReceiverLists.sendRequest(payload, function (data) {
      setLoader(false);
      if (data.status == "S") {
        setState({ receiverLists: data.responseData });
        if (data.responseData.length == 0) {
        } else {
        }
      } else {
      }
    });
  };
  return (
    <Main>
      <Spinner spinning={loader}>
        <div className="container h-100">
          <div className="row h-100 justify-content-center">
            <form>
              <div className="align-self-center col-lg-7 col-md-7 col-sm-12 mx-auto">
                <div className="CR-default-box CR-max-width-620">
                  <ul className="row CR-side-space">
                    <li className="back-arrow-nav d-xs-block d-done">
                      <img src={BackArrow} alt="" />
                    </li>

                    <li className="col-md-12 col-sm-12 col-lg-12 ">
                      <h4 className="text-black CR-font-28 mb-1">Select beneficiary</h4>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12">
                      <p className="text-left">Select a beneficiary to transfer money to.</p>
                    </li>
                    <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                      <ul className="row">
                        {state.receiverLists.map((receiver, key) => {
                          {
                            return (
                              <>
                                <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                                  <div className="align-items-start d-flex justify-content-start w-100 single-box">
                                    <div className="CR-bank-logo me-3">
                                      {/* <img src={icicilogopng} width="100%" height="100%" /> */}
                                    </div>
                                    <div className="d-flex justify-content-between flex-column CR-w-80">
                                      <label className="CR-font-16 CR-black-text CR-fw-600 text-left">
                                        {`${receiver.firstName} ${receiver.lastName}`}
                                      </label>
                                      <p className="CR-font-14 text-left CR-fw-500 mb-0">
                                        {receiver.bankName} <span>&#8226;</span>{" "}
                                        {receiver.unMaskedAccountNo}
                                      </p>
                                    </div>
                                    <span href="/#" className="">
                                      <img src={Chevronright} width="24px" height="24px" />
                                    </span>
                                  </div>
                                </li>
                              </>
                            );
                          }
                        })}

                        {/* <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                                                <div className="align-items-start d-flex justify-content-start w-100 single-box">
                                                    <div className="CR-bank-logo me-3"><img src={icicilogopng} width="100%" height="100%" /></div>
                                                    <div className="d-flex justify-content-between flex-column CR-w-80">
                                                        <label className="CR-font-16 CR-black-text CR-fw-600 text-left">John Thomas Doe</label>
                                                        <p className="CR-font-14 text-left CR-fw-500 mb-0">HSBC UAE <span>&#8226;</span> 32165498710111</p>
                                                    </div>
                                                    <a href="/#" className=""><img src= {Chevronright} width="24px" height="24px" /></a>
                                                </div>
                                            </li>
                                            <li className="col-md-12 col-sm-12 col-lg-12 my-2">
                                                <div className="align-items-start d-flex justify-content-start w-100 single-box">
                                                    <div className="CR-bank-logo me-3"><img src={icicilogopng} width="100%" height="100%" /></div>
                                                    <div className="d-flex justify-content-between flex-column CR-w-80">
                                                        <label className="CR-font-16 CR-black-text CR-fw-600 text-left">John Thomas Doe</label>
                                                        <p className="CR-font-14 text-left CR-fw-500 mb-0">HSBC UAE <span>&#8226;</span> 32165498710111</p>
                                                    </div>
                                                    <a href="/#" className=""><img src={Chevronright}  width="24px" height="24px" /></a>
                                                </div>
                                            </li> */}
                      </ul>
                    </li>

                    <li className="col-md-12 col-sm-12 col-lg-12 text-start mb-5 mt-3">
                      <span
                        onClick={() => {
                          navigate("/my-beneficiary");
                        }}
                        className="CR-blue-link CR-font-14 CR-fw-500"
                      >
                        <img src={Addsvg} width="16px" height="16px" className="me-2" />
                        ADD NEW BENEFICIARY ACCOUNT
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </form>
          </div>
        </div>
      </Spinner>
    </Main>
  );
};

export default SelectBeneDetails;
