import React, { useState, useReducer, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Input, notification, Menu, Dropdown, Button } from "antd";
import { AuthAPI } from "../../../apis/AuthAPI";
import { connect, useDispatch, useSelector } from "react-redux";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import useHttp from "../../../hooks/useHttp";
import Spinner from "../../../reusable/Spinner";
import { setSessionStorage } from "../../../services/utility/storage";
import {
  login,
  setIsLoggedIn,
  setLastLogin,
  setToken,
  setUserFullName,
  setUserId,
  setUserKyc,
} from "../../../reducers/userReducer";
import CustomInput from "../../../reusable/CustomInput";
import FloatInput from "../../../reusable/FloatInput";

function LoginForm(props) {
  const ConfigReducer = useSelector((state) => state.user);
  const websiteSettings = useSelector(
    (state) => state.user.groupIdSettings.settings
  );
  const dispatch = useDispatch();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  let navigate = useNavigate();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      loginData: {},
      nextAction: "",
    }
  );

  const hookUserRiskProfile = useHttp(ProfileAPI.userRiskProfile);
  const hookLogin = useHttp(AuthAPI.login);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    form.setFieldsValue({ loginpassword: "" });
  }, []);

  const onFinish = (value) => {
    
    const payload = {
      requestType: "LOGIN",
      loginId: value.loginId,
      password: value.loginpassword,
      noofAttempts: "1",
      custType: "SEND",
      referer: "",
    };

    setLoader(true);
    hookLogin.sendRequest(payload, function (data) {
      if (data.status == "S") {
        userRiskProfile(data);
        storeLoginData(data);
      } else {
        setLoader(false);
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });

          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) form.setFields(errors);
        } else {
          notification.error({ message: data.errorMessage });
        }
      }
    });
  };

  const userRiskProfile = (loginData) => {
    const userRiskProfilePayload = {
      requestType: "RISKPROFILE",
      userId: loginData.userId,
      ___token: loginData.token,
    };

    setLoader(true);
    hookUserRiskProfile.sendRequest(userRiskProfilePayload, function (data) {
      if (data.status == "S") {
        setState({ nextAction: data.nextAction });
        dispatch(setUserKyc(data.nextAction));
      }
      setLoader(false);
    });
  };

  const storeLoginData = (loginData) => {
    notification.success({
      message: `WELCOME ${loginData.firstName} ${loginData.lastName}`,
    });
    const objLoginData = { ...loginData, ...websiteSettings };
    props.manageAuth("logintoken", loginData);
    saveUser(objLoginData, state.nextAction);

    if (state.nextAction == "KYC_COMPLETE") {
      setTimeout(() => {}, 500);
    } else {
      // can comment this line, not usable at all
      setTimeout(() => {
        navigate("/new-transaction");
      }, 500);
    }
  };

  const saveUser = (data, nextAction) => {
    // for session storage
    if (data.refreshPage) {
      setSessionStorage("accessToken", data.token);
      setSessionStorage("isLoggedIn", true);
      setSessionStorage("regCountryCode", data.regCountryCode);

      setSessionStorage("userID", data.userId);
      setSessionStorage("userFullName", data.firstName + " " + data.lastName);
    } else {
      dispatch(
        login({
          lastLogin: data.lastLoginTimeIST,
          userID: data.userId,
          userFullName: data.firstName + " " + data.lastName,
          accessToken: data.token,
          isLoggedIn: true,
          regCountryCode: data.regCountryCode,
        })
      );
      // dispatch(setLastLogin(data.lastLoginTimeIST));
      // dispatch(setUserId(data.userId));
      // dispatch(setUserKyc(nextAction));
      // dispatch(setUserFullName(data.firstName + " " + data.lastName));
      // dispatch(setToken(data.token));
      // dispatch(setIsLoggedIn(true));
    }
  };

  const menu = (
    <Menu>
      <Menu.Item>
        <Link to="/forgot-password">Forgot Password?</Link>
      </Menu.Item>
      <Menu.Item>
        <Link to="/unlock-account">Unlock Account?</Link>
      </Menu.Item>
    </Menu>
  );

  return (
    <div className="login-right">
      <h1 className="title mb-4">Log In</h1>
      <div className="mb-3">
        <p className="subtitle">
          Not Registered?{" "}
          <Link to="/signup">
            <span>Register here</span>
          </Link>
        </p>

        <div>
          <div className="row">
            <div className="col-md-12">
              <Form
                form={form}
                onFinish={onFinish}
                autoComplete="none"
              >
                <div className="mb-2">
                  {/* <label className="step-label mb-1">Log In ID</label>
                   <Form.Item
                    className="form-item"
                    name="loginId"
                    rules={[
                      {
                        required: true,
                        message: "Please input your Email ID.",
                      },
                      {
                        type: "email",
                        message: "Please input valid Email ID.",
                      },
                    ]}
                  >
                    <Input
                      autoFocus
                      size="large"
                        placeholder="Enter your Email ID"
                      autoComplete="off"
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCut={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                    />
                  </Form.Item> */}
                  <CustomInput
                    name="loginId"
                    label="Email"
                    type="email"
                    // validationRules={[{ min: 3, message: "minimum 3 char" }]}
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCut={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    required
                  />
                </div>
                {/* <CustomInput
                  name="username"
                  validationRules={[{ min: 3, message: "minimum 3 char" }]}
                  required
                >
                  <FloatInput placeholder="Enter emaill address" />
                </CustomInput> */}
                <div className="mb-2">
                  {/* <label className="step-label mb-1">Password</label>
                  <Form.Item
                    className="form-item"
                    name="loginpassword"
                    rules={[
                      {
                        required: true,
                        message: "Please input your Password.",
                      },
                      {
                        min: 10,
                        max: 20,
                        message:
                          "Password should be between 10 and 20 characters long.",
                      },
                    ]}
                  >
                    <Input.Password
                      size="large"
                      // placeholder="Enter password"
                      // onPaste={(e) => {
                      //   e.preventDefault();
                      //   return false;
                      // }}
                      // onCopy={(e) => {
                      //   e.preventDefault();
                      //   return false;
                      // }}
                      // onCut={(e) => {
                      //   e.preventDefault();
                      //   return false;
                      // }}
                    />
                  </Form.Item> */}
                  <CustomInput
                    className="form-item"
                    name="loginpassword"
                    type="password"
                    label="Password"
                    min={10}
                    max={20}
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCut={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    required
                  />
                </div>

                <Spinner spinning={loading}>
                  <div className="d-grid g-2">
                    <button
                      disabled={loading}
                      className="btn btn-primary btn-lg my-1"
                      type="submit"
                    >
                      Login
                    </button>
                  </div>
                </Spinner>
                <Dropdown
                  overlay={menu}
                  trigger={["click"]}
                  placement="bottomLeft"
                  arrow
                >
                  <p role="button" className="btn-link mt-5 text-center">
                    Problems Signing Up ?
                  </p>
                </Dropdown>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginForm;
