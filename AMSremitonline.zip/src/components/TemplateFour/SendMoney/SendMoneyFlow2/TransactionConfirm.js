import React, { useEffect, useReducer, useState } from "react";
import Swal from "sweetalert2";
import { Form, Checkbox, Row, Col } from "antd";
import { Link } from "@mui/material";
import { useSelector } from "react-redux";
import TCModal from "../../../../containers/ModalBox/TCModal";
import { EditOutlined } from "@ant-design/icons";

export default function TransactionConfirm(props) {
  const AuthReducer = useSelector((state) => state.user);
  const [form] = Form.useForm();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      tcModalVisible: false,
    }
  );
  // console.log(props)
  const onClickSendMoney = () => {
    if (props.state.isSelectedBankTransfer) {
      if (props.state._isScheduleTransaction == true) {
        props.bookScheduleTransaction();
      } else {
        props.bookTransaction();
      }
    } else {
      Swal.fire({
        text: "You will now be redirected to a third party payment gateway using PGP encryption to protect the privacy of your details. Once you have successfully completed the transfer of funds you will receive a transaction notice indicating the status of the debit from your account and a reference number will be generated and displayed to you.",
        // showDenyButton: true,
        showCancelButton: true,
        denyButtonText: `Cancel`,
        confirmButtonText: "Confirm",
        confirmButtonColor: "#2dbe60",
      }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          if (props.state._isScheduleTransaction == true) {
            props.bookScheduleTransaction();
          } else {
            props.bookTransaction();
          }
        } else if (result.isDenied) {
          Swal.fire("Changes are not saved", "", "info");
        }
      });
    }
  };

  const handleTcModal = () => {
    setState({ tcModalVisible: true });
  };

  return (
    <div>
      {state.tcModalVisible && <TCModal state={state} setState={setState} />}
      <Row>
        <Col span={12}>
          <div className="mt-4">
            <h6>
              Edit Transaction
              <EditOutlined
                onClick={() => props.setState({ isStep: 1 })}
              />
            </h6>

            <hr className="pr-4" />
            <p>Today's Date</p>
            <p className="fw-600">{props.state.initiateDate}</p>
          </div>
          <div className="mt-4">
            <h6>Sender Name</h6>
            <p className="text-uppercase">{props.state.senderName}</p>
          </div>
          {props.state.isSelectedBankTransfer && (
            <div className="mt-4">
              <h6>Source Account</h6>
              <p className="text-uppercase">{props.state.accountNo}</p>
            </div>
          )}
          <div className="mt-4">
            <p>Amount To Be Sent (inclusive of taxes and discounts)</p>
          </div>
          <p className=" m-0 fs-6">
            <b>
              {AuthReducer.sendCurrencyCode} {props.state.sendAmount}
            </b>
          </p>
          <small
            className="text-danger"
            role="button"
            onClick={() => props.setIsModalVisible(true)}
          >
            View Breakup
          </small>
          <p>
            Transfer Fee {AuthReducer.sendCurrencyCode} {props.state.totalFee}
          </p>
        </Col>
        <Col span={12}>
          <div className="mt-4">
            <h6>
              Recipient
              <EditOutlined
                onClick={() => props.setState({ isStep: 2 })}
              />
            </h6>
            <hr className="pr-4" />
            <p>Estimated Date Of Delivery</p>
            <p className="fw-600">{props.state.expectedDeliveryDate}</p>
          </div>
          {/* <div className="mt-3">
            <small>
              The Exchange rate is confirmed as long as KCB Bank receives the
              money by
            </small>
            <p>DD/MM/YYYY.HHTMM</p>
          </div> */}
          <div className="mt-4">
            <h6>Recipient Name</h6>
            <p className="text-uppercase">{props.state.receiverName}</p>
          </div>
          <div className="mt-4">
            <small>Purpose Of Money Transfer</small>
            <p>{props.state.purposeName}</p>
          </div>
          <div className="mt-4">
            <small>Recipient Bank Account</small>
            <p>{props.state.receiverAccount}</p>
          </div>
          <small>Amount To Be Recieved*</small>
          <p className=" m-0 fs-6">
            <b>
              {AuthReducer.recvCurrencyCode} {props.state.recvAmount}
            </b>
          </p>
          <small>
            * Recipient may receive less due to fees charged by the recipient’s
            bank or foreign taxes
          </small>
        </Col>
      </Row>
      {/* <div className="bg-light mt-4 px-2">
        <p className="m-0 fw-600">Kindly Note:</p>
        <ul>
          <li>
            The card must be a GBP Chip and PIN Debit Card and should not be
            issued by ICICI Bank UK PLC.
          </li>
          <li>
            Credit cards will not be accepted for a Transfer. We may levy
            additional fees up to 3% of total amount on customers when a Credit
            Card is used to fund the money transfer requests to India.
          </li>
          <li>
            The card must be your personal debit card. 3D Secure required for
            online authentication.
          </li>
        </ul>
      </div> */}
      <br />
      <Form onFinish={onClickSendMoney}>
        <div>
          <Form.Item
            className="form-item"
            name="readTermsConditions"
            valuePropName="checked"
            rules={[
              {
                validator: (_, value) =>
                  value
                    ? Promise.resolve()
                    : Promise.reject(
                        new Error("Please confirm terms and conditions.")
                      ),
              },
            ]}
          >
            <Checkbox>
              I acknowledge that I have read, understood and I agree to the{" "}
              <a href="javascript:void(0)" onClick={handleTcModal}>
                Terms &amp; Conditions
              </a>
              .
            </Checkbox>
          </Form.Item>
        </div>

        <div className="d-flex mt-4">
          <button
            className="btn btn-primary text-white px-5"
            onClick={() => props.setState({ isStep: 1 })}
          >
            Cancel
          </button>
          <button
            htmlType="submit"
            className="btn btn-primary text-white px-5 mx-4"
          >
            Send Now
          </button>
        </div>
      </Form>
    </div>
  );
}
