import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import Contact1 from "../Contact/ContactFlowOne/Contact";
const Contact = (props) => {
    const AuthReducer = useSelector((state) => state.user);
    const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
    const templateFlow = AuthReducer.groupIdSettings?.contact?.flow;
    return (
      <>
        <Dashboard pageTitle="Contact">
          {templateFlow === "FLOW1" && (
            <Contact1
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
           {templateFlow === "FLOW2" && (
            <Contact1
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
          {/* {templateFlow === "FLOW2" && (
            <TransactionAction2
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )} */}
        </Dashboard>
      </>
    );
  };
  
  export default Contact;
  