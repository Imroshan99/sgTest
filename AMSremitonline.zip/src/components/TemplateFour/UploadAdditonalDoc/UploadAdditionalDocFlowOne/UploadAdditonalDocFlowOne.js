import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import {
  Form,
  Input,
  Select,
  notification,
  Upload,
  DatePicker,
  message,
  Modal,
} from "antd";
import {
  CameraOutlined,
  DeleteOutlined,
  FilePdfOutlined,
  LoadingOutlined,
} from "@ant-design/icons";
import moment from "moment";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import useHttp from "../../../../hooks/useHttp";
import * as kycLottie from "../../../../assets/images/XR/KYC-under-review.json";

import { TransactionAPI } from "../../../../apis/TransactionAPI";
import Lottie from "react-lottie";
import Spinner from "../../../../reusable/Spinner"
import CustomInput from "../../../../reusable/CustomInput";
const { Option } = Select;

export default function UploadAdditonalDocFlowOne(props) {
  const navigate=useNavigate();
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);

  const [uploadAddDoc, setUploadAddDoc] = useState(true);
  const [backDoc, setBackDoc] = useState("");
  const [frontDoc, setFrontDoc] = useState("");
  const [loading, setLoading] = useState();
  const [spinner, setSpinner] = useState(0);
  const [imageUrl, setImageUrl] = useState();
  const [imageUrl1, setImageUrl1] = useState();
  const [passFileNo, setPassFileNo] = useState();
  const location = useLocation();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      userID: AuthReducer.userID,
      nationalities: [],
      additionalInfo2: "",
      occupationLists: [],
      sourceOFFundLists: [],
      idProofLists: [],
      addressProofLists: [],
      stateLists: [],
      cityLists: [],
      allIdAddressProofList: [],
      profileData: [],
      stateListsIssuer: [],
      issuerCountryList: [],
      sourceFundOther: "",
      occupationOther: "",
      idIssuer: "",
      redirectPage: "",
      redirectPageState: [],
      DocPdf: false,
      DocPdf1: false,
      DocPdf2: false,
    }
  );

  const hookGetNationality = useHttp(GuestAPI.getNationality);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);
  const hookUserDocUpload = useHttp(ProfileAPI.userDocUpload);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetUniqueIdentifierList = useHttp(GuestAPI.uniqueIdentifierList);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetSendingCountryLists = useHttp(GuestAPI.sendingCountryList);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGetSourceOFFundLists = useHttp(TransactionAPI.sourceOFFundLists);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getSourceOFFundLists();
    getUserProfile();
    getNationality();
    getOccupationLists();
    getUniqueIdentifierNames();
    getStateLists();
    getIssuerCountryList();
    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
    form.setFieldsValue({ country: "UK" });
  }, []);

  const getIssuerCountryList = async () => {
    let payload = {
      requestType: "COUNTRYLIST",
    };

    hookGetSendingCountryLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ issuerCountryList: data.responseData });
      }
    });
  };
  const getNationality = async () => {
    const payload = {
      requestType: "NATIONALITYLIST",
      keyword: "",
    };

    hookGetNationality.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ nationalities: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getUserProfile = async () => {
    let payload = {
      requestType: "USERPROFILE",
      userId: state.userID,
    };
    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ profileData: data });
      }
    });
  };

  const getOccupationLists = async () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetOccupationLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        data.responseData.push({
          displayOrder: "18",
          occupationDesc: "Other",
          occupationId: "100",
          occupationName: "Other",
        });
        setState({ occupationLists: data.responseData });
      }
    });
  };

  const getUniqueIdentifierNames = async () => {
    setSpinner((spinner) => spinner + 1);
    let payload = {
      requestType: "UNNAMESLIST",
      idFor: "RECV",
    };

    hookGetUniqueIdentifierList.sendRequest(payload, function (data) {
      setSpinner((spinner) => spinner - 1);
      if (data.status === "S") {
        const docListArray = data.responseData;
        setState({ allIdAddressProofList: docListArray });
      } else {
      }
    });
  };

  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.sendCountryCode,
      keyword: "",
    };
    setSpinner((spinner) => spinner + 1);
    hookGetCountryStates.sendRequest(payload, function (data) {
      setSpinner((spinner) => spinner - 1);
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        const stateIssuerArray = [...data.responseData];
        setState({ stateListsIssuer: stateIssuerArray });
      }
    });
  };

  const getSourceOFFundLists = () => {
    const payload = {
      requestType: "FUNDSOURCELIST",
    };

    hookGetSourceOFFundLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ sourceOFFundLists: data.responseData });
      }
    });
  };

  const submitHandler = (value) => {
    setSpinner((spinner) => spinner + 1);
    let nationalityCode = "";
    state.nationalities.find((i) => {
      if (i.nationality == value.nationality) {
        nationalityCode = i.countryCode;
      }
    });

    let editProfilePayload = {
      requestType: "EDITPROFILE",
      userId: AuthReducer.userID,
      gender: state.profileData.gender,
      dob: state.profileData.dob,
      address1: window.btoa(state.profileData.address1.trim()),
      address2: "",
      address3: "",
      address4: "",
      address5: "",
      state: "",
      city: state.profileData.city,
      sendCountry: "GB",
      zipCode: state.profileData.zip,
      occupation: state.profileData.occupation,
      profession: "1",
      citizenship: state.profileData.citizenship,
      pageName: "EDITPROFILE",
      income: "1",
      commAddress1: "",
      commAddress2: "",
      commCity: "",
      commStateProvince: "",
      commPostalCode: "",
      commCountry: "",
      companyName: "",
      nationality: nationalityCode,
      isSameCommAddressFlag: "N",
      extraInfoRequire: "Y",
      uniqueIdentifierType: value.idtype,
      uniqueIdentifierValue: value.documentidnumber,
      sourceOfFund: "",
      additionalInfo1: state.idIssuer,
      additionalInfo2: state.additionalInfo2, //for ID Exipiry
      additionalInfo3: "", //for Company Address
      additionalInfo4: value.passportfilenumber, //for ID Exipiry
      additionalInfo5: "", //for Remintence Frequencey
      // additionalInfo6: value.sourcefund, //for Source of Fund
      sin: "",
    };
    hookEditProfile.sendRequest(editProfilePayload, function (data) {
      setSpinner((spinner) => spinner - 1);

      if (data.status == "S") {
        userDocUpload({ docType: editProfilePayload.uniqueIdentifierType });
        userDocUpload1({ docType: editProfilePayload.uniqueIdentifierType });
      } else {
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  const afterClose = () => {
    if (!uploadAddDoc) {
      setImageUrl("");
      setImageUrl1("");
      form.resetFields();
      setUploadAddDoc(true);
    }
  };
  const userDocUpload = async (docData) => {
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: docData.docType,
      docName: frontDoc.fileName,
      docExtension: frontDoc.fileName.split(".").pop(),
      userId: AuthReducer.userID,
      document: frontDoc.docUrl,
    };
    setSpinner((spinner) => spinner + 1);

    hookUserDocUpload.sendRequest(docPayload, function (data) {
      setSpinner((spinner) => spinner - 1);

      if (data.status == "S") {
        setUploadAddDoc(false);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const userDocUpload1 = async (docData) => {
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: docData.docType,
      docName: backDoc.fileName1,
      docExtension: backDoc.fileName1.split(".").pop(),
      userId: AuthReducer.userID,
      document: backDoc.docUrl1,
    };
    setSpinner((spinner) => spinner + 1);
    hookUserDocUpload.sendRequest(docPayload, function (data) {
      setSpinner((spinner) => spinner - 1);

      if (data.status == "S") {
        setUploadAddDoc(false);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  const normFile1 = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };
  const normFile2 = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };

  const onChangeIssuerID = (value, type) => {
    if (value === "Other") {
    } else {
      setState({
        idIssuer: value,
      });
      if (type === "ISSUER_STATE") {
      }
    }
  };
  const handleChange = (info) => {
    if (info.file.status === "uploading") {
      setLoading(true);
      return;
    }
    if (info.file.status === "done") {
      getBase64(info.file.originFileObj, (imageUrl) => {
        setLoading(false);
      });
    }
  };

  function getBase64(img, callback) {
    const reader = new FileReader();
    reader.addEventListener("load", () => callback(reader.result));
    reader.readAsDataURL(img);
  }

  return (
    <>
      {/* <Modal
        className="light kyc"
        centered
        afterClose={afterClose}
        visible={props.isModalVisible}
        onCancel={() => {
          props.setIsModalVisible(false);
        }}
        footer={null}
        width={1000}
      > */}
        <Spinner spinning={spinner === 0 ? false : true}>
          {uploadAddDoc ? (
            <>
              <>
                <div className="mb-3">
                  <h2>Upload Additional Document</h2>
                </div>
                {/* <div className="d-flex mb-4">
                <button className="btn btn-info btn-sm me-3">ID Proof</button>
                <button className="btn btn-info btn-sm" disabled={true}>
                  Address Proof
                </button>
              </div> */}
                <Form
                  form={form}
                  autoComplete="none"
                  onFinish={(values) => {
                    if (frontDoc == "") {
                      form.setFields([
                        {
                          name: "document",
                          errors: ["Please upload document"],
                        },
                      ]);
                    }

                    if (frontDoc) {
                      // setValue(values);
                      // // setIdProofForm(false);
                      // setAddProofForm(true);
                      submitHandler(values);
                    }
                  }}
                >
                  <Row>
                    <Col className="pe-3">
                      <Row>
                        {/* <Form.Item
                          wrapperCol={{ span: 24 }}
                          className="form-item w-100"
                          name="idtype"
                          rules={[
                            {
                              required: true,
                              message: "Select Document Type.",
                            },
                          ]}
                        >
                          <Select
                            onChange={(e) => {
                              setPassFileNo(e);
                            }}
                            placeholder="Select Document Type"
                          >
                            {state.allIdAddressProofList.map((uiRow, i) => {
                              return (
                                <Option
                                  key={i}
                                  value={uiRow.docType}
                                >{`${uiRow.docName}`}</Option>
                              );
                            })}
                          </Select>
                        </Form.Item> */}
                        <CustomInput showLabel={false} wrapperCol={{ span: 24 }}
                          className="w-100"
                          name="idtype" type="select" onChange={(e) => {
                            setPassFileNo(e);
                          }}
                          placeholder="Select Document Type" label="Document Type" required>
                            {state.allIdAddressProofList.map((uiRow, i) => {
                              return (
                                <Option
                                  key={i}
                                  value={uiRow.docType}
                                >{`${uiRow.docName}`}</Option>
                              );
                            })}
                        </CustomInput>
                      </Row>
                      <div className="row mb-3">
                        <div className="col-6 text-center">
                        {/* <Form.Item
                          className="mb-2"
                          wrapperCol={{ span: 24 }}
                          name="document"
                          valuePropName="fileList"
                          getValueFromEvent={normFile}
                          multiple={false}
                          rules={[
                            {
                              required: true,
                              message: "Please upload document.",
                            },                           
                          ]}
                        >
                          <Upload
                            name="logo"
                            listType="picture-card"
                            className="avatar-uploader"
                            accept="image/jpg, image/jpeg, image/png,application/pdf"
                            showUploadList={false}
                            beforeUpload={(file) => {
                              setState({
                                DocPdf: file.type.includes("application/pdf"),
                              });
                              const isLt3MB = file.size;
                              if (isLt3MB >= "3000000") {
                                message.error(
                                  "Document upload size limit maximum of 3MB!"
                                );
                                return false;
                              } else {
                                const fileName = file.name;
                                const fileType = file.type;
                                const reader = new FileReader();
                                reader.onload = (e) => {
                                  setFrontDoc({
                                    fileName,
                                    fileType,
                                    docUrl: e.target.result,
                                  });
                                  setImageUrl(e.target.result);
                                };
                                reader.readAsDataURL(file);

                                return false;
                              }
                            }}
                            onChange={handleChange}
                          >
                            {imageUrl ? (
                              <>
                                {state.DocPdf ? (
                                  <FilePdfOutlined />
                                ) : (
                                  <img
                                    src={imageUrl}
                                    alt="avatar"
                                    width="100%"
                                    height="100%"
                                  />
                                )}
                              </>
                            ) : (
                              <div>
                                {loading ? (
                                  <LoadingOutlined />
                                ) : (
                                  <CameraOutlined />
                                )}
                                <div className="mt-8">Upload</div>
                                <div>Front</div>
                              </div>
                            )}
                          </Upload>
                        </Form.Item> */}
                        <CustomInput showLabel={false} label="Upload document" className="mb-2"
                          wrapperCol={{ span: 24 }}
                          name="document"
                          valuePropName="fileList"
                          getValueFromEvent={normFile}
                          multiple={false} required>
                        <Upload
                            name="logo"
                            listType="picture-card"
                            className="avatar-uploader"
                            accept="image/jpg, image/jpeg, image/png,application/pdf"
                            showUploadList={false}
                            beforeUpload={(file) => {
                              setState({
                                DocPdf: file.type.includes("application/pdf"),
                              });
                              const isLt3MB = file.size;
                              if (isLt3MB >= "3000000") {
                                message.error(
                                  "Document upload size limit maximum of 3MB!"
                                );
                                return false;
                              } else {
                                const fileName = file.name;
                                const fileType = file.type;
                                const reader = new FileReader();
                                reader.onload = (e) => {
                                  setFrontDoc({
                                    fileName,
                                    fileType,
                                    docUrl: e.target.result,
                                  });
                                  setImageUrl(e.target.result);
                                };
                                reader.readAsDataURL(file);

                                return false;
                              }
                            }}
                            onChange={handleChange}
                          >
                            {imageUrl ? (
                              <>
                                {state.DocPdf ? (
                                  <FilePdfOutlined />
                                ) : (
                                  <img
                                    src={imageUrl}
                                    alt="avatar"
                                    width="100%"
                                    height="100%"
                                  />
                                )}
                              </>
                            ) : (
                              <div>
                                {loading ? (
                                  <LoadingOutlined />
                                ) : (
                                  <CameraOutlined />
                                )}
                                <div className="mt-8">Upload</div>
                                <div>Front</div>
                              </div>
                            )}
                          </Upload>
                        </CustomInput>
                          {imageUrl && (
                            <DeleteOutlined
                              onClick={() => {
                                setImageUrl("");
                                setFrontDoc("");
                              }}
                            />
                          )}
                        </div>
                        <div className="col-6 text-center">
                          {/* <Form.Item
                            className="mb-2"
                            wrapperCol={{ span: 24 }}
                            name="document2"
                            valuePropName="fileList"
                            getValueFromEvent={normFile1}
                            multiple={false}
                            rules={[
                              {
                                required: false,
                                message: "Please upload document.",
                              },
                            ]}
                          >
                            <Upload
                              name="logo1"
                              listType="picture-card"
                              className="avatar-uploader"
                              accept="image/jpg, image/jpeg, image/png, application/pdf"
                              showUploadList={false}
                              beforeUpload={(file) => {
                                setState({
                                  DocPdf1:
                                    file.type.includes("application/pdf"),
                                });
                                const isLt3MB = file.size;
                                if (isLt3MB >= "3000000") {
                                  message.error(
                                    "Document upload size limit maximum of 3MB!"
                                  );
                                  return false;
                                } else {
                                  const fileName1 = file.name;
                                  const fileType1 = file.type;
                                  const reader = new FileReader();

                                  reader.onload = (e) => {
                                    setBackDoc({
                                      fileName1,
                                      fileType1,
                                      docUrl1: e.target.result,
                                    });
                                    setImageUrl1(e.target.result);
                                  };
                                  reader.readAsDataURL(file);

                                  return false;
                                }
                              }}
                              onChange={handleChange}
                            >
                              {imageUrl1 ? (
                                <>
                                  {state.DocPdf1 ? (
                                    <FilePdfOutlined />
                                  ) : (
                                    <img
                                      src={imageUrl1}
                                      alt="avatar"
                                      width="100%"
                                      height="100%"
                                    />
                                  )}
                                </>
                              ) : (
                                <div>
                                  {loading ? (
                                    <LoadingOutlined />
                                  ) : (
                                    <CameraOutlined />
                                  )}
                                  <div>Upload</div>
                                  <div>Back</div>
                                </div>
                              )}
                            </Upload>
                          </Form.Item> */}
                          <CustomInput className="mb-2"
                            wrapperCol={{ span: 24 }}
                            name="document2"
                            valuePropName="fileList"
                            getValueFromEvent={normFile1}
                            multiple={false} 
                            showLabel={false}
                            label="Document"
                            >
                          <Upload
                              name="logo1"
                              listType="picture-card"
                              className="avatar-uploader"
                              accept="image/jpg, image/jpeg, image/png, application/pdf"
                              showUploadList={false}
                              beforeUpload={(file) => {
                                setState({
                                  DocPdf1:
                                    file.type.includes("application/pdf"),
                                });
                                const isLt3MB = file.size;
                                if (isLt3MB >= "3000000") {
                                  message.error(
                                    "Document upload size limit maximum of 3MB!"
                                  );
                                  return false;
                                } else {
                                  const fileName1 = file.name;
                                  const fileType1 = file.type;
                                  const reader = new FileReader();

                                  reader.onload = (e) => {
                                    setBackDoc({
                                      fileName1,
                                      fileType1,
                                      docUrl1: e.target.result,
                                    });
                                    setImageUrl1(e.target.result);
                                  };
                                  reader.readAsDataURL(file);

                                  return false;
                                }
                              }}
                              onChange={handleChange}
                            >
                              {imageUrl1 ? (
                                <>
                                  {state.DocPdf1 ? (
                                    <FilePdfOutlined />
                                  ) : (
                                    <img
                                      src={imageUrl1}
                                      alt="avatar"
                                      width="100%"
                                      height="100%"
                                    />
                                  )}
                                </>
                              ) : (
                                <div>
                                  {loading ? (
                                    <LoadingOutlined />
                                  ) : (
                                    <CameraOutlined />
                                  )}
                                  <div>Upload</div>
                                  <div>Back</div>
                                </div>
                              )}
                            </Upload>
                          </CustomInput>
                          {imageUrl1 && (
                            <DeleteOutlined
                              onClick={() => {
                                setImageUrl1("");
                                setBackDoc("");
                              }}
                            />
                          )}
                        </div>
                      </div>

                      <p>
                        <small className="opacity-50">
                          Supported formats: JPG, PNG, BMP, PDF
                          <br />
                          File size limit 3MB
                        </small>
                      </p>
                    </Col>

                    <Col md={8} className="b_left  ps-md-3">
                      <Row>
                        <Col md={4}>
                          <label>Document ID / Number</label>
                        </Col>
                        <Col md={8}>
                          {/* <Form.Item
                            name="documentidnumber"
                            rules={[
                              {
                                required: true,
                                message: "Enter ID Number.",
                              },
                              {
                                min: 3,
                                max: 100,
                                message: "Minimum 3 and Maximum 100",
                              },
                              {
                                pattern: /^[a-z0-9]+([-_\s]{1}[a-z0-9]+)*$/i,
                                message:
                                  "Id number must be numeric & alphanumeric without special charecter",
                              },
                            ]}
                          >
                            <Input type="text" autoComplete="none" />
                          </Form.Item> */}
                          <CustomInput showLabel={false} label="ID Number" type="text" autoComplete="none" name="documentidnumber"
                          min={3}
                          max={100}
                            validationRules={[                                                      
                              {
                                pattern: /^[a-z0-9]+([-_\s]{1}[a-z0-9]+)*$/i,
                                message:
                                  "Id number must be numeric & alphanumeric without special charecter",
                              },
                            ]}
                            required
                            />
                        </Col>
                      </Row>
                      <Row>
                        <Col md={4}>
                          <label>Issue Country</label>
                        </Col>
                        <Col md={8}>
                          {/* <Form.Item
                            className="form-item"
                            name="idissuer"
                            rules={[
                              {
                                required: true,
                                message: "Please select ID Issuer",
                              },
                            ]}
                          >
                            <Select
                              className="w-100"
                              onChange={(value) => {
                                onChangeIssuerID(value, "ISSUER_COUNTRY");
                              }}
                              showSearch
                            >
                              {state.issuerCountryList.map((uiRow, i) => {
                                return (
                                  <Option
                                    key={i}
                                    value={uiRow.countryName}
                                  >{`${uiRow.countryName}`}</Option>
                                );
                              })}
                            </Select>
                          </Form.Item> */}
                          <CustomInput 
                          type="select"
                          showLabel={false}
                          label="Issue Country"
                          name="idissuer"
                          className="w-100"
                              onChange={(value) => {
                                onChangeIssuerID(value, "ISSUER_COUNTRY");
                              }}
                              required
                              showSearch>
                          {state.issuerCountryList.map((uiRow, i) => {
                                return (
                                  <Option
                                    key={i}
                                    value={uiRow.countryName}
                                  >{`${uiRow.countryName}`}</Option>
                                );
                              })}
                          </CustomInput>
                        </Col>
                      </Row>
                      <Row>
                        <Col md={4}>
                          <label>Valid Till</label>
                        </Col>
                        <Col md={8}>
                          {/* <Form.Item
                            name="expiryDate"
                            rules={[
                              {
                                required: true,
                                message: "Enter Expiry Date.",
                              },
                            ]}
                          >
                            <DatePicker
                              className="w-100"
                              disabledDate={(current) => {
                                let customDate = moment().format("YYYY-MM-DD");
                                return (
                                  current &&
                                  current < moment(customDate, "YYYY-MM-DD")
                                );
                              }}
                              onChange={(value, dateString) => {
                                let formatedDate =
                                  moment(dateString).format("MM/DD/YYYY");
                                value !== null
                                  ? setState({
                                      additionalInfo2: formatedDate,
                                    })
                                  : setState({ additionalInfo2: "" });
                              }}
                            />
                          </Form.Item> */}
                          <CustomInput showLabel={false} label="Expiry Date" name="expiryDate" required>
                          <DatePicker
                              className="w-100"
                              disabledDate={(current) => {
                                let customDate = moment().format("YYYY-MM-DD");
                                return (
                                  current &&
                                  current < moment(customDate, "YYYY-MM-DD")
                                );
                              }}
                              onChange={(value, dateString) => {
                                let formatedDate =
                                  moment(dateString).format("MM/DD/YYYY");
                                value !== null
                                  ? setState({
                                      additionalInfo2: formatedDate,
                                    })
                                  : setState({ additionalInfo2: "" });
                              }}
                            />
                          </CustomInput>
                        </Col>
                      </Row>
                      <Row>
                        <Col md={4}>
                          <label>Nationality</label>
                        </Col>
                        <Col md={8}>
                          {/* <Form.Item
                            className="form-item"
                            name="nationality"
                            rules={[
                              {
                                required: true,
                                message: "Please select your Nationality.",
                              },
                            ]}
                          >
                            <Select className="w-100" showSearch>
                              {state.nationalities.map((nationality, i) => {
                                return (
                                  <Option
                                    key={i}
                                    value={nationality.nationality}
                                  >
                                    {nationality.nationality}
                                  </Option>
                                );
                              })}
                            </Select>
                          </Form.Item> */}
                          <CustomInput name="nationality" type="select" showLabel={false} label="Nationality" className="w-100" showSearch required>
                          {state.nationalities.map((nationality, i) => {
                                return (
                                  <Option
                                    key={i}
                                    value={nationality.nationality}
                                  >
                                    {nationality.nationality}
                                  </Option>
                                );
                              })}
                          </CustomInput>
                        </Col>
                      </Row>
                      {passFileNo == "PP" && (
                        <Row>
                          <Col md={4}>
                            <label>Passport File Number</label>
                          </Col>
                          <Col md={8}>
                            {/* <Form.Item
                              name="passportfilenumber"
                              rules={[
                                {
                                  required: false,
                                  message: "Enter your passport file Numbers.",
                                },
                                {
                                  min: 3,
                                  max: 100,
                                  message: "Minimum 3 and Maximum 100",
                                },
                                {
                                  pattern: /^[a-z0-9]+([-_\s]{1}[a-z0-9]+)*$/i,
                                  message:
                                    "Id number must be numeric & alphanumeric without special charecter",
                                },
                              ]}
                            >
                              <Input />
                            </Form.Item> */}
                            <CustomInput showLabel={false} label="Passport file Numbers" min={3}
                                max={100}  validationRules={[                                                               
                                {
                                  pattern: /^[a-z0-9]+([-_\s]{1}[a-z0-9]+)*$/i,
                                  message:
                                    "Id number must be numeric & alphanumeric without special charecter",
                                },
                              ]} />
                            <div
                              className="text-end opacity-50"
                            >
                              <small>Optional for Passport Selection</small>
                            </div>
                          </Col>
                        </Row>
                      )}
                      {/* <Row>
                      {!inputFields?.sourceOfFund?.hidden && (
                        <Col md={6}>
                          <label className="form-label">Source of fund</label>
                          <Form.Item
                            className="form-item"
                            name="sourcefund"
                            rules={[
                              {
                                required: true,
                                message: "Select Source of fund.",
                              },
                            ]}
                          >
                            <Select
                              onChange={(value) => {
                                setState({ sourceFundOther: value });
                              }}
                              className="w-100"
                              placeholder="Select Source of fund"
                              showSearch
                            >
                              {state.sourceOFFundLists.map((sList, i) => {
                                return (
                                  <Option key={i} value={sList.sourceOfFund}>
                                    {sList.sourceOfFund}
                                  </Option>
                                );
                              })}
                            </Select>
                          </Form.Item>
                        </Col>
                      )}
                      {!inputFields?.remittanceFrequency?.hidden && (
                        <Col md={6}>
                          <label className="form-label">
                            Remittance Frequency
                          </label>
                          <Form.Item
                            className="form-item"
                            name="remittance_freq"
                            rules={[
                              {
                                required: true,
                                message: "Select Remittance Frequency.",
                              },
                            ]}
                          >
                            <Select
                              className="w-100"
                              placeholder="Select Remittance Frequency"
                              showSearch
                            >
                              <Option value="WEEKLY">Weekly</Option>
                              <Option value="MONTHLY">Monthly</Option>
                              <Option value="QUARTERLY">Quarterly</Option>
                              <Option value="ANNUALLY">Annually</Option>
                              <Option value="ONE_OFF">One-Off</Option>
                            </Select>
                          </Form.Item>
                        </Col>
                      )}
                    </Row>
                    {state.sourceFundOther == "Other" && (
                      <Row>
                        <Col md={6}>
                          <Form.Item
                            name="sourceFundOther"
                            rules={[
                              {
                                required: true,
                                message: "Enter Your Source Of Fund.",
                              },
                            ]}
                          >
                            <Input placeholder="Enter Source of Fund" />
                          </Form.Item>
                        </Col>
                      </Row>
                    )}
                    <Row>
                      <Col md={6}>
                        <label className="form-label">Occupation</label>
                        <Form.Item
                          className="form-item"
                          name="occupation"
                          rules={[
                            {
                              required: true,
                              message: "Select Occupation.",
                            },
                          ]}
                        >
                          <Select
                            onChange={(value) => {
                              setState({ occupationOther: value });
                            }}
                            placeholder="Select Occupation"
                            className="w-100"
                            showSearch
                          >
                            {state.occupationLists.map((ocRow, i) => {
                              return (
                                <Option
                                  key={i}
                                  value={ocRow.occupationName}
                                >{`${ocRow.occupationName}`}</Option>
                              );
                            })}
                          </Select>
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row>
                      {state.occupationOther == "Other" && (
                        <Col md={6}>
                          <Form.Item
                            name="occupationOther"
                            rules={[
                              {
                                required: true,
                                message: "Enter Your Occupation.",
                              },
                            ]}
                          >
                            <Input placeholder="Enter Your Occupation" />
                          </Form.Item>
                        </Col>
                      )}
                    </Row> */}
                    </Col>
                  </Row>
                  <div className="d-flex justify-content-end">
                    <p
                      className="btn btn-link mb-3 me-3 text-primary"
                      onClick={() => {
                        props.setIsModalVisible(false);
                      }}
                    >
                      I'll do this later
                    </p>
                    <button
                      className="btn btn-primary text-white mb-3"
                      htmlType="submit"
                    >
                      Confirm
                    </button>
                  </div>
                </Form>
              </>
            </>
          ) : (
            <>
              <>
                <div className="d-flex flex-column justify-content-center align-items-center">
                  <Lottie
                    height={300}
                    width={300}
                    options={{
                      loop: false,
                      autoplay: true,
                      animationData: kycLottie,
                      rendererSettings: {
                        preserveAspectRatio: "xMidYMid slice",
                      },
                    }}
                  />
                  <h3 className="text-primary fw-800 text-center">
                    Your Document has been uploaded. <br />
                    We'll update you about your KYC status by Email.
                  </h3>
                </div>
                <div className="text-end">
                  <button
                    className="btn btn-primary text-white mb-3"
                    onClick={() => {
                      // props.setIsModalVisible(false);
                      navigate("/new-transaction");
                    }}
                  >
                    Done
                  </button>
                </div>
              </>
            </>
          )}
        </Spinner>
      {/* </Modal> */}
    </>
  );
}
