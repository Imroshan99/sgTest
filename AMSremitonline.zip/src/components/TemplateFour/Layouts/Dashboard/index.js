import React from "react";
import { useSelector } from "react-redux";
import DashboardBody from "./Dashboard";
import Header from "./Header";

const Dashboard = (props) => {
  const { pageTitle } = props;
  const groupConfig = useSelector((state) => state.user);
  // const temp = AuthReducer.groupIdSettings?.theme?.Header;

  return (
    <div className={`__dashboard1 __groupId_${groupConfig.groupId}`}>
      <Header />

      <DashboardBody pageTitle={pageTitle}>{props.children}</DashboardBody>
    </div>
  );
};

export default Dashboard;
