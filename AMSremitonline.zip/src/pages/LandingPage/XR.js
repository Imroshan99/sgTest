/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect, useReducer, useState } from "react";
import moment from "moment";
import "./XR.css";
import Lottie from "react-lottie";
import * as registerLottie from "../../assets/images/XR/register.json";
import * as addBenificiaryLottie from "../../assets/images/XR/Add-Benificiary.json";
import * as startTransactingLottie from "../../assets/images/XR/start-transacting.json";
import * as safeAndSecureLottie from "../../assets/images/XR/safe-and-secure.json";
import * as fullTransperencyLottie from "../../assets/images/XR/full-transperency.json";
import * as bestForexRateLottie from "../../assets/images/XR/best-forex-rate.json";


import Box from "@mui/material/Box";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import MenuItem from "@mui/material/MenuItem";
import IconButton from "@mui/material/IconButton";
import Spinner from "../../reusable/Spinner";

import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";

import { useSelector } from "react-redux";
import { GuestAPI } from "../../apis/GuestAPI";
import { notification } from "antd";
import { Link } from "react-router-dom";
import useHttp from "../../hooks/useHttp";

const HomeXr = () => {
  const ConfigReducer = useSelector((state) => state.user);
  const AuthReducer = useSelector((state) => state.user);

  const defaultSettings = ConfigReducer.groupIdSettings.default;
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const [value, setValue] = React.useState("FER");
  const [rateLoader, setRateLoader] = React.useState(false);
  const [timeoutId, setTimeoutId] = React.useState("");
  const [amount, setAmount] = useState({
    sendAmount: 1000,
    recvAmount: 0,
    // sendAmountError: "",
    // recvAmountError: "",
  });

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      twofa: ConfigReducer.twofa,
      paymentOptionsList: [],
      sendModeCode: defaultSettings.sendModeCode,
      programCode: defaultSettings.programCode,
      totalFee: 0,
      serviceCharge: 0,
      exRate: 0,
      amountPayable: 0,
      expectedDeliveryDate: "",
    }
  );

  const hookPostExchangeRate = useHttp(GuestAPI.postExchangeRate);
  const hookPaymentOptions = useHttp(GuestAPI.paymentOption);

  const handleChange = (event, newValue) => {
    // if (newValue === "2") {
    //   setState({
    //     programCode: "FERINST",
    //   });
    // } else {
    //   setState({
    //     programCode: defaultSettings.programCode,
    //   });
    // }
    setState({
      programCode: newValue,
    });
    setValue(newValue);
  };

  useEffect(() => {
    getPaymentOption();
    loadExhangeRateHandler(1000, AuthReducer.sendCurrencyCode);
  }, []);

  useEffect(() => {
    loadExhangeRateHandler(1000, AuthReducer.sendCurrencyCode);
  }, [state.programCode]);

  const getPaymentOption = () => {
    const payload = {
      requestType: "PAYMENTOPTION",
      amount: "1000",
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCountryCurrency: AuthReducer.recvCurrencyCode,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCountryCurrency: AuthReducer.sendCurrencyCode,
    };

    // setState({ loading: true });
    hookPaymentOptions.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ paymentOptionsList: data.responseData });
        setState({
          programCode: defaultSettings.programCode,
        });
        setValue(defaultSettings.programCode);
        // setState({ loading: false });
      }
    });
  };

  const loadExhangeRateHandler = (valueSendAmount, __currency) => {
    let payload = {
      requestType: "EXCHANGERATE",
      pageName: "PRELOGIN",
      amount: valueSendAmount,
      recvNickName: "NEWRECV_SB",
      recvModeCode: "DC",
      // sendModeCode: "ACH",
      sendModeCode: state.sendModeCode,
      programCode: state.programCode,
      paymentMode1: "",
      paymentMode2: "",
      promoCode: "",
      loyaltyPoints: "",
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCurrencyCode: AuthReducer.recvCurrencyCode,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      // enteredAmtCurrency: "GBP",
      enteredAmtCurrency: __currency,
    };
    setRateLoader(true);
    hookPostExchangeRate.sendRequest(payload, function (data) {
      setRateLoader(false);
      if (data.status == "S") {
        let expectedDeliveryDateStr = data.expectedDeliveryDate;
        let expectedDeliveryDate = expectedDeliveryDateStr.substring(
          0,
          expectedDeliveryDateStr.lastIndexOf(" ") + 1
        );

        setAmount({
          ...amount,
          sendAmount:
            __currency === "GBP" ? data.enteredAmount : data.amountPayable,
          recvAmount:
            __currency === "INR" ? data.enteredAmount : data.recvAmount,
        });
        setState({
          // sendAmount: data.sendAmount,
          // recvAmount: data.recvAmount,
          amountPayable: data.sendAmount,
          totalFee: data.totalFee,
          serviceCharge: data.serviceCharge,
          exRate: data.exRate,
          expectedDeliveryDate: expectedDeliveryDate,
        });
      } else {
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });
        } else {
          notification.error({ message: data.errorMessage });
        }
        setAmount({
          ...amount,
          recvAmount: 0,
        });
        setState({
          totalFee: 0,
          exRate: 0,
        });
      }
    });
  };

  const sendAmountHandler = (e, __currency) => {
    let sendAmtVal = "";
    // setState({ sendAmount: e.target.value })

    sendAmtVal =
      e.target.value.indexOf(".") >= 0
        ? e.target.value.substr(0, e.target.value.indexOf(".")) +
          e.target.value.substr(e.target.value.indexOf("."), 3)
        : e.target.value;
    clearTimeout(timeoutId);
    if (e.target.value) {
      setAmount({
        ...amount,
        sendAmount: sendAmtVal,
        // recvAmount: e.target.value,
      });

      const valueSendAmount = sendAmtVal;
      let valueTimeOutId = setTimeout(
        () => loadExhangeRateHandler(valueSendAmount, __currency),
        500
      );
      setTimeoutId(valueTimeOutId);
    } else {
      setAmount({
        ...amount,
        sendAmount: "",
        recvAmount: "",
      });
    }
  };

  const recvAmountHandler = (e) => {
    let recvAmtVal = "";
    recvAmtVal =
      e.target.value.indexOf(".") >= 0
        ? e.target.value.substr(0, e.target.value.indexOf(".")) +
          e.target.value.substr(e.target.value.indexOf("."), 3)
        : e.target.value;
    clearTimeout(timeoutId);
    if (e.target.value) {
      setAmount({
        ...amount,
        // sendAmount: e.target.value,
        recvAmount: recvAmtVal,
      });

      const valueSendAmount = recvAmtVal;
      let valueTimeOutId = setTimeout(
        () => loadExhangeRateHandler(valueSendAmount, "INR"),
        500
      );
      setTimeoutId(valueTimeOutId);
    } else {
      setAmount({
        ...amount,
        recvAmount: "",
        sendAmount: "",
      });
    }
  };

  return (
    <div className="main">
      <section className="xr_header">
        <div className="container py-3">
          <div className="row">
            <div className="col">
              <Link to="/">
                <img
                  src={require("../../assets/images/logos/" +
                    AuthReducer.groupId +
                    "_light_logo.svg")}
                  height="48px"
                />
              </Link>
            </div>
            <div className="col text-end">
              <Box sx={{ flexGrow: 1, display: { md: "block", xs: "none" } }}>
                <Link
                  className="btn btn-sm text-light shadow-none"
                  to="/contact"
                >
                  Contact
                </Link>
                <Link
                  className="btn btn-sm text-light shadow-none me-3"
                  to="/signup"
                >
                  Sign Up
                </Link>
                <Link className="btn btn-sm btn-secondary fw-800" to="/signin">
                  Log In
                </Link>
              </Box>

              <Box
                justifyContent={"end"}
                sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}
              >
                <IconButton
                  size="large"
                  aria-label="account of current user"
                  aria-controls="menu-appbar"
                  aria-haspopup="true"
                  onClick={handleOpenNavMenu}
                  color="default"
                  style={{ color: "#FFFFFF" }}
                >
                  <MenuIcon />
                </IconButton>
                <Menu
                  id="basic-menu"
                  anchorEl={anchorElNav}
                  // anchorOrigin={{
                  //   vertical: "bottom",
                  //   horizontal: "left",
                  // }}
                  keepMounted
                  // transformOrigin={{
                  //   vertical: "top",
                  //   horizontal: "left",
                  // }}
                  open={Boolean(anchorElNav)}
                  onClose={handleCloseNavMenu}
                  sx={{
                    display: { xs: "block", md: "none" },
                  }}
                >
                  <MenuItem key="m1" onClick={handleCloseNavMenu}>
                    <Link className="text-primary" to={"/signin"}>
                      LOGIN
                    </Link>
                  </MenuItem>

                  <MenuItem key="m2" onClick={handleCloseNavMenu}>
                    <Link className="text-primary" to={"/signup"}>
                      SIGN UP
                    </Link>
                  </MenuItem>

                  <MenuItem onClick={handleCloseNavMenu}>
                    <Link className="text-primary" to={"/"}>
                      Contact
                    </Link>
                  </MenuItem>
                </Menu>
              </Box>
            </div>
          </div>
          <div className="row my-5">
            <div className="col-12 col-md-6">
              <div className="headline">
                Transfer
                <br />
                <span style={{ color: "#10E7DC" }}>Made</span>
                <br />
                Simple
              </div>
            </div>
            <div className="col col-md-6">
              <div
                className="_m_padding"
                style={{
                  height: "500px",
                }}
              >
                <div className="xr_sendmoney_box mt-5">
                  <div className="row input_wrapper p-0">
                    <div className="col-8 col-md-9 py-2 px-3">
                      <div className="row">
                        <div className="col-5 col-md-6">
                          <input
                            type="text"
                            // placeholder="Amount to send"
                            // defaultValue={amount.sendAmount}
                            value={amount.sendAmount}
                            onChange={(e) =>
                              sendAmountHandler(e, AuthReducer.sendCurrencyCode)
                            }
                          />
                        </div>
                        <div className="col-7 col-md-6 text-end amount_label">
                          Amount to Send
                        </div>
                      </div>
                    </div>
                    <div className="col-4 col-md-3 py-2 country_dropdown_wrapper d-flex justify-content-center">
                      <div className="country_dropdown">
                        <span className="flagicon me-2">
                          <img
                            src={require("../../assets/images/flags/GB.png")}
                          />
                        </span>
                        <span className="countryName">GBP</span>
                      </div>
                    </div>
                  </div>
                  <div className="row  mt-4 mb-4 align-items-center">
                    <div className="col-12 col-md-6 ps-0 mobile_p_0">
                      <Box
                        sx={{ width: "100%", typography: "body1" }}
                        className="transfer_charge"
                      >
                        <Spinner
                          // indicator={
                          //   <Lottie
                          //     height={120}
                          //     width={120}
                          //     options={{
                          //       loop: true,
                          //       autoplay: true,
                          //       animationData: xrSpinnerLottie,
                          //       rendererSettings: {
                          //         preserveAspectRatio: "xMidYMid slice",
                          //       },
                          //     }}
                          //   />
                          // }
                          spinning={rateLoader}
                          delay={500}
                        >
                          <TabContext value={value}>
                            <Box
                              sx={{ borderBottom: 1, borderColor: "divider" }}
                            >
                              <TabList
                                onChange={handleChange}
                                aria-label="lab API tabs example"
                              >
                                {state.paymentOptionsList.map((item) => {
                                  return (
                                    <Tab
                                      label={item.programName}
                                      value={item.programCode}
                                      className="flex-fill"
                                    />
                                  );
                                })}

                                {/* <Tab
                                  label="Credit/Debit Card"
                                  value="2"
                                  className="flex-fill"
                                /> */}
                              </TabList>
                            </Box>
                            <TabPanel value="FER">
                              <ul className="transfer_charge_list">
                                <li>
                                  <div className="d-flex bd-highlight">
                                    <div className="bd-highlight seq_icon">
                                      -
                                    </div>
                                    <div className="flex-fill bd-highlight">
                                      Transfer Fees
                                    </div>
                                    <div className="flex-fill bd-highlight text-end">
                                      <span className="mx-2 text-info charge_value_span">
                                        {state.totalFee}
                                      </span>
                                      {AuthReducer.sendCurrencyCode}
                                    </div>
                                  </div>
                                </li>
                                <li>
                                  <div className="d-flex bd-highlight">
                                    <div className="bd-highlight seq_icon">
                                      -
                                    </div>
                                    <div className="flex-fill bd-highlight">
                                      Bank Charges
                                    </div>
                                    <div className="flex-fill bd-highlight text-end">
                                      <span className="mx-2 text-info  charge_value_span">
                                        {state.serviceCharge}
                                      </span>
                                      {AuthReducer.sendCurrencyCode}
                                    </div>
                                  </div>
                                </li>
                              </ul>
                            </TabPanel>
                            <TabPanel value="FERINST">
                              <ul className="transfer_charge_list">
                                <li>
                                  <div className="d-flex bd-highlight">
                                    <div className="bd-highlight seq_icon">
                                      -
                                    </div>
                                    <div className="flex-fill bd-highlight">
                                      Transfer Fees
                                    </div>
                                    <div className="flex-fill bd-highlight text-end">
                                      <span className="mx-2 text-info charge_value_span">
                                        {state.totalFee}
                                      </span>
                                      {AuthReducer.sendCurrencyCode}
                                    </div>
                                  </div>
                                </li>
                                <li>
                                  <div className="d-flex bd-highlight">
                                    <div className="bd-highlight seq_icon">
                                      -
                                    </div>
                                    <div className="flex-fill bd-highlight">
                                      Bank Charges
                                    </div>
                                    <div className="flex-fill bd-highlight text-end">
                                      <span className="mx-2 text-info  charge_value_span">
                                        {state.serviceCharge}
                                      </span>
                                      {AuthReducer.sendCurrencyCode}
                                    </div>
                                  </div>
                                </li>
                              </ul>{" "}
                            </TabPanel>
                          </TabContext>
                        </Spinner>
                      </Box>
                    </div>
                    <div className="col-12 col-md-6 ps-auto ps-md-4">
                      <div className="row">
                        <div className="col-7 pb-2 px-3 text-light fw-600 ps-2 pe-0">
                          Amount to convert
                        </div>
                        <div className="col-5 pb-2 px-3 text-light text-end  fw-600 ps-0 pe-2">{`${state.amountPayable} ${AuthReducer.sendCurrencyCode}`}</div>
                        <div className="col-12">
                          <div className="row btn-info exchangert rounded-3">
                            <div className="col-7 py-2 px-3">Exchange Rate</div>
                            <div className="col-5 py-2 px-3 text-end">{`${state.exRate} ${AuthReducer.recvCurrencyCode}`}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="row input_wrapper p-0 mt-3">
                    <div className="col-8 col-md-9 py-2 px-3">
                      <div className="row">
                        <div className="col-6">
                          <input
                            type="text"
                            // placeholder="Amount to receive"

                            value={amount.recvAmount}
                            onChange={(e) => recvAmountHandler(e)}
                          />
                        </div>
                        <div className="col-6 text-end amount_label">
                          Receiver Gets
                        </div>
                      </div>
                    </div>
                    <div className="col-4 col-md-3 py-2 country_dropdown_wrapper d-flex justify-content-center">
                      <div className="country_dropdown">
                        <span className="flagicon me-2">
                          <img
                            src={require("../../assets/images/flags/IN.png")}
                          />
                        </span>
                        <span className="countryName">INR</span>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col d-flex justify-content-start mt-3 expected_time p-0">
                      <img
                        src={require("../../assets/images/icons/clock.png")}
                        className="me-2"
                      />
                      <span>
                        Estimated Time for Transfer :{" "}
                        {moment(
                          state.expectedDeliveryDate,
                          "YYYY-MM-DD HH:mm A"
                        ).format("DD MMMM, yyyy hh:mm A")}
                      </span>
                    </div>
                  </div>
                  <div className="row mt-3">
                    {/* <div className="col">
                      <button className="btn btn-info outline w-100">
                        How much did I save?
                      </button>
                    </div> */}
                    <div className="col p-0">
                      <Link
                        to="/signin"
                        className="btn btn-info text-primary fw-bold w-100"
                      >
                        Begin Transfer
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <div
              className="col"
              // style={{
              //   backgroundImage: `url(${Globe})`,
              // }}
            ></div> */}
            {/* <div className="Home-Transfer-Right-Container"></div> */}
          </div>
        </div>
      </section>
      <section className="globe_bottom">
        <div className="globe_bottom_overlay"></div>
        <div className="container">
          <div className="flex_wrapper">
            <div className="features">
              <h2 className="title animated fadeInLeft text-primary">
                Send money in 3 simple steps
              </h2>
              <p className="animated fadeInLeft subtitle text-center">
                With zero transaction fees*
              </p>
              <ul>
                <li>
                  <h4>Step 1</h4>
                  <Lottie
                    height={300}
                    width={300}
                    options={{
                      loop: true,
                      autoplay: true,
                      animationData: registerLottie,
                      rendererSettings: {
                        preserveAspectRatio: "xMidYMid slice",
                      },
                    }}
                  />
                  <h2 className="bottom-title text-primary">Register</h2>
                </li>
                <li>
                  <h4>Step 2</h4>
                  <Lottie
                    height={300}
                    width={300}
                    options={{
                      loop: true,
                      autoplay: true,
                      animationData: addBenificiaryLottie,
                      rendererSettings: {
                        preserveAspectRatio: "xMidYMid slice",
                      },
                    }}
                  />
                  <h2 className="bottom-title text-primary">Add beneficiary</h2>
                </li>
                <li>
                  <h4>Step 3</h4>
                  <Lottie
                    height={300}
                    width={300}
                    options={{
                      loop: true,
                      autoplay: true,
                      animationData: startTransactingLottie,
                      rendererSettings: {
                        preserveAspectRatio: "xMidYMid slice",
                      },
                    }}
                  />
                  <h2 className="bottom-title text-primary">
                    Start Transacting
                  </h2>
                </li>
              </ul>
            </div>
            <div className="btn-wrapper">
              <Link
                to="/signin"
                className="btn-info"
                style={{
                  textAlign: "center",
                  display: "block",
                  zIndex: 9,
                }}
              >
                Start Transferring
              </Link>
            </div>
          </div>
        </div>
      </section>
      <section className="bg-green-tint">
        <div className="container">
          <div className="flex_wrapper">
            <div className="features">
              <h2 className="title animated fadeInLeft">Safe and Secure</h2>
              {/* <p className="animated fadeInLeft subtitle text-center">
                With zero transaction fees*
              </p> */}
            </div>
          </div>

          <div className="row justify-content-md-center">
            <div className="col-12 col-md-4 img_feature_box">
              <Lottie
                height={300}
                width={300}
                options={{
                  loop: true,
                  autoplay: true,
                  animationData: safeAndSecureLottie,
                  rendererSettings: {
                    preserveAspectRatio: "xMidYMid slice",
                  },
                }}
              />
            </div>
            <div className="col-12 col-md-4 d-flex align-items-center">
              <p className="textwrap">
                Your transaction is completely safe and secure
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="bg-green-tint">
        <div className="container">
          <div className="flex_wrapper">
            <div className="features">
              <h2 className="title animated fadeInLeft">Full Transparency</h2>
              {/* <p className="animated fadeInLeft subtitle text-center">
                With zero transaction fees*
              </p> */}

              <div className="row justify-content-md-center  d-flex align-items-center mt-80">
                <div className="col-12 col-md-4">
                  <p className="textwrap">
                    There are no hidden charges. You know what all charges are
                    applicable and how much money your receiver will receive.
                  </p>
                </div>
                <div className="col-12 col-md-4 text-center img_feature_box">
                  <Lottie
                    height={300}
                    width={300}
                    options={{
                      loop: true,
                      autoplay: true,
                      animationData: fullTransperencyLottie,
                      rendererSettings: {
                        preserveAspectRatio: "xMidYMid slice",
                      },
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="bg-green-tint">
        <div className="container">
          <div className="flex_wrapper ">
            <div className="features">
              <h2 className="title animated fadeInLeft">Best Forex Rate</h2>
              <p className="animated fadeInLeft subtitle text-center">
                With zero transaction fees*
              </p>

              <div className="row justify-content-md-center mt-80 mb-5">
                <div className="col-12 col-md-4 img_feature_box text-center">
                  <Lottie
                    height={300}
                    width={300}
                    options={{
                      loop: true,
                      autoplay: true,
                      animationData: bestForexRateLottie,
                      rendererSettings: {
                        preserveAspectRatio: "xMidYMid slice",
                      },
                    }}
                  />
                </div>
                <div className="col-12 col-md-4 d-flex align-items-center">
                  <p className="textwrap">
                    We provide you live rate that you can book for next 24
                    hours.
                  </p>
                </div>
              </div>

              <div className="row home_partner_section">
                <div className="col-md-12 text-center">
                  <div className="subhead mb-4">
                    Transfer money to over 130+ banks across India with XMonies
                  </div>
                </div>
                <div className="col-6 col-md-2">
                  <img
                    src={require("../../assets/images/XR/partner1.png")}
                    className="w-100"
                  />
                </div>
                <div className="col-6 col-md-2">
                  <img
                    src={require("../../assets/images/XR/partner2.png")}
                    className="w-100"
                  />
                </div>
                <div className="col-6 col-md-2">
                  <img
                    src={require("../../assets/images/XR/partner3.png")}
                    className="w-100"
                  />
                </div>
                <div className="col-6 col-md-2">
                  <img
                    src={require("../../assets/images/XR/partner4.png")}
                    className="w-100"
                  />
                </div>
                <div className="col-6 col-md-2">
                  <img
                    src={require("../../assets/images/XR/partner5.png")}
                    className="w-100"
                  />
                </div>
                <div className="col-6 col-md-2">
                  <img
                    src={require("../../assets/images/XR/partner6.png")}
                    className="w-100"
                  />
                </div>
              </div>

              <div className="row justify-content-md-center mt-4 pb-5">
                <div className="col-md-8 opacity-50 text-center">
                  Trademarks, trade names and logos displayed are registered
                  trademarks of their respective owners. No affiliation or
                  endorsement of Xmonies should be implied.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export const Footer = () => {
  return (
    <footer>
      <div className="container my-5">
        <div className="row">
          <div className="col-6 col-md-2">
            <h3>Company</h3>

            <ul>
              <li>
                <a
                  href="https://resources.xmonies.com/news"
                  target="_blank"
                  rel="noreferrer"
                >
                  In News
                </a>
              </li>
              <li>About Us</li>
              <li>
                <a
                  href="https://resources.xmonies.com/blog"
                  target="_blank"
                  rel="noreferrer"
                >
                  Blogs
                </a>
              </li>
              <li>
                <a
                  href="https://resources.xmonies.com/press"
                  target="_blank"
                  rel="noreferrer"
                >
                  Press
                </a>
              </li>
            </ul>
          </div>

          <div className="col-6 col-md-3">
            <h3>Associate With Us</h3>

            <ul>
              <li>
                <a
                  href="https://affiliate.xmonies.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  Become a Affiliate
                </a>
              </li>

              <li>
                <a
                  href="https://partner.xmonies.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  Partner
                </a>
              </li>
              <li>
                <Link to={"/referrals"}>Refer and Earn</Link>
              </li>
              <li>
                <a
                  href="https://careers.xmonies.com"
                  target="_blank"
                  rel="noreferrer"
                >
                  Careers
                </a>
              </li>
            </ul>
          </div>

          <div className="col-6 col-md-2">
            <h3>Legal</h3>

            <ul>
              <li>
                <Link to={"/regulations"}>Regulations</Link>
              </li>
              <li>
                <Link to={"/privacy-policy"}>Privacy Policy</Link>
              </li>
              <li>
                <Link to={"/terms-and-conditions"}>Terms and Conditions</Link>
              </li>
              <li>
                <Link to={"/cookie-policy"}>Cookie Policy</Link>
              </li>
            </ul>
          </div>

          <div className="col-6 col-md-2">
            <h3>Contact Us</h3>

            <ul>
              <li>
                <Link to={"/contact"}>Call or Mail Us</Link>
              </li>
              <li>
                <Link to={"/feedback"}>Give Feedback</Link>
              </li>
              <li>
                <Link to={"/raise-issue"}>Raise an Issue</Link>
              </li>
              <li>
                <Link to={"/faq"}>FAQ’s</Link>
              </li>
              <li>Live Rates</li>
            </ul>
          </div>

          <div className="col-12 col-md-3">
            <h3>Social Media</h3>
            <div className="socialmedia">
              <img src={require("../../assets/images/XR/facebook.png")} />
              <img src={require("../../assets/images/XR/twitter.png")} />
              <img src={require("../../assets/images/XR/instagram.png")} />
              <img src={require("../../assets/images/XR/koo.png")} />
              <img src={require("../../assets/images/XR/linkedin.png")} />
            </div>
          </div>
        </div>

        <div className="row mt-80 justify-content-center">
          <div className="col-8">
            <div>
              <div className="copyright mb-3">
                © XeOPAR FINTECH PRIVATE LIMITED, 2022
              </div>
              <div className="disclaimer">
                The website https://www.xmonies.com is owned and operated by
                XeOPAR Fintech Pvt. Ltd., registered with Ministry of Corporate
                Affairs, India under Companies Act, 2013 and is regulated under
                Reserve Bank of India (FFMC License Number: DEL.FFMC/849/2019).
                XeOPAR Fintech is a agent of Rational Foreign Exchange Limited
                (RationalFx), registered in England & Wales (Company number:
                08071223) and authorised by the Financial Conduct Authority
                (FRN: 507958) under the Payment Services Regulations 2017, for
                the provision of payment services.
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default HomeXr;
