import { useSelector } from "react-redux";
import { getProcessingPartner } from "../../../../services/utility/group";
import LuluKyc from "../Integrations/LuluKyc";
import Kyc from "./Kyc";

export default function KycFlowTwo(props) {
  const AuthReducer = useSelector((state) => state.user);
  if (getProcessingPartner(AuthReducer.sendCountryCode) === "LULU") {
    return <LuluKyc />;
  }

  return <Kyc />;
}
