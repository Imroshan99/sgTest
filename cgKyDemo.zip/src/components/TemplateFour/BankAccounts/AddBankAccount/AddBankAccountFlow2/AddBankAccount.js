import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Tabs, Select, notification, Spin } from "antd";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { config } from "../../../../../config";
import { useSelector } from "react-redux";

import ReviewBankAccountDetails from "../../ViewBankDetails";
import useHttp from "../../../../../hooks/useHttp";
import { achBankAccountAPI } from "../../../../../apis/achBankAccountAPI";
import CustomInput from "../../../../../reusable/CustomInput";

const { TabPane } = Tabs;
const { Option } = Select;

export default function AddBankAccount(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const [loading, setLoader] = useState(0);
  const [activeStep, setActiveStep] = useState("STEP1");

  let navigate = useNavigate();
  let location = useLocation();
  const [bankListData, setBankListData] = useState([]);
  const [routingListData, setRoutingListData] = useState([]);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      userFullName: AuthReducer.userFullName,
      bankName: null,
      accountNo: null,
      confirmAccountNo: null,
      accountType: null,
      nickName: null,
      routingNumber: null,
      processType: null,

      redirectPage: "",
      redirectPageState: [],
    }
  );

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getBankListHandler();
    setState({
      redirectPage: location.state.fromPage,
      redirectPageState: location.state.fromPageState,
    });
  }, []);

  const hookGetBankNames = useHttp(achBankAccountAPI.getBankNames);
  const hookGetBankRoutingNumber = useHttp(
    achBankAccountAPI.getBankRoutingNumber
  );

  const getBankListHandler = () => {
    let bankListPayload = {
      requestType: "GETBANKNAME",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      bankName: "",
    };
    setLoader((loading) => loading + 1);
    hookGetBankNames.sendRequest(bankListPayload, function (data) {
      setLoader((loading) => loading - 1);
      if (data.status == "S") {
        console.log(data.responseData);
        setBankListData(data.responseData);
        // setState({ transactionLists: data.responseData });
      }
    });
  };

  const handleChangeBankName = (data) => {
    let routingPayload = {
      requestType: "GETBANKNAME",
      userId: AuthReducer.userID,
      countryCode: AuthReducer.sendCountryCode,
      bankName: data,
    };
    setLoader((loading) => loading + 1);
    hookGetBankRoutingNumber.sendRequest(routingPayload, function (data) {
      setLoader((loading) => loading - 1);
      if (data.status == "S") {
        setRoutingListData(data.responseData);
      }
    });
  };

  const hookCheckDuplicateBankAccount = useHttp(
    achBankAccountAPI.checkDuplicateBankAccount
  );
  const hookCheckAchAccountNickName = useHttp(
    achBankAccountAPI.checkAchAccountNickName
  );

  const handleAccountNoBlur = (e) => {
    if (e.target.value.length >= 1) {
      const payloadDuplicateBankAccount = {
        requestType: "CHECKDUPLICATE",
        userId: AuthReducer.userID,
        bankName: props.state.bankName,
        accountNo: e.target.value,
        routingNumber: props.state.routingNumber,
        processType: "YODLEE",
      };
      setLoader((loading) => loading + 1);

      hookCheckDuplicateBankAccount.sendRequest(
        payloadDuplicateBankAccount,
        function (data) {
          setLoader((loading) => loading - 1);
          if (DataView.status == "S") {
            // notification.success({ message: DataView.message });
          } else {
            // notification.error({ message: res.data.errorMessage });
            form.setFields([
              { name: "accountNo", errors: [data.errorMessage] },
            ]);
          }
        }
      );
    }
  };

  const handleNickNameBlur = (e) => {
    if (e.target.value.length >= 1) {
      const payloadCheckNickName = {
        requestId: config.requestId,
        requestType: "CHECKACCNICKNAME",
        channelId: config.channelId,
        clientId: AuthReducer.clientId,
        groupId: AuthReducer.groupId,
        sessionId: AuthReducer.sessionId,
        ipAddress: "127.0.0.1",
        userId: AuthReducer.userID,
        nickName: e.target.value,
      };

      hookCheckAchAccountNickName.sendRequest(
        payloadCheckNickName,
        function (data) {
          if (data.status == "S") {
            // notification.success({ message: data.message });
          } else {
            // notification.error({ message: data.errorMessage });
            form.setFields([{ name: "nickName", errors: [data.message] }]);
          }
        }
      );
    }
  };

  const handleSetSteps = (stepValue) => {
    setActiveStep(stepValue);
  };

  const onFinish = async (value) => {
    form.setFields([
      { name: "accountNo", errors: [] },
      { name: "nickName", errors: [] },
    ]);

    setState({
      bankName: value.bankName,
      routingNumber: value.routingNumber,
      accountType: value.accountType,
      processType: "YODLEE",
      accountNo: value.accountNo,
      confirmAccountNo: value.accountNo,
      // nickName: value.nickName,
      nickName:
        value.accountHolderName
          .substring(0, 8)
          .replace(" ", "")
          .toUpperCase()
          .toString(16) + Math.random().toString(16).slice(2),
    });
    setActiveStep("REVIEW");
  };

  return (
    <div className="AddBankAccount bg_gradient container mt-md-4 mt-sm-4">
      <div className="T3_container">
        <Spin spinning={loading === 0 ? false : true}>
          {!state.showConfirmBankAccountDetails && (
            <Row>
              <Col lg={8} md={10}>
                <div className="p-3 mb-4">
                  <h4 className="mb-4 title">Add Bank Account</h4>

                  {activeStep === "STEP1" && (
                    <Form
                      form={form}
                      onFinish={onFinish}
                      initialValues={{
                        accountHolderName: state.userFullName,
                        bankName: state.bankName,
                        routingNumber: state.routingNumber,
                        accountType: state.accountType,
                        accountNo: state.accountNo,
                        accConNum: state.confirmAccountNo,
                        nickName: state.nickName,
                      }}
                    >
                      <Row className="justify-content-center">
                        <Col md={12}>
                          <div className="">
                            <label className="form-label">
                              <span className="red_ast">*</span>
                              Account Holder Name
                            </label>
                            <CustomInput
                              className="form-item"
                              name="accountHolderName"
                              min={3}
                              max={40}
                              required
                              // type="text"
                              label="Account Holder Name"
                              showLabel={false}
                              placeholder="Account Holder Name"
                              validationRules={[
                                {
                                  pattern: /^[A-Za-z. ]+$/,
                                  message: "Enter valid name",
                                },
                              ]}
                            />

                             
                          </div>
                        </Col>

                        <Col md={12}>
                          <div className="">
                            <label className="form-label">
                              <span className="red_ast">*</span>Bank Name
                            </label>
                            <CustomInput className="form-item" name="bankName" onChange={handleChangeBankName} placeholder="Select Bank Name" type="select" label="Bank Name" showLabel={false} required>
                              {" "}
                              {bankListData.map((acc, i) => {
                                return <Option key={i} value={acc.bankName}>{`${acc.bankName}`}</Option>;
                              })}
                            </CustomInput>

                              
                          </div>
                        </Col>

                        <Col md={12}>
                          <div className="">
                            <label className="form-label">
                              <span className="red_ast">*</span>
                              ABA Routing Number
                            </label>
                            <CustomInput className="form-item" name="routingNumber" placeholder="Select Routing Number" label="ABA Routing Number" showLabel={false} required type="select" min={9} max={9}>
                              {routingListData.map((acc, i) => {
                                return <Option key={i} value={acc.routingNumber}>{`${acc.routingNumber}`}</Option>;
                              })}
                            </CustomInput>
                             
                          </div>
                        </Col>

                        <Col md={12}>
                          <div className="">
                            <label className="form-label">
                              <span className="red_ast">*</span>Account Type
                            </label>
                            <CustomInput className="form-item" name="accountType" label="Account Type" showLabel={false} type="select" placeholder="Select Account Type" required>
                              {" "}
                              <Option key="ac1" value="S">
                                Saving
                              </Option>
                              <Option key="ac2" value="C">
                                Current / Checking
                              </Option>
                            </CustomInput>
                             
                          </div>
                        </Col>

                        <Col md={12}>
                          <div className="">
                            <label className="form-label">
                              <span className="red_ast">*</span>Account Number
                            </label>

                            <CustomInput
                              className="form-item"
                              name="accountNo"
                              min={8}
                              max={25}
                              required
                              type="password"
                              label="Account Number"
                              showLabel={false}
                              placeholder="Enter your Account Number"
                              onBlur={handleAccountNoBlur}
                              onPaste={(e) => {
                                e.preventDefault();
                                return false;
                              }}
                              onCopy={(e) => {
                                e.preventDefault();
                                return false;
                              }}
                              maxLength={25}
                              visibilityToggle={false}
                              validationRules={[
                                {
                                  pattern: /^[0-9\b]+$/,
                                  message: "Only Numbers allowed",
                                },
                              ]}
                            />
                             
                          </div>
                        </Col>
                        <Col md={12}>
                          <div className="">
                            <label className="form-label">
                              <span className="red_ast">*</span>
                              Confirm Account Number
                            </label>
                            <CustomInput
                              className="form-item"
                              name="accConNum"
                              // type="text"
                              placeholder="Enter your Confirm Account Number"
                              min={8}
                              max={25}
                              maxLength={25}
                              required
                              label="Confirm Account Number"
                              showLabel={false}
                              validationRules={[
                                {
                                  pattern: /^[0-9\b]+$/,
                                  message: "Only Numbers allowed",
                                },
                                ({ getFieldValue }) => ({
                                  validator(rule, value) {
                                    if (!value || getFieldValue("accountNo") === value) {
                                      return Promise.resolve();
                                    }
                                    return Promise.reject("The two account number that you entered do not match!");
                                  },
                                }),
                              ]}
                              onPaste={(e) => {
                                e.preventDefault();
                                return false;
                              }}
                              onCopy={(e) => {
                                e.preventDefault();
                                return false;
                              }}
                            />
                             
                          </div>
                        </Col>

                         

                        <Col md={12}>
                          <div className="d-flex justify-content-end">
                            <button
                              onClick={() => {
                                if (state.redirectPage === "NEW_TRANSACTION") {
                                  navigate("/new-transaction", {
                                    state: state.redirectPageState,
                                  });
                                } else {
                                  navigate("/my-bank-accounts");
                                }
                              }}
                              className="btn btn-secondary me-3 my-3"
                              type="button"
                            >
                              Back
                            </button>
                            <button
                              className="btn btn-primary text-white my-3"
                              type="submit"
                              //   onClick={() => setIsICICI(true)}
                            >
                              Review
                            </button>
                          </div>
                        </Col>
                      </Row>
                    </Form>
                  )}

                  {activeStep === "REVIEW" && <ReviewBankAccountDetails accessToken={props.appState.accessToken} isLoggedIn={props.appState.isLoggedIn} publicKey={props.appState.publicKey} setStep={handleSetSteps} setState={setState} state={state} />}
                </div>
              </Col>
            </Row>
          )}
        </Spin>
      </div>
    </div>
  );
}
