import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Select, notification, AutoComplete, Modal } from "antd";
import { BankAccountAPI } from "../../../../../apis/BankAccountAPI";
import { ReceiverAPI } from "../../../../../apis/ReceiverAPI";
import { config } from "../../../../../config";
import { useSelector } from "react-redux";
import useHttp from "../../../../../hooks/useHttp";
import { inputValidations } from "../../../../../services/validations/validations";
import Spinner from "../../../../../reusable/Spinner";
import { useLocation, useNavigate } from "react-router-dom";
import CustomInput from "../../../../../reusable/CustomInput";
const { Option } = Select;
export default function AddBankAccount(props) {
  const navigate = useNavigate();
  const location = useLocation();
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const [spinner, setSpinner] = useState(false);
  console.log('props', props)
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      userFullName: AuthReducer.userFullName,
      nationalities: [],
      stateCities: [],
      _showOTPBOX: false,
      showConfirmBankAccountDetails: false,
      isConfirmAddRecipient: false,
      formData: {},
      verificationToken: "",
      isOTPVerfied: false,
      isModalVisible: false,
      otpType: "RA",

      branchCode: "",
      bankBranch: "",
      bankAddress: "",
      bankState: "",
      bankCity: "",
      bankName: "",
      bankId: "",
      bankCountry: "",
      bankLists: [],
    }
  );

  const hookValidateBankCode = useHttp(BankAccountAPI.validateBankCode);
  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookCheckDuplicateBankAccount = useHttp(
    BankAccountAPI.checkDuplicateBankAccount
  );
  const hookAddBankAccount = useHttp(BankAccountAPI.addBankAccount);

  useEffect(() => {
    getBankList();
  }, []);

  // useEffect(() => {
  //   form.resetFields();
  //   setState({ showConfirmBankAccountDetails: false });
  // }, [props.visible]);

  const afterClose = () => {
  
    if (location.pathname !== "new-transaction") {
      props.accountsList();
    }
    setState({ showConfirmBankAccountDetails: false });
    setSpinner(false);
    props.setVisible(false);
  };

  const onChangeBankSortCode = async (e) => {
    if (e.target.value.length >= 1) {
      const payload = {
        requestType: "VALIDATEBANKCODE",
        bankCode: e.target.value,
        userId: state.userID,
        countryCode: AuthReducer.sendCountryCode,
      };

      hookValidateBankCode.sendRequest(payload, function (data) {
        if (data.status == "S") {
        } else {
          form.setFields([
            { name: "bankSortCode", errors: [data.errorMessage] },
          ]);
        }
      });
    }
  };

  const getBankList = async (e) => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.sendCountryCode,
      userId: state.userID,
    };

    setSpinner(true);
    hookGetBankLists.sendRequest(payload, function (data) {
      setSpinner(false);
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
      }
    });
  };

  const onFinish = async (value) => {
    let formData = {
      requestType: "SENDERACCOUNTADD",
      userId: state.userID,
      countryCode: AuthReducer.sendCountryCode,
      currencyCode: AuthReducer.sendCurrencyCode,
      accountHolder: state.userFullName,
      bankCode: value.bankSortCode,
      bankNumber: "",
      bankName: value.bankName.toUpperCase().trim(),
      accountNo: value.accountNo,
      accountType: "S",
      accCurrencyCode: AuthReducer.sendCurrencyCode,
      sortCode: value.bankSortCode,
      bankCountry: AuthReducer.sendCountryCode,
      ifsc: "",
      branchCode: "",
      bankBranch: "",
      bankCity: "",
      bankState: "",
      isDefaultAcc: "",
      tncAgree: "",
      processType: "",
      routingNumber: "",
      processingPartner: "",
      processingMode: "",
      remark: "",
      isSwiftCodeValid: "",
      noOfAttempts: "",
      transitNumber: "",
      swiftCode: "",
      iban: "",
      bsbCode: "",
    };

    let checkDuplicateData = {
      requestId: config.requestId,
      requestType: "CHECKDUPLICATE",
      channelId: config.channelId,
      clientId: state.clientId,
      groupId: state.groupId,
      sessionId: state.sessionId,
      ipAddress: "127.0.0.1",
      userId: state.userID,
      bankName: value.bankName.trim(),
      accountNo: value.accountNo,
    };
    setSpinner(true);
    hookCheckDuplicateBankAccount.sendRequest(
      checkDuplicateData,
      function (data) {
        if (data.status === "S") {
          setState({ formData: formData, showConfirmBankAccountDetails: true });
        } else {
          notification.error({ message: data.errorMessage });
        }
        setSpinner(false);
      }
    );
  };

  const saveReceiver = async () => {
    setSpinner(true);
    hookAddBankAccount.sendRequest(state.formData, function (data) {
      setSpinner(false);
      if (data.status == "S") {
        notification.success({ message: data.message });
        if (location?.state?.fromPage === "NEW_TRANSACTION") {
          navigate("/new-transaction", { state: location.state.fromPageState });
        } else {
          navigate("/my-bank-accounts");
        }
        afterClose();
        if (props.getBankAccountLists) {
          props.getBankAccountLists();
        } else {
          props.accountsList();
        }
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
     
    });
  };
  return (
    <div>
      {/* <Modal
        className="primary"
        centered
        visible={props.visible}
        onCancel={() => props.setVisible(false)}
        forceRender={true}
        footer={null}
        width={500}
      > */}
      <Spinner spinning={spinner}>
        {!state.showConfirmBankAccountDetails ? (
          <>
            <div className="row mb-3">
              <div className="col mb-3">
                <h2>Add Bank Account</h2>
              </div>
            </div>
            <div className="Modal-Bottom-Content-Container ">
              <Form form={form} onFinish={onFinish} autoComplete="off">
                <Row className="justify-content-center">
                  <Col md={12}>
                    <div className="">
                      <CustomInput className="form-item" label="Bank Sort Code" type="text" name="bankSortCode" min={6} max={6} placeholder="Bank Sort Code" />
                       
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="">
                      
                      
                      <CustomInput className="form-item" name="bankName" placeholder="Select Bank or Type Bank Name" required label="Bank Name">
                        <AutoComplete className="w-100" placeholder="Select Bank or Type Bank Name" filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1} showSearch>
                          {state.bankLists.map((bank, i) => {
                            return (
                              <Option key={i} value={bank.bankName}>
                                {bank.bankName}
                              </Option>
                            );
                          })}
                        </AutoComplete>
                      </CustomInput>
                       
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="">
                      <CustomInput name="accountNo" className="form-item" min={5} max={34} label="Account Number" required placeholder="Enter Your Account Number" />
                      
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="">
                     
                      <CustomInput
                        name="accConNum"
                        className="form-item"
                        min={5}
                        max={34}
                        type="text"
                        label="Confirm Account Number"
                        required
                        placeholder="Enter your Confirm Account Number"
                        validationRules={[
                          ({ getFieldValue }) => ({
                            validator(rule, value) {
                              if (!value || getFieldValue("accountNo") === value) {
                                return Promise.resolve();
                              }
                              return Promise.reject("The two account number that you entered do not match!");
                            },
                          }),
                        ]}
                      />
                      
                    </div>
                  </Col>

                  <Col md={12}>
                    <div className="d-flex justify-content-end mt-3">
                      <button className="btn btn-primary m-w-100" htmlType="submit">
                        Review
                      </button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </div>
          </>
        ) : (
          <Row>
            <div>
              <div className="col mb-4">
                <h2>Confirm Bank Account</h2>
              </div>
              <div className="row gx-3 align-items-center">
                <p className="col-sm-5 text-muted text-sm-end mb-0 mb-sm-3">Bank Sort Code:</p>
                <p className="col-sm-7 text-3">{state.formData.sortCode}</p>
              </div>

              <div className="row gx-3 align-items-center">
                <p className="col-sm-5 text-muted text-sm-end mb-0 mb-sm-3">Bank Name:</p>
                <p className="col-sm-7 text-3">{state.formData.bankName}</p>
              </div>

              <div className="row gx-3 align-items-center">
                <p className="col-sm-5 text-muted text-sm-end mb-0 mb-sm-3">Account Number:</p>
                <p className="col-sm-7 text-3">{state.formData.accountNo}</p>
              </div>

              <div className="d-flex justify-content-between mt-4">
                <button
                  className="btn btn-light text-primary"
                  onClick={() => {
                    setState({ showConfirmBankAccountDetails: false });
                  }}
                >
                  Back
                </button>
                <button className="btn btn-primary" onClick={saveReceiver}>
                  Verify Account
                </button>
              </div>
            </div>
          </Row>
        )}
      </Spinner>
      {/* </Modal> */}
    </div>
  );
}
