import React from "react";

import { Row, Col } from "react-bootstrap";
import { Form, Input, notification, Select } from "antd";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { useReducer } from "react";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import Spinner from "../../../../reusable/Spinner";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import CustomInput from "../../../../reusable/CustomInput";

const { Option } = Select;
const { TextArea } = Input;

export default function Contact1(props) {
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const navigate = useNavigate();
  const AuthReducer = useSelector((state) => state.user);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    phoneCodes: [],
    loader: false,
  });
  const hookContactUsPostLogin = useHttp(GuestAPI.contactUsPostLogin);
  const hookContactUsPreLogin = useHttp(GuestAPI.contactUsPreLogin);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);

  useEffect(() => {
    getCountryPhoneCode();
  }, []);
  const getCountryPhoneCode = () => {
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };
    setState({ loader: true });
    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      setState({ loader: false });
      if (data.status === "S") {
        const phoneCodeStatic = [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
        ];
        setState({ phoneCodes: phoneCodeStatic });
      }
    });
  };
  const onSubmitHandlerPostLogin = (value) => {
    let payload = {
      requestType: "POSTCONTACTUS",
      category: value.category,
      comments: value.comments.trim(),
      userId: AuthReducer.userID,
      pageFrom: "POST",
      identifier: "CS",
    };
    setState({ loader: true });
    hookContactUsPostLogin.sendRequest(payload, function (data) {
      setState({ loader: false });
      if (data.status === "S") {
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/new-transaction");
          }
        });
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  const onSubmitHandlerPreLogin = (value) => {
    let payload = {
      requestType: "PRECONTACTUS",
      category: value.category,
      fullName: value.fullName.trim(),
      mobilePhoneCode: value.mobilePhoneCode,
      mobileNo: value.mobileNo,
      emailId: value.emailId,
      comments: value.comments.trim(),
      pageFrom: "PRE",
      identifier: "CS",
    };
    setState({ loader: true });
    hookContactUsPreLogin.sendRequest(payload, function (data) {
      setState({ loader: false });
      if (data.status === "S") {
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            navigate("/");
          }
        });
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form1.setFields(errors);
      }
    });
  };
  return (
    <React.Fragment>
      <Spinner spinning={state.loader}>
        <div className="template2__main">
          <div className="sendmoney__page preloginform">
            <div className="container contactus">
              {AuthReducer.isLoggedIn ? (
                <Form form={form} onFinish={(value) => onSubmitHandlerPostLogin(value)}>
                  <Row>
                    <Col>
                      <CustomInput type="select" name="category" label="Issue category" placeholder="Select a category" size="large" required>
                        <Option value="Generic Enquiry">Generic Enquiry</Option>
                        <Option value="Money Transfer">Money Transfer Enquiry</Option>
                        <Option value="Business Enquiry">Business Enquiry</Option>
                        <Option value="Partnership Enquiry">Partnership Enquiry</Option>
                        <Option value="Affiliate Enquiry">Affiliate Enquiry</Option>
                      </CustomInput>
                    </Col>
                    <Col>
                      <CustomInput name={"comments"} label="Describe more" required>
                        <TextArea className="bg-secondary-light" style={{ resize: "none", height: "12.2rem" }} autoComplete="none" />
                      </CustomInput>
                    </Col>
                  </Row>
                  <div className="color-secondary-light contact_footer">
                    {/* Or write to us at <a href="mailto:care@xmonies.com">care@xmonies.com</a> */}
                  </div>
                  <div className="col-12 text-end">
                    <button className="btn btn-sm btn-light text-primary px-5" htmlType="submit">
                      Send
                    </button>
                  </div>
                </Form>
              ) : (
                <Form form={form1} onFinish={(value) => onSubmitHandlerPreLogin(value)}>
                  <Row>
                    <Col>
                      <Row>
                        <CustomInput
                          name="fullName"
                          className="form-item"
                          label="Your Name"
                          size="large"
                          placeholder="Enter your Name"
                          required
                          validationRules={[
                            {
                              pattern: /^([\w]{1,})+\s+([\w\s]{1,})+$/i,
                              message: "Please enter valid name.",
                            },
                            {
                              pattern: /^([^0-9]*)$/,
                              message: "Number not allow in full name",
                            },
                          ]}
                        />
                      </Row>
                      <Row>
                        <CustomInput label="Email address" className="form-item" name="emailId" type="email" size="large" placeholder="Enter your email address" required />
                      </Row>
                      <Row>
                        <label className="step-label  mb-1">Mobile Number</label>
                        <div className="d-flex group_input">
                          <div className="w-25 ">
                            
                            <CustomInput placeholder="Select phone Code" type="select" className="form-item" name="mobilePhoneCode" showLabel={false} required label="Country Code">
                              {state.phoneCodes.map((phoneCode, i) => {
                                return <Option key={i} value={phoneCode.countryPhoneCode}>{`+${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>;
                              })}
                            </CustomInput>
                          </div>
                          <div className="w-75">
                             
                            <CustomInput
                              className="form-item"
                              name="mobileNo"
                              showLabel={false}
                              label="Mobile Number"
                              validationRules={[
                                {
                                  pattern: /^[0-9\b]+$/,
                                  message: "Only numbers allowed",
                                },
                              ]}
                              min={10}
                              max={10}
                              placeholder="Enter your mobile number"
                              size="large"
                              required
                            />
                          </div>
                        </div>
                      </Row>
                    </Col>
                    <Col>
                      <Row>
                        <CustomInput type="select" name="category" label="Issue category" placeholder="Select a category" size="large" required>
                          <Option value="Generic Enquiry">Generic Enquiry</Option>
                          <Option value="Money Transfer">Money Transfer Enquiry</Option>
                          <Option value="Business Enquiry">Business Enquiry</Option>
                          <Option value="Partnership Enquiry">Partnership Enquiry</Option>
                          <Option value="Affiliate Enquiry">Affiliate Enquiry</Option>
                        </CustomInput>
                      </Row>
                      <Row>
                        <CustomInput name={"comments"} label="Describe more" required>
                          <TextArea className="bg-secondary-light" style={{ resize: "none", height: "12.2rem" }} autoComplete="none" />
                        </CustomInput>
                      </Row>
                    </Col>
                  </Row>
                  <div className="color-secondary-light contact_footer">
                    {/* Or write to us at <a href="mailto:care@xmonies.com">care@xmonies.com</a> */}
                  </div>
                  <div className="col-12 text-end">
                    <button className="btn btn-sm btn-light text-primary px-5" htmlType="submit">
                      Send
                    </button>
                  </div>
                </Form>
              )}
            </div>
          </div>
        </div>
      </Spinner>
    </React.Fragment>
  );
}
