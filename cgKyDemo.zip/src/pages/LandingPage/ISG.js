import React, { useEffect, useReducer, useState } from "react";
// import '../../../assets/scss/home.scss'

import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Container from "@mui/material/Container";

import IosShareRoundedIcon from "@mui/icons-material/IosShareRounded";
import ShoppingBagRoundedIcon from "@mui/icons-material/ShoppingBagRounded";
import PeopleAltRoundedIcon from "@mui/icons-material/PeopleAltRounded";
import CheckBoxRoundedIcon from "@mui/icons-material/CheckBoxRounded";

import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";

import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputAdornment from "@mui/material/InputAdornment";

import { useSelector } from "react-redux";
import { GuestAPI } from "../../apis/GuestAPI";

import { notification } from "antd";
import { Link } from "react-router-dom";
import useHttp from "../../hooks/useHttp";
import ExchangeRateWidget from "./Widgets/ExchangeRateWidget";

const ISG = (props) => {
  const ConfigReducer = useSelector((state) => state.user);
  const AuthReducer = useSelector((state) => state.user);

  const defaultSettings = ConfigReducer.groupIdSettings.default;
  // console.log(defaultSettings)
  // const { isLoading, apiData, serverError, sendRequest } = useHttp(GuestAPI.getNationality);
  // const getNationality = useHttp(GuestAPI.getNationality);
  // const occupationLists = useHttp(GuestAPI.occupationLists);

  const [value, setValue] = React.useState("1");
  const [loading, setLoader] = React.useState(false);
  const [timeoutId, setTimeoutId] = React.useState("");
  const [amount, setAmount] = useState({
    totalSendAmount: 0,
    sendAmount: 1000,
    recvAmount: 0,
    // sendAmountError: "",
    // recvAmountError: "",
  });

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: ConfigReducer.twofa,
      sessionId: ConfigReducer.sessionId,
      // sendAmount: 1000,
      // recvAmount: 0,
      // enteredAmount: 0,
      // netRecvAmount: 0,
      totalFee: 0,
      exRate: 0,

      recvCountryCode:
        AuthReducer.recvCountryCode === "" ? "IN" : AuthReducer.recvCountryCode,
      recvCurrencyCode:
        AuthReducer.recvCurrencyCode === ""
          ? "INR"
          : AuthReducer.recvCurrencyCode,
    }
  );

  const hookPostExchangeRate = useHttp(GuestAPI.postExchangeRate);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  useEffect(() => {
    loadExhangeRateHandler(1000, AuthReducer.sendCurrencyCode);
    // getNationality.sendRequest();
    // occupationLists.sendRequest()
    // sendRequest(GuestAPI.occupationLists)

    // sendRequest()
    // console.log(AuthReducer.groupIdSettings);
    // console.log(AuthReducer.groupIdSettings.signUpForm.formType);
  }, []);
  // useEffect(() => {
  //   const timeOutId = setTimeout(() => loadExhangeRateHandler(), 500);
  //   return () => clearTimeout(timeOutId);
  // }, [state.sendAmount]);
  // console.log("data", getNationality.apiData);
  // useEffect(() => {
  //     loadExhangeRateHandler()
  // }, [state.sendAmount])

  const loadExhangeRateHandler = (valueSendAmount, __currency) => {
    let payload = {
      requestType: "EXCHANGERATE",
      pageName: "PRELOGIN",
      amount: valueSendAmount,
      recvNickName: "NEWRECV_SB",
      recvModeCode: "DC",
      // sendModeCode: "ACH",
      sendModeCode: defaultSettings.sendModeCode,
      programCode: defaultSettings.programCode,
      paymentMode1: "",
      paymentMode2: "",
      promoCode: "",
      loyaltyPoints: "",
      recvCountryCode: state.recvCountryCode,
      recvCurrencyCode: state.recvCurrencyCode,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      // enteredAmtCurrency: "GBP",
      enteredAmtCurrency: __currency,
    };

    hookPostExchangeRate.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setAmount({
          ...amount,
          // sendAmount: __currency === 'USD' ?  data.enteredAmount : data.sendAmount,
          sendAmount: data.amountPayable,
          recvAmount: data.recvAmount,
          totalSendAmount: data.sendAmount,
        });
        setState({
          // sendAmount: data.sendAmount,
          // recvAmount: data.recvAmount,

          totalFee: data.totalFee,
          exRate: data.exRate,
        });
      } else {
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });
        } else {
          notification.error({ message: data.errorMessage });
        }
        setAmount({
          ...amount,
          recvAmount: 0,
        });
        setState({
          totalFee: 0,
          exRate: 0,
        });
      }
    });
  };

  const sendAmountHandler = (e, __currency) => {
    // setState({ sendAmount: e.target.value })
    setAmount({
      ...amount,
      sendAmount: e.target.value,
      // recvAmount: e.target.value,
    });
    clearTimeout(timeoutId);
    const valueSendAmount = e.target.value;
    let valueTimeOutId = setTimeout(
      () => loadExhangeRateHandler(valueSendAmount, __currency),
      500
    );
    setTimeoutId(valueTimeOutId);
  };

  const recvAmountHandler = (e) => {
    setAmount({
      ...amount,
      // sendAmount: e.target.value,
      recvAmount: e.target.value,
    });
    clearTimeout(timeoutId);
    const valueSendAmount = e.target.value;
    let valueTimeOutId = setTimeout(
      () => loadExhangeRateHandler(valueSendAmount, "KES"),
      500
    );
    setTimeoutId(valueTimeOutId);
  };

  return (
    <>
      <header>
        <div className="container">
          <nav className="navbar navbar-expand-lg navbar-light py-3">
            <div className="container-fluid">
              <Link to="/">
                <img
                  src={`images/${AuthReducer.groupId}/logo.png`}
                  height="48px"
                  alt="Logo"
                />
              </Link>

              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div
                className="collapse navbar-collapse"
                id="navbarSupportedContent"
              >
                <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                  {/* <li className="nav-item">
                    <a className="nav-link active" aria-current="page" href="#">
                      Home
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">
                      Link
                    </a>
                  </li> */}
                </ul>
                <div className="d-flex">
                  <Link className="btn btn-outline-primary" to={"/signin"}>
                    Login
                  </Link>
                  <Link className="btn btn-primary ms-3" to={"/signup"}>
                    Register
                  </Link>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>
      <div>
        <section className="hero-wrap">
          <div className="hero-mask opacity-75 bg-dark"></div>
          <div
            className="hero-bg"
            style={{
              backgroundImage: `url(${require("../../assets/images/home-bg/ISG.webp")})`,
            }}
          ></div>
          <div className="hero-content d-flex fullscreen">
            <Container className="my-auto py-5">
              <Box>
                <Grid
                  container
                  spacing={{ xs: 2, md: 4 }}
                  className=" py-5"
                >
                  <Grid
                    item
                    lg={6}
                    xl={7}
                    className="my-auto text-center text-lg-start pb-4 pb-lg-0"
                  >
                    <h1 className="fw-700 text-white mb-4">
                      Experience super fast <br className="d-none d-xl-block" />
                      money transfer <br className="d-none d-xl-block" />
                      at a branch near you
                    </h1>
                    <p className="lead text-light mb-4">
                      Remit Money from{" "}
                      {AuthReducer.sendCountryCode === "US" ? "USA" : "Singapore"} to{" "}
                      {state.recvCountryCode === "KE" ? "Kenya" : "India"}{" "}
                      with Ease &amp; Simplicity. Get the Best Exchange rates
                      with Multiple Offers to choose from.
                    </p>
                  </Grid>
                  <Grid item lg={6} xl={5} className="my-auto mx-auto">
                    {/* <ExchangeRateWidget /> */}
                    <div className="d-block justify-content-center">
                      <Box
                        className="rounded-5"
                        sx={{
                          bgcolor: "background.paper",
                          width: "100%",
                          typography: "body1",
                        }}
                      >
                        <TabContext value={value}>
                          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                            <TabList
                              onChange={handleChange}
                              value={value}
                              variant="fullWidth"
                              aria-label="full width tabs example"
                              className="money-tabs"
                            >
                              <Tab
                                label="Send Money"
                                value="1"
                                className="money-tab-links"
                              />
                            </TabList>
                          </Box>
                          <TabPanel value="1">
                            <Box>
                              <FormControl
                                fullWidth
                                sx={{ my: 1 }}
                                // error
                                helperText="Incorrect entry."
                                onChange={(e) =>
                                  sendAmountHandler(
                                    e,
                                    AuthReducer.sendCurrencyCode
                                  )
                                }
                              >
                                <InputLabel htmlFor="You Send-amount">
                                  You Send
                                </InputLabel>
                                <OutlinedInput
                                  id="outlined-adornment-amount"
                                  type="number"
                                  // step="0.01"
                                  // inputProps={{ maxLength: 5 }}
                                  defaultValue={amount.sendAmount}
                                  value={amount.sendAmount}
                                  // onChange={handleChange('amount')}
                                  startAdornment={
                                    <InputAdornment position="start">
                                      {AuthReducer.sendCurrencyCode}
                                    </InputAdornment>
                                  }
                                  label="You Send"
                                />
                                {/* <FormHelperText id="component-error-text">
                                Amount should be between 1 and 9 characters long
                              </FormHelperText> */}
                              </FormControl>
                              <FormControl
                                fullWidth
                                sx={{ my: 1 }}
                                onChange={(e) => recvAmountHandler(e)}
                                // onChange={(e) =>
                                //   setState({ recvAmount: e.currentTarget.value })
                                // }
                              >
                                <InputLabel htmlFor="outlined-adornment-amount">
                                  Recipient Gets
                                </InputLabel>
                                <OutlinedInput
                                  id="outlined-adornment-amount"
                                  type="number"
                                  // readOnly
                                  value={amount.recvAmount}
                                  // onChange={handleChange('amount')}
                                  // defaultValue={amount.recvAmount}
                                  startAdornment={
                                    <InputAdornment position="start">
                                      {state.recvCurrencyCode}
                                    </InputAdornment>
                                  }
                                  label="Recipient Gets"
                                />
                              </FormControl>

                              <Box className="d-flex flex-wrap my-2 text-muted">
                                <p className="me-2 mb-0">Send Amount -</p>
                                <p className="fw-600 mb-0 ms-2">{`${amount.totalSendAmount} ${AuthReducer.sendCurrencyCode}`}</p>
                              </Box>
                              <Box className="d-flex flex-wrap my-2 text-muted">
                                <p className="me-2 mb-0">Total fees -</p>
                                <p className="fw-600 mb-0 ms-2">{`${state.totalFee} ${AuthReducer.sendCurrencyCode}`}</p>
                              </Box>
                              <Box className="d-flex flex-wrap my-2 text-muted">
                                <p className="me-2 mb-0">
                                  The current exchange rate is{" "}
                                </p>
                                {/* <p className="fw-600 mb-0">1 USD = 1.42030 AUD</p> */}
                                <p className="fw-600 mb-0">
                                  1 {AuthReducer.sendCurrencyCode} ={" "}
                                  {`${state.exRate} ${state.recvCurrencyCode}`}
                                </p>
                              </Box>
                              <Box sx={{ mt: 2 }}>
                                <div className="d-grid g-2">
                                  <Link
                                    to="/signin"
                                    className="btn text-white btn-primary my-1"
                                  >
                                    Send Now
                                  </Link>
                                  {/* <button
                                  className="btn text-white btn-primary my-1"
                                  onClick={loadExhangeRateHandler}
                                  disabled={
                                    state.sendAmount == "" ||
                                    state.sendAmount == 0
                                  }
                                >
                                  Send Now
                                </button> */}
                                </div>
                                {AuthReducer.groupId === "KCB" && (
                                  <div className="d-grid g-2">
                                    <Link
                                      to="/request-money"
                                      className="btn text-white btn-secondary my-1"
                                    >
                                      Request Money
                                    </Link>
                                  </div>
                                )}
                              </Box>
                            </Box>
                          </TabPanel>
                        </TabContext>
                      </Box>
                    </div>
                  </Grid>
                </Grid>
              </Box>
            </Container>
          </div>
        </section>

        <section className="section bg-grey py-5">
          <Container>
            <Box className="text-center" sx={{ my: 2, p: 2 }}>
              <div className="text-primary">OUR PROCESS</div>
              <h2 className="fw-700">Fast and Easy Way to Send Money</h2>
              <p>
                Get started with Ackers Inc in just a few seconds. We provide
                fast and simple steps to send money to your loved one. With just
                a few steps, and you are done!
              </p>
            </Box>
            <Box>
              <Grid container spacing={{ xs: 2, md: 4 }}>
                <Grid item xs={12} md={3}>
                  <div className="featured-box style-4">
                    <div className="featured-box-icon">
                      <h1>
                        <IosShareRoundedIcon
                          fontSize="large"
                          className="text-primary"
                        />
                      </h1>
                    </div>
                    <h3 className="fw-500">Select Country</h3>
                    <p className="">
                      Select the country of your Beneficiary and view the
                      exchange rate. We offer competitive exchange rate.
                    </p>
                  </div>
                </Grid>
                <Grid item xs={12} md={3}>
                  <div className="featured-box style-4">
                    <div className="featured-box-icon">
                      <h1>
                        <CheckBoxRoundedIcon
                          fontSize="large"
                          className="text-primary"
                        />
                      </h1>
                    </div>
                    <h3 className="fw-500">Enter Amount</h3>
                    <p className="">
                      Enter the amount which you want to send and view the exact
                      amount which will be delivered. You will definitely get
                      the best final digits.
                    </p>
                  </div>
                </Grid>
                <Grid item xs={12} md={3}>
                  <div className="featured-box style-4">
                    <div className="featured-box-icon">
                      <h1>
                        <PeopleAltRoundedIcon
                          fontSize="large"
                          className="text-primary"
                        />
                      </h1>
                    </div>
                    <h3 className="fw-500">Enter Beneficiary</h3>
                    <p className="">
                      Enter the Beneficiary personal and bank information
                    </p>
                  </div>
                </Grid>
                <Grid item xs={12} md={3}>
                  <div className="featured-box style-4">
                    <div className="featured-box-icon">
                      <h1>
                        <ShoppingBagRoundedIcon
                          fontSize="large"
                          className="text-primary"
                        />
                      </h1>
                    </div>
                    <h3 className="fw-500">Confirm and Pay</h3>
                    <p className="">
                      Add your account information and book the transaction.
                    </p>
                  </div>
                </Grid>
              </Grid>
            </Box>
          </Container>
        </section>

        <section className="section bg-white py-5">
          <Container>
            <Box className="text-center" sx={{ my: 2, p: 2 }}>
              <div className="text-primary">OUR SECURITY</div>
              <h2 className="fw-700">Your Safety is Our Concern</h2>
              <p>
                We implement highest levels of encryption techniques to protect
                your data.
              </p>
            </Box>
          </Container>
        </section>

        <section className="footer-section bg-white pb-4">
          <div className="footer-copyright pt-4">
            <Box>
              <Container>
                <Grid container spacing={{ xs: 12, md: 12 }}>
                  <Grid item xs={12} lg={12}>
                    <p className="text-center text-lg-start mb-2 mb-lg-0">
                      Copyright © 2022 {ConfigReducer.groupIdSettings.title}.
                      All rights reserved
                    </p>
                  </Grid>
                </Grid>
              </Container>
            </Box>
            {/* <div className="container">
                        <div className="row">
                            <div className="col-lg">
                                <p className="text-center text-lg-left mb-2 mb-lg-0">Copyright © 2020 <a to="#!">Payyed</a>. All Rights Reserved.</p>
                            </div>
                            <div className="col-lg d-lg-flex align-items-center justify-content-lg-end">
                                <ul className="nav justify-content-center">
                                    <li className="nav-item"> <Link className="nav-link active" to="#!">Security</Link></li>
                                    <li className="nav-item"> <Link className="nav-link" to="#!">Terms</Link></li>
                                    <li className="nav-item"> <Link className="nav-link" to="#!">Privacy</Link></li>
                                </ul>
                            </div>
                        </div>
                    </div> */}
          </div>
        </section>
      </div>
    </>
  );
};
export default ISG;
