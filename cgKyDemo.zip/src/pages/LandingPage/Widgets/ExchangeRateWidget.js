/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect, useReducer, useState } from "react";
import moment from "moment";
import "./Widget.scss";
import Box from "@mui/material/Box";

import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";

import { useSelector } from "react-redux";
import { GuestAPI } from "../../../apis/GuestAPI";
import { notification, Select, Spin } from "antd";
import { Link } from "react-router-dom";
import useHttp from "../../../hooks/useHttp";
import { COUNTRY } from "../../../services/Country";
import useDidMountEffect from "../../../hooks/useDidMountEffect";

import axios from "axios";
import { getFlagPath } from "../../../services/utility/flags";

const { Option } = Select;
export default function ExchangeRateWidget() {
  const ConfigReducer = useSelector((state) => state.user);
  const AuthReducer = useSelector((state) => state.user);
  const currentURL = window.location.origin;
  const defaultSettings = ConfigReducer.groupIdSettings.default;
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [value, setValue] = React.useState("FER");
  const [rateLoader, setRateLoader] = React.useState(false);
  const [timeoutId, setTimeoutId] = React.useState("");
  const [amount, setAmount] = useState({
    sendAmount: 1000,
    recvAmount: 0,
    offers: [],
    offerModal: false,
    showOffer: false,
    // sendAmountError: "",
    // recvAmountError: "",
  });

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      twofa: ConfigReducer.twofa,
      paymentOptionsList: [],
      sendModeCode: defaultSettings.sendModeCode,
      programCode: defaultSettings.programCode,
      totalFee: 0,
      serviceCharge: 0,
      exRate: 0,
      amountPayable: 0,
      expectedDeliveryDate: "",

      countryList: [],
      receiverCountryList: [],
      tickerMessages: [],

      sendCountryCode: defaultSettings.sendCountryCode,
      sendCurrencyCode: defaultSettings.sendCurrencyCode,
      recvCountryCode: "",
      recvCurrencyCode: "",
    }
  );
  console.log("defaultSettings", defaultSettings);
  const hookCountryList = useHttp(GuestAPI.countryList);
  const hookReceiverCountryList = useHttp(GuestAPI.receiverCountryList);
  const hookPostExchangeRate = useHttp(GuestAPI.postExchangeRate);
  const hookPaymentOptions = useHttp(GuestAPI.paymentOption);

  useEffect(() => {
    getCountryList();
    getReceiverCountryList();
    // getOffers();
    // getTickerMessages();
    // getPaymentOption();
    // loadExhangeRateHandler(1000, state.sendCurrencyCode);
  }, []);

  useDidMountEffect(() => {
    console.log("programCode==>", state.programCode);
    loadExhangeRateHandler(1000, state.sendCurrencyCode);
  }, [state.programCode]);

  useEffect(() => {
    if (state.recvCountryCode !== "") {
      getPaymentOption();
      loadExhangeRateHandler(1000, state.sendCurrencyCode);
    }
  }, [state.recvCountryCode]);

  const getPaymentOption = () => {
    const payload = {
      requestType: "PAYMENTOPTION",
      amount: "1000",
      sendCountryCode: state.sendCountryCode,
      sendCountryCurrency: state.sendCurrencyCode,
      recvCountryCode: state.recvCountryCode,
      recvCountryCurrency: state.recvCurrencyCode,
    };

    // setState({ loading: true });
    hookPaymentOptions.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ paymentOptionsList: data.responseData });
        setState({
          programCode: defaultSettings.programCode,
        });
        setValue(defaultSettings.programCode);
        // setState({ loading: false });
      }
    });
  };

  const loadExhangeRateHandler = (valueSendAmount, __currency) => {
    let payload = {
      requestType: "EXCHANGERATE",
      pageName: "PRELOGIN",
      amount: valueSendAmount,
      recvNickName: "NEWRECV_SB",
      recvModeCode: "DC",
      // sendModeCode: "ACH",
      sendModeCode: state.sendModeCode,
      programCode: state.programCode,
      paymentMode1: "",
      paymentMode2: "",
      promoCode: "",
      loyaltyPoints: "",
      recvCountryCode: state.recvCountryCode,
      recvCurrencyCode: state.recvCurrencyCode,
      sendCountryCode: state.sendCountryCode,
      sendCurrencyCode: state.sendCurrencyCode,
      // enteredAmtCurrency: "GBP",
      enteredAmtCurrency: __currency,
    };
    setRateLoader(true);
    hookPostExchangeRate.sendRequest(payload, function (data) {
      setRateLoader(false);
      if (data.status === "S") {
        // let expectedDeliveryDateStr = data.expectedDeliveryDate;
        let expectedDeliveryDateStr = data.expectedDeliveryDateTZ;
        let expectedDeliveryDate = expectedDeliveryDateStr.substring(
          0,
          expectedDeliveryDateStr.lastIndexOf(" ") + 1
        );

        setAmount({
          ...amount,
          sendAmount:
            __currency === "GBP" ? data.enteredAmount : data.amountPayable,
          recvAmount:
            __currency === "INR" ? data.enteredAmount : data.recvAmount,
        });
        setState({
          // sendAmount: data.sendAmount,
          // recvAmount: data.recvAmount,
          amountPayable: data.sendAmount,
          totalFee: data.totalFee,
          serviceCharge: data.serviceCharge,
          exRate: data.exRate,
          expectedDeliveryDate: expectedDeliveryDate,
        });
      } else {
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });
        } else {
          notification.error({ message: data.errorMessage });
        }
        setAmount({
          ...amount,
          recvAmount: 0,
        });
        setState({
          totalFee: 0,
          exRate: 0,
        });
      }
    });
  };

  const sendAmountHandler = (e, __currency) => {
    let sendAmtVal = "";
    // setState({ sendAmount: e.target.value })

    sendAmtVal =
      e.target.value.indexOf(".") >= 0
        ? e.target.value.substr(0, e.target.value.indexOf(".")) +
          e.target.value.substr(e.target.value.indexOf("."), 3)
        : e.target.value;
    clearTimeout(timeoutId);
    if (e.target.value) {
      setAmount({
        ...amount,
        sendAmount: sendAmtVal,
        // recvAmount: e.target.value,
      });

      const valueSendAmount = sendAmtVal;
      let valueTimeOutId = setTimeout(
        () => loadExhangeRateHandler(valueSendAmount, __currency),
        500
      );
      setTimeoutId(valueTimeOutId);
    } else {
      setAmount({
        ...amount,
        sendAmount: "",
        recvAmount: "",
      });
    }
  };

  const recvAmountHandler = (e) => {
    let recvAmtVal = "";
    recvAmtVal =
      e.target.value.indexOf(".") >= 0
        ? e.target.value.substr(0, e.target.value.indexOf(".")) +
          e.target.value.substr(e.target.value.indexOf("."), 3)
        : e.target.value;
    clearTimeout(timeoutId);
    if (e.target.value) {
      setAmount({
        ...amount,
        // sendAmount: e.target.value,
        recvAmount: recvAmtVal,
      });

      const valueSendAmount = recvAmtVal;
      let valueTimeOutId = setTimeout(
        () => loadExhangeRateHandler(valueSendAmount, "INR"),
        500
      );
      setTimeoutId(valueTimeOutId);
    } else {
      setAmount({
        ...amount,
        recvAmount: "",
        sendAmount: "",
      });
    }
  };

  const getCountryList = () => {
    const payload = { requestType: "COUNTRYLIST" };
    hookCountryList.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          countryList: data.responseData,
        });
      }
    });
  };

  const getReceiverCountryList = (
    countryCode = "US",
    countryCurrency = "USD"
  ) => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: countryCode,
      sendCurrency: countryCurrency,
    };
    hookReceiverCountryList.sendRequest(payload, function (data) {
      if (data.status === "S") {
        const recvCountryListData = data.responseData;
        setState({
          receiverCountryList: recvCountryListData,
          recvCountryCode: recvCountryListData[0].recvCountry,
          recvCurrencyCode: recvCountryListData[0].recvCurrency,
        });
      }
    });
  };

  const handleSenderCountry = (value, e) => {
    let __send_country = value;
    let __send_currency = e["data-sendCurrency"];
    setState({
      sendCountryCode: __send_country,
      sendCurrencyCode: __send_currency,
    });
    getReceiverCountryList(__send_country, __send_currency);
  };

  const handleReceivingCountry = (value) => {
    setState({
      recvCountryCode: value,
      recvCurrencyCode: COUNTRY[value].countryCurrency,
    });
  };

  return (
    <div className="exchange_rate_widget1">
      <div className="row ">
        <div className="col-12 col-md-12">
          <div className="_m_padding">
            <div className="xr_sendmoney_box">
              <div className="amount_label ps-0 ps-md-2">You send</div>
              <div className="row input_wrapper p-0">
                <div className="col-8 col-md-9 py-2 px-3">
                  <input
                    type="text"
                    // placeholder="Amount to send"
                    // defaultValue={amount.sendAmount}
                    value={amount.sendAmount}
                    onChange={(e) =>
                      sendAmountHandler(e, state.sendCurrencyCode)
                    }
                  />
                </div>
                <div className="col-4 col-md-3 py-2 country_dropdown_wrapper d-flex justify-content-center">
                  <div className="country_dropdown">
                    <Select
                      size="large"
                      className="w-100"
                      defaultValue={state.sendCountryCode}
                      onChange={handleSenderCountry}
                    >
                      {state.countryList.map((clist, i) => {
                        return (
                          <Option
                            key={i}
                            data-sendCurrency={clist.sendCurrency}
                            value={clist.sendCountry}
                          >
                            <div className="d-flex align-items-center">
                              <img
                                src={getFlagPath(clist.sendCountry)}
                                height={"24px"}
                                className="me-2"
                              />
                              <span>{clist.sendCurrency}</span>
                            </div>
                          </Option>
                        );
                      })}
                    </Select>
                  </div>
                </div>
              </div>

              <div className=" amount_label ps-0 ps-md-2">Receiver Gets</div>
              <div className="row input_wrapper p-0">
                <div className="col-8 col-md-9 py-2 px-3">
                  <input
                    type="text"
                    value={amount.recvAmount}
                    onChange={(e) => recvAmountHandler(e)}
                  />
                </div>
                <div className="col-4 col-md-3 py-2 country_dropdown_wrapper d-flex justify-content-center">
                  <div className="country_dropdown">
                    <Select
                      size="large"
                      className="w-100"
                      defaultValue={state.recvCountryCode}
                      value={state.recvCountryCode}
                      onChange={handleReceivingCountry}
                    >
                      {state.receiverCountryList.map((clist, i) => {
                        return (
                          <Option key={i} value={clist.recvCountry}>
                            <div className="d-flex align-items-center">
                              <img
                                src={getFlagPath(clist.recvCountry)}
                                height={"24px"}
                                className="me-2"
                              />
                              <span>{clist.recvCurrency}</span>
                            </div>
                          </Option>
                        );
                      })}
                    </Select>
                  </div>
                </div>
              </div>
              <div className="row  mt-4 align-items-center">
                <div className="col-12 col-md-12 ps-auto ps-md-4 pt-3 pt-md-0">
                  <div className="row">
                    <div className="col-7 pb-2 px-3  fw-600 ps-2 pe-0">
                      Transfer Fees
                    </div>
                    <div className="col-5 pb-2 px-3 text-end  fw-600 ps-0 pe-2">{`${state.totalFee} ${state.sendCurrencyCode}`}</div>
                  </div>
                  <div className="row">
                    <div className="col-7 pb-2 px-3  fw-600 ps-2 pe-0">
                      {/* Amount to convert */}
                      Sending Amount
                    </div>
                    <div className="col-5 pb-2 px-3 text-end  fw-600 ps-0 pe-2">{`${state.amountPayable} ${state.sendCurrencyCode}`}</div>
                  </div>
                  <div className="row ">
                    <div className="col-7 pb-2 px-3  fw-600 ps-2 pe-0">
                      Exchange Rate
                    </div>
                    <div className="col-5 pb-2 px-3 text-end  fw-600 ps-0 pe-2">{`${state.exRate} ${state.recvCurrencyCode}`}</div>
                  </div>

                  <div className="row">
                    <div className="col d-flex justify-content-start mt-3 expected_time px-3  fw-600 ps-2">
                      {/* <img
                  src={require("../../assets/images/icons/clock.png")}
                  className="me-2"
                /> */}
                      <span>
                        Estimated Time for Transfer :{" "}
                        {moment(
                          state.expectedDeliveryDate,
                          "YYYY-MM-DD HH:mm A"
                        ).format("DD MMMM, yyyy hh:mm A")}
                      </span>
                    </div>
                  </div>
                  <div className="row mt-3">
                    <div className="col  fw-600 ps-2">
                      <Link
                        to="/signin"
                        className="btn btn-primary btn-lg w-100"
                      >
                        Send Money Now
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
