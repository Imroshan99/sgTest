import React from "react";
// import '../../../assets/scss/home.scss'

import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Container from "@mui/material/Container";

import IosShareRoundedIcon from "@mui/icons-material/IosShareRounded";
import ShoppingBagRoundedIcon from "@mui/icons-material/ShoppingBagRounded";
import PeopleAltRoundedIcon from "@mui/icons-material/PeopleAltRounded";
import CheckBoxRoundedIcon from "@mui/icons-material/CheckBoxRounded";

import { useSelector } from "react-redux";
import { Link } from "react-router-dom";

import ExchangeRateWidget from "./Widgets/ExchangeRateWidget";
import { Dropdown, Menu } from "antd";
import { SmileOutlined } from "@ant-design/icons";

const menu = (
  <Menu>
    <Menu.Item><Link to={"/signin"}>Login</Link></Menu.Item>
    <Menu.Item><Link to={"/signup"}>Register</Link></Menu.Item>
  </Menu>
);
const CGPN = (props) => {
  const ConfigReducer = useSelector((state) => state.user);
  const AuthReducer = useSelector((state) => state.user);

  return (
    <>
      <header>
        <div className="container">
          <nav className="navbar navbar-expand-lg navbar-light py-3">
            <div className="container-fluid">
              <Link to="/">
                <img
                  src={`images/${AuthReducer.groupId}/logo.png`}
                  height="48px"
                  alt="Logo"
                />
              </Link>
              <Dropdown overlay={menu} trigger={["click"]}
                placement="bottomRight">
                <a onClick={(e) => e.preventDefault()}>
                  <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                  >
                    <span className="navbar-toggler-icon"></span>
                  </button>
                </a>
              </Dropdown>
              <div
                className="collapse navbar-collapse"
                id="navbarSupportedContent"
              >
                <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                  {/* <li className="nav-item">
                    <a className="nav-link active" aria-current="page" href="#">
                      Home
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">
                      Link
                    </a>
                  </li> */}
                </ul>
                <div className="d-flex">
                  <Link className="btn btn-outline-primary" to={"/signin"}>
                    Login
                  </Link>
                  <Link className="btn btn-primary ms-3" to={"/signup"}>
                    Register
                  </Link>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>
      <div>
        <section className="hero-wrap">
          <div className="hero-mask opacity-75 bg-dark"></div>
          <div
            className="hero-bg"
            style={{
              backgroundImage: `url('images/${AuthReducer.groupId}/home-banner.jpg')`,
            }}
          ></div>
          <div className="hero-content d-flex fullscreen">
            <Container className="my-auto py-5">
              <Box>
                <Grid container spacing={{ xs: 2, md: 4 }} className=" py-5">
                  <Grid
                    item
                    lg={6}
                    xl={7}
                    className="my-auto text-center text-lg-start pb-4 pb-lg-0"
                  >
                    <h1 className="fw-700 text-white mb-4">
                      Experience super fast <br className="d-none d-xl-block" />
                      money transfer <br className="d-none d-xl-block" />
                      at a branch near you
                    </h1>
                    <p className="lead text-light mb-4">
                      Remit Money with Ease &amp; Simplicity. Get the Best
                      Exchange rates with Multiple Offers to choose from.
                    </p>
                  </Grid>
                  <Grid item lg={6} xl={5} className="my-auto mx-auto">
                    <ExchangeRateWidget />
                  </Grid>
                </Grid>
              </Box>
            </Container>
          </div>
        </section>

        <section className="section bg-grey py-5">
          <Container>
            <Box className="text-center" sx={{ my: 2, p: 2 }}>
              <div className="text-primary">OUR PROCESS</div>
              <h2 className="fw-700">Fast and Easy Way to Send Money</h2>
              <p>
                Get started with Ackers Inc in just a few seconds. We provide
                fast and simple steps to send money to your loved one. With just
                a few steps, and you are done!
              </p>
            </Box>
            <Box>
              <Grid container spacing={{ xs: 2, md: 4 }}>
                <Grid item xs={12} md={3}>
                  <div className="featured-box style-4">
                    <div className="featured-box-icon">
                      <h1>
                        <IosShareRoundedIcon
                          fontSize="large"
                          className="text-primary"
                        />
                      </h1>
                    </div>
                    <h3 className="fw-500">Select Country</h3>
                    <p className="">
                      Select the country of your Beneficiary and view the
                      exchange rate. We offer competitive exchange rate.
                    </p>
                  </div>
                </Grid>
                <Grid item xs={12} md={3}>
                  <div className="featured-box style-4">
                    <div className="featured-box-icon">
                      <h1>
                        <CheckBoxRoundedIcon
                          fontSize="large"
                          className="text-primary"
                        />
                      </h1>
                    </div>
                    <h3 className="fw-500">Enter Amount</h3>
                    <p className="">
                      Enter the amount which you want to send and view the exact
                      amount which will be delivered. You will definitely get
                      the best final digits.
                    </p>
                  </div>
                </Grid>
                <Grid item xs={12} md={3}>
                  <div className="featured-box style-4">
                    <div className="featured-box-icon">
                      <h1>
                        <PeopleAltRoundedIcon
                          fontSize="large"
                          className="text-primary"
                        />
                      </h1>
                    </div>
                    <h3 className="fw-500">Enter Beneficiary</h3>
                    <p className="">
                      Enter the Beneficiary personal and bank information
                    </p>
                  </div>
                </Grid>
                <Grid item xs={12} md={3}>
                  <div className="featured-box style-4">
                    <div className="featured-box-icon">
                      <h1>
                        <ShoppingBagRoundedIcon
                          fontSize="large"
                          className="text-primary"
                        />
                      </h1>
                    </div>
                    <h3 className="fw-500">Confirm and Pay</h3>
                    <p className="">
                      Add your account information and book the transaction.
                    </p>
                  </div>
                </Grid>
              </Grid>
            </Box>
          </Container>
        </section>

        <section className="section bg-white py-5">
          <Container>
            <Box className="text-center" sx={{ my: 2, p: 2 }}>
              <div className="text-primary">OUR SECURITY</div>
              <h2 className="fw-700">Your Safety is Our Concern</h2>
              <p>
                We implement highest levels of encryption techniques to protect
                your data.
              </p>
            </Box>
          </Container>
        </section>
        <section className="section bg-white ">
          <Container>
            <Box className="text-center text-dark">
            <div className="d-flex justify-content-between">
              <Link className="text-dark text-decoration-none" to={"/request-money"}>Request Money</Link>
              <Link className="text-dark text-decoration-none" to={"/contact"}>Contact Us</Link>
              <Link className="text-dark text-decoration-none" to={"/feedback"}>Feedback</Link>
              <Link className="text-dark text-decoration-none" to={"/raise-issue"}>Raise Issue</Link>
            </div>
            </Box>
            </Container>
            </section>
        <section className="footer-section bg-white pb-4">
          <div className="footer-copyright pt-4">
            <Box>
              <Container>
                <Grid container spacing={{ xs: 12, md: 12 }}>
                  <Grid item xs={12} lg={12}>
                    <p className="text-center text-lg-start mb-2 mb-lg-0">
                      Copyright © 2022 {ConfigReducer.groupIdSettings.title}.
                      All rights reserved
                    </p>
                  </Grid>
                </Grid>
              </Container>
            </Box>
            {/* <div className="container">
                        <div className="row">
                            <div className="col-lg">
                                <p className="text-center text-lg-left mb-2 mb-lg-0">Copyright © 2020 <a to="#!">Payyed</a>. All Rights Reserved.</p>
                            </div>
                            <div className="col-lg d-lg-flex align-items-center justify-content-lg-end">
                                <ul className="nav justify-content-center">
                                    <li className="nav-item"> <Link className="nav-link active" to="#!">Security</Link></li>
                                    <li className="nav-item"> <Link className="nav-link" to="#!">Terms</Link></li>
                                    <li className="nav-item"> <Link className="nav-link" to="#!">Privacy</Link></li>
                                </ul>
                            </div>
                        </div>
                    </div> */}
          </div>
        </section>
      </div>
    </>
  );
};
export default CGPN;
