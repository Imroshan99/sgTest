// window.KCB_SETTINGS = {
//   HOST: "cross-border-remittance-kcb-mremit.apps.dev.aro.kcbgroup.com",
//   API: "https://cross-border-remittance-admin-kcb-mremit.apps.dev.aro.kcbgroup.com",
// };
window.KCB_SETTINGS = {
  HOST: "qaonekcb.remit.in",
  API: "https://qaone.remit.in",
};
