export const GroupSettings = {
  KCB: {
    title: "KCB Mint",
    template: "TEMPLATE_THREE",
    default: { sendModeCode: "ACH", programCode: "FER" },
    signInForm: {
      twoFA: "Y",
    },
    signUpForm: {
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        columns: {
          status: "DISABLED", //disable status column
        },
      },
      AddRecipientForm: {
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
      },
    },
    profileModule: {
      // addressApi : 'ADDRESSNOW',
      twoFA: "N",
      inputFields: {},
    },
    kyc: {
      inputFields: {
        sourceOfFund: { hidden: true },
        remittanceFrequency: { hidden: true },
      },
    },
    settings: {
      rightClick: false,
      selectText: false,
    },
  },
  XR: {
    title: "XMONIES",
    template: "TEMPLATE_TWO",
    default: { sendModeCode: "CIP", programCode: "FER" },
    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        columns: {
          // status: "DISABLED", //disable status column
        },
      },
      AddRecipientForm: {
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
      },
    },
    profileModule: {
      twoFA: "N",
      // addressApi : 'ADDRESSNOW',
      inputFields: {},
    },
    kyc: {
      inputFields: {
        ssn: { hidden: true },
      },
    },
    settings: {
      rightClick: true,
      selectText: true,
    },
  },
  "MF": {
    title: "Muthoot Finance Remit",
    template: "TEMPLATE_ONE",
    default: { sendModeCode: "CIP", programCode: "FER" },
    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        columns: {
          status: "DISABLED", //disable status column
        },
      },
      AddRecipientForm: {
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
      },
    },
    profileModule: {
      // addressApi : 'ADDRESSNOW',
      twoFA: "N",
      inputFields: {},
    },
    kyc: {
      inputFields: {
        sourceOfFund: { hidden: true },
        remittanceFrequency: { hidden: true },
      },
    },
    settings : {
      rightClick : false,
      selectText : false
    }
  },
  "CSB": {
    title: "CSB Bank Remit",
    template: "TEMPLATE_ONE",
    default: { sendModeCode: "CIP", programCode: "FER" },
    signInForm: {
      twoFA: "N",
    },
    signUpForm: {
      formType: "REGULAR", // formType: "REGULAR" | STEPS,
    },
    recipientModule: {
      recipientList: {
        columns: {
          status: "DISABLED", //disable status column
        },
      },
      AddRecipientForm: {
        recipientBankBranchRadio: false,
        defaultRecipientBranch: "LOCATION", //LOCATION or IFSC
        twoFA: "N",
      },
    },
    profileModule: {
      // addressApi : 'ADDRESSNOW',
      twoFA: "N",
      inputFields: {},
    },
    kyc: {
      inputFields: {
        sourceOfFund: { hidden: true },
        remittanceFrequency: { hidden: true },
      },
    },
    settings : {
      rightClick : false,
      selectText : false
    }
  },
};
