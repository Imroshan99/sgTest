import React, { useState } from "react";
import LocalPrintshopIcon from "@mui/icons-material/LocalPrintshop";
import StarIcon from "@mui/icons-material/Star";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import moment from "moment";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import { config } from "../../../../config";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { notification } from "antd";
import { jsPDF } from "jspdf";
import useHttp from "../../../../hooks/useHttp";

// import Printer, { print } from 'react-pdf-print'

function ThankYouScheduleTransaction(props) {
  const ids = ["1"];
  const [isFav, setFav] = useState(false);
  const [isShowPrintReciept, setIsShowPrintReciept] = useState(false);
  const txnReceiptDetail = props.state.txnReceiptDetails;
  // const txnReceiptDetail = {
  //     "responseId": "2580969",
  //     "requestId": "mkxz6qe",
  //     "responseType": "TXNDETAILS",
  //     "groupId": "ICA",
  //     "token": null,
  //     "status": "S",
  //     "message": "Success",
  //     "errorCode": null,
  //     "errorMessage": null,
  //     "errorList": null,
  //     "rptRefNo": "RPT4104",
  //     "sendModeCode": "ACH",
  //     "programCode": "FERSB",
  //     "paymodeType": null,
  //     "programName": "ICICI Bank Account",
  //     "sendCountry": "CA-CAD",
  //     "sendAmount": "77600.00",
  //     "sendAmountText": "Seventy Seven Thousand  Six Hundred and",
  //     "exRate": "",
  //     "promoCode": "",
  //     "recvCountry": "IN-INR",
  //     "receiverNickName": "FSDF",
  //     "receiverName": "RITESH GOSAVI",
  //     "recvBankName": "HDFC BANK LTD",
  //     "recvAccNumber": "123123123123",
  //     "recvAddress": "12121",
  //     "recvMobileNo": "91-8600523361",
  //     "rpBookingDate": "2022-03-03 14:21:49",
  //     "senderBankName": "ICICI BANK",
  //     "routingNumber": null,
  //     "senderAccountNo": "1234567890",
  //     "purpose": "19",
  //     "purposeDesc": "Purchase of permissible Real Estate other than Agri/Plantation/Farm by NRI/PIO",
  //     "recordToken": null,
  //     "bankAcc_labelCode": null,
  //     "bankAcc_captionCode": null,
  //     "bankAcc_valueCode": null,
  //     "customerName": "MAU GIRI",
  //     "customerAddress1": "1405, Upper Ottawa St",
  //     "customerAddress2": "11",
  //     "customerState": "Ontario",
  //     "customerCity": "Hamilton",
  //     "customerZipCode": "L8W 3J6",
  //     "customerMobileNo": "91-8600523361",
  //     "recvAddress2": null,
  //     "recvState": "HARYANA",
  //     "recvCity": "AMBALA SADAR",
  //     "recvZipCode": "425001",
  //     "subPurpose": "",
  //     "subPurposeDesc": "",
  //     "transactionStatusCode": "A",
  //     "transactionStatus": "Transaction Active",
  //     "amountPayable": "77600.00"
  // }

  const hookTxnFaviorate = useHttp(TransactionAPI.txnFaviorate);

  const onClickFavourite = () => {
    let payload = {
      requestType: "FAVOURITETRANSACTION",
      favouriteFlag: isFav ? "0" : "1",
      rgtn: txnReceiptDetail.rgtn,
      userId: props.state.userID,
    };

    hookTxnFaviorate.sendRequest(payload, function (data) {
      if (data.status == "S") {
        if (isFav) {
          notification.success({
            message:
              "Transaction has been removed from faviorate successfully.",
          });
        } else {
          notification.success({
            message: "Transaction has been added to faviorate successfully.",
          });
        }
        setFav(!isFav);
      }
    });
  };

  const onClickprintPDF = () => {
    var doc = new jsPDF();
    doc.setFontSize(12);
    doc.text(10, 20, "Trans. Initiation Date:");
    doc.text(60, 20, txnReceiptDetail.rpBookingDate);
    doc.text(110, 20, " Purpose of Payment:");
    doc.text(160, 20, txnReceiptDetail.purposeDesc);

    doc.text(10, 27, " Estimated Delivery Date:");
    doc.text(60, 27, ``);
    doc.text(110, 27, " Transfer Type:");
    doc.text(160, 27, `Online`);

    doc.text(10, 34, " Tracking Number:");
    doc.text(60, 34, txnReceiptDetail.rptRefNo);
    doc.text(110, 34, " Exchange Rate:");
    doc.text(160, 34, `1 CAD = 0.00 INR`);

    doc.text(10, 41, " Mode of Payment:");
    doc.text(60, 41, txnReceiptDetail.programName);
    doc.setTextColor(255, 0, 0); //set font color to red

    doc.setFontSize(14);
    doc.text(10, 50, "Sender");
    doc.text(110, 50, `Receiver`);
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0); //set font color to black
    doc.text(10, 59, txnReceiptDetail.customerName);
    doc.text(110, 59, txnReceiptDetail.receiverName);
    doc.setFontSize(11);
    doc.text(10, 65, txnReceiptDetail.customerAddress1);
    doc.text(110, 65, txnReceiptDetail.recvAddress);
    doc.text(10, 70, txnReceiptDetail.customerAddress2);
    doc.text(110, 70, txnReceiptDetail.recvCity);
    doc.text(
      10,
      75,
      `${txnReceiptDetail.customerCity}, ${txnReceiptDetail.customerState}`
    );
    doc.text(110, 75, txnReceiptDetail.recvState);
    doc.text(10, 80, txnReceiptDetail.customerZipCode);
    doc.text(110, 80, txnReceiptDetail.recvZipCode);

    doc.text(10, 85, txnReceiptDetail.customerMobileNo);
    doc.text(110, 85, `Ph:91-8600523361`);
    doc.setFontSize(12);
    doc.setFont(undefined, "bold");
    doc.text(10, 92, "Bank of Montreal");
    doc.text(110, 92, txnReceiptDetail.recvBankName);
    doc.text(10, 97, "A/c No. 098765432112");
    doc.text(110, 97, `A/c No. ${txnReceiptDetail.recvAccNumber}`);
    doc.setFont(undefined, "normal");
    doc.setFontSize(11);
    doc.text(10, 120, "Transfer Amount:");
    doc.text(60, 120, `800.00 CAD`);
    doc.text(110, 120, "Converted Amount");
    doc.text(160, 120, ``);

    doc.text(10, 127, "Transfer Fees:");
    doc.text(60, 127, ``);
    doc.text(110, 127, "Promo Code Benefit");
    doc.text(160, 127, `INR`);
    doc.line(10, 130, 90, 130);
    doc.line(110, 130, 190, 130);
    doc.setFontSize(13);
    doc.text(10, 135, "Transfer Amount:");
    doc.setTextColor(255, 0, 0);
    doc.text(60, 135, `800.00 CAD`);
    doc.setTextColor(0, 0, 0);
    doc.text(110, 135, "Total to Recipient:");
    doc.text(160, 135, `INR`);
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0); //set font color to black
    doc.setFont(undefined, "bold");
    doc.text(
      10,
      150,
      "eTransfer (ACH): Pay from My Bank account with another Canadian Financial Institution."
    );
    doc.setFont(undefined, "normal");
    doc.text(
      10,
      156,
      `• The current Daily limit for online money transfer limits is CAD 10000000.00 in one calendar day to any bank account in India.`
    );
    doc.text(
      10,
      161,
      "• Please ensure all receiver details provided to us are correct and updated prior to executing any transaction"
    );
    doc.text(
      10,
      174,
      "• Typically, the amount will be transferred within 5 business days of transfer request being submitted to ICICI Bank Canada."
    );
    doc.text(
      10,
      168,
      "• Please keep your bank account adequately funded for the Transfer Amount."
    );
    doc.text(
      10,
      179,
      "• Once you confirm the details, you won’t be able to make any changes."
    );
    doc.setFont(undefined, "bold");
    doc.text(10, 186, "Disclosures:");
    doc.setFont(undefined, "normal");
    doc.text(
      10,
      192,
      "1. ICICI Bank Canada is a wholly owned subsidiary of ICICI Bank Limited "
    );
    doc.text(10, 199, "2. “ * “ denotes field is mandatory.");
    doc.text(
      10,
      205,
      "3. Please ensure that the Receiver’s banking details that you enter or select is correct, including account number."
    );
    doc.text(
      10,
      210,
      "4. Receivers cannot be a Business or Trust. For further information, please contact our Customer Care Center toll-free at "
    );
    doc.text(
      10,
      217,
      " 1-888-424-2422 or email customercare.ca@icicibank.com "
    );
    doc.text(
      10,
      223,
      "5. Please select appropriate Purpose of Remittance prior to conducting your remittance transaction. If the Purpose of your "
    );
    doc.text(
      10,
      228,
      "   remittance does not match one of the existing Purpose of Remittance list available online, please contact our Customer"
    );
    doc.text(
      10,
      235,
      "   Care center toll-free at 1-888-424-2422 or email customercare.ca@icicibank.com "
    );
    doc.text(
      10,
      240,
      "6. ICICI Bank Canada is not responsible for funds transferred to an unintended recipient, if incorrect details are provided."
    );
    doc.text(
      10,
      245,
      "7. ICICI Bank Canada is not liable to retrieve funds transferred to an unintended recipient, if incorrect Receiver details "
    );
    doc.text(10, 250, "   are provided.");
    doc.text(
      10,
      256,
      "8. Once Money Transfer request has been submitted, your remittance cannot be cancelled, changed or recalled."
    );
    doc.text(
      10,
      260,
      "9. ICICI Bank Canada is not liable for any additional charge or fees levied by the external bank, including "
    );
    doc.text(
      10,
      265,
      "   for transferring money to your account with ICICI Bank Canada."
    );
    doc.text(
      10,
      271,
      "10. ICICI Bank Canada will make reasonable efforts to process all transactions within 2 business days of receiving a Money "
    );
    doc.text(
      10,
      276,
      "    Transfer request, subject to all verification processes beingcomplete and information provided by the applicant being "
    );
    doc.text(
      10,
      281,
      "    correct. However, the ICICI Bank Canada will not be liable or responsible for any delay in processing transactions"
    );
    doc.text(
      10,
      286,
      "    within the said timeline, including for losses or damages caused by such delay."
    );
    doc.text(
      10,
      290,
      "11. ICICI Bank Canada will reverse the Money Transfer charges within 10 business days, if the transaction is executed from"
    );
    doc.text(10, 295, "    HiValue Plus Chequing Account. ");
    doc.text(
      10,
      300,
      "12. Remittances are subject to the Terms and Conditions mentioned on the website.  Click here for details."
    );

    doc.save(`${txnReceiptDetail.rptRefNo}.pdf`);
  };

  if (!isShowPrintReciept) {
    return (
      <>
        {/* <div className="p-2 bg-secondary">
                    <h3 className="mb-0 text-white">Initiated</h3>
                </div>
                <div className='container p-5'> */}
        <section className="text-center">
          <h3>{txnReceiptDetail.amountPayable} CAD</h3>
          <h5>
            Transfer initiated to <b>{txnReceiptDetail.receiverName}</b>
          </h5>
          <h5>
            Your Tracking Id / Ref Id is <b>{txnReceiptDetail.rptRefNo}</b>
          </h5>
          <h5>Expected to reach by {txnReceiptDetail.rpBookingDate}</h5>
        </section>

        <section className="my-3 text-center">
          <button
            className="border-0 bg-none "
            onClick={() => setIsShowPrintReciept(true)}
            type="button"
          >
            <LocalPrintshopIcon className="mx-2" />
            Print Reciept
          </button>

          <span className="mx-4 fs-4">|</span>
          <button className="border-0 bg-none">
            {!isFav ? (
              <StarBorderIcon className="mx-2" onClick={onClickFavourite} />
            ) : (
              <StarIcon className="mx-2" onClick={onClickFavourite} />
            )}
            Add To Favourite
          </button>
        </section>
        <section className="text-center">
          <button
            className="btn my-4 "
            type="button"
            onClick={() =>
              props.setState({
                isStep: 1,
                promoValueWithDesc: "",
                isSelectedBankTransfer: false,
                _isScheduleTransaction: false,
                sendAccId: "",
                achAccId: "",
                accountNo: "",
              })
            }
          >
            Make Another Transfer
          </button>
        </section>
        {/* </div> */}
      </>
    );
  } else {
    return (
      // <div className='container p-5'>
      <div className="p-5">
        <section>
          <h5>Receipt</h5>
        </section>
        <hr />
        <section>
          <div className="row">
            <div className="col-md-3">Trans. Initiation Date:</div>
            <div className="col-md-3">{txnReceiptDetail.rpBookingDate}</div>
            <div className="col-md-3">Purpose of Payment:</div>
            <div className="col-md-3">{txnReceiptDetail.purposeDesc}</div>
          </div>

          <div className="row">
            <div className="col-md-3">Estimated Delivery Date:</div>
            <div className="col-md-3"></div>
            <div className="col-md-3">Transfer Type:</div>
            <div className="col-md-3">Online</div>
          </div>

          <div className="row">
            <div className="col-md-3">Tracking Number:</div>
            <div className="col-md-3">{txnReceiptDetail.rptRefNo}</div>
            <div className="col-md-3">Exchange Rate:</div>
            <div className="col-md-3">1 CAD = 0.00 INR</div>
          </div>

          <div className="row">
            <div className="col-md-3">Mode of Payment:</div>
            <div className="col-md-3">{txnReceiptDetail.programName}</div>
            <div className="col-md-3"></div>
            <div className="col-md-3"></div>
          </div>
        </section>

        <section className="mt-3">
          <div className="row">
            <div className="col-md-6">
              <h5>Sender</h5>
            </div>
            <div className="col-md-6">
              <h5>Receiver</h5>
            </div>
          </div>

          <div className="row">
            <div className="col-md-6">{txnReceiptDetail.customerName}</div>
            <div className="col-md-6">{txnReceiptDetail.receiverName}</div>
          </div>

          <div className="row">
            <div className="col-md-6">{txnReceiptDetail.customerAddress1}</div>
            <div className="col-md-6">{txnReceiptDetail.recvAddress}</div>
          </div>

          <div className="row">
            <div className="col-md-6">{txnReceiptDetail.customerAddress2}</div>
            <div className="col-md-6">{txnReceiptDetail.recvCity}</div>
          </div>

          <div className="row">
            <div className="col-md-6">
              {txnReceiptDetail.customerCity}, {txnReceiptDetail.customerState}
            </div>
            <div className="col-md-6">{txnReceiptDetail.recvState}</div>
          </div>

          <div className="row">
            <div className="col-md-6">{txnReceiptDetail.customerZipCode}</div>
            <div className="col-md-6">{txnReceiptDetail.recvZipCode}</div>
          </div>

          <div className="row">
            <div className="col-md-6">{txnReceiptDetail.customerMobileNo}</div>
            <div className="col-md-6">{txnReceiptDetail.recvMobileNo}</div>
          </div>

          <div className="row mt-2">
            <div className="col-md-6">Bank of Montreal</div>
            <div className="col-md-6">{txnReceiptDetail.recvBankName}</div>
          </div>

          <div className="row">
            <div className="col-md-6">A/c No. 098765432112</div>
            <div className="col-md-6">
              A/c No. {txnReceiptDetail.recvAccNumber}
            </div>
          </div>

          <div className="row mt-2">
            <div className="col-md-3">Transfer Amount:</div>
            <div className="col-md-3">800.00 CAD</div>
            <div className="col-md-3">Converted Amount</div>
            <div className="col-md-3"></div>
          </div>

          <div className="row">
            <div className="col-md-3">Transfer Fees:</div>
            <div className="col-md-3"></div>
            {/* <hr /> */}
            <div className="col-md-3">Promo Code Benefit</div>
            <div className="col-md-3">INR</div>
          </div>
          <hr />

          <div className="row mt-2">
            <div className="col-md-3">Total Amount:</div>
            <div className="col-md-3">800.00 CAD</div>
            <div className="col-md-3">Total to Recipient:</div>
            <div className="col-md-3"></div>
          </div>
        </section>

        <section className="mt-3">
          <p>
            <b>
              eTransfer (ACH): Pay from My Bank account with another Canadian
              Financial Institution.
            </b>
          </p>
          <p>
            • The current Daily pmit for online money transfer limits is CAD
            10000000.00 in one calendar day to any bank account in India.
          </p>
          <p>
            • Please ensure all receiver details provided to us are correct and
            updated prior to executing any transaction
          </p>
          <p>
            • Typically, the amount will be transferred within 5 business days
            of transfer request being submitted to ICICI Bank Canada.
          </p>
          <p>
            • Please keep your bank account adequately funded for the Transfer
            Amount.
          </p>
          <p>
            • Once you confirm the details, you won’t be able to make any
            changes.
          </p>

          <p>
            <b>Disclosures:</b>
          </p>
          <p>
            1. ICICI Bank Canada is a wholly owned subsidiary of ICICI Bank
            Limited
          </p>
          <p>2. “ * “ denotes field is mandatory.</p>
          <p>
            3. Please ensure that the Receiver’s banking details that you enter
            or select is correct, including account number.
          </p>
          <p>
            4. Receivers cannot be a Business or Trust. For further information,
            please contact our Customer Care Center toll-free at 1-888-424-2422
            or email mailto:customercare.ca@icicibank.com
          </p>
          <p>
            5. Please select appropriate Purpose of Remittance prior to
            conducting your remittance transaction. If the Purpose of your
            remittance does not match one of the existing Purpose of Remittance
            list available online, please contact our Customer Care center
            toll-free at 1-888-424-2422 or email
            mailto:customercare.ca@icicibank.com
          </p>
          <p>
            6. ICICI Bank Canada is not responsible for funds transferred to an
            unintended recipient, if incorrect Receiver details are provided.
          </p>
          <p>
            7. ICICI Bank Canada is not liable to retrieve funds transferred to
            an unintended recipient, if incorrect Receiver details are provided.
          </p>
          <p>
            8. Once Money Transfer request has been submitted, your remittance
            cannot be cancelled, changed or recalled.
          </p>
          <p>
            9. ICICI Bank Canada is not liable for any additional charge or fees
            levied by the external bank, including for transferring money to
            your account with ICICI Bank Canada.
          </p>
          <p>
            10. ICICI Bank Canada will make reasonable efforts to process all
            transactions within 2 business days of receiving a Money Transfer
            request, subject to all verification processes being complete and
            information provided by the applicant being correct. However, the
            ICICI Bank Canada will not be liable or responsible for any delay in
            processing transactions within the said timeline, including for
            losses or damages caused by such delay.
          </p>
          <p>
            11. ICICI Bank Canada will reverse the Money Transfer charges within
            10 business days, if the transaction is executed from HiValue Plus
            Chequing Account.
          </p>
          <p>
            12. Remittances are subject to the Terms and Conditions mentioned on
            the website. Click here for details.
          </p>
        </section>

        <section className="m-4 text-center">
          <button
            className="border-0 bg-none btn btn-sm"
            onClick={() => setIsShowPrintReciept(false)}
            type="button"
          >
            Cancel
          </button>

          <button
            className="border-0 bg-none btn btn-sm"
            onClick={onClickprintPDF}
            type="button"
          >
            Download
          </button>

          <button
            className="border-0 bg-none btn btn-sm"
            onClick={() => window.print()}
            type="button"
          >
            Print Receipt (PDF)
          </button>
        </section>
      </div>
    );
  }
}

export default ThankYouScheduleTransaction;
