import { Link } from "react-router-dom";
import React, { useState, Fragment, useEffect, useReducer } from "react";
import {
  Collapse,
  Row,
  Col,
  Input,
  Space,
  Modal,
  Radio,
  Button,
  Divider,
  notification,
} from "antd";
// import GBp from "../../../../assets/images/Gbp.png";
// import inr from "../../../../assets/images/inr.png";
import moment from "moment";
import { useSelector } from "react-redux";
import { flags } from "../../../../services/utility/flags";
import useHttp from "../../../../hooks/useHttp";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { Alert } from "@mui/material";

export default function NewTransaction(props) {
  const { Panel } = Collapse;
  const AuthReducer = useSelector((state) => state);

  const hookRecipientRequestLists = useHttp(ReceiverAPI.recipientRequestLists);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      recipientRequestLists: [],
      amountError: false,
    }
  );

  useEffect(() => {
    const timeOutId = setTimeout(() => {
      if (props.state.sendAmount >= 1) {
        props.onCallComputeExchangeRates(
          "SENDMONEY",
          props.state.isDenefit,
          props.state.promoCode,
          props.state.sendAmount
        );
      } else {
        //  alert('Please enter valid amount')
        // setState({
        //   amountError : true
        // })
      }
    }, 500);
    return () => clearTimeout(timeOutId);
  }, [props.state.sendAmount]);

  useEffect(() => {
    recipientRequestListsHandler();
  }, []);

  const recipientRequestListsHandler = () => {
    const payload = {
      requestType: "RECREQLIST",
      userId: AuthReducer.userID,
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
      favouriteFlag: "",
    };
    hookRecipientRequestLists.sendRequest(payload, (res) => {
      console.log(res);
      if (res.status === "S") {
        setState({
          recipientRequestLists: res.responseData,
        });
      }
    });
  };

  //  console.log(AuthReducer)

  return (
    <Fragment>
      <div className="new-transaction">
        <Row className="py-2 align-items-center">
          <Col span={16}>
            {state.recipientRequestLists.map((v, i) => {
              return (
                <Alert
                  severity="info"
                  className="mb-2"
                  key={`request__list__${i}`}
                >
                  You have new request form {v.recvFirstName} {v.recvLastName} -{" "}
                  <Link to="/recipient-request-list">Click here</Link>
                </Alert>
              );
            })}
          </Col>
        </Row>
        <Collapse accordion>
          <Panel header="Recent Transactions" key="1">
            {props.state.transactionLists.map((list, i) => {
              return (
                <div className="row mb-3" key={i}>
                  <div className="col-12 col-md-6">
                    <h6 className="text-uppercase">{list.receiverName}</h6>
                    <small>
                      <span>{`${list.amount}`} on </span>
                      <span>
                        {moment(list.bookingDate).format("DD/MM/YYYY")}
                      </span>
                    </small>
                  </div>
                  <div className="col-12 col-md-6 text-end ">
                    <Link
                      className="btn btn-primary text-white btn-sm me-2"
                      to={{
                        pathname: "/repeat-transaction",
                      }}
                      state={{ rgtn: list.rgtn, txnRefNo: list.txnRefNo }}
                    >
                      Repeat
                    </Link>

                    <Link
                      className="btn btn-primary text-white btn-sm"
                      to={{
                        pathname: "/track-money-transfer",
                      }}
                      state={{ rgtn: list.rgtn }}
                    >
                      Track
                    </Link>
                  </div>
                </div>
              );
            })}
          </Panel>
          <Panel header="Recent Favourite" key="2">
            {props.state.favouriteTransactionLists.map((list, i) => {
              return (
                <Row justify="space-between" key={i}>
                  <Col span={12} className="d-block">
                    <h6 className="text-uppercase">{list.receiverName}</h6>
                    <small>
                      <span>{`${list.amount}`} on </span>
                      <span>
                        {moment(list.bookingDate).format("DD/MM/YYYY")}
                      </span>
                    </small>
                  </Col>
                  <Col span={12} className="text-end ">
                    <Link
                      className="btn btn-primary text-white btn-sm m-2"
                      to={{
                        pathname: "/repeat-transaction",
                      }}
                      state={{ rgtn: list.rgtn, txnRefNo: list.txnRefNo }}
                    >
                      Repeat
                    </Link>

                    <Link
                      className="btn btn-primary text-white btn-sm"
                      to={{
                        pathname: "/track-money-transfer",
                      }}
                      state={{ rgtn: list.rgtn }}
                    >
                      Track
                    </Link>
                  </Col>
                </Row>
              );
            })}
          </Panel>
        </Collapse>

        <Row justify="space-between " className="py-5 align-items-center">
          <Col span={5} xs={16} md={5} className="form-inputs">
            <label className="form-label">You send</label>
            <Input
              type="number"
              step="0.01"
              min={0}
              value={props.state.sendAmount}
              onChange={(e) => {
                props.setState({ sendAmount: e.target.value });
                if (e.target.value === "0" || e.target.value === "") {
                  setState({
                    amountError: true,
                  });
                } else {
                  setState({
                    amountError: false,
                  });
                }
              }}
              onBlur={() =>
                props.onCallComputeExchangeRates(
                  "SENDMONEY",
                  props.state.isDenefit,
                  props.state.promoCode,
                  props.state.sendAmount
                )
              }
            />
            {state.amountError && (
              <span role="alert" className="ant-form-item-explain-error">
                Please enter valid amount
              </span>
            )}
          </Col>
          <Col span={2} xs={6} md={2}>
            <div className="d-flex flag">
              <img
                src={require("../../../../assets/images/flags/" +
                  flags[AuthReducer.sendCountryCode])}
                alt={AuthReducer.sendCurrencyCode}
                className="flag-img"
              />
              <h3 className="px-2 mb-0">{AuthReducer.sendCurrencyCode}</h3>
            </div>
          </Col>
          <Col
            span={6}
            xs={24}
            md={6}
            justify="center"
            className="rate-change text-center"
          >
            <p className="mt-3 mt-md-0">
              Exchange Rate:
              <br />1 {AuthReducer.sendCurrencyCode} ={" "}
              {props.state.displayExRate} {AuthReducer.recvCurrencyCode}
            </p>
            <hr />
            <Button
              disabled={props.state.recvAmount == 0}
              onClick={() => props.setIsModalVisible(true)}
              className="mt-1 text-center text-primary border-0"
            >
              View Breakup
            </Button>
          </Col>
          <Col span={5} xs={16} md={5} className="form-inputs">
            <label className="form-label">Reciever gets</label>
            <Input
              type="number"
              step="0.01"
              min={0}
              readOnly={AuthReducer.groupId === "KCB" ? true : false}
              value={props.state.recvAmount}
              // onChange={(e) => props.setState({ recvAmount: e.target.value })}
              onChange={(e) => {
                props.setState({ recvAmount: e.target.value });
                if (e.target.value === "0" || e.target.value === "") {
                  setState({
                    amountError: true,
                  });
                } else {
                  setState({
                    amountError: false,
                  });
                }
              }}
              onBlur={() =>
                props.onCallComputeExchangeRates(
                  "SENDMONEY",
                  props.state.isDenefit,
                  props.state.promoCode,
                  props.state.recvAmount,
                  "REVERSE"
                )
              }
            />
          </Col>
          <Col span={2} xs={6} md={2}>
            <div className="d-flex flag">
              <img
                src={require("../../../../assets/images/flags/" +
                  flags[AuthReducer.recvCountryCode])}
                alt={AuthReducer.recvCurrencyCode}
                className="flag-img"
              />
              <h3 className="px-2 mb-0">{AuthReducer.recvCurrencyCode}</h3>
            </div>
          </Col>
        </Row>

        <div className="px-4">
          <Radio.Group name="radiogroup">
            <Space direction="vertical">
              {props.state.categoryPromoLists.map((cpl, i) => {
                return (
                  <Radio
                    value={i}
                    onClick={() => {
                      props.setState({
                        isDenefit: true,
                        applyPromoCode: false,
                        promoCode: cpl.promoCode,
                      });
                      setTimeout(() => {
                        props.onCallComputeExchangeRates(
                          "SENDMONEY",
                          true,
                          cpl.promoCode,
                          props.state.sendAmount
                        );
                      }, 500);
                    }}
                  >
                    {cpl.promoDesc}
                  </Radio>
                );
              })}

              {AuthReducer.groupId === "KCB" && (
                <Radio
                  value={10000}
                  onClick={() => {
                    props.setState({
                      isDenefit: false,
                      applyPromoCode: true,
                      promoCode: "",
                      promoValueWithDesc: "",
                    });
                    setTimeout(() => {
                      props.onCallComputeExchangeRates(
                        "SENDMONEY",
                        false,
                        "",
                        props.state.sendAmount
                      );
                    }, 500);
                  }}
                >
                  Apply promo code
                </Radio>
              )}
            </Space>
          </Radio.Group>
        </div>
        {props.state.applyPromoCode == true && (
          <div className="row">
            <div className="col-5">
              <Input
                placeholder="Enter promo code"
                onChange={(e) => props.setState({ promoCode: e.target.value })}
              />
            </div>
            <div className="col-5">
              <button
                className="btn btn-primary text-white btn-sm"
                disabled={props.state.promoCode == ""}
                onClick={props.applyPromo}
              >
                Apply promo code
              </button>
            </div>
          </div>
        )}
        {props.state.promoValueWithDesc != "" && (
          <div className="col-12">
            <p className="text-success">{props.state.promoValueWithDesc}</p>
          </div>
        )}
        <button
          className="btn btn-primary text-white btn-sm px-5 mx-4 my-4"
          disabled={props.state.recvAmount == 0}
          onClick={() => {
            if (props.state.sendAmount >= 1) {
              if (props.state.groupId == "KCB") {
                props.userRiskProfile();
                // alert(props.state.groupId)
                props.getAchAccountLists();
              } else {
                // props.setState({ isStep: 2 });
                props.userRiskProfile();
                props.getBankAccountLists();
              }

              props.getReceiverLists();
              props.getPaymentOption();

              props.getSourceOFFundLists();
            } else {
              notification.error({
                message: "Please enter valid amount",
              });
            }
          }}
        >
          Continue
        </button>
      </div>
    </Fragment>
  );
}
