import React, { createRef, forwardRef, useState } from "react";
import { useSelector } from "react-redux";

function XRInvoice(props, ref) {
  const AuthReducer = useSelector((state) => state);
  console.log("props", props);
  const invRef = createRef();

  const [isFav, setFav] = useState(false);

  return (
    <div ref={ref}>
      {props._invoiceTxnRefNumber && (
        <div>
          <div
            style={{
              width: "800px",
            }}
          >
            <section className="bg-light p-3 mt-3" ref={invRef}>
              <div>
                <img
                  src={require("../../../../../assets/images/logos/" +
                    AuthReducer.groupId +
                    "_logo.png")}
                  height="48px"
                />
              </div>
              <p className="mt-3">
                <span
                  style={{
                    backgroundColor: "#31c331",
                    color: "#FFF",
                    padding: "4px",
                    marginRight: "10px",
                  }}
                >
                  DONE
                </span>
                Step 1 : Money Transfer Request to XMONIES
                <br />
                Status: Transaction successfully booked. Funds awaited.
                <br />
                Please note that Guaranteed Rate will be applicable only if we
                receive the funds within 24 hours of transaction booking.
                <br />
                Your XMONIES Transaction No. (XRTN) :
                <b>{props._invoiceTxnRefNumber}</b>
              </p>

              <p className="mt-3">
                <span
                  style={{
                    backgroundColor: "#FF0000",
                    color: "#FFF",
                    padding: "4px",
                    marginRight: "10px",
                  }}
                >
                  PENDING
                </span>
                Step 2 : Transfer Money to XMONIES Bank Account
                <br />
                We have received your transaction request for{" "}
                {/* {`${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`} */}
                . The unique reference number for this transaction request is{" "}
                {props._invoiceTxnRefNumber}. Please follow the steps mentioned
                below to enable us to process your request:
                <br />
                Kindly print the Wire Transfer form and present it to your local
                bank.
                <br />
                <ol>
                  <li>
                    Approach your local bank in United Kingdom for initiating a
                    wire transfer transaction
                  </li>
                  <li>
                    Instruct your local bank to route the transaction though our
                    bank details mentioned below mentioning{" "}
                    {props._invoiceTxnRefNumber} in the additional information
                    usually field 70 or 72 of the SWIFT message
                  </li>
                </ol>
                We shall process your transaction post receiving the money in
                our account.
                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tbody>
                    <tr>
                      <td width="30%">
                        <strong>Name On The Account:</strong>
                      </td>
                      <td>RFX CLIENT AC GBP LLOYDS</td>
                    </tr>
                    <tr></tr>
                    <tr>
                      <td width="30%">
                        <strong>Bank Account Number:</strong>
                      </td>
                      <td>00569643</td>
                    </tr>
                    <tr></tr>
                    <tr>
                      <td width="30%">
                        <strong>Partner/Correspondent Bank:</strong>
                      </td>
                      <td>Lloyds Bank</td>
                    </tr>
                    <tr></tr>
                    <tr>
                      <td width="30%">
                        <strong>Swift Code:</strong>
                      </td>
                      <td>LOYDGB21F43</td>
                    </tr>
                    <tr></tr>
                    <tr>
                      <td width="30%">
                        <strong>Sort Code:</strong>
                      </td>
                      <td>304065</td>
                    </tr>
                    <tr></tr>
                    <tr>
                      <td width="30%">
                        <strong>IBAN:</strong>
                      </td>
                      <td>GB33LOYD30406500569643</td>
                    </tr>
                    <tr></tr>

                    <tr>
                      <td width="30%">
                        <strong>XMONIES Transaction Number </strong>
                      </td>
                      <td>{props._invoiceTxnRefNumber}</td>
                    </tr>
                  </tbody>
                </table>
                <span>
                  (Please ensure that you enter the XMONIES Transaction Number
                  in the Wire Transfer instruction)
                </span>
              </p>

              <p>
                All charges to be paid by me
                <br />
                <b>Important Information:</b>
                <ol>
                  <li>
                    Please ensure that the account from which the money is sent
                    belongs to you. In case of any discrepancy, the transaction
                    may be rejected or the processing may get delayed.
                  </li>
                  <li>
                    The exchange rate at which the money is converted is the
                    rate prevailing on the day on conversion of funds by Bank.
                  </li>
                  <li>XMONIES Payment Policy &amp; Error Resolution.</li>
                </ol>
              </p>
            </section>
          </div>
        </div>
      )}
    </div>
  );
}

export default forwardRef(XRInvoice);
