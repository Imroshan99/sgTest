import React, { useState } from "react";
import LocalPrintshopIcon from "@mui/icons-material/LocalPrintshop";
import StarIcon from "@mui/icons-material/Star";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import moment from "moment";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import { config } from "../../../../config";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { notification } from "antd";
import { jsPDF } from "jspdf";
import * as autoTable from "jspdf-autotable";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";

function BankThankYou(props) {
  const AuthReducer = useSelector((state) => state);

  const [isFav, setFav] = useState(false);
  const txnReceiptDetail = props.state.txnReceiptDetails;

  const hookTxnFaviorate = useHttp(TransactionAPI.txnFaviorate);

  // const txnReceiptDetail = {
  //     amountPayable: "802.00",
  //     bankAcc_captionCode: null,
  //     bankAcc_labelCode: null,
  //     bankAcc_valueCode: null,
  //     bankCode: "5552",
  //     bookingDate: "2022-02-08 13:20:33",
  //     bookingDateTZ: "2022-02-08 07:50:33",
  //     bookingDateTwoHrs: "09:50 AM GMT 08 Feb, 2022",
  //     convertedAmount: "9672.00",
  //     customerAddress1: "Mytholmes Lane",
  //     customerAddress2: "Haworth",
  //     customerCity: "Nagpur",
  //     customerMobileNo: "91-7874698582",
  //     customerName: "DARSHANA NIINAWE",
  //     customerState: "West Yorkshire",
  //     customerZipCode: "BD22 8EZ",
  //     errorCode: null,
  //     errorList: null,
  //     errorMessage: null,
  //     exRate: "12.09",
  //     exRateWithoutPromo: "19.09",
  //     expDeliveryDate: "2022-02-08 15:21:00.0",
  //     expDeliveryDateTZ: "2022-02-08 09:51:00.0",
  //     fee: "2.00",
  //     feeTax: "0.00",
  //     feeTaxPercentage: "0",
  //     groupId: "IUK",
  //     gst: "1029.61",
  //     isCategoryPromo: "N",
  //     message: "Success",
  //     mobileWalletName: "",
  //     payDate: "",
  //     payDateTZ: null,
  //     paymodeType: "",
  //     pointEarnValue: "48.36",
  //     pointsEarn: "",
  //     programCode: "FERINST",
  //     programName: "Debit Card",
  //     promoBenefit: "0.00",
  //     promoCode: "",
  //     purpose: "6",
  //     purposeDesc: "Family Maintainance test1",
  //     receiveAmountText: "Nine Thousand  Six Hundred and Seventy Two",
  //     receiverName: "NITIN  KADAM",
  //     receiverNickName: "175356",
  //     recordToken: "",
  //     recvAccNumber: "963258741231",
  //     recvAddress: "",
  //     recvAddress2: "",
  //     recvAmount: "9672.00",
  //     recvBankBranchName: "MUMBAI - LBS MARG KURLA, MAHARASHTRA",
  //     recvBankName: "ICICI BANK LTD",
  //     recvCity: "MAHAKALPADA",
  //     recvCountry: "IN-INR",
  //     recvMobileNo: "-",
  //     recvModeCode: "DC",
  //     recvModeCodeDesc: "Bank Account Credit",
  //     recvState: "",
  //     recvZipCode: "",
  //     requestId: "96lscjw",
  //     responseId: "2451359",
  //     responseType: "TXNDETAILS",
  //     rgtn: "55341408240058",
  //     routingNumber: "",
  //     sendAmount: "800.00",
  //     sendAmountText: "Eight Hundred and Two",
  //     sendCountry: "GB-GBP",
  //     sendModeCode: "CIP",
  //     senderAccountNo: "04111050238585",
  //     senderBankName: "HDFC",
  //     showCancelButton: "",
  //     status: "S",
  //     token: null,
  //     totalFee: "2.00",
  //     traceNo: "",
  //     transactionStatus: "Transaction Booked",
  //     transactionStatusCode: "101",
  //     transactionSubStatus: "N.A.",
  //     transaferFee: "2.0",
  //     transferMessage: null,
  //     txnRefNumber: "UK1Z1814192",
  //     validityDate: "2022-02-10"
  // };

  const onClickFavourite = () => {
    let payload = {
      requestType: "FAVOURITETRANSACTION",
      favouriteFlag: isFav ? "0" : "1",
      rgtn: txnReceiptDetail.rgtn,
      userId: props.state.userID,
    };

    hookTxnFaviorate.sendRequest(payload, function (data) {
      if (data.status == "S") {
        if (isFav) {
          notification.success({
            message:
              "Transaction has been removed from faviorate successfully.",
          });
        } else {
          notification.success({
            message: "Transaction has been added to faviorate successfully.",
          });
        }
        setFav(!isFav);
      }
    });
  };

  const onClickprintPDF = () => {
    var doc = new jsPDF();
    doc.text(
      10,
      10,
      `Follow the steps below to complete your transfer to ${txnReceiptDetail.recvBankName}`
    );
    doc.setFontSize(16);
    doc.setTextColor(255, 165, 0);
    doc.text(10, 20, "Step 1");
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(13);
    doc.text(
      10,
      27,
      `Login to your bank's internet banking. Go to funds transfer and select your`
    );
    doc.text(
      10,
      33,
      `account number ${txnReceiptDetail.recvAccNumber} to send funds.`
    );
    doc.setFontSize(16);
    doc.setTextColor(255, 165, 0);
    doc.text(10, 41, "Step 2");
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(13);
    doc.text(
      10,
      47,
      `Initiate a transfer by inputting the below mandatory details in the corresponding fields:`
    );
    doc.setFontSize(14);
    doc.setFont("times");
    doc.text(10, 60, "Transfer Amount");
    doc.text(
      110,
      60,
      `${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`
    );
    doc.text(10, 70, "Recipient Name:");
    doc.text(110, 70, `${txnReceiptDetail.receiverName}`);
    doc.text(10, 80, "Recipient Bank:");
    doc.text(110, 80, `${txnReceiptDetail.recvBankName} `);
    doc.text(10, 90, "Recipient Bank Clearing / Sort Code:");
    doc.text(110, 90, `600004 `);
    doc.text(10, 100, "Recipient Account Number:");
    doc.text(110, 100, `${txnReceiptDetail.recvAccNumber}`);
    doc.text(10, 110, "Purpose of Payment:");
    doc.text(110, 110, `${txnReceiptDetail.purposeDesc}`);
    doc.text(10, 120, "Mode of Payment:");
    doc.text(110, 120, `${txnReceiptDetail.recvModeCodeDesc}`);
    // doc.setTextBackground(165, 0, 0);
    doc.setTextColor(255, 0, 0); //set font color to red
    doc.text(
      11,
      132,
      `Post online transfer, ${txnReceiptDetail.recvBankName} will be credited within 1-3 working days.`
    );
    doc.setTextColor(255, 0, 0); //set font color to red

    doc.text(11, 140, "Kindly note:");
    doc.setTextColor(0, 0, 0); //set font color to red
    doc.setFontSize(13);
    doc.text(
      11,
      150,
      `• The Tracking number ${txnReceiptDetail.txnRefNumber} is unique and is valid only for this transaction.`
    );
    doc.text(
      11,
      155,
      ` DO NOT PRECEDE the Tracking Number with any other comment. In case the Tracking number is `
    );
    doc.text(
      11,
      160,
      " number is missing or incorrectly provided in your transfer payment details, your funds may"
    );
    doc.text(11, 165, " get rejected or processing may get delayed.");

    doc.text(
      11,
      175,
      "• Please ensure that you send exactly the same amount as confirmed in the Amount/Currency field above. "
    );
    doc.text(
      11,
      180,
      "  This amount should be lower than or equal to your Net banking funds transfer limit (if any) as set-up"
    );
    doc.text(11, 185, "  for your Remitting Bank account.");

    doc.text(
      11,
      195,
      "• Once you initiate the money transfer from your local bank account to Bank Correspondent Bank "
    );
    doc.text(
      11,
      200,
      "  account using your local bank’s Internet Banking facility, depending upon the electronic clearing "
    );
    doc.text(
      11,
      205,
      "  used by your local bank to transfer the money and the associated clearing time, Bank will "
    );
    doc.text(11, 210, "  typically receive the funds within 1 working day.");

    doc.text(
      11,
      220,
      "• ICICI Bank will typically receive the funds within 1 working day."
    );
    doc.text(
      11,
      225,
      "  ICICI Bank will credit the funds into the receivers ICICI Bank Account within 1 working day of"
    );
    doc.text(
      11,
      230,
      "  ICICI Bank receiving the money. Timelines exclude banking holidays as well as Saturday and Sunday"
    );
    doc.text(
      11,
      235,
      "  in the remitting country and in India. Please Click here to view the list of banking holidays in"
    );
    doc.text(11, 240, "  United Kingdom and in India.");

    doc.text(
      11,
      250,
      "• Timelines exclude banking holidays as well as Saturday and Sunday in the remitting country and "
    );
    doc.text(
      11,
      255,
      "  in India. Please Click here to view the list of banking holidays in United Kingdom and in India."
    );

    doc.text(
      11,
      265,
      "• The INR amount disbursed to the beneficiary (as per your remittance request) will be net of the "
    );
    doc.text(11, 270, "  Conversion Service Tax. ");

    doc.text(
      11,
      280,
      "• Service Tax on currency conversion is applicable slab-wise. This will be calculated based on the"
    );
    doc.text(
      11,
      285,
      "  actual rate at which the funds are converted, as the Service tax is applicable on converted INR "
    );
    doc.text(
      11,
      290,
      "  value. Click here to know the slab wise service tax structure.Read Less"
    );

    doc.save(`${txnReceiptDetail.txnRefNumber}.pdf`);
  };

  // const onClickprintPDF = () => {

  //     var doc = new jsPDF();

  //     doc.text(10, 10, `Your transaction is successful.`);
  //     doc.text(10, 20, 'You can know the current status of your transaction by ');
  //     doc.text(10, 25, 'entering the tracking number')
  //     doc.setTextColor(255, 165, 0);
  //     doc.text(10, 30, `here.`)
  //     doc.setTextColor(0, 0, 0);
  //     doc.setDrawColor(255, 0, 0);
  //     doc.setLineWidth(0.1);
  //     doc.line(10, 40, 510, 40);

  //     doc.text(10, 49, 'Transfer tracking number:');
  //     doc.text(78, 49, txnReceiptDetail.txnRefNumber);
  //     doc.setDrawColor(255, 0, 0);
  //     doc.setLineWidth(0.05);
  //     doc.line(10, 55, 510, 55);

  //     doc.text(10, 62, 'Sender details');
  //     doc.text(10, 70, 'Name:');
  //     doc.text(30, 70, txnReceiptDetail.customerName);
  //     doc.setDrawColor(255, 0, 0);
  //     doc.setLineWidth(0.05);
  //     doc.line(10, 78, 510, 78);

  //     doc.text(10, 87, 'Recipient Details');
  //     doc.text(10, 97, 'Name:');
  //     doc.text(30, 97, txnReceiptDetail.receiverName);
  //     doc.text(10, 107, 'Bank Account Name:');
  //     doc.text(70, 107, txnReceiptDetail.recvBankName);
  //     doc.text(10, 117, 'Account Number:');
  //     doc.text(60, 117, txnReceiptDetail.recvAccNumber);
  //     doc.setDrawColor(255, 0, 0);
  //     doc.setLineWidth(0.05);
  //     doc.line(10, 122, 510, 122);

  //     doc.autoTable({ html: '.table' })
  //     doc.text(10, 128, 'Payment Details');
  //     var finalY = doc.lastAutoTable.finalY || 15
  //     doc.autoTable({
  //         startY: finalY + 122,
  //         // head: [['ID', 'Name', 'Email', 'Country', 'IP-address']],
  //         body: [
  //             [
  //                 'Transfer tracking number:', txnReceiptDetail.txnRefNumber,
  //                 'Initiated at:', txnReceiptDetail.bookingDate,
  //             ],
  //             [
  //                 'Payment Mode:', 'Debit Card',
  //                 'Applied Exchange Rate:', '1 GBP = 18.71 INR'
  //             ],
  //             [
  //                 'Transfer Amount:', `${txnReceiptDetail.amountPayable} GBP`,
  //                 'Transfer Fees:', `${txnReceiptDetail.totalFee} GBP`,
  //             ],
  //             [
  //                 'Promo Code:', '',
  //                 'M21 Reward:', '0.00 GBP or INR',
  //             ],
  //             [
  //                 'Receiver Gets:', `${txnReceiptDetail.recvAmount} INR`,
  //                 'Estimated Time of Arrival:', txnReceiptDetail.expDeliveryDate,
  //             ],
  //             [
  //                 'Purpose of payment:', txnReceiptDetail.purposeDesc,
  //                 '', '',
  //             ],

  //         ],
  //     })

  //     doc.text(10, 195, 'Kindly note:');
  //     doc.setFontSize(12);
  //     doc.text(10, 203, `• The Tracking number ${txnReceiptDetail.txnRefNumber} is unique and is valid only for this transoction.`);
  //     doc.text(10, 210, '   DO NOT PRECEDE the Tracking Number with any other comment when checking the status.');
  //     doc.text(10, 220, '• Timelines exclude Saturday and Sunday and bank holidays in the UK, USA and India.');
  //     doc.text(10, 230, '• Terms & Conditions apply. ');
  //     doc.text(10, 240, '• Need Help, Click here');

  //     doc.save(`${txnReceiptDetail.txnRefNumber}.pdf`);

  // }

  return (
    <div className="container p-5">
      <div className="row">
        <div className="col-md-1"></div>
        <div className="col-md-10">
          <section>
            <h5>
              Follow the steps below to complete your transfer to{" "}
              {txnReceiptDetail.recvBankName}
            </h5>
            <h5>Step 1</h5>
            <p>
              Login to your bank's internet banking. Go to funds transfer and
              select your account number {txnReceiptDetail.recvAccNumber} to
              send funds.
            </p>
            <h5>Step 2</h5>
            <p>
              Initiate a transfer by inputting the below mandatory details in
              the corresponding fields:
            </p>

            <div className="row">
              <div className="col-md-6">Transfer Amount:</div>
              <div className="col-md-6">
                <b>{`${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`}</b>
              </div>
            </div>
            <div className="row">
              <div className="col-md-6">Recipient Name:</div>
              <div className="col-md-6">
                <b>{txnReceiptDetail.recvBankName}</b>
              </div>
            </div>
            <div className="row">
              <div className="col-md-6">Recipient Bank:</div>
              <div className="col-md-6">
                <b>Royal Bank of Scotland</b>
              </div>
            </div>
            <div className="row">
              <div className="col-md-6">
                Recipient Bank Clearing / Sort Code:
              </div>
              <div className="col-md-6">
                <b>600004</b>
              </div>
            </div>
            <div className="row">
              <div className="col-md-6">Recipient Account Number:</div>
              <div className="col-md-6">
                <b>{txnReceiptDetail.recvAccNumber}</b>
              </div>
            </div>
            <div className="row">
              <div className="col-md-6">Purpose of Payment:</div>
              <div className="col-md-6">
                <b>{txnReceiptDetail.purposeDesc}</b>
              </div>
            </div>
            <div className="row">
              <div className="col-md-6">Mode of Payment:</div>
              <div className="col-md-6">
                <b>Net Express</b>
              </div>
            </div>
          </section>

          <section>
            <div className="p-2 mt-3 alert-danger">
              <p className="mb-0 text-dark">
                Post online transfer, {txnReceiptDetail.recvBankName} will be
                credited within 1-3 working days.
              </p>
            </div>
          </section>

          <section className="bg-light p-3 mt-3">
            <h5 className="mx-3">Kindly note:</h5>
            <ul>
              <li>
                The Tracking number {txnReceiptDetail.txnRefNumber} is unique
                and is valid only for this transaction.DO NOT PRECEDE the
                Tracking Number with any other comment.In case the Tracking
                number is missing or incorrectly provided in your transfer
                payment details, your funds may get rejected or processing may
                get delayed.{" "}
              </li>
              <li>
                Please ensure that you send exactly the same amount as confirmed
                in the Amount/Currency field above. This amount should be lower
                than or equal to your Net banking funds transfer limit (if any)
                as set-up for your Remitting Bank account.
              </li>
              <li>
                Once you initiate the money transfer from your local bank
                account to ICICI Bank Correspondent Bank account using your
                local bank’s Internet Banking facility, depending upon the
                electronic clearing used by your local bank to transfer the
                money and the associated clearing time, ICICI Bank will
                typically receive the funds within 1 working day.
              </li>
              <li>
                ICICI Bank will credit the funds into the receiver's ICICI Bank
                Account within 1 working day of ICICI Bank receiving the money.
              </li>
              <li>
                {" "}
                Timelines exclude banking holidays as well as Saturday and
                Sunday in the remitting country and in India. Please Click here
                to view the list of banking holidays in United Kingdom and in
                India.
              </li>
              <li>
                {" "}
                The INR amount disbursed to the beneficiary (as per your
                remittance request) will be net of the Conversion Service Tax.
              </li>
              <li>
                {" "}
                Service Tax on currency conversion is applicable slab-wise. This
                will be calculated based on the actual rate at which the funds
                are converted, as the Service tax is applicable on converted INR
                value. Click here to know the slab wise service tax
                structure.Read Less
              </li>
            </ul>
          </section>
          <ht />

          <section className="text-center">
            <p>
              Your tracking ID is <b>{txnReceiptDetail.txnRefNumber}</b>
            </p>
            <p>
              "You can use this ID to track your transaction once you have
              initiated a transfer at your local bank.",
            </p>
          </section>

          <section className="my-3 text-center">
            <button
              className="border-0 bg-none "
              onClick={onClickprintPDF}
              type="button"
            >
              {" "}
              <LocalPrintshopIcon className="mx-2" />
              View and Download
            </button>
            <span className="mx-4 fs-4">|</span>
            <button className="border-0 bg-none">
              {!isFav ? (
                <StarBorderIcon className="mx-2" onClick={onClickFavourite} />
              ) : (
                <StarIcon className="mx-2" onClick={onClickFavourite} />
              )}
              Add To Favourite
            </button>
          </section>
          <section className="text-center">
            <button
              className="btn my-4 "
              type="button"
              onClick={() =>
                props.setState({
                  isStep: 1,
                  promoValueWithDesc: "",
                  isSelectedBankTransfer: false,
                  _isScheduleTransaction: false,
                  sendAccId: "",
                  achAccId: "",
                  accountNo: "",
                })
              }
            >
              Make Another Transfer
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}

export default BankThankYou;
