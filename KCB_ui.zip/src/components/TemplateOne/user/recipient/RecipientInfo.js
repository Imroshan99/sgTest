import { Form, Input, Button, Modal, notification, Spin } from "antd";
import moment from "moment";

function RecipientInfo(props) {

  const recipientDetails = props.state.modalRecipientsDetails;
  return (
    <Modal
      centered
      title="Recipient Details"
      visible={props.state.isModalVisible}
      onCancel={() => props.setState({ isModalVisible: false })}
      footer={null}
    >
      <div className="row">
        <div className="col-md-6 mb-3">
        Account Number <br /> {recipientDetails.accountNo}
        </div>
        <div className="col-md-6 mb-3">
        Recipient's Bank Name <br /> {recipientDetails.bankName}
        </div>
      </div>
      <div className="row">
        <div className="col-md-6 mb-3">
        Full Name <br /> {recipientDetails.accountHolderName}
        </div>
        <div className="col-md-6 mb-3">
          City <br /> {recipientDetails.city}
        </div>
        <div className="col-md-6 mb-3">
        Nationality <br /> {recipientDetails.recvCountryName}
        </div>
      </div>
    </Modal>
  );
}

export default RecipientInfo;
