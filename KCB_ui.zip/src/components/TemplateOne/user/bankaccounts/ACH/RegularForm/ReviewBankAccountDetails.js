import React, { useState, useEffect, useReducer } from "react";

import { Row, Col, Button } from "react-bootstrap";
import { Form, Input, Tabs, Select, notification, Spin, Checkbox } from "antd";
import { Link, useNavigate } from "react-router-dom";
import { achBankAccountAPI } from "../../../../../../apis/achBankAccountAPI";
import { config } from "../../../../../../config";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../../../../helpers/makeHash";
import { Option } from "antd/lib/mentions";
import Swal from "sweetalert2";
import { PencilSquare } from "react-bootstrap-icons";
import TCModal from "../../../../../../containers/ModalBox/TCModal";
import useHttp from "../../../../../../hooks/useHttp";

export default function ReviewBankAccountDetails(props) {
  const AuthReducer = useSelector((state) => state);
  let navigate = useNavigate();
  const [loading, setLoader] = useState(false);
  const [form] = Form.useForm();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      tcModalVisible: false,
    }
  );

  const hookAddBankAccount = useHttp(
    achBankAccountAPI.addBankAccount
  );

  const handleTcModal = () => {
    setState({ tcModalVisible: true });
  };

  const onFinish = async (value) => {
    let formData = {
      requestType: "addACHAccount",     
      userId: AuthReducer.userID,
      routingNumber: props.state.routingNumber,
      nickname: props.state.nickName,
      accountHolder: props.state.userFullName,
      bankName: props.state.bankName,
      accountNo: props.state.accountNo,
      accountType: props.state.accountType,
      countryCode: AuthReducer.sendCountryCode,
      currencyCode: AuthReducer.sendCurrencyCode,
      processType: "DC",
    };

    hookAddBankAccount.sendRequest(formData, function (data) {
      if (data.status === "S") {
        notification.success({ message: data.message });
        if (props.state.redirectPage === "NEW_TRANSACTION") {
          navigate("/new-transaction", { state: props.state.redirectPageState });
        } else {
          navigate("/my-bank-accounts");
        }
        
      } else {
        notification.error({ message: data.errorMessage });
      }
    });   
  };

  return (
    <div>
      <Form form={form} onFinish={onFinish}>
        <Row className="justify-content-center">
          <Col md={6}>
            <div className="">
              <h5 className="mb-3">
                Basic Bank Details
                <a
                  href="#"
                  className="ms-auto text-2 text-uppercase btn-link"
                  onClick={() => props.setStep("STEP1")}
                >
                  <span className="me-1">
                    <PencilSquare />
                  </span>
                  Edit
                </a>
              </h5>
              <div className="mb-3">
                <label className="form-label">ABA Routing Number</label>
                <br />
                <strong>{props.state.routingNumber}</strong>
              </div>
              <div className="mb-3">
                <label className="form-label">Bank Name</label>
                <br />
                <strong>{props.state.bankName}</strong>
              </div>
              <div className="mb-3">
                <label className="form-label">Account Type</label>
                <br />
                <strong>{props.state.accountType ==='S' ? 'Saving' : 'Current / Checking'}</strong>
              </div>
            </div>
          </Col>
          <Col md={6}>
            <div className="">
              <h5 className="mb-3">
                My Account Details{" "}
                <a
                  href="#"
                  className="ms-auto text-2 text-uppercase btn-link"
                  onClick={() => props.setStep("STEP1")}
                >
                  <span className="me-1">
                    <PencilSquare />
                  </span>
                  Edit
                </a>
              </h5>
              <div className="mb-3">
                <label className="form-label">Account Number</label>
                <br />
                <strong>{props.state.accountNo}</strong>
              </div>
              {/* <div className="mb-3">
                <label className="form-label">Nick Name</label>
                <br />
                <strong>{props.state.nickName}</strong>
              </div> */}
            </div>
          </Col>

          <Col md={12}>
            <div className="">
              <Form.Item
                name="agreement"
                valuePropName="checked"
                rules={[
                  {
                    validator: (_, value) =>
                      value
                        ? Promise.resolve()
                        : Promise.reject(new Error("Should accept agreement")),
                  },
                ]}
              >
                <Checkbox>
                  I agree to the ACSS Authorization. (?){" "}
                  <a href="#" onClick={handleTcModal} >Terms &amp; Conditions</a>
                </Checkbox>
              </Form.Item>
            </div>
          </Col>

          <Col md={12}>
            <div className="d-flex justify-content-end">
              <Button
                onClick={(e) => {
                  props.setStep("STEP1");
                }}
                className="btn btn-secondary btn-sm me-3 my-3"
              >
                Back
              </Button>
              <button
                className="btn btn-primary text-white btn-sm my-3"
                type="submit"
                // onClick={() => setIsICICI(true)}
              >
                Add Account
              </button>
            </div>
          </Col>
        </Row>
      </Form>
      {state.tcModalVisible && <TCModal state={state} setState={setState} />}
    </div>
  );
}
