import React, { useState, useEffect, useReducer, Fragment } from "react";
import { Table, Spin } from "antd";
import { DeleteOutlined } from "@ant-design/icons";
import { Link, useNavigate } from "react-router-dom";

import moment from "moment";
import { config } from "../../../../../config";
import { useSelector } from "react-redux";
import DefaultLayout from "../../../layout/DefaultLayout";
import { encrypt, decrypt, publickey } from "../../../../../helpers/makeHash";
import ViewBankDetails from "./ViewBankDetails";
import Swal from "sweetalert2";
import { achBankAccountAPI } from "../../../../../apis/achBankAccountAPI";
import useHttp from "../../../../../hooks/useHttp";

function BankAccountList(props) {
  const AuthReducer = useSelector((state) => state);
  const [loading, setLoader] = useState(false);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      bankAccountList: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      isModalVisible: false,
      modalAccountDetails: {},
    }
  );

  const hookBankAccountList = useHttp(achBankAccountAPI.bankAccountList);
  const hookViewBankAccountDetails = useHttp(achBankAccountAPI.viewBankAccountDetails);
  const hookDeleteBankAccountDetails = useHttp(achBankAccountAPI.deleteBankAccountDetails);

  useEffect(async () => {
    accountsList();
  }, []);

  const accountsList = () => {
    if (props.appState.isLoggedIn) {
      const payload = {
        requestType: "SENDERACCOUNTLIST",       
        userId: state.userID,
        countryCode: AuthReducer.sendCountryCode,
        favouriteFlag: "1",
        startIndex: "0",
        recordsPerRequest: "50",
      };

      hookBankAccountList.sendRequest(payload, function (data) {
        if (data.status === "S") {
          let resData = [];
          data.responseData.forEach((detail, i) => {
            let data1 = {
              key: i,
              nickName: `${detail.nickName}`,
              aCHAccId: `${detail.aCHAccId}`,
              recordToken: `${detail.recordToken}`,
              bankName: `${detail.bankName}`,
              accountNo: `${detail.accountNo}`,
              routingNumber: `${detail.routingNumber}`,
              dateAdded: moment(detail.createdDate).format("MM-DD-YYYY"),
              status:
                detail.recordStatus.toUpperCase() === "R"
                  ? "Verified"
                  : "Pending",
            };
            console.log("resdatas", data1);
            resData.push(data1);
          });
          setState({
            bankAccountList: resData,
          });
        }
      });
    }
  };

  const viewDetailsHandlerClick = (row) => {
    setState({ isModalVisible: true });
    const payload = {
      requestType: "SENDERACCOUNT",     
      userId: state.userID,
      achAccId: row.aCHAccId,
      recordToken: row.recordToken,
    };

    hookViewBankAccountDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        console.log('modal dala', data)
        setState({
          modalAccountDetails: data,
        });
      }
    });
  };

  const deleteAccountHandler = (row) => {
    console.log(row);
    Swal.fire({
      text: "Are you sure you want to delete this bank account?",
      showCancelButton: true,
      denyButtonText: `Cancel`,
      confirmButtonText: "Confirm",
      confirmButtonColor: "#2dbe60",
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        // Swal.fire('Saved!', '', 'success')
        const payload = {
          requestType: "modfifyACHAccount",          
          userId: state.userID,
          achAccId: row.aCHAccId,
          recordToken: row.recordToken,
        };

        hookDeleteBankAccountDetails.sendRequest(payload, function (data) {
          if (data.status == "S") {
            accountsList();
          }
        });
      } else if (result.isDenied) {
        Swal.fire("Changes are not saved", "", "info");
      }
    });
  };
  console.log("modal", state.modalAccountDetails);

  return (
    <Fragment>
   
      <div className="p-2 inner_title_wrapper">
        <div className="container">
          <h2 className="mb-0 inner_title">
          My Bank Accounts
          </h2>
        </div>
      </div>
     
      <Spin spinning={loading} delay={100}>
        <DefaultLayout
          accessToken={props.appState.accessToken}
          isLoggedIn={props.appState.isLoggedIn}
          publicKey={props.appState.publicKey}
        >
          <div className="card p-4 mb-4">
            <div className="d-flex justify-content-end">
              <Link
                to={"/add-bank-account"}
                className="btn btn-primary text-white btn-sm mb-3"
              >
                Add Bank Account
              </Link>
            </div>
            {
              <Table
                columns={[
                  {
                    title: "Nick Name",
                    dataIndex: "nickName",
                  },
                  {
                    title: "Bank Name",
                    dataIndex: "bankName",
                  },
                  {
                    title: "Account No",
                    dataIndex: "accountNo",
                  },
                  {
                    title: "Bank Clearing Code",
                    dataIndex: "routingNumber",
                  },
                  {
                    title: "Date Added",
                    dataIndex: "dateAdded",
                  },
                  {
                    title: "Status",
                    dataIndex: "status",
                  },
                  {
                    title: "",
                    dataIndex: "",
                    key: "x",
                    render: (text, record, index) => {
                      //   console.log("Record : ", record)
                      return (
                        <a
                          i={index}
                          onClick={() => viewDetailsHandlerClick(text)}
                        >
                          View Details
                        </a>
                      );
                    },
                  },
                  {
                    title: "",
                    dataIndex: "",
                    key: "y",
                    render: (text, record, index) => {
                      return (
                        <DeleteOutlined
                          i={index}
                          onClick={() => deleteAccountHandler(text)}
                        />
                      );
                    },
                  },
                ]}
                dataSource={state.bankAccountList}
                pagination={false}
              />
            }
          </div>
        </DefaultLayout>
        <ViewBankDetails state={state} setState={setState} />
      </Spin>
    </Fragment>
  );
}

export default BankAccountList;
