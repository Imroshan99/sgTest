import React from 'react'
import ProfileThumb from '../../../assets/images/profile-thumb.jpg';
import Grid from '@mui/material/Grid';
import ForumRoundedIcon from '@mui/icons-material/ForumRounded';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import { ArrowRight, PencilSquare } from 'react-bootstrap-icons';

function LeftSidebar(props) {

    return (
        <>
            <div className="bg-white shadow-sm rounded text-center p-3 mb-4">
                <div className="profile-thumb mt-3 mb-4">
                    <img className="rounded-circle" src={ProfileThumb} alt="" />
                    {/* <div className="profile-thumb-edit bg-primary text-white">
                        <PencilSquare className="position-absolute" />
                        <input type="file" className="custom-file-input" id="customFile" />
                    </div> */}
                </div>
                <p className="text-3 fw-500 mb-2">Hello, {`${props.state.userFullName}`}</p>
                {/* <p className="mb-2"><a href="#!" className="text-5 text-light" data-bs-toggle="tooltip" data-bs-original-title="Edit Profile" aria-label="Edit Profile"><PencilSquare size={20} /></a></p> */}
            </div>

            <div className="bg-white shadow-sm rounded text-center p-3 mb-4">
                <div className="text-17 text-light my-3"><AccountBalanceWalletIcon style={{ fontSize: '60px' }} /></div>
                <h3 className="text-9 fw-400">$2956.00</h3>
                <p className="mb-2 text-muted opacity-8">Available Balance</p>
                <hr className="mx-n3" />
                <div className="d-flex">

                    <a href="#!" className="btn-link me-auto">Withdraw</a>
                    <a href="#!" className="btn-link ms-auto">Deposit</a></div>
            </div>
            {/* <div className="bg-white shadow-sm rounded text-center p-3 mb-4">
                            <div className="text-17 text-light my-3"><ForumRoundedIcon style={{ fontSize: '60px' }} /></div>
                            <h3 className="text-5 fw-400 my-4">Need Help?</h3>
                            <p className="text-muted opacity-8 mb-4">Have questions or concerns regrading your account?<br />
                                Our experts are here to help!.</p>
                            <div className="d-grid"><a href="#!" className="btn btn-primary">Chate with Us</a></div>
                        </div> */}
        </>
    )
}

export default LeftSidebar
