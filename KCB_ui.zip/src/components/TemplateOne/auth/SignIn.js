import React, { useState, useReducer, useEffect } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Container from "@mui/material/Container";
import { Link, useNavigate } from "react-router-dom";
import { Form, Input, notification, Spin, Menu, Dropdown, Button } from "antd";
import { AuthAPI } from "../../../apis/AuthAPI";
import ExchangeRate from "../../../containers/ExchangeRate";
import { config } from "../../../config";
import { connect, useSelector } from "react-redux";
import OTPBox from "../../../containers/OTPBox";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";
import { flags } from "../../../services/utility/flags";
import useHttp from "../../../hooks/useHttp";
// import { store } from "../../../store";

function SignIn(props) {
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);

  const signInFormConfig = ConfigReducer.groupIdSettings.signInForm;
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  let navigate = useNavigate();
  // console.log('store new', store.getState())

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: signInFormConfig.twoFA,
      sessionId: ConfigReducer.sessionId,
      otpType: "LG",
      _isShowOTPBOX: false,
      isModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      loginData: {},
      nextAction: "",
    }
  );

  const hookUserRiskProfile = useHttp(ProfileAPI.userRiskProfile);
  const hookSendOTP = useHttp(ProfileAPI.sendOTP);
  const hookLogin = useHttp(AuthAPI.login);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    form.setFieldsValue({ userpassword: "" });
    // userRiskProfile("")
  }, []);

  const onFinish = (value) => {
    const payload = {
      requestType: "LOGIN",
      loginId: value.loginId,
      password: value.userpassword,
      noofAttempts: "1",
      custType: "SEND",
      referer: "",
    };

    setLoader(true);
    hookLogin.sendRequest(payload, function (data) {
      if (data.status == "S") {
        if (state.twofa == "N") {
          storeLoginData(data);
          userRiskProfile(data);
        } else {
          setState({ loginData: data });
          userRiskProfile(data);
          sendOTP(data);
        }
      } else {
        notification.error({ message: data.errorMessage });
        setLoader(false);
        // notification.error({
        //   message:
        //     "Login Id or password not correct. Please enter valid credentials.",
        // });

        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
      setLoader(false);
    });
  };

  const userRiskProfile = (loginData) => {
    const userRiskProfilePayload = {
      requestType: "RISKPROFILE",
      userId: loginData.userId,
      ___token: loginData.token,
    };

    setLoader(true);
    hookUserRiskProfile.sendRequest(userRiskProfilePayload, function (data) {
      if (data.status == "S") {
        setState({ nextAction: data.nextAction });
      }
      setLoader(false);
    });
  };

  const sendOTP = (data) => {
    const OTPData = {
      requestType: "SENDOTP",
      otpType: state.otpType,
      userId: data.userId,
      otpOption: "SM",
    };

    setLoader(true);
    hookSendOTP.sendRequest(OTPData, function (data) {
      if (data.status == "S") {
        // notification.success({ message: decodeData.message })
        setState({
          verificationToken: data.verificationToken,
          _isShowOTPBOX: true,
          isModalVisible: true,
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
      setLoader(false);
    });
  };

  const storeLoginData = (loginData) => {
    notification.success({
      message: `WELCOME ${loginData.firstName} ${loginData.lastName}`,
    });
    props.saveUser(loginData, state.nextAction);
    props.manageAuth("logintoken", loginData);

    if (state.nextAction == "KYC_COMPLETE") {
      setTimeout(() => {
        navigate("/new-transaction");
      }, 500);
      // } else if (
      //   state.nextAction == "DOB" ||
      //   state.nextAction == "ADDRESS" ||
      //   state.nextAction == "REVIEW"
      // ) {
      //   setTimeout(() => {
      //     // navigate("/new-transaction");
      //     navigate("/profile-setup");
      //   }, 500);
      // } else if (state.nextAction == "JUMIO") {
      //   // setTimeout(() => { navigate('/profile-setup') }, 500);
      //   setTimeout(() => {
      //     navigate("/jumio-page");
      //   }, 500);
      // } else if (state.nextAction == "PROFILE_REVIEW") {
      //   setTimeout(() => {
      //     navigate("/profile");
      //   }, 500);
    } else {
      setTimeout(() => {
        navigate("/new-transaction");
      }, 500);
    }
  };

  const menu = (
    <Menu>
      {/* <Menu.Item>
        <Link to="/forgot-userid">Forgot User ID? </Link>
      </Menu.Item> */}
      <Menu.Item>
        <Link to="/forgot-password">Forgot Password?</Link>
      </Menu.Item>
      {/* <Menu.Item>
        <Link to="/unlock-userid">User ID locked?</Link>
      </Menu.Item> */}
      <Menu.Item>
        <Link to="/unlock-account">Unlock Account?</Link>
      </Menu.Item>
    </Menu>
  );

  return (
    <div className="d-flex w-100 h-100">
      <Container className="my-auto mx-auto py-5">
        {state._isShowOTPBOX && (
          <OTPBox
            state={state}
            setState={setState}
            storeLoginData={storeLoginData}
            otpType={state.otpType}
            useFor="login"
            appState={props.appState}
          />
        )}
        <Box>
          <Grid container spacing={2}>
            <Grid item md={6} lg={6} xl={6}>
              <div>
                <img
                  src={require("../../../assets/images/banners/remittence.png")}
                  width="100%"
                />
              </div>
              {/* <ExchangeRate /> */}
            </Grid>
            <Grid
              item
              xs={12}
              md={6}
              lg={6}
              xl={6}
              className="my-auto mx-auto pb-4 pb-lg-0"
            >
              {/* bg-light text-dark shadow-md rounded   */}
              <div className="card pt-4">
                <h3 className="fw-400 text-center">Log In</h3>
                <hr />
                <div className="p-3 pt-sm-4 pb-sm-5 px-sm-5">
                  <Form form={form} onFinish={onFinish} autoComplete="off">
                    <div className="mb-3">
                      <label className="form-label">Email address</label>
                      <Form.Item
                        className="form-item"
                        name="loginId"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Email ID.",
                          },
                          {
                            type: "email",
                            message: "Please input valid Email ID.",
                          },
                        ]}
                      >
                        <Input
                          size="large"
                          placeholder="Enter your Email ID"
                          autoComplete="off"
                          onPaste={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCopy={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCut={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                        />
                      </Form.Item>
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Password</label>
                      <Form.Item
                        className="form-item"
                        name="userpassword"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Password.",
                          },
                        ]}
                      >
                        <Input.Password
                          size="large"
                          placeholder="Enter password"
                          onPaste={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCopy={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                          onCut={(e) => {
                            e.preventDefault();
                            return false;
                          }}
                        />
                      </Form.Item>
                    </div>
                    <div className="d-grid">
                      {/* <Link className="btn-link mb-2" to={'./signup'}>Trouble Logging In?</Link> */}
                      <Dropdown
                        overlay={menu}
                        trigger={["click"]}
                        placement="bottomLeft"
                        arrow
                      >
                        <p role="button" className="btn-link mb-2">
                          Trouble Logging In?
                        </p>
                      </Dropdown>
                      {/* <Link className="btn-link" to={"./signup"}>
                        Login using NRI Registered Email ID with ICICI Bank
                      </Link> */}
                    </div>
                    <div className="my-4"></div>
                    <Spin spinning={loading} delay={500}>
                      <div className="d-grid g-2">
                        <button
                          className="btn btn-primary text-white my-1"
                          type="submit"
                        >
                          Login
                        </button>
                      </div>
                    </Spin>
                    <div className="d-grid g-2">
                      <Link className="btn btn btn-secondary my-1" to={"/"}>
                        Cancel
                      </Link>
                    </div>
                  </Form>
                </div>
              </div>
            </Grid>
          </Grid>
        </Box>
      </Container>
    </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    saveUser: (data, nextAction) => {
      // dispatch({ type: 'SET_USER_TOKEN', payload: data.token })
      dispatch({ type: "SET_USER_LAST_LOGIN", payload: data.lastLoginTimeIST });
      dispatch({ type: "SET_USER_ID", payload: data.userId });
      dispatch({ type: "SET_USER_KYC", payload: nextAction });
      dispatch({
        type: "SET_USER_FULL_NAME",
        payload: data.firstName + " " + data.lastName,
      });
      dispatch({ type: "SET_USER_LOGIN", payload: true });
    },
  };
};

export default connect(null, mapDispatchToProps)(SignIn);
