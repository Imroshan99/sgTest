export default function FAQ() {
  return (
    <div className="bg_gradient container mt-md-5 mt-sm-4">
      <div className="T3_container pb-5">
        <h4 className="title mb-3">KCB Mint - Frequently Asked Questions</h4>
        <p>
          <strong>1. What is KCB Mint?</strong>
        </p>
        <p>
          KCB Mint is an online money transfer solution offered by KCB which
          enables Customers in the Diaspora &nbsp;send money to any bank account
          or mobile wallet in Kenya (Need to add other KCB markets). Client can
          receive funds to their accounts in all the major currencies and to
          mobile wallets in KES.
        </p>
        <p>
          <strong>2. Who can use KCB Mint?</strong>
        </p>
        <p>
          KCB Mint can be used by any customer in the diaspora who wants to send
          money from his/ her bank account or card in US, and Canada. to a
          beneficiary&rsquo;s bank account or mobile wallet in Kenya (add other
          KCB markets). The remitter can also send money to his/ her own Account
          in Kenya.
        </p>
        <p>
          <strong>
            3. Do I need to be a KCB customer to use the KCB Mint service?
          </strong>
        </p>
        <p>
          The KCB Mint service can be availed to any individual (at least 18
          years of age) for personal &nbsp;&nbsp;&nbsp;money transfer needs in
          receiving markets, from the serviceable countries. Neither the sender
          nor the Beneficiary needs to be a KCB customer to access the service.
        </p>
        <p>
          <strong>4. Why should I trust KCB Mint?</strong>
        </p>
        <p>KCB Mint is a service provided by KCB.</p>
        <p>
          KCB is a regulated entity by the Central Bank of Kenya and has a rich
          history having been established by the Government of Kenya in 1968 and
          is a subsidiary of the KCB Group which is the largest bank in East
          Africa.
        </p>
        <p>
          <strong>5. Is KCB Mint safe?</strong>
        </p>
        <p>
          When you pay through KCB Mint, the money is transferred through
          Electronic Clearing System (ECS) in your sending country to the
          designated account held and operated by KCB. Thus, the money always
          moves within the banking system. All transactions and information
          exchanges happen on fully secure encrypted lines and your data is
          stored on servers that are protected by advanced firewalls which have
          undergone extensive security tests.
        </p>
        <p>
          <strong>
            6. How do I start using the service? What details are needed at the
            time of registration on KCB Mint?
          </strong>
        </p>
        <p>
          Go to the KCB Website , click on the Mint / Remittance option on the
          Menu bar.
        </p>
        <p>
          You can register on KCB Mint by providing your personal details like
          Name, Date of birth, Gender and your mobile number and then continue
          by choosing a unique Login Id and a password.
        </p>
        <p>
          <strong>7. How do I transfer money using KCB Mint?</strong>
        </p>
        <p>
          Follow the below steps to send money to your loved ones using the
          transfer option available on KCB Mint
        </p>
        <ol style={{ listStyleType: "lower-alpha" }}>
          <li>Login to KCB Mint.</li>
          <li>Add a new Beneficiary or select an existing Beneficiary.</li>
          <li>
            Add sending amount, select the Purpose of remittance and click.
          </li>
          <li>
            After submitting the request, you will receive a Transaction
            reference number and account details to which you need to send.
          </li>
          <li>
            Now, login to your overseas Bank&rsquo;s online banking account.
          </li>
          <li>
            Initiate a fund transfer for the same amount (as you have booked on
            KCB Mint) to the account mentioned in payment details.
          </li>
          <li>
            Input the Transaction reference number in the free text field/
            description field.
          </li>
          <li>
            &nbsp;We will credit the Beneficiary&rsquo;s account or mobile
            wallet in Kenya as per your instructions on KCB Mint.
          </li>
        </ol>
        <p>
          <strong>
            8. Can I transfer money from my friends or relatives overseas
            account?
          </strong>
        </p>
        <p>
          No, the overseas account from which the transfer is initiated should
          belong to the registered user of KCB Mint. Only those transactions
          will be processed where the name is reflecting in the KCB Mint account
          matches with the account holder&rsquo;s name in the Bank account from
          where the money transfer is made.
        </p>
        <p>
          <strong>
            9. How much time will it take for my Beneficiary to receive money?
          </strong>
        </p>
        <p>
          Your beneficiary will receive the money into his/ her bank account in
          Kenya, Tanzania, South Sudan, Uganda, Rwanda, Burundi and Ethiopia
          within the same working day from the time you initiate a fund transfer
          from your overseas bank account.
        </p>
        <p>
          <strong>
            10. What are the options available for Beneficiary to receive money
            in Kenya?
          </strong>
        </p>
        <p>The options available to your Beneficiary to receive money are:</p>
        <ul>
          <li>
            KCB account credit &ndash; You can send money to your
            beneficiaries&rsquo; account with KCB,
          </li>
          <li>Credit to any other account in Kenya.</li>
          <li>Credit to mobile wallet (MPESA)</li>
        </ul>
        <p>
          <strong>
            11. How do I know that money has reached my Beneficiary?
          </strong>
        </p>
        <p>
          You will get an email when we process the funds on our end. You can
          also track the status on &lsquo;Transaction History&rsquo; section on
          KCB
        </p>
        <p>
          <strong>
            12. What is the exchange rate applied to my transaction?
          </strong>
        </p>
        <p>
          The exchange rate that is applied to your transaction is the rate
          which is applicable on the day of sending the remittance.
        </p>
        <p>
          <strong>13. What is Indicative exchange rate?</strong>
        </p>
        <p>
          The rate which is displayed in the exchange rate table and on the
          transaction booking page is an indicative rate which helps you in
          arriving at an approximate Kenya Shilling value of your transfer.
        </p>
        <p>
          <strong>
            14. Which currencies can you use to make a KCB Mint remittance?
          </strong>
        </p>
        <p>
          The currency applicable in the remitting country or corridor.&nbsp;
        </p>
        <p>
          <strong>15. Who can you send money to using KCB Mint?</strong>
        </p>
        <p>Anyone with a valid account or mobile wallet.</p>
        <p>
          <strong>
            16. Do you or your beneficiary need to open any special bank
            account?
          </strong>
        </p>
        <p>No, you simply sign up on the KCB Mint platform.</p>
        <p>
          <strong>17. What if I forget my Login Id?</strong>
        </p>
        <p>
          Please follow prompts for &ldquo;forgot password or username&rdquo; to
          reset your credentials
        </p>
        <p>
          <strong>18. What if I forget my Login Id?</strong>
        </p>
        <p>
          Please write an email to
          <a href="mailto:info@ke.kcbgroup.com"> info@ke.kcbgroup.com </a>
          in case you forget the Login Id, the team would assist for the same.
        </p>
      </div>
    </div>
  );
}
