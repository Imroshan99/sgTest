import React from "react";
import { Link } from "react-router-dom";

function PageNotFound() {
  return (
    <div className="bg_gradient container">
      <section className="section T3_container">
        <div className="text-center">
          <h2 className="text-25 mb-0">404</h2>
          <h3 className="text-6 mb-3">
            oops! The page you requested was not found!
          </h3>
          <p className="text-3 text-muted">
            The page you are looking for was moved, removed, renamed or might
            never existed.
          </p>
          <Link
            to={"/"}
            className="btn btn-primary text-light shadow-none px-5 m-2"
          >
            Home
          </Link>
          <Link
            to={"/signin"}
            className="btn btn-outline-dark shadow-none px-5 m-2"
          >
            Back
          </Link>
        </div>
      </section>
    </div>
  );
}

export default PageNotFound;
