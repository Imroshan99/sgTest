import React from "react";
import { useSelector } from "react-redux";
// import HomeXr from "./XR"
// import HomeKcb from "./KCB"

const HomeKcb = React.lazy(() => import("./KCB"));

const HomePage = () => {
  const AuthReducer = useSelector((state) => state);
  switch (AuthReducer.groupId) {
    case "KCB":
      return <HomeKcb />;

    default:
      break;
  }
};

export default HomePage;
