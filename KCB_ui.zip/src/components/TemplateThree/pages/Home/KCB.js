import React, { useEffect, useReducer, useState } from "react";
import { Input, Select, Spin } from "antd";

import USDLogo from "../../../../assets/images/svg/usd.svg";
import KESLogo from "../../../../assets/images/svg/kes.svg";
import svgText from "../../../../assets/images/KCB/home-text.svg";
import svgTextM from "../../../../assets/images/svg/mob-landing-text.svg";
import { useSelector } from "react-redux";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { notification } from "antd";
import { useNavigate } from "react-router-dom";
import useHttp from "../../../../hooks/useHttp";
import { Option } from "antd/lib/mentions";
import bulb from "../../../../assets/images/svg/landing-text.svg";
import arrow from "../../../../assets/images/svg/arrow.svg";

const HomeKcb = (props) => {
  let navigate = useNavigate();

  const ConfigReducer = useSelector((state) => state);
  const AuthReducer = useSelector((state) => state);

  const defaultSettings = ConfigReducer.groupIdSettings.default;
  // console.log(defaultSettings)
  // const { isLoading, apiData, serverError, sendRequest } = useHttp(GuestAPI.getNationality);
  // const getNationality = useHttp(GuestAPI.getNationality);
  // const occupationLists = useHttp(GuestAPI.occupationLists);

  const [value, setValue] = React.useState("1");
  const [loading, setLoader] = React.useState(false);
  const [timeoutId, setTimeoutId] = React.useState("");
  const [amount, setAmount] = useState({
    totalSendAmount: 0,
    sendAmount: 1000,
    recvAmount: 0,
    amountPayable: 0
   
    // sendAmountError: "",
    // recvAmountError: "",
  });

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: ConfigReducer.twofa,
      sessionId: ConfigReducer.sessionId,
      // sendAmount: 1000,
      // recvAmount: 0,
      // enteredAmount: 0,
      // netRecvAmount: 0,
      totalFee: 0,
      exRate: 0,
    }
  );

  const hookPostExchangeRate = useHttp(GuestAPI.postExchangeRate);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  useEffect(() => {
    loadExhangeRateHandler(1000, AuthReducer.sendCurrencyCode);
    // getNationality.sendRequest();
    // occupationLists.sendRequest()
    // sendRequest(GuestAPI.occupationLists)

    // sendRequest()
    // console.log(AuthReducer.groupIdSettings);
    // console.log(AuthReducer.groupIdSettings.signUpForm.formType);
  }, []);
  // useEffect(() => {
  //   const timeOutId = setTimeout(() => loadExhangeRateHandler(), 500);
  //   return () => clearTimeout(timeOutId);
  // }, [state.sendAmount]);
  // console.log("data", getNationality.apiData);
  // useEffect(() => {
  //     loadExhangeRateHandler()
  // }, [state.sendAmount])

  const loadExhangeRateHandler = (valueSendAmount, __currency) => {
    let payload = {
      requestType: "EXCHANGERATE",
      pageName: "PRELOGIN",
      amount: valueSendAmount,
      recvNickName: "NEWRECV_SB",
      recvModeCode: "DC",
      // sendModeCode: "ACH",
      sendModeCode: defaultSettings.sendModeCode,
      programCode: defaultSettings.programCode,
      paymentMode1: "",
      paymentMode2: "",
      promoCode: "",
      loyaltyPoints: "",
      recvCountryCode: AuthReducer.recvCountryCode,
      recvCurrencyCode: AuthReducer.recvCurrencyCode,
      sendCountryCode: AuthReducer.sendCountryCode,
      sendCurrencyCode: AuthReducer.sendCurrencyCode,
      // enteredAmtCurrency: "GBP",
      enteredAmtCurrency: __currency,
    };
    setLoader(true)
    hookPostExchangeRate.sendRequest(payload, function (data) {
      setLoader(false)
      if (data.status == "S") {
        setAmount({
          ...amount,
          sendAmount: __currency === 'USD' ?  data.enteredAmount : data.sendAmount,
          // sendAmount: data.enteredAmount,
          recvAmount: data.recvAmount,
          amountPayable: data.amountPayable,
          totalSendAmount: data.sendAmount,
        });
        setState({
          // sendAmount: data.sendAmount,
          // recvAmount: data.recvAmount,

          totalFee: data.totalFee,
          exRate: data.exRate,
        });
      } else {
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });
        } else {
          notification.error({ message: data.errorMessage });
        }
        setAmount({
          ...amount,
          recvAmount: 0,
        });
        setState({
          totalFee: 0,
          exRate: 0,
        });
      }
    });
  };

  const sendAmountHandler = (e, __currency) => {
    // setState({ sendAmount: e.target.value })
    setAmount({
      ...amount,
      sendAmount: e.target.value.replace(/[^0-9]/g, ""),
      // recvAmount: e.target.value,
    });
    clearTimeout(timeoutId);
    const valueSendAmount = e.target.value;
    let valueTimeOutId = setTimeout(
      () => loadExhangeRateHandler(valueSendAmount, __currency),
      500
    );
    setTimeoutId(valueTimeOutId);
  };

  const recvAmountHandler = (e) => {
    setAmount({
      ...amount,
      // sendAmount: e.target.value,
      recvAmount: e.target.value,
    });
    clearTimeout(timeoutId);
    const valueSendAmount = e.target.value;
    let valueTimeOutId = setTimeout(
      () => loadExhangeRateHandler(valueSendAmount, "KES"),
      500
    );
    setTimeoutId(valueTimeOutId);
  };

  return (
    <div className="LandingPage bg_gradient py-0 py-md-5">
      <div className="LandingPage-Container T3_container">
        <p className="small-p">Processed by Golden Money Transfer, Inc.</p>
        <img
          className="mb-3 landing-img-1"
          src={svgText}
          alt="Send Money  where it matters!"
        />
        <img
          className="mb-3 landing-img-2"
          src={svgTextM}
          alt="Send Money  where it matters!"
        />
        <h6 className="landing-img-1">Convenient, Safe, Accessible</h6>
        <h4 className="landing-img-2 title mb-3">Send Money</h4>
        <div className="LandingPage-Input-Container">
          <Spin spinning={loading} >
          <div className="Input-Group-Container mb-3">
            <div className="label1" style={{ width: "100%" }}>
              <label>Select Currency</label>
            </div>
            <div className="Inp-Con">
              <label className="label2">Select Currency</label>
              <Select style={{ border: 0 }} defaultValue="usd">
                <Option value="usd">
                  <img src={USDLogo} alt="USD Logo"></img>
                </Option>
              </Select>
            </div>
            <div className="label1" style={{ width: "100%" }}>
              <label>Sending Amount</label>
            </div>
            <div className="Inp-Con">
              <label className="label2">Sending Amount</label>
              <Input
                className="LandingInput"
                defaultValue={amount.sendAmount}
                value={amount.sendAmount}
                onChange={(e) =>
                  sendAmountHandler(e, AuthReducer.sendCurrencyCode)
                }
              />
            </div>
          </div>

          <div className="Input-Group-Container">
            <div className="label1" style={{ width: "100%" }}>
              <label>Select Currency</label>
            </div>
            <div className="Inp-Con">
              <label className="label2">Select Currency</label>
              <Select style={{ border: 0 }} defaultValue="usd">
                <Option value="usd">
                  <img src={KESLogo} alt="KES Logo"></img>
                </Option>
              </Select>
            </div>
            <div className="label1" style={{ width: "100%" }}>
              <label>Receiving Amount</label>
            </div>
            <div className="Inp-Con">
              <label className="label2">Receiving Amount</label>
              <Input
                className="LandingInput"
                value={amount.recvAmount}
                onChange={(e) => recvAmountHandler(e)}
              />
            </div>
          </div>
          </Spin>

          <div>
            <div className=" my-2 text-muted">
              <p className="small-p me-2 mb-0">
                Total fees -{" "}
                {`${state.totalFee} ${AuthReducer.sendCurrencyCode}`}
                <br />
                Amount Payable -{" "}
                {`${amount.amountPayable} ${AuthReducer.sendCurrencyCode}`}
                <br />
                Total Send Amount -{" "}
                {`${amount.totalSendAmount} ${AuthReducer.sendCurrencyCode}`}
              </p>
              <p className=" small-p mt-0 me-2 mb-0">
                The current exchange rate is 1 {AuthReducer.sendCurrencyCode} ={" "}
                {`${state.exRate} ${AuthReducer.recvCurrencyCode}`}
              </p>
            </div>
          </div>

          <div className="get-started-button-container">
            <div className="d-grid g-2 mb-3">
              <div
                onClick={() => navigate("signin")}
                className="d-flex justify-content-between btn text-white btn-sec1 my-1 mt-3"
              >
                <img style={{ visibility: "hidden" }} src={arrow}></img>
                Get Started
                <img src={arrow}></img>
              </div>
            </div>
          </div>
          <div className="landing-info-text ">
            <p className="small-p m-0">Easy Transfer to Kenyan Accounts</p>
            <ul>
              <li className="under-p-li">
                Directly Transfer to Mpesa & Airtel Money
              </li>
              <li className="under-p-li">
                Directly Transfer to local bank accounts
              </li>
              <li className="under-p-li">
                Directly Transfer to local cash agents
              </li>
            </ul>
            <img
              className=" mb-3 mt-3"
              style={{ marginTop: "20px" }}
              src={bulb}
              alt="Protect yourself from fraud"
            ></img>
          </div>
        </div>
      </div>
    </div>
  );
};
export default HomeKcb;
