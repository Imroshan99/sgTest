import React, { useState, useReducer, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Form, Input, notification, Spin } from "antd";
import { config } from "../../../config";
import { AuthAPI } from "../../../apis/AuthAPI";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";
import useHttp from "../../../hooks/useHttp";

function SetNewPassword(props) {
  const ConfigReducer = useSelector((state) => state);
  let navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: ConfigReducer.twofa,
      sessionId: ConfigReducer.sessionId,
    }
  );

  const hookResetPassword = useHttp(AuthAPI.resetPassword);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    // alert(props.state.activeTab)
  }, []);

  const saveSignUpData = (value) => {
    form.setFields([{ name: "password", errors: [] }]);
    const resetPasswordPayload = {
      requestType: "RESETPASSWORD",
      password: value.password,
      verifyType: "O",
      verifiedToken: props.state.verifiedToken,
    };

    setLoader(true);
    hookResetPassword.sendRequest(resetPasswordPayload, function (data) {
      if (data.status == "S") {
        notification.success({ message: data.message });
        navigate("/signin");
      } else {
        setLoader(false);
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          if (error.field != "password") {
            notification.error({ message: error.error });
          }
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  return (
    <div className="card pt-4">
     
      <div className="p-3 pt-sm-4 pb-sm-5 px-sm-5">
      <h4 className="title">Set New password</h4>
      
      <hr />
        <Form form={form} onFinish={saveSignUpData}>
          <div className="mb-3">
            <label htmlFor="exampleFormControlInput1" className="form-label">
              Enter New Password
            </label>
            <Form.Item
              className="form-item"
              name="password"
              rules={[
                { required: true, message: "Please input your Password." },
                {
                  min: 10,
                  max: 20,
                  message:
                    "Password should be between 10 and 20 characters long.",
                },
              ]}
            >
              <Input.Password size="large" placeholder="Enter your Password" visibilityToggle={false} />
            </Form.Item>
          </div>
          <div className="mb-3">
            <label htmlFor="exampleFormControlInput1" className="form-label">
              Confirm New Password
            </label>
            <Form.Item
              className="form-item"
              name="confirmPassword"
              rules={[
                {
                  required: true,
                  message: "Please input your Confirm Password.",
                },
                ({ getFieldValue }) => ({
                  validator(rule, value) {
                    if (!value || getFieldValue("password") === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(
                      "The two password that you entered do not match!"
                    );
                  },
                }),
              ]}
            >
              <Input.Password
                size="large"
                placeholder="Enter your Confirm Password"
              />
            </Form.Item>
          </div>
          <div className="my-4"></div>
          <Spin spinning={loading} delay={500}>
            <div className="d-grid g-2">
              <button className="btn btn-primary text-white my-1" type="submit">
                Submit
              </button>
            </div>
          </Spin>
          {/* <div className="d-grid g-2">
            <button
              className="btn btn btn-secondary my-1"
              type="button"
              onClick={() =>
                props.setState({
                  _isShowOTPBOX: false,
                  _isShowSetPassword: false,
                })
              }
            >
              Back
            </button>
          </div> */}
        </Form>
      </div>
    </div>
  );
}

export default SetNewPassword;
