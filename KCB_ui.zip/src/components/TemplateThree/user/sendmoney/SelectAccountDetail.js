import React, { useEffect, useState } from "react";
import { Form, Select, Row, Col, Space, Radio, Spin } from "antd";
import { Link, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import arrow from "../../../../assets/images/svg/arrow.svg";

const { Option } = Select;

export default function SelectAccountDetail(props) {
  const AuthReducer = useSelector((state) => state);
  const [form1] = Form.useForm();
  const location = useLocation();

  useEffect(() => {
    form1.setFieldsValue({
      recipient: props.state.receiverName,
      isBankTransfer: props.state.isSelectedBankTransfer ? "Bank Transfer" : "",
      sourceAccount: props.state.senderName,
    });

    console.log("data=>", props.state.isSelectedBankTransfer);
  }, []);
  useEffect(() => {
    if (location?.state?.fromPage === "RECIPIENT_REQUEST_LIST") {
      const recData = props.state.receiverLists.filter((i) => {
        return i.nickName.toLowerCase() === location.state.newNickName.toLowerCase();
      });
      props.setState({sendAmount:location.state.sendAmount});
      form1.setFieldsValue({
        recipient: `${recData[0]?.firstName} ${recData[0]?.lastName} ${recData[0]?.accountNo} ${recData[0]?.bankName}`,
      });
      
      props.setState({
        receiverName: `${recData[0]?.firstName} ${recData[0]?.lastName}`,
        receiverAccount: recData[0]?.unmaskedAccountNo,
        nickName: recData[0]?.nickName,
      });
    }
  }, [props.state.receiverLists]);

  const handleChangeRecipent = (rec) => {
    let recipent = JSON.parse(rec);
    props.setState({
      receiverName: `${recipent.firstName} ${recipent.lastName}`,
      receiverAccount: recipent.accountNo,
      nickName: recipent.nickName,
    });
  };

  const handleChangeBankAccount = (acc) => {
    let account = JSON.parse(acc);
    console.log("account", account);
    props.setState({
      sendAccId: props.state.groupId == "KCB" ? "" : account.sendAccId,
      achAccId: props.state.groupId == "KCB" ? account.aCHAccId : "",
      accountNo: account.accountNo,
      senderName: account.accountHolderName,
    });
    // ${rec.firstName} ${rec.lastName} ${rec.accountNo}
  };

  const onFinishAccount = (value) => {
    props.setState({ isStep: 3 });
    props.getPurposeLists();
  };

  return (
    <div className="select-account-container mt-md-5 mt-sm-5">
      <Spin spinning={props.state.spin1}>
        <h4 className="title mb-3">Send Money</h4>
        <Form form={form1} onFinish={onFinishAccount}>
          <div className="select-container">
            <div className="d-flex flex-column">
              <label className="form-label">Select Recipient</label>
              <Form.Item className="form-item" name="recipient" rules={[{ required: true, message: "Please select your recipient." }]}>
                <Select className="w-100" onChange={handleChangeRecipent} placeholder="Select Recipient">
                  {props.state.receiverLists.map((rec, i) => {
                    return <Option key={i} value={JSON.stringify(rec)}>{`${rec.firstName} ${rec.lastName} ${rec.accountNo} (${rec.bankName})`}</Option>;
                  })}
                </Select>
              </Form.Item>
            </div>
            <Link
              style={{
                height: "45.59px",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                marginTop: "2rem",
              }}
              to={{
                pathname: "/add-recipient",
              }}
              state={{
                fromPage: "NEW_TRANSACTION",
                fromPageState: {
                  sendAmount: props.state.sendAmount,
                  activeStep: 2,
                },
              }}
              className="btn btn-secondary mb-5 mb-md-0 text-white btn-sm"
            >
              Add New Recipient
            </Link>
          </div>

          <div style={{ width: "70%" }}>
            <Form.Item
              className="form-item"
              name="isBankTransfer"
              rules={[
                {
                  required: true,
                  message: "Please select your Bank Transfer.",
                },
              ]}
            >
              <Radio.Group>
                <Space direction="Horizontaly">
                  <Radio
                    value={"Bank Transfer"}
                    onClick={() => {
                      props.setState({ isSelectedBankTransfer: true });
                    }}
                  >
                    Bank Transfer
                  </Radio>
                </Space>
              </Radio.Group>
            </Form.Item>
          </div>

          {props.state.isSelectedBankTransfer && (
            <div className="select-container">
              <div className="mb-4 mb-md-0">
                <Form.Item
                  className="form-item"
                  name="sourceAccount"
                  rules={[
                    {
                      required: true,
                      message: "Please select your source account.",
                    },
                  ]}
                >
                  <Select onChange={handleChangeBankAccount} placeholder="Select Source Account">
                    {props.state.bankAccountLists.map((acc, i) => {
                      return <Option key={i} value={JSON.stringify(acc)}>{`${acc.accountHolderName} ${acc.accountNo}`}</Option>;
                    })}
                  </Select>
                </Form.Item>
              </div>
              <div>
                <Link
                  style={{
                    height: "45.59px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  to={{
                    pathname: "/add-bank-account",
                  }}
                  state={{
                    fromPage: "NEW_TRANSACTION",
                    fromPageState: {
                      sendAmount: props.state.sendAmount,
                      activeStep: 2,
                    },
                  }}
                  className="btn btn-secondary text-white btn-sm "
                >
                  Add New Bank Account
                </Link>
              </div>
            </div>
          )}
          <p className="mt-3">
            Please Note: There is transfer fee of {props.state.totalFee} {AuthReducer.sendCurrencyCode} applied on this transaction {props.state.isSelectedBankTransfer}
          </p>
          <div className="d-flex my-2">
            <button htmlType="submit" className="cont-button">
              <img style={{ visibility: "hidden" }} src={arrow}></img>
              Continue
              <img src={arrow}></img>
            </button>
            {/* <button
              className="btn btn-primary text-white btn-sm px-5"
              onClick={() => props.setState({ isStep: 1 })}
            >
              Back
            </button>
            <button
              htmlType="submit"
              className="btn btn-primary text-white btn-sm px-5 mx-4"
            >
              Proceed
            </button> */}
          </div>
        </Form>
      </Spin>
    </div>
  );
}
