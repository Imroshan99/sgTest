import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form,  Tabs, Select,  Spin } from "antd";
import {  useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import AddBankAccountStep1 from "./AddBankAccountStep1";
import AddBankAccountStep2 from "./AddBankAccountStep2";
import ReviewBankAccountDetails from "./ReviewBankAccountDetails";

const { TabPane } = Tabs;
const { Option } = Select;

export default function AddBankAccount(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  // console.log(AuthReducer);
  const [loading, setLoader] = useState(false);
  const [activeStep, setActiveStep] = useState("STEP1");
  const [isICICI, setIsICICI] = useState(true);
  let navigate = useNavigate();
  let location = useLocation();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      userFullName: AuthReducer.userFullName,
      bankName: null,
      accountNo: null,
      confirmAccountNo: null,
      accountType: null,
      nickName: null,
      routingNumber: null,
      processType: null,

      redirectPage: "",
      redirectPageState: [],
      
    }
  );

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    setState({
      redirectPage: location.state.fromPage,
      redirectPageState: location.state.fromPageState,
    });
  }, []);


  const handleSetSteps = (stepValue) => {
    setActiveStep(stepValue);
  };

  return (
    <div>
      <div className="p-2 inner_title_wrapper">
        <div className="container">
          <h2 className="mb-0 inner_title">
          {!state.showConfirmBankAccountDetails
            ? "Add Bank Account"
            : "My Bank Account Review"}
          </h2>
        </div>
      </div>
      
        <Spin spinning={loading} delay={500}>
          {!state.showConfirmBankAccountDetails && (
            <Row className="justify-content-center ">
              <Col lg={8} md={10}>
                <div className="card p-3 mb-4">
                  {activeStep === "STEP1" && (
                    <AddBankAccountStep1
                      accessToken={props.appState.accessToken}
                      isLoggedIn={props.appState.isLoggedIn}
                      publicKey={props.appState.publicKey}
                      setStep={handleSetSteps}
                      setState={setState}
                      state={state}
                    />
                  )}
                  {activeStep === "STEP2" && (
                    <AddBankAccountStep2
                      accessToken={props.appState.accessToken}
                      isLoggedIn={props.appState.isLoggedIn}
                      publicKey={props.appState.publicKey}
                      setStep={handleSetSteps}
                      setState={setState}
                      state={state}
                    />
                  )}
                  {activeStep === "REVIEW" && (
                    <ReviewBankAccountDetails
                      accessToken={props.appState.accessToken}
                      isLoggedIn={props.appState.isLoggedIn}
                      publicKey={props.appState.publicKey}
                      setStep={handleSetSteps}
                      setState={setState}
                      state={state}
                    />
                  )}
                </div>
              </Col>
            </Row>
          )}
        </Spin>
    </div>
  );
}
