import React from "react";
import SubHeader from "../layout/SubHeader";
import RegulationsPage from "../../../pages/Regulations";
import { Footer } from "../../../pages/LandingPage/XR";

const Rgulations = (props) => {
  return (
    <React.Fragment>
      <SubHeader title="Regulations" />
      <div className="template2__main py-5">
        <div className="sendmoney__page">
          <div className="container">
            <RegulationsPage />
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
};

export default Rgulations;
