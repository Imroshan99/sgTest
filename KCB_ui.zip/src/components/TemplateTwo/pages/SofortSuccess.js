import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import SubHeader from "../layout/SubHeader";

export default function SofortSuccess() {
  const [searchParams, setSearchParams] = useSearchParams();
  const transId = searchParams.get("transId");
  console.log("transId", transId);
  useEffect(() => {
    window.localStorage.setItem(transId, "SUCCESS");
    window.close("", "_parent", "");
  }, []);

  const onClickWindowCloseHandler = () => {
    window.close("", "_parent", "");
    // var newWindow = window.open();
    // setTimeout(() => {
    // newWindow.location = "https://www.google.com";
    //   window.open("https://www.google.com")
    // }, 2000);
  };
  return (
    <div>
      <SubHeader title="Transaction Successful. Thank you" />
      <div className="text-center">
        <button
          className="btn btn-primary text-light mt-5"
          onClick={onClickWindowCloseHandler}
        >
          close window
        </button>
      </div>
    </div>
  );
}
