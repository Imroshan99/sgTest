import React, { useEffect, useState } from "react";
import { Form, Input, Radio, Checkbox, notification, Spin, Select } from "antd";
import moment from "moment";
import { AuthAPI } from "../../../apis/AuthAPI";
import useHttp from "../../../hooks/useHttp";
const { Option } = Select;

export default function SignUpStep1(props) {
  const hookcheckLoginId = useHttp(AuthAPI.checkLoginId);

  const [form] = Form.useForm();
  const [loader, setLoader] = useState(false);
  const [otherSourceReg, setOtherSourceReg] = useState(false);
  const [yearstate, setYearState] = useState([]);
  const [dayState, SetDayState] = useState([]);
  const [dataForm, setDataForm] = useState({
    name: "",
    email: "",
    dob: "",
    gender: "",
  });
  let monthNameList = [
    { monthCode: "01", month: "January" },
    { monthCode: "02", month: "February" },
    { monthCode: "03", month: "March" },
    { monthCode: "04", month: "April" },
    { monthCode: "05", month: "May" },
    { monthCode: "06", month: "June" },
    { monthCode: "07", month: "July" },
    { monthCode: "08", month: "August" },
    { monthCode: "09", month: "September" },
    { monthCode: "10", month: "October" },
    { monthCode: "11", month: "November" },
    { monthCode: "12", month: "December" },
  ];
  useEffect(() => {
    getYearfun();
    getDatefun();
  }, []);

  const getYearfun = (startYear) => {
    var currentYear = new Date().getFullYear() - 18,
      years = [];
    startYear = startYear || 1943;
    while (startYear <= currentYear) {
      years.push(startYear++);
    }
    setYearState(years);
  };
  const getDatefun = () => {
    let day = [];
    for (let startDay = 1; startDay <= 31; startDay++) {
      let dayzero;
      if (startDay < 10) {
        dayzero = `0${startDay}`;
        day.push(dayzero);
      } else {
        day.push(startDay);
      }
      SetDayState(day);
    }
  };

  const onFinish = (value) => {
    let selectDate = `${value.year}-${value.month}-${value.day}`;
    let calAge = calculate_age(selectDate);
    function calculate_age(selectDate) {
      var today = new Date();
      var birthDate = new Date(selectDate);
      var age_now = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age_now--;
      }
      return age_now;
    }
    if (calAge >= 18) {
      if (moment(`${value.year}-${value.month}-${value.day}`).isValid()) {
        props.setState({ dob: `${value.year}-${value.month}-${value.day}` });
        setDataForm(() => ({
          ...dataForm,
          dob: `${value.year}-${value.month}-${value.day}`,
        }));
        setLoader(true);
        let postData = {
          requestType: "CHECKLOGINID",
          loginId: value.email,
        };
        hookcheckLoginId.sendRequest(postData, function (data) {
          if (data.status == "S") {
            props.setStepData(value);
            props.setCurrent((prevState) => prevState + 1);
            setLoader(false);
          } else {
            notification.error({ message: data.errorMessage });
            form.setFields([{ name: "email", errors: [data.errorMessage] }]);
            setLoader(false);
          }
        });
      } else {
        form.setFields([{ name: "day", errors: ["Please select valid day"] }]);
      }
    } else {
      form.setFields([{ name: "year", errors: ["You are under 18 age"] }]);
    }
  };

  return (
    <Form form={form} autoComplete="none" onFinish={onFinish}>
      <label className="step-label mb-1">Full Name</label>
      <Form.Item
        name="name"
        rules={[
          {
            required: true,
            message: "Please enter your name",
          },
          {
            pattern: /^([\w]{1,})+\s+([\w\s]{1,})+$/i,
            message: "Input is not valid.",
          },
          {
            pattern: /^([^0-9]*)$/,
            message: "Number not allow in name",
          },
        ]}
      >
        <Input
          size="large"
          onChange={(e) => {
            setDataForm(() => ({ ...dataForm, name: e.target.value }));
          }}
        />
      </Form.Item>
      <label className="step-label  mb-1">Email ID</label>
      <Form.Item
        name="email"
        rules={[
          {
            type: "email",
            message: "The input is not valid E-mail!",
          },
          {
            required: true,
            message: "Please input your E-mail!",
          },
        ]}
      >
        <Input
          size="large"
          onChange={(e) => {
            setDataForm(() => ({ ...dataForm, email: e.target.value }));
          }}
        />
      </Form.Item>
      <label className="step-label  mb-1">Date Of Birth</label>
      <div className="d-flex  gap-2">
        <Form.Item
          className="form-item flex-fill"
          name="day"
          rules={[
            {
              required: true,
              message: "Please select your day",
            },
          ]}
        >
          <Select size="large" className="w-100" placeholder="Day ">
            {dayState.map((day, i) => {
              return (
                <Option key={i} value={day}>
                  {day}
                </Option>
              );
            })}
          </Select>
        </Form.Item>
        <Form.Item
          className="form-item flex-fill"
          name="month"
          rules={[
            {
              required: true,
              message: "Please select your month",
            },
          ]}
        >
          <Select size="large" className="w-100" placeholder="Month ">
            {monthNameList.map((month, i) => {
              return (
                <Option key={i} value={month.monthCode}>
                  {month.month}
                </Option>
              );
            })}
          </Select>
        </Form.Item>
        <Form.Item
          className="form-item flex-fill"
          name="year"
          rules={[
            {
              required: true,
              message: "Please select your year",
            },
          ]}
        >
          <Select size="large" className="w-100" placeholder="Year ">
            {yearstate.map((year, i) => {
              return (
                <Option key={i} value={year}>
                  {year}
                </Option>
              );
            })}
          </Select>
        </Form.Item>
      </div>
      <label className="step-label mb-1">Gender</label>
      <Form.Item
        name="gender"
        tooltip="Please select your gender"
        rules={[
          {
            required: true,
            message: "Please select your gender",
            whitespace: true,
          },
        ]}
      >
        <Radio.Group
          onChange={(e) => {
            setDataForm(() => ({ ...dataForm, gender: e.target.value }));
          }}
        >
          <Radio value={"M"}>Male</Radio>
          <Radio value={"F"}>Female</Radio>
          <Radio value={"T"}>Other</Radio>
        </Radio.Group>
      </Form.Item>

      <div className="">
        <label className="step-label mb-1">How did you hear about us?</label>
        <Form.Item
          className="form-item"
          name="marketingCommunicationMedia"
          rules={[
            {
              required: true,
              message: "Please select how did you hear about us.",
            },
          ]}
        >
          <Radio.Group
            onChange={(e) => {
              // setDataForm(() => ({ ...dataForm, gender: e.target.value }));
              if (e.target.value === "Other") {
                setOtherSourceReg(true);
              } else {
                setOtherSourceReg(false);
              }
            }}
          >
            <Radio value="Internet">Internet</Radio>
            <Radio value="Newspaper">Newspaper</Radio>
            <Radio value="Other">Other</Radio>
          </Radio.Group>
        </Form.Item>
        {otherSourceReg && (
          <Form.Item
            name="marketingCommunicationMediaOther"
            rules={[
              {
                min: 2,
                max: 60,
                message: "Should be Min 2 and Max 60",
              },
              {
                required: true,
                message: "Please enter other value",
              },
            ]}
          >
            <Input
              size="large"
              placeholder="Enter other source of registeration"
            />
          </Form.Item>
        )}
      </div>
      <Spin spinning={loader}>
        <div className="step-action  mt-3">
          <div className="d-grid g-2">
            <button
              disabled={loader}
              className="btn btn-primary text-white my-1"
              htmlType="submit"
            >
              Next
            </button>
          </div>
        </div>
      </Spin>
    </Form>
  );
}
