import React, { useState, useReducer, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Input, notification, Spin, Menu, Dropdown, Button } from "antd";
import { AuthAPI } from "../../../apis/AuthAPI";
import { connect, useDispatch, useSelector } from "react-redux";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import useHttp from "../../../hooks/useHttp";
import LogoXmonies from "../layout/LogoXmonies";

function SignIn(props) {
  const ConfigReducer = useSelector((state) => state);
  const dispatch = useDispatch();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  let navigate = useNavigate();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      loginData: {},
      nextAction: "",
    }
  );

  const hookUserRiskProfile = useHttp(ProfileAPI.userRiskProfile);
  const hookLogin = useHttp(AuthAPI.login);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    form.setFieldsValue({ loginpassword: "" });
  }, []);

  const onFinish = (value) => {
    const payload = {
      requestType: "LOGIN",
      loginId: value.loginId,
      password: value.loginpassword,
      noofAttempts: "1",
      custType: "SEND",
      referer: "",
    };

    setLoader(true);
    hookLogin.sendRequest(payload, function (data) {
      if (data.status == "S") {
        userRiskProfile(data);
        storeLoginData(data);
      } else {
        setLoader(false);
        if (data.errorList) {
          notification.error({ message: data.errorList[0].error });

          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) form.setFields(errors);
        } else {
          notification.error({ message: data.errorMessage });
        }
      }
    });
  };

  const userRiskProfile = (loginData) => {
    const userRiskProfilePayload = {
      requestType: "RISKPROFILE",
      userId: loginData.userId,
      ___token: loginData.token,
    };

    setLoader(true);
    hookUserRiskProfile.sendRequest(userRiskProfilePayload, function (data) {
      if (data.status == "S") {
        setState({ nextAction: data.nextAction });
        dispatch({ type: "SET_USER_KYC", payload: data.nextAction });
      }
      setLoader(false);
    });
  };

  const storeLoginData = (loginData) => {
    notification.success({
      message: `WELCOME ${loginData.firstName} ${loginData.lastName}`,
    });
    props.saveUser(loginData, state.nextAction);
    props.manageAuth("logintoken", loginData);

    if (state.nextAction == "KYC_COMPLETE") {
      setTimeout(() => {}, 500);
    } else {
      setTimeout(() => {
        navigate("/new-transaction");
      }, 500);
    }
  };

  const menu = (
    <Menu>
      <Menu.Item>
        <Link to="/forgot-password">Forgot Password?</Link>
      </Menu.Item>
      <Menu.Item>
        <Link to="/unlock-account">Unlock Account?</Link>
      </Menu.Item>
    </Menu>
  );

  return (
    <div className="container-fluid __t2">
      <div className="row">
        <div className="col-12 col-md-5  p-0 ">
          <LogoXmonies />
        </div>
        <div className="col-12 col-md-7 col-xl-6 col-xxl-5 p-auto p-md-5 align-self-center">
          <div className="login-right">
            <h1 className="title mb-4">Log In</h1>
            <div className="mb-3">
              <p className="subtitle">
                New to xMonies?{" "}
                <Link to="/signup">
                  <span>Sign Up</span>
                </Link>
              </p>

              <div>
                <div className="row">
                  <div className="col-md-12">
                    <Form form={form} onFinish={onFinish} autoComplete="none">
                      <div className="mb-2">
                        <label className="step-label mb-1">Log In ID</label>
                        <Form.Item
                          className="form-item"
                          name="loginId"
                          rules={[
                            {
                              required: true,
                              message: "Please input your Email ID.",
                            },
                            {
                              type: "email",
                              message: "Please input valid Email ID.",
                            },
                          ]}
                        >
                          <Input
                            autoFocus
                            size="large"
                            placeholder="Enter your Email ID"
                            autoComplete="off"
                            // onPaste={(e) => {
                            //   e.preventDefault();
                            //   return false;
                            // }}
                            // onCopy={(e) => {
                            //   e.preventDefault();
                            //   return false;
                            // }}
                            // onCut={(e) => {
                            //   e.preventDefault();
                            //   return false;
                            // }}
                          />
                        </Form.Item>
                      </div>
                      <div className="mb-2">
                        <label className="step-label mb-1">Password</label>
                        <Form.Item
                          className="form-item"
                          name="loginpassword"
                          rules={[
                            {
                              required: true,
                              message: "Please input your Password.",
                            },
                            {
                              min: 10,
                              max: 20,
                              message:
                                "Password should be between 10 and 20 characters long.",
                            },
                          ]}
                        >
                          <Input.Password
                            size="large"
                            placeholder="Enter password"
                            // onPaste={(e) => {
                            //   e.preventDefault();
                            //   return false;
                            // }}
                            // onCopy={(e) => {
                            //   e.preventDefault();
                            //   return false;
                            // }}
                            // onCut={(e) => {
                            //   e.preventDefault();
                            //   return false;
                            // }}
                          />
                          
                        </Form.Item>
                      </div>
                     

                      <Spin spinning={loading}>
                        <div className="d-grid g-2">
                          <button
                            disabled={loading}
                            className="btn btn-primary text-white my-1"
                            type="submit"
                          >
                            Login
                          </button>
                        </div>
                      </Spin>
                      <Dropdown
                        overlay={menu}
                        trigger={["click"]}
                        placement="bottomLeft"
                        arrow
                      >
                        <p role="button" className="btn-link mt-5 text-center">
                          Problems Signing Up ?
                        </p>
                      </Dropdown>
                    </Form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    saveUser: (data, nextAction) => {
      dispatch({ type: "SET_USER_LAST_LOGIN", payload: data.lastLoginTimeIST });
      dispatch({ type: "SET_USER_ID", payload: data.userId });
      // dispatch({ type: "SET_USER_KYC", payload: nextAction });
      dispatch({
        type: "SET_USER_FULL_NAME",
        payload: data.firstName + " " + data.lastName,
      });
      dispatch({ type: "SET_USER_LOGIN", payload: true });
    },
  };
};

export default connect(null, mapDispatchToProps)(SignIn);
