import React, { useState, useEffect } from "react";
import { Form, Input, Select, Modal, notification, Spin } from "antd";
import { Row, Col } from "react-bootstrap";

const { Option } = Select;

export default function EditContactBox(props) {
  const [form] = Form.useForm();

  useEffect(() => {
    form.setFieldsValue({
      mobilePhoneCode: props.state.mobilePhoneCode,
      mobileNo: props.state.mobileNo,
      communicationEmailID: props.state.emailId,
    });
    props.setState({
      editableMobileNo: props.state.mobileNo,
    });
  }, []);

  useEffect(() => {
    if (props.state.senderContactDetailsErrors) {
      let errors = [];
      props.state.senderContactDetailsErrors.forEach((error, i) => {
        let errorData = {
          name: error.field,
          errors: [error.error],
        };
        errors.push(errorData);
      });
      form.setFields(errors);
    } else {
      form.setFields([{ name: "mobileNo", errors: [] }]);
    }
  }, [props.state.senderContactDetailsErrors]);

  const onFinish = (value) => {
    // props.sendOTP("CU", "Edit_Contact");
    if (props.state.twofa === "Y") {
      props.sendOTP("CU", "Edit_Contact");
    } else {
      props.editSenderContactdtls("");
    }
  };

  return (
    <>
      <Modal
        centered
        className="primary"
        width={450}
        visible={props.state._isShowContactEditModel}
        onCancel={() => props.setState({ _isShowContactEditModel: false })}
        footer={null}
      >
        <Form
          form={form}
          onFinish={onFinish}
          initialValues={{
            mobileNo: props.state.mobileNo,
            phoneNo: props.state.phoneNo,
          }}
        >
          <Spin spinning={props.loader}>
            <div className="d-flex justify-content-center align-items-center">
              <Row className="justify-content-center">
                <Row>
                  <div className="p-0 mb-4">
                    <h4 className="text-white">Contact details</h4>
                  </div>
                </Row>

                {props.state.editContactTab == 1 && (
                  <>
                    <Col md={4}>
                      <label className="form-label">Country Code</label>
                      <Form.Item
                        className="form-item"
                        name="mobilePhoneCode"
                        rules={[
                          {
                            required: true,
                            message: "Please select your Country Code.",
                          },
                        ]}
                      >
                        <Select
                          size="large"
                          className="w-100"
                          placeholder="Select Country Code"
                          showSearch
                          optionFilterProp="children"
                          onSelect={(v) =>
                            props.setState({ editablemobilePhoneCode: v })
                          }
                        >
                          {props.state.phoneCodes.map((list, i) => {
                            return (
                              <Option key={i} value={list.countryPhoneCode}>
                                {list.countryPhoneCode} ( {list.countryName})
                              </Option>
                            );
                          })}
                        </Select>
                      </Form.Item>
                    </Col>
                    <Col md={8}>
                      <label className="form-label">Mobile</label>
                      <Form.Item
                        className="form-item"
                        name="mobileNo"
                        rules={[
                          {
                            required: true,
                            message: "Please input your Mobile Number.",
                          },
                          {
                            min: 10,
                            max: 10,
                            message: "Mobile number must be 10 digit.",
                          },
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                        ]}
                      >
                        <Input
                          onChange={(e) =>
                            props.setState({ editableMobileNo: e.target.value })
                          }
                          size="large"
                          placeholder="Enter your Mobile"
                        />
                      </Form.Item>
                    </Col>
                  </>
                )}
                {/* {props.state.editContactTab == 2 && (
                  <Col md={12}>
                    <label className="form-label">Phone Number</label>
                    <Form.Item
                      className="form-item"
                      name="phoneNo"
                      rules={[
                        {
                          min: 10,
                          max: 10,
                          message: "Mobile number must be 10 digit.",
                        },
                        {
                          pattern: /^[0-9\b]+$/,
                          message: "Only Numbers allowed",
                        },
                      ]}
                    >
                      <Input
                        onChange={(e) =>
                          props.setState({ phoneNo: e.target.value })
                        }
                        size="large"
                        placeholder="Enter your Phone Number"
                      />
                    </Form.Item>
                  </Col>
                )} */}
                {props.state.editContactTab == 3 && (
                  <Col md={12}>
                    <label className="form-label">Communication Email ID</label>
                    <Form.Item
                      className="form-item"
                      name="communicationEmailID"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Communication Email ID.",
                        },
                        {
                          type: "email",
                          message: "Please input your valid email.",
                        },
                      ]}
                    >
                      <Input
                        onChange={(e) =>
                          props.setState({ emailId: e.target.value })
                        }
                        size="large"
                        placeholder="Enter your Communication Email ID"
                      />
                    </Form.Item>
                  </Col>
                )}

                <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                  <button
                    className="btn btn-danger btn-block btn-sm px-4"
                    onClick={() =>
                      props.setState({ _isShowContactEditModel: false })
                    }
                    type="button"
                  >
                    Cancel
                  </button>
                  <button className="btn btn-secondary btn-sm px-4">
                    Submit
                  </button>
                </div>
              </Row>
            </div>
          </Spin>
        </Form>
      </Modal>
    </>
  );
}
