import React from "react";
import { Link } from "react-router-dom";
import SubHeader from "../../../layout/SubHeader";

const SofortTranscationSuccess = () => {
  return (
    <React.Fragment>
      <SubHeader />
      <div className="template2__main">
        <div className="sendmoney__page">
          <div className="container">
            <div className="row py-5">
              <div className="col-12">
                <h2 className="text-info mb-3">Transaction Successful</h2>
                <h5 className="text-light mb-4">
                  Your transaction is compleated. Money is on the way.
                </h5>
                <p className="text-light">
                  <strong>
                    You can always track the status of your transfer from{" "}
                    <Link to="/my-transaction" className="text-info">
                      My Transactions
                    </Link>{" "}
                    page.
                  </strong>
                </p>
                <div className="text-end">
                  <Link
                    className="btn btn-sm btn-light text-white"
                    to="/my-transaction"
                  >
                    Go to Account Summary
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default SofortTranscationSuccess;
