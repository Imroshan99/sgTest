import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
} from "react";
import {
  Form,
  Table,
  Spin,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
  Tabs,
} from "antd";
import DefaultLayout from "../../layout/DefaultLayout";
import Grid from "@mui/material/Grid";
import { GuestAPI } from "../../../../apis/GuestAPI";
import useHttp from "../../../../hooks/useHttp";
import { useSelector } from "react-redux";

const { Option } = Select;

export default function PhoneNumber(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      isTransactionBook: false,
      phoneCodeList: [],
      userID: AuthReducer.userID,
      loading: false,
      countryPhoneCode: "",
      phoneNumber: "",
    }
  );

  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookReferFriend = useHttp(GuestAPI.referFriend);

  useEffect(() => {
    getCountryPhoneCodeList();
  }, []);

  const getCountryPhoneCodeList = () => {
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };

    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      if (data.status === "S") {
        setState({ phoneCodeList: data.responseData });
      }
    });
  };

  const sendSms = () => {
    const payload = {
      requestType: "ADDREFERAL",
      userId: state.userID,
      firstName: "",
      lastName: "",
      emailId: "",
      mobilePhoneCode: state.countryPhoneCode,
      mobileNo: state.phoneNumber,
      countryCode: "GB",
    };

    setState({ loading: true });
    hookReferFriend.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ loading: false });
      }
    });
  };

  const handleCountryPhoneCodes = (data) => {
    setState({ countryPhoneCode: data });
  };

  const handlePhoneNumber = (e) => {
    setState({ phoneNumber: e.target.value });
  };

  return (
    <React.Fragment>
      <div style={{ marginLeft: "100px" }}>
        <Form form={form} onFinish={sendSms}>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={12}>
              <h4>Enter Recipient’s Phone Number</h4>

              <div style={{ display: "flex" }}>
                <Form.Item
                  className="form-item"
                  name="mobilePhoneCode"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Country Code.",
                    },
                  ]}
                >
                  <Select
                    size="large"
                    className="w-100"
                    placeholder="Select Country Code"
                    onChange={handleCountryPhoneCodes}
                  >
                    {state.phoneCodeList.map((phoneCode, i) => {
                      return (
                        <Option
                          key={i}
                          value={phoneCode.countryPhoneCode}
                        >{`${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>
                      );
                    })}
                  </Select>
                </Form.Item>

                <Form.Item
                  name="phoneNumber"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Phone Number.",
                    },
                  ]}
                >
                  <Input
                    className="w-100"
                    type="number"
                    placeholder="Enter Phone Number"
                    onChange={handlePhoneNumber}
                  />
                </Form.Item>
              </div>
              <br />
              <p>
                We will send the reciepient an SMS containing your unique
                Referal Code
              </p>
              <button
                htmlType="submit"
                className="btn"
                style={{
                  background: "#003153",
                  float: "right",
                  color: "#fff",
                  marginTop: "20px",
                }}
              >
                Send SMS
              </button>
            </Grid>
          </Grid>
        </Form>
      </div>
    </React.Fragment>
  );
}
