import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
} from "react";
import {
  Form,
  Table,
  Spin,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
  Tabs,
} from "antd";
import DefaultLayout from "../../layout/DefaultLayout";
import Grid from "@mui/material/Grid";
import PhoneNumber from "./PhoneNumber";
import Email from "./Email";
import UniqueLink from "./UniqueLink";

const { TabPane } = Tabs;

export default function ReferUsModal(props) {
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      isTransactionBook: false,
    }
  );

  const callback = (key) => {
    console.log(key);
  };

  return (
    <React.Fragment>
      <h2 style={{ color: "black" }}>Refer Us</h2>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={12}>
          <Tabs defaultActiveKey="1" onChange={callback} type="card">
            <TabPane tab="Phone Number" key="1">
              <PhoneNumber />
            </TabPane>
            <TabPane tab="E-Mail" key="2">
              <Email />
            </TabPane>
            <TabPane tab="Unique Link" key="3">
              <UniqueLink />
            </TabPane>
          </Tabs>
        </Grid>
      </Grid>
    </React.Fragment>
  );
}
