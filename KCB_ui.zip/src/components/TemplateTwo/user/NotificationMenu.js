import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { useEffect, useReducer, useState } from "react";
import { useSelector } from "react-redux";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { config } from "../../../config";
import useHttp from "../../../hooks/useHttp";
import { Spin } from "antd";
import { NavLink } from "react-router-dom";

export default function NotificationMenu(props) {
  const AuthReducer = useSelector((state) => state);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      notificationLists: [],
      notificationDesc: "",
      isModalVisible: false,
    }
  );
  return (
    <>
      <Menu
        anchorEl={props.anchorElNoti}
        id="account-menu"
        open={Boolean(props.anchorElNoti)}
        onClose={props.handleCloseNotiMenu}
        onClick={props.handleCloseNotiMenu}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            // filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <Spin spinning={props.notificationLoader}>
          <div className="Notification-Menu-Main-Container">
            <h3 className="Notification-Menu-Title inner_title_color mt-2">
              Notifications
            </h3>
            {props.state.notificationList == "" ? (
              <p className="Notification-Menu-Title-h6 px-3">
                No Notifications
              </p>
            ) : (
              props.state.notificationList.map((value, key) => {
                return (
                  <MenuItem>
                    <div className="Notification-Menu-Container">
                      <h6 className="Notification-Menu-Title-h6 m-0 inner_title_color">
                        {value.notificationTitle}
                      </h6>
                      <div className="Notification-Menu-Description-p m-0 inner_title_color">
                        {value.notificationDesc}
                      </div>
                    </div>
                  </MenuItem>
                );
              })
            )}
            {/* View all and clear button */}
            {/* <div className="notification-menu-bottom-container">
              <p className="Notification-Menu-Bottom-p m-0 mt-2 inner_title_color">
                Clear all Notifications
              </p>
              <p className="Notification-Menu-Bottom-p m-0 mt-2 inner_title_color">
                View all
              </p>
            </div> */}
          </div>
        </Spin>
      </Menu>
    </>
  );
}
