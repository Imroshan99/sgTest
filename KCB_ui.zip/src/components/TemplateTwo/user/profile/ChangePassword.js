import React, { useEffect, useReducer, useState } from "react";
import logorefresh from "../../../../assets/images/svg/refreshCaptcha.svg";
import { Form, Input, Row, Col, Spin, notification } from "antd";
import Swal from "sweetalert2";
import { useSelector } from "react-redux";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import SubHeader from "../../layout/SubHeader";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { passwordValidate } from "../../../../services/validations/group";
import { passwordStrength } from "../../../../services/utility/Helper";

export default function ChangePassword(props) {
  const [loader, setLoader] = useState(true);
  const [captchaID, setCaptchaID] = useState();
  const [captchaImg, setCaptchaImg] = useState();
  const [strengthBadge, setStrengthBadge] = useState("None");
  const [strengthBadgeConfPass, setstrengthBadgeConfPass] = useState("None");
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      twofa: AuthReducer.twofa,
      userID: AuthReducer.userID,
      userFullName: AuthReducer.userFullName,
      newPassword: "",
      confNewPassword: "",
    }
  );

  const hookChangePassword = useHttp(ProfileAPI.changePassword);
  const hookgetCaptcha = useHttp(GuestAPI.getCaptcha);
  const hookVerifyCaptcha = useHttp(GuestAPI.verifyCaptcha);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getCaptcha();
  }, []);

  const getCaptcha = () => {
    setLoader(true);
    let payload = {
      requestType: "GETCAPTCHA",
    };
    hookgetCaptcha.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setCaptchaID(data.id);
        setCaptchaImg(data.captchaImage);
        setLoader(false);
      } else {
      }
    });
  };

  const onFinish = (value) => {
    setLoader(true);
    let captchaPayload = {
      requestType: "VERIFYCAPTCHA",
      id: captchaID,
      captchaResponse: value.captcha,
    };
    hookVerifyCaptcha.sendRequest(captchaPayload, function (data) {
      if (data.status == "S") {
        let changePasswordPayload = {
          requestType: "CHANGEPASSWORD",
          userId: AuthReducer.userID,
          oldPassword: value.oldPassword,
          newPassword: value.newPassword,
          twofa: "N",
        };
        hookChangePassword.sendRequest(changePasswordPayload, function (data) {
          if (data.status == "S") {
            setLoader(false);
            Swal.fire({
              title: "Success",
              text: data.message,
              icon: "success",
              confirmButtonColor: "#2dbe60",
            }).then((result) => {
              if (result.isConfirmed) {
                window.location.href = "/signin";
              }
            });
          } else {
            getCaptcha();
            setLoader(false);
            notification.error({ message: data.errorMessage });
            let errors = [];
            data.errorList.forEach((error, i) => {
              let errorData = {
                name: error.field,
                errors: [error.error],
              };
              errors.push(errorData);
            });

            if (errors.length > 0) form.setFields(errors);
          }
        });
      } else {
        form.setFields([{ name: "captcha", errors: ["Incorrect Captcha"] }]);
        getCaptcha();
      }
    });
  };
  const passwordStrenthHandler = (e) => {
    setStrengthBadge(
      e.target.value == "" ? "None" : passwordStrength(e.target.value)
    );
  };

  const confPasswordHandler = (e) => {
    setstrengthBadgeConfPass(
      e.target.value == "" ? "None" : passwordStrength(e.target.value)
    );
  };

  return (
    <div>
      <SubHeader title="Change Password" />
      <Spin spinning={loader}>
        <div className="template2__main">
          <div className="container change_password__page py-5">
            {!state.showConfirmBankAccountDetails && (
              <Form form={form} onFinish={onFinish}>
                <div className="ChangePassword">
                  <div className="row b_line">
                    <div className="col-md-5">
                      <label className="form-label text-light">
                        Current Password
                      </label>
                      <Form.Item
                        className="form-item"
                        name="oldPassword"
                        rules={[
                          {
                            required: true,
                            message: "Enter Current Password.",
                          },
                        ]}
                      >
                        <Input.Password size="large" />
                      </Form.Item>
                    </div>
                  </div>

                  <div className="row mt-5">
                    <div className="col-md-5">
                      <label className="form-label text-light">
                        Choose a New Password
                      </label>
                      <Form.Item
                        className="form-item"
                        name="newPassword"
                        rules={[
                          {
                            required: true,
                            message: "Please input your New Password.",
                          },
                          ...passwordValidate("XR"),
                        ]}
                      >
                        <div className="d-flex ">
                          <Input.Password
                            visibilityToggle={false}
                            onChange={passwordStrenthHandler}
                            size="large"
                            maxLength={20}
                            addonAfter={
                              <div className="text-primary">
                                Strength:{" "}
                                <span className="text-info-dark">
                                  {strengthBadge}
                                </span>
                              </div>
                            }
                          />
                        </div>
                      </Form.Item>
                      <label className="form-label text-light">
                        Confirm New Password
                      </label>
                      <Form.Item
                        className="form-item"
                        name="ConfirmNewPassword"
                        rules={[
                          {
                            required: true,
                            message: "Please enter Confirm New Password.",
                          },
                          ...passwordValidate("XR"),
                          ({ getFieldValue }) => ({
                            validator(rule, value) {
                              if (
                                !value ||
                                getFieldValue("newPassword") === value
                              ) {
                                return Promise.resolve();
                              }
                              return Promise.reject(
                                "Confirm password does not match with new password"
                              );
                            },
                          }),
                        ]}
                      >
                        <div className="d-flex">
                          <Input.Password
                            visibilityToggle={false}
                            onChange={confPasswordHandler}
                            size="large"
                            maxLength={20}
                            addonAfter={
                              <div className="text-primary">
                                Strength:{" "}
                                <span className="text-info-dark">
                                  {strengthBadgeConfPass}
                                </span>
                              </div>
                            }
                          />
                        </div>
                      </Form.Item>
                      <p className="text-info m-0">
                        <small>
                          Password must contain at least one Uppercase Letter,
                          at least one Lowercase letter and at least one special
                          symbol
                        </small>
                      </p>
                    </div>
                    <div className="col-md-2 text-center d-none d-md-block">
                      <span
                        className="_v_line_secondary mt-5"
                        style={{ height: "100px" }}
                      ></span>
                    </div>
                    <div className="col-md-5">
                      <label className="form-label text-light">
                        Word Verification
                      </label>
                      <div className="w-100 d-flex mb-3">
                        <div className="me-3">
                          <img
                            src={`data:image/jpeg;base64,${captchaImg}`}
                            alt="captcha"
                          />
                        </div>
                        <div
                          className="d-flex align-items-center text-light my-3"
                          style={{ cursor: "pointer" }}
                          onClick={getCaptcha}
                        >
                          <img
                            src={logorefresh}
                            alt="refresh"
                            className="me-2"
                          />
                          <span>Refresh Code</span>
                        </div>
                      </div>
                      <Form.Item
                        className="form-item"
                        name="captcha"
                        rules={[
                          {
                            required: true,
                            message: "Enter Captcha.",
                          },
                        ]}
                      >
                        <Input
                          size="large"
                          placeholder="Enter the text shown in the Image"
                        />
                      </Form.Item>
                    </div>
                  </div>

                  <div className="d-flex justify-content-end">
                    <button
                      style={{ width: "10rem", fontWeight: 700 }}
                      className="mt-5 btn btn-sm btn-light text-primary"
                      type="submit"
                    >
                      Change Password
                    </button>
                  </div>
                </div>
              </Form>
            )}
          </div>
        </div>
      </Spin>
    </div>
  );
}
