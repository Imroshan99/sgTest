import React, { useEffect, useLayoutEffect } from "react";
import Home from "../../pages/LandingPage/index";
import Dashboard from "./Dashboard";
import SignUp from "./auth/SignUp";
import SignIn from "./auth/SignIn";
import Header from "./layout/Header";

import ForgotUserID from "./auth/ForgotUserID";
import ForgotPassword from "./auth/ForgotPassword";
import UnlockUserid from "./auth/UnlockUserid";
import { Helmet } from "react-helmet";
import { PublicRoute } from "./../../Routes/PublicRoute";
import SingleSignUpForm from "./auth/SingleSignUpForm";
import { Route, Routes, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import UnlockAccount from "./auth/UnlockAccount";


const RequestMoney = React.lazy(() => import("./pages/request-money"));

export default function TemplateOne({ state, manageRefreshToken, manageAuth }) {
  const AuthReducer = useSelector((state) => state);
  const _title = useSelector((state) => state.groupIdSettings.title);

  // useEffect(() => {
  //   var head = document.head;
  //   var link = document.createElement("link");

  //   link.type = "text/css";
  //   link.rel = "stylesheet";
  //   link.href = 'css/template2.css';

  //   head.appendChild(link);

  //   return () => {
  //     head.removeChild(link);
  //   };
  // }, []);

  // useEffect(() => {
  //   const ls = new SecureLS({
  //     encodingType: "des",
  //     isCompression: false,
  //     encryptionSecret: 'sdfsdfsdf',
  //   });
  //   ls.set("Hello", {data: "hell"});
  // }, []);

  return (
    <>
      <Helmet>
        <title>{_title}</title>
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href={require(`./../../assets/images/fav_icons/${
            AuthReducer.groupId + "_logo.ico"
          }`)}
        />
        {/* <noscript>{`<link rel="stylesheet" type="text/css" href="foo.css" />`}</noscript> */}
      </Helmet>
      <Routes>
        <Route
          path="/"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              <Home appState={state} manageAuth={manageAuth} />
            </PublicRoute>
          }
        />
        <Route
          path="/signin"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              <SignIn appState={state} manageAuth={manageAuth} />
            </PublicRoute>
          }
        />
        <Route
          path="/signup"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              {AuthReducer.groupIdSettings.signUpForm.formType === "REGULAR" ? (
                <SignUp appState={state} manageAuth={manageAuth} />
              ) : (
                <SingleSignUpForm appState={state} manageAuth={manageAuth} />
              )}
            </PublicRoute>
          }
        />
        <Route
          path="/*"
          element={<Dashboard appState={state} manageAuth={manageAuth} />}
        />

        <Route element={<Header appState={state} />}>
          <Route path="/request-money" element={<RequestMoney />} />
        </Route>

        <Route
          path="/request-money"
          element={<RequestMoney appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/forgot-userid"
          element={<ForgotUserID appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/forgot-password"
          element={<ForgotPassword appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/unlock-userid"
          element={<UnlockUserid appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/unlock-account"
          element={<UnlockAccount appState={state} manageAuth={manageAuth} />}
        />

       
        <Route
          exact
          path="/"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              <Home appState={state} />
            </PublicRoute>
          }
        />
        <Route path="*" element={<Home appState={state} />} />
        {/* <Route path="*" element={<PageNotFound appState = {state}/>} /> */}
        {/* <Route
          path="/track-money-transfer"
          element={<TrackMoneyTransfer appState={state} />}
        /> */}
        {/* <Route
          path="/ThankYouScheduleTransaction"
          element={
            <ThankYouScheduleTransaction
              appState={state}
              manageRefreshToken={manageRefreshToken}
            />
          }
        />

        {state.isLoggedIn && (
          <Fragment>
            <Route
              path="/dashboard"
              element={
                <Dashboard
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />

            <Route
              path="/kyc"
              element={
                <KycPage
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/change-password"
              element={
                <ChangePassword
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/profile"
              element={
                <Profile
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
             <Route path="/my-bank-accounts" element={<BankAccountList appState={state} manageRefreshToken={manageRefreshToken} />} /> 
            <Route
              path="/my-bank-accounts"
              element={
                <BankAccountList
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/add-bank-account"
              element={
                <AddBankAccount
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/my-recipient"
              element={
                <RecipientList
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/recipient-request-list"
              element={
                <RecipientRequestList
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/add-recipient"
              element={
                <AddRecipient
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/new-transaction"
              element={
                <TranctionAction
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/repeat-transaction"
              element={
                <RepeatTranscation
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/transaction-list"
              element={
                <TransactionList
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/track-money-transfer"
              element={
                <TrackMoneyTransfer
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/jumio-page"
              element={
                <JumioPage
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />

            <Route path="/thankYou" element={<ThankYou appState={state} />} />
            <Route
              path="/bankThankYou"
              element={<BankThankYou appState={state} />}
            />
            <Route
              path="/profile-setup"
              element={<ProfileSetup appState={state} />}
            />

            <Route
              path="/rate-alert"
              element={
                <RateAlert
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/notification-list"
              element={<Notification appState={state} />}
            />
          </Fragment> */}
        {/* )} */}
      </Routes>
    </>
  );
}
