import KycPage from "../auth/KYC";
import { useSelector } from "react-redux";
import React, { useState, useRef, useReducer, useEffect } from "react";
import { Modal, Button } from "antd";
import XRInvoice from "../user/sendmoney/Invoice/XR";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { TransactionAPI } from "../../../apis/TransactionAPI";
import useHttp from "../../../hooks/useHttp";
import KYCModal from "../auth/KYCModal";

export default function SubHeader(props) {
  const AuthReducer = useSelector((state) => state);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const pdfRef = useRef(null);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      transactionLists: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,

      _invoiceTxnRefNumber: "",
      _invoiceData: [],
      pdfDetails: "",
      coreBankDetailsList: [],
    }
  );

  const hookGetTransactionReceiptDetails = useHttp(
    TransactionAPI.transactionReceiptDetails
  );
  const hookGetCoreBankDetails = useHttp(TransactionAPI.getCoreBankDetails);

  useEffect(() => {
    // getCoreBankDetails();
  }, []);

  const getCoreBankDetails = () => {
    const payload = {
      requestType: "CORRBANKDTLS",
      userId: state.userID,
      sendCountryCode: "GB",
      sendCurrencyCode: "GBP",
      sendModeCode: "CIP",
    };

    hookGetCoreBankDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ coreBankDetailsList: data.responseData });
      }
    });
  };

  const onClickViewAndDownload = (txnRefno) => {
    const payload = {
      requestType: "TXNDETAILS",
      rgtn: "",
      txnRefNo: props.txnRefNumber,
      userId: state.userID,
    };

    hookGetTransactionReceiptDetails.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ pdfDetails: data });
        downloadPdf();
      }
    });
  };

  const downloadPdf = () => {
    html2canvas(pdfRef.current, {
      windowWidth: "1200px",
      scale: 1,
    }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      pdf.addImage(imgData, "JPEG", 0, 0);
      // pdf.output('dataurlnewwindow');
      pdf.save(`${props.txnRefNumber}.pdf`);
    });
  };

  const transcationBookedHeader = (
    <React.Fragment>
      <p className="mb-0">Booking ID: {props.txnRefNumber} </p>
      <p className="welcome_username">Transaction Booking Successful</p>
    </React.Fragment>
  );

  return (
    <>
      <div style={{ position: "absolute", marginTop: "-2000px" }}>
        <XRInvoice
          ref={pdfRef}
          pdfDetails={state.pdfDetails}
          bankDetails={state.coreBankDetailsList}
        />
      </div>
      <div className="subheader pt-5 pb-4">
        <div className="container">
          {AuthReducer.isLoggedIn == true && (
            <div className="d-flex justify-content-between align-items-end">
              <div className="welcome__box">
                {!props.title && (
                  <React.Fragment>
                    {props.isTransactionBook && transcationBookedHeader}
                    {!props.isTransactionBook && (
                      <>
                        <p className="mb-0">Welcome to xMonies,</p>
                        <p className="welcome_username">
                          {AuthReducer.userFullName}
                        </p>
                      </>
                    )}
                  </React.Fragment>
                )}
                {props.title && (
                  <React.Fragment>
                    <p className="welcome_username">{props.title}</p>
                  </React.Fragment>
                )}
              </div>
              <div className="d-flex align-items-center">
                {props.isTransactionBook ? (
                  <button
                    onClick={onClickViewAndDownload}
                    className="btn btn-primary text-white "
                  >
                    Download Reciept
                  </button>
                ) : (
                  AuthReducer.userKYC == "DOB" && (
                    <button
                      className="btn btn-primary text-white "
                      onClick={() => setIsModalVisible(true)}
                    >
                      Complete KYC
                    </button>
                  )
                )}
              </div>
              <KYCModal
                isModalVisible={isModalVisible}
                setIsModalVisible={setIsModalVisible}
              />
            </div>
          )}
          {AuthReducer.isLoggedIn == false && (
            <div className="d-flex justify-content-between align-items-center">
              <div className="welcome__box">
                <p className="welcome_username">{props.title}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
