import React from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import "../../TemplateTwo/style.scss";

const LogoXmonies = () => {
  const AuthReducer = useSelector((state) => state);
  return (
    <div className="login-left">
      <div className="login-logo">
        <Link to={"/"}>
          <img
            src={require("../../../assets/images/logos/" +
              AuthReducer.groupId +
              "_light_logo.svg")}
            height="72px"
          />
        </Link>
        <p className="txtlogo mt-0 p-0">Transfer made simple</p>
      </div>
    </div>
  );
};

export default LogoXmonies;
