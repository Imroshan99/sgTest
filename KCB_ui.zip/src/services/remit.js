// Entry point of Website
// domain mapped ==>
// qaonekcb.remit.in
// qaonexr.remit.in
// qaonemf.remit.in
// qaonecsb.remit.in

const remit = {
  HOST:
    window.location.hostname === "localhost"
      ? // ? "cross-border-remittance-kcb-mremit.apps.dev.aro.kcbgroup.com"
        "qaonekcb.remit.in"
      : window.location.hostname,
};

const getAppDetails = (HOST) => {
  switch (HOST) {
    case "ui-app-service-secured-kcb-fablefintech.apps.dev.aro.kcbgroup.com":
      return {
        API_URL:
          "https://kcb-fablefintect-kcb-fablefintech.apps.dev.aro.kcbgroup.com",
      };

    case "qaonekcb.remit.in":
      return {
        API_URL: "https://qaone.remit.in",
      };

    default:
      return {
        API_URL: window.KCB_SETTINGS.API,
      };
  }
};

export const appDetails = getAppDetails(remit.HOST);

export default remit;
