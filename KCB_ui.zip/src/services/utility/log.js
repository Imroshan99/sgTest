const message = function () {
  console.log(...arguments);
};

export default {
  message: message,
};
