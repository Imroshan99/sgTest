import { Navigate } from "react-router-dom";

export const PublicRoute = ({ auth, children }) => {
  const isAllowed = auth.isLoggedIn;
  if (isAllowed) {
    return <Navigate to="/new-transaction" replace />;
  }

  return children;
};
