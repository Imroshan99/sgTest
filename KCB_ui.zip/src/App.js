import React, { useEffect, useState, useReducer, Fragment, useLayoutEffect } from "react";
import "./App.css";
import Log from "./services/utility/log";
import { BrowserRouter as Router, useLocation } from "react-router-dom";
import { useIdleTimer } from "react-idle-timer";
import { connect, useDispatch, useSelector } from "react-redux";
import "sweetalert2/src/sweetalert2.scss";
import "./assets/scss/home.scss";
import { GuestAPI } from "./apis/GuestAPI";
// import PageNotFound from './components/pages/PageNotFound';
import Swal from "sweetalert2";
import { AuthAPI } from "./apis/AuthAPI";
import { config } from "./config";
import moment from "moment";
import jwt_decode from "jwt-decode";
import { GroupSettings } from "./GroupSettings";
import remit from "./services/remit";
import { encrypt, decrypt, publickey } from "./helpers/makeHash";
import PageNotFound from "./components/TemplateOne/pages/PageNotFound";
import useHttp from "./hooks/useHttp";
import log from "./services/utility/log";

const TemplateOne = React.lazy(() => import("./components/TemplateOne"));
const TemplateTwo = React.lazy(() => import("./components/TemplateTwo"));
const TemplateThree = React.lazy(() => import("./components/TemplateThree"));

// disable consolelog for production
// console.log = function () {};

// import("./services/strings/KCB").then((math) => {
//   log.message(math.add(16, 26));
// });
function App(props) {
  var tokenInterval;
  const AuthReducer = useSelector((state) => state);
  const websiteSettings = useSelector((state) => state.groupIdSettings);

  const dispatchRedux = useDispatch();

  const [isLoadGroupConfgAPI, setLoadGroupConfgAPI] = useState(false);
  const [isLoadGroupConfgErrorPage, setIsLoadGroupConfgErrorPage] = useState(false);

  const [handleOnActionCount, setHandleOnActionCount] = useState(0);

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    userLastActivitiyAt: new Date(),
    publicKey: "",
    accessToken: "",
    isLoggedIn: false,
    tokenExpiredAt: new Date(),
    tokenExpiredMinute: 4,
  });

  useEffect(() => {
    if (websiteSettings) {
      // Disable right click
      document.addEventListener("contextmenu", (e) => {
        if (!websiteSettings.settings.rightClick) {
          e.preventDefault();
        }
      });

      // Disable select text
      document.addEventListener("selectstart", (e) => {
        if (!websiteSettings.settings.selectText) {
          e.preventDefault();
        }
      });
    }
  }, [websiteSettings]);

  useEffect(async () => {
    log.message("before service key func");
    await getServiceKeyHandler();
    await getGroupConfigHandler();
    log.message("after group config");
  }, []);

  // Store Access Token when change
  useEffect(() => {
    dispatchRedux({ type: "SET_USER_TOKEN", payload: state.accessToken });
  }, [state.accessToken]);

  useEffect(() => {
    if (state.isLoggedIn) {
      tokenInterval = setInterval(async function () {
        var end = moment(state.userLastActivitiyAt); // expired time
        var start = moment(state.tokenExpiredAt);
        if (end.diff(start, "minutes") == state.tokenExpiredMinute) {
          let accessToken = await manageRefreshToken("USEEFFECT");
          log.message("call interval", accessToken);
        }
      }, 1000);

      const unloadCallback = (event) => {
        event.preventDefault();
        event.returnValue = "There is pending work. Sure you want to leave?";
        return "";
      };

      window.addEventListener("beforeunload", unloadCallback);
      return () => window.removeEventListener("beforeunload", unloadCallback);
    }
  }, [state.isLoggedIn]);

  //get Group Config from API
  const getGroupConfigHandler = async () => {
    const payloadGroupConfig = {
      url: remit.HOST,
    };

    await GuestAPI.groupConfig(payloadGroupConfig)
      .then((_res) => {
        const res = {
          status: 200,
          data: {
            clientId: "KCB",
            groupId: "KCB",
            colors: {
              "--bs-danger": "#dc3545",
              "--bs-warning": "#ffc107",
              "--bs-success": "#198754",
              "--bs-secondary": "#1f65a7",
              "--bs-light": "#f8f9fa",
              "--bs-dark": "#212529",
              "--bs-primary": "#173c79",
              "--bs-info": "#0dcaf0",
              "--bs-primary-rgb": "23, 60, 121",
              "--bs-primary-light": "#e3eeff",
            },
            twofa: false,
          },
        };
        if (res.data.colors != null) {
          for (var i = 0; Object.keys(res.data.colors).length > i; i++) {
            getComputedStyle(document.documentElement).getPropertyValue(
              Object.keys(res.data.colors)[i]
            );
            document.documentElement.style.setProperty(
              Object.keys(res.data.colors)[i],
              res.data.colors[Object.keys(res.data.colors)[i]]
            );
          }
        }
        if (res.data.groupId) {
          log.message("In Group Config func");
          props.saveConfig(res.data);
          setLoadGroupConfgAPI(true);
        } else {
          setIsLoadGroupConfgErrorPage(true);
        }
      })
      .catch((error) => log.message(error));
  };

  // Get Service Key from API
  const getServiceKeyHandler = async () => {
    await GuestAPI.serviceKey()
      .then((res) => {
        setState({ publicKey: res.data.key });
        props.savePublicKey(res.data.key);
      })
      .catch((error) => log.message(error));
  };

  let isTokenRefreshing = false;

  const manageRefreshToken = async (callFrom = "DEFAULT") => {
    var end = moment(state.tokenExpiredAt).add(state.tokenExpiredMinute, "minutes"); // expired time
    var start = moment(new Date());
    if (state.isLoggedIn) {
      if (end.diff(start, "minutes") <= 1) {
        if (!isTokenRefreshing) {
          const dt = new Date();
          isTokenRefreshing = true;

          let refreshTokenData = {
            requestId: config.requestId,
            requestType: "RefreshToken",
            channelId: config.channelId,
            clientId: AuthReducer.clientId,
            groupId: AuthReducer.groupId,
            sessionId: AuthReducer.sessionId,
            userId: AuthReducer.userID,
            ipAddress: "127.0.0.1",
            // token: state.accessToken,
            token: AuthReducer.accessToken,
          };

          if (config.IS_ENC) {
            var key = config.key;
            var iv = config.iv;
            var body = encrypt(refreshTokenData, key, iv);
            var pubValue = iv.concat(key);
            var identifier = publickey(state.publicKey, pubValue);

            var postData = {
              body: body,
              identifier: identifier,
            };
          } else {
            var postData = refreshTokenData;
          }

          // let newToken;

          await AuthAPI.refreshToken(postData, state.accessToken)
            .then((res) => {
              if (config.IS_ENC) {
                var decode = decrypt(res.data.body, key, iv);
                var decodeData = JSON.parse(decode);
              } else {
                var decodeData = res.data;
              }

              var jwtDecoded = jwt_decode(decodeData.token);
              log.message("jwtDecoded.refreshAt", jwtDecoded.refreshAt);
              setState({
                accessToken: decodeData.token,
                tokenExpiredAt: new Date(),
                tokenExpiredMinute: jwtDecoded.refreshAt - 1,
                // tokenExpiredMinute: 4 - 1,
              });

              let newToken = decodeData.token;
              isTokenRefreshing = false;

              log.message("return with new token", newToken);
              return newToken;
            })
            .catch((error) => {
              log.message(error);
              setState({ isLoggedIn: false });
              clearInterval(tokenInterval);
              log.message("return clearInterval and no token");
              return false;
            });
        }
      } else {
        log.message("return with old token");
        return state.accessToken;
      }
    } else {
      log.message("return with no token");
      return false;
    }
  };

  const manageAuth = (type, data) => {
    if (type == "logintoken") {
      var jwtDecoded = jwt_decode(data.token);
      setState({
        accessToken: data.token,
        isLoggedIn: true,
        tokenExpiredAt: new Date(),
        tokenExpiredMinute: jwtDecoded.refreshAt - 1,
        // tokenExpiredMinute: 4 - 1,
      });
    }
  };

  const handleOnIdle = (event) => {
    log.message("user is idle", "last active == " + getLastActiveTime());
    log.message("handle on idle triggered");
    if (state.isLoggedIn) {
      Swal.fire({
        title: "Alert",
        text: "Your session has been expired.Please login again to continue.",
        icon: "warning",
        confirmButtonColor: "#2dbe60",
        allowOutsideClick: false,
        preConfirm: () => {
          if (state.isLoggedIn) {
            window.location.href = "/signin";
            return false;
          }
        },
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = "/signin";
        }
      });
    }
  };

  const handleOnActive = (event) => {
    log.message("user is active", "time remaining == " + getRemainingTime());
  };

  const handleOnAction = async (event) => {
    log.message("handle on action triggered", event.type);
    var currentTime = new Date();
    setState({ userLastActivitiyAt: currentTime });

    if (state.isLoggedIn) {
      var end = moment(state.tokenExpiredAt).add(state.tokenExpiredMinute, "minutes"); // expired time
      log.message("token exipire at ===>", end.format("HH.mm"));

      var start = moment(currentTime);
      log.message("Differenc in handleONacton : ", end.diff(start, "minutes") + " " + start);
      log.message("Remaining seconds ===>", end.diff(start, "seconds"));
      if (end.diff(start, "minutes") <= 1) {
        if (handleOnActionCount === 0) {
          setHandleOnActionCount(1);
          var accessToken = await manageRefreshToken("handleOnAction");
          log.message("handleOnAction accessToken", accessToken);
          setTimeout(() => {
            setHandleOnActionCount(0);
          }, 5000);
        }
      }
    }
    // log.message('user did something', getRemainingTime())
  };

  const { getRemainingTime, getLastActiveTime } = useIdleTimer({
    timeout: 1000 * 60 * 9, //added 8 minute for idle 60 * 8
    onIdle: handleOnIdle,
    onActive: handleOnActive,
    onAction: handleOnAction,
    debounce: 500,
  });

  if (isLoadGroupConfgAPI) {
    return (
      // basename="new-ui"
      <Router>
        <ScrollToTop />
        {AuthReducer.groupIdSettings.template === "TEMPLATE_ONE" && (
          <TemplateOne
            state={state}
            manageRefreshToken={manageRefreshToken}
            manageAuth={manageAuth}
          />
        )}
        {AuthReducer.groupIdSettings.template === "TEMPLATE_TWO" && (
          <TemplateTwo
            state={state}
            manageRefreshToken={manageRefreshToken}
            manageAuth={manageAuth}
          />
        )}
        {AuthReducer.groupIdSettings.template === "TEMPLATE_THREE" && (
          <TemplateThree
            state={state}
            manageRefreshToken={manageRefreshToken}
            manageAuth={manageAuth}
          />
        )}
      </Router>
    );
  } else {
    return <Fragment></Fragment>;
  }
}

const ScrollToTop = function () {
  const { pathname } = useLocation();
  useLayoutEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "auto",
    });
  }, [pathname]);

  return null;
};

// const mapStateToProps = (state) => ({
//   userToken: state.accessToken
// })

const mapDispatchToProps = (dispatch) => {
  return {
    saveConfig: (data) => {
      // dispatch({ type: 'SET_CLIENT_ID', payload: data.clientId }) //ICA
      // dispatch({ type: 'SET_GROUP_ID', payload: data.groupId }) //ICA
      // dispatch({ type: 'SET_TWOFA', payload: data.twofa ? 'Y' : 'N' }) //Y for with opt module

      const dataGroupSeetings = GroupSettings[data.groupId];

      dispatch({ type: "SET_GROUP_ID_SETTINGS", payload: dataGroupSeetings });

      dispatch({ type: "SET_CLIENT_ID", payload: data.clientId });
      dispatch({ type: "SET_GROUP_ID", payload: data.groupId });

      if (data.groupId === "KCB") {
        dispatch({ type: "SET_SEND_COUNTRY_CODE", payload: "US" });
        dispatch({ type: "SET_SEND_CURRENCY_CODE", payload: "USD" });
        dispatch({ type: "SET_RECV_COUNTRY_CODE", payload: "KE" });
        dispatch({ type: "SET_RECV_CURRENCY_CODE", payload: "KES" });
      } else if (data.groupId === "MF") {
        dispatch({ type: "SET_SEND_COUNTRY_CODE", payload: "US" });
        dispatch({ type: "SET_SEND_CURRENCY_CODE", payload: "USD" });
        dispatch({ type: "SET_RECV_COUNTRY_CODE", payload: "IN" });
        dispatch({ type: "SET_RECV_CURRENCY_CODE", payload: "INR" });
      } else if (data.groupId === "CSB") {
        dispatch({ type: "SET_SEND_COUNTRY_CODE", payload: "AE" });
        dispatch({ type: "SET_SEND_CURRENCY_CODE", payload: "AED" });
        dispatch({ type: "SET_RECV_COUNTRY_CODE", payload: "IN" });
        dispatch({ type: "SET_RECV_CURRENCY_CODE", payload: "INR" });
      } else {
        dispatch({ type: "SET_SEND_COUNTRY_CODE", payload: "GB" });
        dispatch({ type: "SET_SEND_CURRENCY_CODE", payload: "GBP" });
        dispatch({ type: "SET_RECV_COUNTRY_CODE", payload: "IN" });
        dispatch({ type: "SET_RECV_CURRENCY_CODE", payload: "INR" });
      }

      dispatch({ type: "SET_TWOFA", payload: data.twofa ? "Y" : "N" });
      // dispatch({ type: "SET_TWOFA", payload:  'N' });
      dispatch({ type: "SET_SESSION_ID", payload: config.sessionId });
      dispatch({ type: "SET_USER_FULL_NAME", payload: "" });

      // sendCountryCode: state.groupId == 'ICA' ? "CA" : "GB",
      // sendCurrencyCode: state.groupId == 'ICA' ? "CAD" : "GBP",
    },
    savePublicKey: (pubKey) => {
      dispatch({ type: "SET_PUBLIC_KEY", payload: pubKey });
    },
  };
};

// export default connect(mapStateToProps, mapDispatchToProps)(App)
export default connect(null, mapDispatchToProps)(App);
