import React from "react";
import { useSelector } from "react-redux";

const Cookie = React.lazy(() => import("./XR"));

const CookiePolicy = () => {
  const AuthReducer = useSelector((state) => state);
  switch (AuthReducer.groupId) {
    case "KCB":
      return <div>To be updated soon</div>;
      break;

    case "XR":
      return <Cookie />;
      break;

    default:
      return <div>To be updated soon</div>;
      break;
  }
};

export default CookiePolicy;
