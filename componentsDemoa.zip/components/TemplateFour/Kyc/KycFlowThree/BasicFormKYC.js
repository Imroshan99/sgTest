import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import {
  Form,
  Input,
  Tabs,
  Select,
  notification,
  Spin,
  Checkbox,
  Upload,
  Button,
  DatePicker,
  message,
  Modal,
} from "antd";
import moment from "moment";
import { Link, useNavigate, useLocation, useOutletContext } from "react-router-dom";
import Swal from "sweetalert2";
import { useDispatch, useSelector } from "react-redux";

import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import useHttp from "../../../../hooks/useHttp";
import { inputValidations } from "../../../../services/validations/validations";
import CustomInput from "../../../../reusable/CustomInput";
import { ViAmericaJumioAPI } from "../../../../apis/ViAmericaApi/JumioAPI";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import { getProcessingPartner } from "../../../../services/utility/group";
import { setKycDoneFrmTxnValidate } from "../../../../reducers/userReducer";

const { Option } = Select;
const countryCodeList = [{ countryName: "United States of America", countryPhoneCode: "1" }];
const BasicFormKYC = (props) => {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const { inputFields } = ConfigReducer.groupIdSettings.kyc;
  // console.log(AuthReducer);
  const [loading, setLoader] = useState(0);

  const [isJumioKYCVisible, setIsJumioKYCVisible] = useState(false);

  let navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();
  const { setTitle } = useOutletContext();

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    userID: AuthReducer.userID,
    userFullName: AuthReducer.userFullName,

    stateLists: [],
    cityLists: [],
    profileData: [],

    stateListsIssuer: [],
    issuerCountryList: [],
  });

  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookEditProfileChangeCountry = useHttp(ProfileAPI.editProfileChangeCountry);

  useEffect(() => {
    setTitle("Complete Basic KYC");
    getStateLists();
    getUserProfile();
  }, []);
  const getUserProfile = async () => {
    let payload = {
      requestType: "USERPROFILE",
      userId: AuthReducer.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookGetProfile.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ profileData: data });
        // autoFillKYC(data);
      } else {
        notification.error({
          message: data.errorMessage ? data.errorMessage : "Get Profile failed.",
        });
      }
    });
  };
  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.sendCountryCode,
      keyword: "",
    };

    setLoader((prevState) => prevState + 1);
    hookGetCountryStates.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        const stateIssuerArray = [
          ...data.responseData,
          {
            stateCode: "OTHER",
            state: "Other",
          },
        ];
        setState({ stateListsIssuer: stateIssuerArray });
      }
    });
  };
  const onSelectStateHandler = async (stateCode) => {
    form.setFieldsValue({ city: "" });
    const cityPayload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.sendCountryCode,
      stateCode: stateCode,
    };

    setLoader((prevState) => prevState + 1);
    hookGetStateCities.sendRequest(cityPayload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      } else {
        setState({
          cityLists: [],
        });
      }
    });
  };
  const onFinish = (value) => {
    let clientID;
    if (getProcessingPartner(AuthReducer.sendCountryCode) === "VIAMERICAS") {
      clientID = {
        clientId: "VIAMERICAS",
      };
    }
    let editProfilePayload = {
      ...clientID,
      requestType: "EDITPROFILE",
      userId: AuthReducer.userID,
      occupation: state._occupationId,
      homePhoneNo: "",
      companyName: value.companyName,
      emailId: state.profileData.emailId,
      pageName: "EDITPROFILE",
      ssn: value.ssn ? value.ssn : "",
      passportExpiryDt:
        state.profileData.passportExpiryDt == "1900-01-01"
          ? ""
          : state.profileData.passportExpiryDt,
      address5: state.profileData.address5,
      pep: "",
      passportIssueDate: "",
      address4: "",
      profession: "606",
      isSameCommAddressFlag: "Y",
      motherMaidenName: "",
      marketingCommunication: "",
      tnc: "Y",
      primaryBusinessFunction: "",
      firstName: state.profileData.firstName,
      nationality: "US",
      flatNo: "",
      dob: state.profileData.dob,
      SIN: value.ssn ? value.ssn : "",
      salutation: "",
      periodicUpdate: "",
      passportIssuePlace: "",
      income: "0",
      lastName: state.profileData.lastName,
      gender: state.profileData.gender ? state.profileData.gender : "M",

      // data for viamerica
      employer: value.companyName,
      employerPhoneCode: value.employerPhoneCode,
      employerPhoneNo: value.employerPhoneNumer,

      // address
      address1: window.btoa(value.address1),
      address2: window.btoa(value.address2),
      address3: "",
      state: window.btoa(value.state),
      city: window.btoa(value.city),
      zipCode: value.zipCode.replace(/\s/g, ""),
      sendCountry: AuthReducer.sendCountryCode,

      // communication address
      commAddress1: window.btoa(value.address1),
      commAddress2: window.btoa(value.address2),
      commStateProvince: value.state,
      commCity: value.city,

      commPostalCode: value.zipCode.replace(/\s/g, ""),
      commCountry: AuthReducer.sendCountryCode,

      documentType: value.idtype,
      industry: state._industryId,
      title: "",
      isEmailVerified: "Y",
      sourceOfFund: state._sourceOfFundId,
      drivingLicenseNo: value.idtype === "DL" ? value.id_number : "",
      mobilePhoneCode: state.profileData.mobilePhoneCode,
      // clientId: "VIAMERICAS",
      extraInfoRequire: "", //Y
      citizenship: "US", //US
      mobileNo: state.profileData.mobileNo,
      isMobileVerified: "Y",

      middleName: state.profileData.middleName,
      uniqueIdentifierType: value.idtype,
      uniqueIdentifierValue: value.id_number,
    };
    setLoader((prevState) => prevState + 1);
    hookEditProfileChangeCountry.sendRequest(editProfilePayload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        notification.success({
          message: "Congratulations on completing the KYC.",
        });
        // if (props.fromReview) {
        //   props.setState({ viewTarnsaction: true });
        // } else {
          dispatch(setKycDoneFrmTxnValidate(true));
          navigate("/new-transaction", {
            state: {
              fromPageState: location?.state?.fromPageState,
              // autoFillData: location?.state?.autoFillData,
              // autoFill: location?.state?.autoFill,
            },
          });
        // }
      } else {
        notification.error({
          message: data.errorMessage ? data.errorMessage : "Edit Profile change country failed.",
        });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };
  return (
    <div>
      <Spin spinning={loading === 0 ? false : true} delay={500}>
        <Row className="justify-content-center ">
          <Col lg={10} md={12}>
            <div className="">
              <Form
                form={form}
                onFinish={onFinish}
                // initialValues={{
                //   sendCountry: sendCountryConstant(),
                //   commCountry: sendCountryConstant(),
                // }}
              >
                <Row className="justify-content-center">
                  <Col md={12}>
                    <label className="form-label">
                      <span className="red_ast">*</span>Sender Address
                    </label>

                    <CustomInput name="address1" label="Address" showLabel={false} required>
                      <Input.TextArea placeholder="Address" />
                    </CustomInput>
                  </Col>
                  <Col md={4}>
                    <label className="form-label">
                      <span className="red_ast">*</span>State
                    </label>
                    <CustomInput
                      type="select"
                      showLabel={false}
                      label="State"
                      className="w-100"
                      placeholder="Select State"
                      showSearch
                      name="state"
                      onChange={onSelectStateHandler}
                      required
                    >
                      {state.stateLists.map((st, i) => {
                        return <Option key={i} value={st.state}>{`${st.state}`}</Option>;
                      })}
                    </CustomInput>
                  </Col>
                  <Col md={4}>
                    <label className="form-label">
                      <span className="red_ast">*</span>City
                    </label>

                    <CustomInput
                      type="select"
                      showLabel={false}
                      label="City"
                      name="city"
                      className="w-100"
                      placeholder="Select City"
                      showSearch
                      required
                    >
                      {state.cityLists.map((st, i) => {
                        return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                      })}
                    </CustomInput>
                  </Col>
                  <Col md={4}>
                    <label className="form-label">
                      <span className="red_ast">*</span>
                      Zipcode / Postal Code
                    </label>
                    <CustomInput
                      showLabel={false}
                      label="Zipcode / Postal Code"
                      name="zipCode"
                      validationRules={[...inputValidations.zipCode(AuthReducer.sendCountryCode)]}
                      placeholder="Zipcode / Postal Code"
                      required
                    />
                  </Col>
                  <Col md={12}>
                    <div className="d-flex justify-content-end">
                      <Link to={"/"} className="btn btn-secondary me-3 my-3">
                        Back
                      </Link>
                      <button
                        className="btn btn-primary text-white my-3"
                        type="submit"
                        // onClick={() => setIsICICI(true)}
                      >
                        Continue
                      </button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </div>
          </Col>
        </Row>
      </Spin>
    </div>
  );
};
export default BasicFormKYC;
