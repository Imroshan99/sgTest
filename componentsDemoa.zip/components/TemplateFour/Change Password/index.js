import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import ChangePasswordFlowOne from "./ChangePasswordFlowOne/ChangePasswordFlowOne";
import ChangePasswordFlowTwo from "./ChangePasswordFlowTwo/ChangePasswordFlowTwo";
import { useOutletContext } from "react-router-dom";
import { useEffect } from "react";

const ChangePassword = (props) => {
  const { setTitle } = useOutletContext();
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.changePasswordForm?.flow;
  useEffect(() => {
    setTitle("Change Password");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <ChangePasswordFlowOne
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
      {templateFlow === "FLOW2" && (
        <ChangePasswordFlowTwo
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default ChangePassword;
