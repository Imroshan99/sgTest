import { Form, Input, Button, Select } from "antd";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import useHttp from "../../../../hooks/useHttp";
import CustomInput from "../../../../reusable/CustomInput";

export default function RecipientRequestNickNameForm({
  record,
  nickNameHandler,
}) {
  const [form] = Form.useForm();
  const [nickName, setNickName] = useState("");
  const [validateStatus, setValidateStatus] = useState("");
  const AuthReducer = useSelector((state) => state.user);

  const hookCheckRecvNickName = useHttp(ReceiverAPI.checkRecvNickName);
  // console.log('nick', record.nickName)
  useEffect(() => {
    form.setFieldsValue({
      nickName : record.nickName
    })
    if(nickName != record.nickName){
      setValidateStatus('')
    }
  }, [record.nickName]);

  useEffect(() => {
    const timeOutId = setTimeout(() => {
      if (nickName) {
        checkRecvNickNameHandler();
      }
    }, 500);
    return () => clearTimeout(timeOutId);
  }, [nickName]);

  const checkRecvNickNameHandler = () => {
    const payload = {
      requestType: "RECVNICKNAME",
      userId: AuthReducer.userID,
      nickName: nickName,
    };
    hookCheckRecvNickName.sendRequest(payload, (res) => {
      if (res.status === "S") {
        setValidateStatus("success");
        nickNameHandler(nickName, record.recordToken);
      } else {
        setValidateStatus("error");
        form.setFields([
          {
            name: "nickName",
            errors: [res.errorMessage],
          },
        ]);
      }
    });
  };

  return (
    <Form
      form={form}
      initialValues={{
        nickName: record.nickName,
      }}
    >
      {/* {record.nickName} */}
      <CustomInput
        name="nickName"
        validateStatus={validateStatus}
        hasFeedback
        min={3}
        max={40}
        label="Nick Name"
        showLabel={false}
        onChange={(e) => {
          setNickName(e.target.value);
        }}
        validationRules={[
          {
            pattern: /^[a-zA-Z0-9]+$/,
            message: "No Special Chars",
          },
        ]}
        required
      />
       
    </Form>
  );
}
