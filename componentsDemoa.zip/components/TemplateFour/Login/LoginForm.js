import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Menu, Dropdown } from "antd";

import Spinner from "../../../reusable/Spinner";

import CustomInput from "../../../reusable/CustomInput";

function LoginForm(props) {
  const { loading, onFinish, form } = props;
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    form.setFieldsValue({ loginpassword: "" });
  }, []);

  const menu = (
    <Menu>
      <Menu.Item>
        <Link to="/forgot-password">Forgot Password?</Link>
      </Menu.Item>
      <Menu.Item>
        <Link to="/unlock-account">Unlock Account?</Link>
      </Menu.Item>
    </Menu>
  );

  return (
    <div className="login-right">
      <h1 className="title mb-4">Log In</h1>
      <div className="mb-3">
        <p className="subtitle">
          Not Registered?{" "}
          <Link to="/signup">
            <span>Register here</span>
          </Link>
        </p>

        <div>
          <div className="row">
            <div className="col-md-12">
              <Form form={form} onFinish={onFinish} autoComplete="none">
                <div className="mb-2">
                  <CustomInput
                    name="loginId"
                    label="Email"
                    type="email"
                    // validationRules={[{ min: 3, message: "minimum 3 char" }]}
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCut={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    required
                  />
                </div>

                <div className="mb-2">
                  <CustomInput
                    className="form-item"
                    name="loginpassword"
                    type="password"
                    label="Password"
                    min={10}
                    max={20}
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCut={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    required
                  />
                </div>

                <Spinner spinning={loading}>
                  <div className="d-grid g-2">
                    <button
                      disabled={loading}
                      className="btn btn-primary btn-lg my-1"
                      type="submit"
                    >
                      Login
                    </button>
                  </div>
                </Spinner>
                <Dropdown
                  overlay={menu}
                  trigger={["click"]}
                  placement="bottomLeft"
                  arrow
                >
                  <p role="button" className="btn-link mt-5 text-center">
                    Problems Signing In?
                  </p>
                </Dropdown>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginForm;
