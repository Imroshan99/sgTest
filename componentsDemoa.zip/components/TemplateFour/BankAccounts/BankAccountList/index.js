import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import BankAccountListFlow1 from "./BankAccountListFlow1/BankAccountList";
import Dashboard from "../../Layouts/Dashboard";
import { useOutletContext } from "react-router-dom";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const BankAccountList = (props) => {
  const { setTitle } = useOutletContext();
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow =
    AuthReducer.groupIdSettings?.bankAccount?.bankAccountList?.flow;

  useEffect(() => {
    setTitle("Bank Account List");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <BankAccountListFlow1 manageAuth={props.manageAuth} />
      )}
      {templateFlow === "FLOW2" && (
        <BankAccountListFlow1 manageAuth={props.manageAuth} />
      )}
    </>
  );
};

export default BankAccountList;
