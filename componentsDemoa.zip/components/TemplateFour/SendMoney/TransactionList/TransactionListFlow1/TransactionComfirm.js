import { Col, Form, Modal, Row } from "antd";
import React from "react";
import { useSelector } from "react-redux";
import CustomInput from "../../../../../reusable/CustomInput";
import { LuluTransactionAPI } from "../../../../../apis/LuluApi/TransactionAPI";
import Swal from "sweetalert2";
import useHttp from "../../../../../hooks/useHttp";

const TransactionComfirm = (props) => {
  const [form] = Form.useForm();
  const { setIsBankModalVisible, isBankModalVisible, selectTxnDetails, setSelectTxnDetails, getTransactionList } = props;
  const AuthReducer = useSelector((state) => state.user);

  const hookConfirmTransaction = useHttp(LuluTransactionAPI.confirmTransaction);

  const onFinish = (value) => {
    const payloadConfirmTrn = {
      requestType: "LULUENQUIRETRANSACTION",
      userId: AuthReducer.userID,
      bankRefNumber: value?.bankRefNo,
      transactionRefNumber: selectTxnDetails?.luluTransactionId,
    };

    hookConfirmTransaction.sendRequest(payloadConfirmTrn, function (data) {
      if (data.status == "S") {
        setIsBankModalVisible(false);
        setSelectTxnDetails(false);
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            getTransactionList(null);
          }
        });
      } else {
      }
    });
  };
  return (
    <Modal
      className="primary"
      centered
      visible={isBankModalVisible}
      onCancel={() => {
        setSelectTxnDetails(null);
        setIsBankModalVisible(false);
      }}
      width={600}
      footer={null}
    >
      <Form form={form} onFinish={onFinish}>
        <Row>
          <Col md={24}>
            <div className="">
              <label className="form-label">
                <span className="red_ast">*</span>Bank Reference Number
              </label>
              <CustomInput
                className="form-item"
                label="Bank Reference Number"
                showLabel={false}
                name="bankRefNo"
                type="text"
                placeholder="Enter your Bank Reference Number"
                maxLength={20}
                min={6}
                required
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCopy={(e) => {
                  e.preventDefault();
                  return false;
                }}
              />
            </div>
          </Col>
          <Col md={12}>
            <button className="btn btn-primary text-white my-3" type="submit">
              Confirm
            </button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
};

export default TransactionComfirm;