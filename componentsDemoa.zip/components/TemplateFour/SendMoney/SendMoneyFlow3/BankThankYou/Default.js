import React, { createRef, useState } from "react";
import LocalPrintshopIcon from "@mui/icons-material/LocalPrintshop";
import StarIcon from "@mui/icons-material/Star";
import HomeIcon from "@mui/icons-material/Home";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import { notification } from "antd";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { useSelector } from "react-redux";

import { Link } from "react-router-dom";
import useHttp from "../../../../../hooks/useHttp";
import { PDFDownloadLink } from "@react-pdf/renderer";
import ViaReceipt from "../../TransactionList/TransactionListFlow1/Invoice/ViaReceipt";

function DefaultBankThankYou(props) {
  const AuthReducer = useSelector((state) => state.user);

  const invRef = createRef();

  const [isFav, setFav] = useState(false);
  const txnReceiptDetail = props.state.txnReceiptDetails;

  const hookTxnFaviorate = useHttp(TransactionAPI.txnFaviorate);

  const onClickFavourite = () => {
    let payload = {
      requestType: "FAVOURITETRANSACTION",
      favouriteFlag: isFav ? "0" : "1",
      rgtn: txnReceiptDetail.rgtn,
      userId: props.state.userID,
    };

    hookTxnFaviorate.sendRequest(payload, function (data) {
      if (data.status === "S") {
        if (isFav) {
          notification.success({
            message:
              "Transaction has been removed from favourite successfully.",
          });
        } else {
          notification.success({
            message: "Transaction has been added to favourite successfully.",
          });
        }
        setFav(!isFav);
      }
    });
  };

  const savePDF = () => {
    // const input = document.getElementById("divToPrint");

    html2canvas(invRef.current).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      pdf.addImage(imgData, "JPEG", 0, 0);
      // pdf.output('dataurlnewwindow');
      pdf.save(`${txnReceiptDetail.txnRefNumber}.pdf`);
    });
  };
  return (
    <div className="container p-5">
      <div className="row">
        <div className="col-md-1"></div>
        <div className="col-md-10">
          <section className="text-center">
            <h2>Transaction Booked Successfully</h2>
          </section>
          <section className="my-3 text-center">
            <Link className="btn btn-secondary mx-1  mt-2" to={"/"}>
              <HomeIcon />
            </Link>
            <PDFDownloadLink
          document={<ViaReceipt txnReceiptDetail={txnReceiptDetail}/>}
          fileName={`Via.pdf`}
        >
          {({ loading }) =>
            loading ? (
              <span>loading...</span>
            ) : (
              <button
              className="btn btn-secondary mx-1  mt-2"
              // onClick={savePDF}
              type="button"
            >
              <LocalPrintshopIcon className="me-2" />
              Download Receipt
            </button>
            )
          }
        </PDFDownloadLink>
           

            <button className="btn btn-secondary mx-1  mt-2">
              {!isFav ? (
                <StarBorderIcon className="me-2" onClick={onClickFavourite} />
              ) : (
                <StarIcon className="me-2" onClick={onClickFavourite} />
              )}
              Add To Favourite
            </button>

            <Link className="btn btn-secondary mx-1 mt-2" to={"/"}>
              <AddCircleOutlineIcon className="me-2" />
              Make Another Transfer
            </Link>
          </section>
          <section className="bg-light p-3 mt-3" ref={invRef}>
            <div>
              <img
                src={`images/${AuthReducer.groupId}/logo.png`}
                height="48px"
                alt="Logo"
              />
            </div>
            <p className="mt-3">
              Money transfer request to Muthoot Finance Remit Account
              authorized. <br />
              Transaction Status- Transaction Booked Successfully and awaiting
              payment.
            </p>
            <p className="mt-3">
              1. Note down your MFTN : <b>{txnReceiptDetail.txnRefNumber}</b>
            </p>
            <p className="mt-3">
              2. Login to Internet banking of your local bank account.
            </p>
            <p className="mt-3">
              3. Go to funds transfer section and make us a beneficiary/
              recipient.
            </p>
            <p className="mt-3">
              4. Enter the beneficiary/ recipient information as below :
            </p>
            <p className="mt-3">
              <table className="table">
                <tbody>
                  <tr>
                    <td>
                      <strong>Transaction Number</strong>
                    </td>
                    <td>{txnReceiptDetail.txnRefNumber}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Date of Booking:</strong>
                    </td>
                    <td>{txnReceiptDetail.bookingDate}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Transfer Amount:</strong>
                    </td>
                    <td>{`${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Name:</strong>
                    </td>
                    <td>{txnReceiptDetail.receiverName}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Bank Branch:</strong>
                    </td>
                    <td>{txnReceiptDetail.recvBankBranchName}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Receiver&rsquo;s Account Number:</strong>
                    </td>
                    <td>{txnReceiptDetail.recvAccNumber}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Send Mode:</strong>
                    </td>
                    <td>{txnReceiptDetail.sendModeCode}</td>
                  </tr>
                  <tr>
                    <td>
                      <strong>Transaction Status:</strong>
                    </td>
                    <td>{txnReceiptDetail.transactionStatus}</td>
                  </tr>
                </tbody>
              </table>
            </p>
            <p className="mt-3">
              Note : Please mention your Muthoot Finance Transcation No. (MFTN)
              : {txnReceiptDetail.txnRefNumber} in "reference description
              details" in your Internet banking website when you do the
              transfer. This will help us to trace your money.
            </p>
            <p className="mt-3">
              5. Enter the amount to be transferred as being{" "}
              {`${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`}
              . (Also make sure you{" "}
              {`${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`}{" "}
              i.e. the exact same amount that you have done a booking for.)
            </p>
            <p className="mt-3">6. Confirm the transcation.</p>
          </section>
        </div>
      </div>
    </div>
  );
}

export default DefaultBankThankYou;
