import React from "react";
import { useSelector } from "react-redux";
import RecipientInfo1 from "./RecipientInfoFlow1/RecipientInfo";
import RecipientInfo2 from "./RecipientInfoFlow2/RecipientInfo";
import Dashboard from "../Layouts/Dashboard";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const RecipientInfo = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow =
    AuthReducer.groupIdSettings?.recipientModule?.RecipientInfo?.flow;

  return (
    <>
      {templateFlow === "FLOW1" && (
        <RecipientInfo1
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
      {templateFlow === "FLOW2" && (
        <RecipientInfo2
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default RecipientInfo;
