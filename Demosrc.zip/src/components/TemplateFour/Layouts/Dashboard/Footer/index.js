import Footer1 from "./Footer1";

export default function Footer() {
  return (
    <footer>
      <Footer1 />
    </footer>
  );
}
