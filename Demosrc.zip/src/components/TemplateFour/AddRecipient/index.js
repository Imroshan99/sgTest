import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import AddReipient2 from "./AddRecipientFlow2/AddRecipient";
import AddReipient1 from "./AddRecipientFlow1/AddRecipient";
import Dashboard from "../Layouts/Dashboard";
import { useOutletContext } from "react-router-dom";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const AddReipient = (props) => {
  const { setTitle } = useOutletContext();
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow =
    AuthReducer.groupIdSettings?.recipientModule?.AddRecipientForm?.flow;
  const modalFlow =
    AuthReducer.groupIdSettings?.recipientModule?.AddRecipientForm?.modal
      ?.modal;

  useEffect(() => {
    setTitle("Add Recipients");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <AddReipient1 appState={props.appState} manageAuth={props.manageAuth} />
      )}
      {templateFlow === "FLOW2" && (
        <AddReipient2 appState={props.appState} manageAuth={props.manageAuth} />
      )}
    </>
  );
};

export default AddReipient;
