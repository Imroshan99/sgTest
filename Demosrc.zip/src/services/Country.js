export const COUNTRY = {
  GB: {
    countryCurrency: "GBP",
    isoCountrycode: "GBR",
    countryName: "United Kingdom",
    countryCode: "GB",
  },
  US: {
    countryCurrency: "USD",
    isoCountrycode: "US",
    countryName: "United States of America",
    countryCode: "US",
  },
  IN: {
    countryCurrency: "INR",
    isoCountrycode: "IN",
    countryName: "India",
    countryCode: "IN",
  },
  NP: {
    countryCurrency: "NPR",
    isoCountrycode: "NP",
    countryName: "Nepal",
    countryCode: "NP",
  },
};
