import React, { useEffect } from "react";
import { Link, useOutletContext } from "react-router-dom";

const FAQ = () => {
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("FAQ's");
  }, []);
  return (
    <div>
      <section className="section">
        <div className="container">
          <h5 className="mt-1 mb-3">Q 1. What is CG PAY money transfers?</h5>
          <p className="text-3 text-muted">CG PAY is a personalized online remittance service offered by CGPAY Nepal. CG PAY ensures quick money transfers to Nepal by Non-Resident Nepalese living overseas. The service is user friendly, provides global coverage, multiple payments & delivery modes and above all, it has the lowest service charges.</p>
          <h5 className="mt-1 mb-3">Q 2. Which currencies can you use to make a remittance?</h5>
          <p className="text-3 text-muted">Currently you can make a remittance in United States of America (USD).</p>
          <h5 className="mt-1 mb-3">Q 3. Whom can you send money to using CG PAY?</h5>
          <p className="text-3 text-muted">You can only send money to your own account or to a family member's account or to a friend's account using CG PAY.</p>
          <h5 className="mt-1 mb-3">Q 4. Why should you use CG PAY Money Transfers?</h5>
          <p className="text-3 text-muted">
            CG PAY Money Transfers enable you to satisfy the financial needs of your loved ones quickly, safely and conveniently from across the seven seas. CG PAY, our cutting edge money remittance service is far better than the traditional money transfers options like cheques, money transfer agents and wire transfers. The service is user friendly, provides global coverage, multiple payments & delivery modes and above all, it has the lowest service charges. Enjoy peace of mind with our "always
            there" customer support via phone, chat and e-mail.
          </p>
          <h5 className="mt-1 mb-3">Q 5. Are CG PAY Money Transfers safe?</h5>
          <p className="text-3 text-muted">
            CG PAY Money Transfers does not share the personal information provided by you with any third party (unless, of course, we are required to do so by law!). For details, read our Privacy Policy Moreover, CG PAY Money Transfer lets you put in money into your CG PAY account either by a local wire transfer via your bank account or an Online Transfer that directly debits your local bank account. This money can then be used by you to either remit money to your loved ones in Nepal or to pay
            for purchases made on Nepal websites. When you put in money in your CG PAY account either by wire transfer or online transfer, you will be reassured to know that no debit appears in your bank account unless you have personally authorized it. All transactions are carried out across secure encrypted lines and state-of-the-art firewalls, which have been put through extensive security tests to ensure that the integrity of the security system cannot be compromised.
          </p>
          <h5 className="mt-1 mb-3">Q 6. What is the CG PAY Transaction Number or CGPTN?</h5>
          <p className="text-3 text-muted">
            The CG PAY Transaction Number or CGPTN is the unique number displayed on your screen at the time of booking your remittance. It is reference number for your transaction. You can know the exact status of your transfer by simply clicking on your CGPTN on our Online Status Tracker. Whether you are sending an email or chatting with us online about your money transfer, you always need to quote your CGPTN. While sending a wire transfer to the recipient's bank via your local bank, you need
            to fill in your CGPTN on the Remittance Confirmation Page. On completion of a transaction at CG PAY Money Transfers, you must submit a printout of this page to your bank. This step is required by your local bank to process your money transfer.
          </p>
          <h5 className="mt-1 mb-3">Q 7. Is there a limit on the number of beneficiaries that you can remit money to?</h5>
          <p className="text-3 text-muted">No. You can send money to as many recipients as you wish. CG PAY has an Address Book tool in which you can store your receivers' details.</p>
          <h5 className="mt-1 mb-3">Q 8. Do you or your beneficiary need to open any special bank account?</h5>
          <p className="text-3 text-muted">No. You can continue using your existing bank account for the money transfer.</p>
          <h5 className="mt-1 mb-3">Q 9. Do I need to sign up for an account to send money through CG PAY? Do I need to pay any fees to sign up for a CG PAY account?</h5>
          <p className="text-3 text-muted">To send money through CG PAY, you need to first join us by registering on our website - Registration is absolutely free. After you create an account, CG PAY stores your relevant details and your receivers' information in your user profile. You can easily send money later on without re-entering payment and recipient information. All information stored in your account is secure and will not be shared or made available to anyone else.</p>
          <h5 className="mt-1 mb-3">Q 10. How long will it take to complete the enrollment? Do I have to wait to start using the service once I enroll?</h5>
          <p className="text-3 text-muted">It takes just about 5 minutes or less to complete the enrollment forms. No, there is no waiting time. Once you complete the enrollment process, you can immediately begin using the service.</p>
          <h5 className="mt-1 mb-3">Q 11. What is CG PAY's privacy policy?</h5>
          <p className="text-3 text-muted">
            <Link to="/privacy-policy">Click here</Link> to read our Privacy Policy.
          </p>
          <h5 className="mt-1 mb-3">Q 12. What is CG PAY' User agreement?</h5>
          <p className="text-3 text-muted">
            {" "}
            <Link to="/privacy-policy">Click here</Link> to read our User agreement.
          </p>
          <h5 className="mt-1 mb-3">Q 13. What are the sending options available to me?</h5>
          <p className="text-3 text-muted">
            CIP/Internet Transfer - Internet Bank Transfer is the easiest way to send money electronically to most banks. You can simply transfer the funds by logging into your local Internet banking service. Wire transfer - A Wire Transfer to CG PAY usually enables you to transfer money from your existing overseas bank account to Nepal in 48 hours. CG PAY provides you with a unique tracking number to help you track the status of your transaction at any point of time.
          </p>
          <h5 className="mt-1 mb-3">Q 14. What are the receiving options available to my recipients?</h5>
          <p className="text-3 text-muted">Direct Deposit - All remittances can be directly deposited to the account of the beneficiary specified by you as soon as CG PAY receives your remittance. You can also transfer money into your own bank account in Nepal. To check list of banks, click here.</p>
          <h5 className="mt-1 mb-3">Q 15. What is an indicative rate? At what rate will my money actually be paid out?</h5>
          <p className="text-3 text-muted">
            Our customers can depend on the 'indicative rates' as a reasonable estimate of the exchange rate at which their transfer will take place eventually. The actual conversion rate of CG PAY is the rate applied on the morning the day your funds get converted in Nepal. The conversion rate may differ from the current indicative rate. For example, if CG PAY says that the indicative rate of USD/NPR is 1 USD = NPR 100, that indicative rate may reduce to 1 USD = NPR 99 or it may also increase
            to 1 USD = NPR 101 at the moment of the actual conversion.
          </p>
          <h5 className="mt-1 mb-3">Q 16. What is a fixed exchange rate?</h5>
          <p className="text-3 text-muted">
            To safeguard yourself from any fluctuations in currency rates try our fixed exchange rate option. The money will be paid out to you at this rate only irrespective of any fluctuations in actual rates. However, you should complete the transfer within 1 working day itself or else transfer will be auto cancelled. Your transaction could be delayed because of the following reasons: You do not send the money into our account for the purpose of transfer. You do not submit adequate KYC
            documents or answer our KYC call for the purpose of verification. We are unable to trace your funds. In such a case you would have to re-book a transfer with the same amount at the prevailing rate.
          </p>
          <h5 className="mt-1 mb-3">Q 17. How do I use the exchange rate calculator?</h5>
          <p className="text-3 text-muted">
            The exchange rate calculator is used for informational purposes only. The rates in this calculator do not represent the actual rate that will be applied to your transaction. This calculator provides an approximation.
            <Link to="/">To view exchange rate calculator, click here.</Link>
          </p>
          <h5 className="mt-1 mb-3">Q 18. When will a transaction be processed?</h5>
          <p className="text-3 text-muted">
            CG PAY can only begin processing your transaction request once the money is received in our account in the sending country. We shall pay out the money within 1 working day itself. However, if you are a new user, then it can take 2-3 working days as we will first need to do KYC verification. Also take into account that all days must be bank working days in the sending country and in Nepal. Cut Off Timing: 1st Day of transaction will be considered, if bank transfer from your account to
            CG PAY's account happens before the below mentioned cut off timings Country Time USA 3pm GMT Monday to Friday* Excluding Bank Holidays in all countries *Booking date will not be considered as the first transaction date.
          </p>
          <h5 className="mt-1 mb-3">Q 19. What is the KYC (Know your customer) process for CG PAY?</h5>
          <p className="text-3 text-muted">When you do a transaction with CG PAY for the first time a KYC verification call will be done and if required one would have to furnish a scanned valid photo id and address proof. When you add a new recipient to your CG PAY account, a verification call will be made regarding the transfer. Valid Address proofs, rent agreement, Company Letter, Electricity\Utility bill, Bank Statement, Driving License, Id proof, Passport Driving License.</p>
          <h5 className="mt-1 mb-3">Q 20. What does 'delivery date' mean?</h5>
          <p className="text-3 text-muted">
            This is the date the funds should be available to the beneficiary for the CG PAY transaction. We cannot always guarantee the availability of funds on a particular date because of the differences in time zones, holiday lists and general processing schedules of different countries. The delivery date indicated by us for the transaction should be considered only as an estimate rather than the actual date for availability of funds. We advise you to check the CG PAY Status Tracker to
            confirm that your funds have been received by the beneficiary. Please Note: CG PAY can only begin processing your transaction request once the money is received in our account in the sending country.
          </p>
          <h5 className="mt-1 mb-3">Q 21. On what holidays will the remittances not be processed?</h5>
          <p className="text-3 text-muted">Remittances will not be processed on weekends and on the following bank holidays.</p>
          <h5 className="mt-1 mb-3">Q 22. How will I know when my recipient has received the money?</h5>
          <p className="text-3 text-muted">
            CG PAY provides this information to you via email notifications and on the CG PAY Status Tracker. We will send a series of email notifications informing you of the status of your transaction. The first email is sent shortly after you submit a CG PAY transaction. The second email is sent when your payment has been cleared and CG PAY assigns responsibility of your transaction to our partner in the recipient's country. Upon completion of the transaction, you will receive another email
            informing you that your recipient has received the funds.
          </p>
          <h5 className="mt-1 mb-3">Q 23. How do I repeat a remittance which I had done before?</h5>
          <p className="text-3 text-muted">To avoid the painstaking process of booking a transfer with the same details again we have introduced the repeat a remittance feature, wherein a list of remittances done in the past is displayed and in order to repeat the transfer you have to just click on the button next to it.</p>
          <h5 className="mt-1 mb-3">Q 24. Are there any additional fees?</h5>
          <p className="text-3 text-muted">No, there are no additional fees.</p>
          <h5 className="mt-1 mb-3">Q 25. How do I unlock my account?</h5>
          <p className="text-3 text-muted">
            We have created an account unlock option on the login page. This will help you to unlock your account instantly. You can unlock your account only once in 24 hours. Alternatively, please email an 'unlock request' to customer support email address from your registered ID. For more details, contact our customer support team by <Link to="/unlock-account">clicking here</Link>.
          </p>
          <h5 className="mt-1 mb-3">Q 26. What if I am having problems signing in to my CG PAY account?</h5>
          <p className="text-3 text-muted">
            In case you cannot log-in to your valid CG PAY account, please contact our customer support team for assistance. For details contact our Customer Support, <Link to="/contact">click here</Link>.
          </p>
          <h5 className="mt-1 mb-3">Q 27. How do I change my CG PAY account settings?</h5>
          <p className="text-3 text-muted">After logging into your CG PAY account, click on the Account Settings link in the My Profile section of the menu on the left hand side of the page. Make the required changes and save them.</p>
          <h5 className="mt-1 mb-3">Q 28. How do I add a receiver?</h5>
          <p className="text-3 text-muted">After logging into your CG PAY account, click on the My Receivers tab on the left hand side of the page. Enter the required details of the new receiver here and save them.</p>
          <h5 className="mt-1 mb-3">Q 29. How do I close my CG PAY account?</h5>
          <p className="text-3 text-muted">
            If you wish to close your CG PAY account, please contact our customer support team to understand the closure process. For details contact our Customer Support, <Link to="/contact">click here</Link>.
          </p>
          <h5 className="mt-1 mb-3">Q 30. How do I change my CG PAY password?</h5>
          <p className="text-3 text-muted">After logging into your CG PAY account, click on the Change Password link in the My Profile section of the menu, on the left hand side of the page. Make the required changes and save it.</p>
          <h5 className="mt-1 mb-3">Q 31. What if I forget my CG PAY password?</h5>
          <p className="text-3 text-muted">You need to be logged out. You need to click on the Forgot Password link in the login box on the home page. Enter the requested details and you will receive an email with a new password. Use this password to log in again. When you access your account, change the password according to your preference.</p>
          <h5 className="mt-1 mb-3">Q 32. I want to block my account as I believe that my password has been leaked?</h5>
          <p className="text-3 text-muted">We advise you to frequently change your password and maintain total secrecy about your login details to prevent fraudulent misuse of your CG PAY account. In case you need to block your account, just send an email to customer support from the email ID you had earlier registered with us.</p>
          <h5 className="mt-1 mb-3">Q 33. What is the exchange rate applied on my remittance?</h5>
          <p className="text-3 text-muted">
            The exchange rate applicable on your remittance is based on the existing rate for the day that your funds get converted to Nepali Rupees. On the day that you book your remittance, the prevailing exchange rate for that particular day is shown to you on our online rate calculator only as an indication. So you will know the approximate amount your beneficiaries in Nepal will receive in Nepali rupees for the remittance that you will be sending to them in your local currency.
          </p>
          <h5 className="mt-1 mb-3">Q 34. How can I view the Exchange Rate for the day?</h5>
          <p className="text-3 text-muted">
            You can view the exchange rate for the day by using the online exchange rate calculator on our website. <Link to="/">Click here for today's exchange rates</Link>.
          </p>
          <h5 className="mt-1 mb-3">Q 35. What is the transfer fee for sending money to Nepal?</h5>
          <p className="text-3 text-muted">The following transfer fee will be applicable for sending money to Nepal.</p>
        </div>
      </section>
    </div>
  );
};

export default FAQ;
