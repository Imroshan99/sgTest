import { Route } from "react-router-dom";

import Login from "./../Login/index";
import SignUp from "./../Registration";

import ForgotPassword from "./../Login/ProblemsLogin/ForgotPassword";
import UnlockAccount from "./../Login/ProblemsLogin/UnlockAccount";
import HomePage from "../../../pages/LandingPage";

import { useSelector } from "react-redux";
import AuthTemplate from "../Layouts/Auth";
import { PublicRoute } from "../../../Routes/PublicRoute";

const AuthRoutes = (state, manageAuth) => {
  const AuthReducer = useSelector((state) => state.user);

 
  return (
    <Route element={<AuthTemplate />}>
      
      {/* <Route element={<TestNew />} > */}

      {/* Auth Routes */}
      <Route
        path="/signin"
        element={
          <PublicRoute>
            <Login manageAuth={manageAuth} />
          </PublicRoute>
        }
      />

      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/unlock-account" element={<UnlockAccount />} />
      <Route path="/signup" element={<SignUp />} />

      
    </Route>
  );
};

export default AuthRoutes;
