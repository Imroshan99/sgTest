import React from "react";
import "./style.scss";
import "./groupid.scss";
import { Helmet } from "react-helmet";
import { PublicRoute } from "./../../Routes/PublicRoute";
import { Outlet, Route, Routes, useLocation } from "react-router-dom";

import { useSelector } from "react-redux";

import PageNotFound from "./PageNotFound";
import DashboardRoutes from "./Routes/DashboardRoutes";
import AuthRoutes from "./Routes/AuthRoutes";
import HomePage from "../../pages/LandingPage";
// export function TestNew() {
//   const [dt, setDt] = useState(new Date())
//   useEffect(()=> {
//     setDt(new Date())
//   }, [])
//   return (
//     <>
//       <div>My subheader {dt.toISOString()}</div>
//       <Outlet />
//     </>
//   );
// }

export default function TemplateFour({
  state,
  manageRefreshToken,
  manageAuth,
}) {
  const AuthReducer = useSelector((state) => state.user);

  const _title = AuthReducer.groupIdSettings?.title;

  return (
    <>
      <Helmet>
        <title>{_title}</title>
        <meta name="description" content={_title} />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href={`images/${AuthReducer.groupId}/favicon.ico`}
        />
        {/* <noscript>{`<link rel="stylesheet" type="text/css" href="foo.css" />`}</noscript> */}
      </Helmet>
      <Routes>
        <Route
          path="/"
          element={
            <PublicRoute>
              <HomePage />
            </PublicRoute>
          }
        />
        {AuthRoutes(state, manageAuth)}
        {DashboardRoutes(state, manageAuth)}

        
      </Routes>
    </>
  );
}
