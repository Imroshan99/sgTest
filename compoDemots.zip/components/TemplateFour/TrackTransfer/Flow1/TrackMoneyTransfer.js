import { Stepper, Step, StepLabel } from "@mui/material";
import React, { useEffect, useReducer } from "react";
import { useLocation } from "react-router-dom";
import { useSelector } from "react-redux";


import { TransactionAPI } from "../../../../apis/TransactionAPI";
import useHttp from "../../../../hooks/useHttp";



function TrackMoneyTransfer(props) {
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);

  const steps = [
    "Transfer Initiated",
    `${ConfigReducer.groupIdSettings.title} Received funds in Local Currency` ,
    `Currency converted to ${AuthReducer.recvCurrencyCode}`,
    `${ConfigReducer.groupIdSettings.title} has received funds`,
    "Credited to Recipients Bank account"
  ];

  //   const { pathData } = props.location;
  //   console.log(location.rgtn);
  //   console.log(props);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      trackingDetails: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      rgtn: location.state.rgtn,
    }
  );

  const hookTrackTranscation = useHttp(TransactionAPI.trackTranscation);

  useEffect(() => {
    trackTranscation();
  }, []);

  const trackTranscation = () => {
    let transactiondata = {
      requestType: "TRACKMYTRANSFER",
      rgtn: state.rgtn,
      userId: state.userID,
    };

    hookTrackTranscation.sendRequest(transactiondata, function (data) {
      setState({ trackingDetails: data });
    });
  };

  return (
    <div className="container">
      <section className="my-5 text-center">
        <h5>Tracking ID - {state.trackingDetails.txnRefNo} </h5>
      </section>

      <section>
        <Stepper activeStep={state.trackingDetails.pictograph} alternativeLabel>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </section>
      <ht />

      <section>
        <div className="row text-center my-5">
          <div className="col-md-4">
            <strong>Current Status</strong>
            <br />
            {state.trackingDetails.statusDescription}
          </div>
          <div className="col-md-4">
            <strong>Estimate Date of Delivery</strong>
            <br />
            {state.trackingDetails.expectedDeliveryDate}
          </div>
          <div className="col-md-4">
            <strong>Call us for Assistance</strong>
            <br />
           {AuthReducer.groupId === 'KCB' ? '+0 8081 314 151' : ''} 
          </div>
        </div>
      </section>
    </div>
  );
}

export default TrackMoneyTransfer;
