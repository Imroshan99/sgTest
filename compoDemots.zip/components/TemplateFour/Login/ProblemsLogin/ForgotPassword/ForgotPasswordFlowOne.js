import React, { useState, useEffect, useReducer } from "react";
import { useNavigate } from "react-router-dom";
import { Form, Input, notification, Spin } from "antd";
import InputOTPBox from "../../../../../containers/InputOTPBox";
import { useSelector } from "react-redux";
import { AuthAPI } from "../../../../../apis/AuthAPI";
import useHttp from "../../../../../hooks/useHttp";
import SetNewPassword from "../SetNewPassword";

export default function ForgotPasswordFlowOne(props) {
  let navigate = useNavigate();

  const ConfigReducer = useSelector((state) => state.user);

  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const [current, setCurrent] = React.useState(0);
  const [showBtn, setShowBtn] = useState(true);
  const [loading, setLoader] = useState(false);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      isModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      twofa: "Y",
      // twofa: ConfigReducer.twofa,
      formData: {},
      _isShowOTPBOX: false,
      _isShowSuccessMessage: false,
      otpType: "FP",
    }
  );

  const hookForgotPassword = useHttp(AuthAPI.forgotPassword);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const onCreateLead = (value) => {
    let forgotPasswordPayload = {
      requestType: "FORGOTPASSWORD",
      loginId: value.loginId,
      dob: "",
      verifyType: value.verifyType,
    };

    setLoader(true);
    hookForgotPassword.sendRequest(forgotPasswordPayload, (res) => {
      if (res.status == "S") {
        if (value.verifyType === "O") {
          setState({ verificationToken: res.verificationToken });
          if (state.twofa == "N") {
            setState({
              isModalVisible: true,
              formData: value,
            });
          } else {
            setState({
              _isShowOTPBOX: true,
              isModalVisible: true,
              formData: value,
            });
            setShowBtn(false);
          }
        }
        if (value.verifyType === "L") {
          notification.success({ message: res.message });
          navigate("/signin");
        }
      } else {
        setLoader(false);
        notification.error({ message: res.errorMessage });

        let errors = [];
        res.data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) {
          if (value.verifyType === "O") {
            form.setFields(errors);
          }
          if (value.verifyType === "L") {
            form1.setFields(errors);
          }
        }
      }
      setLoader(false);
    });
  };

  return (
    // <div className="container-fluid __t2">
    //   <div className="row">
      
    //     <div className="col-12 col-md-7 col-xl-6 col-xxl-5 p-5 align-self-center">

          // <div className="login-right">
            <div>
              <h1 className="title mb-4">Forgot Password</h1>

              <div className="row">
                <div className="col-md-12">
                  {state._isShowSuccessMessage == false ? (
                    <>
                      <Form
                        form={form}
                        initialValues={{ verifyType: "O" }}
                        onFinish={onCreateLead}
                      >
                        <div md={2}>
                          <div className="">
                            <label className="step-label mb-1">
                              Enter User ID
                            </label>
                            <Form.Item
                              className="form-item"
                              name="loginId"
                              rules={[
                                {
                                  required: true,
                                  message: "Please enter user id",
                                },
                              ]}
                            >
                              <Input size="large" />
                            </Form.Item>
                          </div>
                          <div className="d-grid">
                            <Form.Item name="verifyType" hidden={true}>
                              <Input type={"hidden"} />
                            </Form.Item>
                            <Spin spinning={loading}>
                              {showBtn && (
                                <button className="btn btn-primary text-white w-100">
                                  {state.twofa == "Y"
                                    ? "Verify With OTP"
                                    : "Verify Without OTP"}
                                </button>
                              )}
                            </Spin>
                          </div>
                        </div>
                      </Form>

                      {state._isShowOTPBOX && (
                        <InputOTPBox
                          state={state}
                          setState={setState}
                          otpType={state.otpType}
                          useFor="forgot_password"
                          appState={props.appState}
                          setCurrent={setCurrent}
                        />
                      )}
                    </>
                  ) : (
                    <SetNewPassword
                      state={state}
                      setState={setState}
                      appState={props.appState}
                    />
                  )}
                </div>
              </div>
            </div>
          // </div>

    //     </div>
    //   </div>
    // </div>
  );
}
