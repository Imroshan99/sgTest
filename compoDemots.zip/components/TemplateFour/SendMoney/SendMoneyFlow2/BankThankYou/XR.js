import React, { createRef, useState } from "react";
import LocalPrintshopIcon from "@mui/icons-material/LocalPrintshop";
import StarIcon from "@mui/icons-material/Star";
import HomeIcon from "@mui/icons-material/Home";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import { notification } from "antd";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { useSelector } from "react-redux";

import { Link } from "react-router-dom";
import useHttp from "../../../../../hooks/useHttp";

function XRBankThankYou(props) {
  const AuthReducer = useSelector((state) => state.user);

  const invRef = createRef();

  const [isFav, setFav] = useState(false);
  const txnReceiptDetail = props.state.txnReceiptDetails;

  const hookTxnFaviorate = useHttp(TransactionAPI.txnFaviorate);

  const onClickFavourite = () => {
    let payload = {
      requestType: "FAVOURITETRANSACTION",
      favouriteFlag: isFav ? "0" : "1",
      rgtn: txnReceiptDetail.rgtn,
      userId: props.state.userID,
    };

    hookTxnFaviorate.sendRequest(payload, function (data) {
      if (data.status === "S") {
        if (isFav) {
          notification.success({
            message:
              "Transaction has been removed from favourite successfully.",
          });
        } else {
          notification.success({
            message: "Transaction has been added to favourite successfully.",
          });
        }
        setFav(!isFav);
      }
    });
  };

  const savePDF = () => {
    html2canvas(invRef.current, {
      // x: window.scrollX,
      // y: window.scrollY,
      windowWidth: "1200px",
      // windowHeight: window.innerHeight,
      scale: 1,
    }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF();
      pdf.addImage(imgData, "JPEG", 0, 0);
      // pdf.output('dataurlnewwindow');
      pdf.save(`${txnReceiptDetail.txnRefNumber}.pdf`);
    });
  };
  return (
    <div className="container p-0 p-md-5">
      <div className="row">
        <div className="col-md-1"></div>
        <div className="col-md-10">
          <section className="text-center">
            <h2>Transaction Booked Successfully</h2>
          </section>
          <section className="my-3 text-center">
            <Link className="btn btn-secondary mx-1 mt-2" to={"/"}>
              <HomeIcon />
            </Link>

            <button
              className="btn btn-secondary mx-1  mt-2"
              onClick={savePDF}
              type="button"
            >
              <LocalPrintshopIcon className="mx-2" />
              View and Download Receipt
            </button>

            <button className="btn btn-secondary mx-1  mt-2">
              {!isFav ? (
                <StarBorderIcon className="mx-2" onClick={onClickFavourite} />
              ) : (
                <StarIcon className="mx-2" onClick={onClickFavourite} />
              )}
              Add To Favourite
            </button>

            <Link className="btn btn-secondary mx-1 mt-2 " to={"/"}>
              Make Another Transfer
            </Link>
          </section>
          <section className="bg-light p-3 mt-3" ref={invRef}>
            <div>
              <img
                src={require("../../../../../assets/images/logos/" +
                  AuthReducer.groupId +
                  "_logo.png")}
                height="48px"
              />
            </div>
            <p className="mt-3">
              <span>DONE</span>
              Step 1 : Money Transfer Request to XMONIES
              <br />
              Status: Transaction successfully booked. Funds awaited.
              <br />
              Please note that Guaranteed Rate will be applicable only if we
              receive the funds within 24 hours of transaction booking.
              <br />
              Your XMONIES Transaction No. (XRTN) :
              <b>{txnReceiptDetail.txnRefNumber}</b>
            </p>

            <p className="mt-3">
              <span>PENDING</span>
              Step 2 : Transfer Money to XMONIES Bank Account
              <br />
              We have received your transaction request for{" "}
              {`${txnReceiptDetail.amountPayable} ${AuthReducer.sendCurrencyCode}`}
              . The unique reference number for this transaction request is{" "}
              {txnReceiptDetail.txnRefNumber}. Please follow the steps mentioned
              below to enable us to process your request:
              <br />
              Kindly print the Wire Transfer form and present it to your local
              bank.
              <br />
              <ol>
                <li>
                  Approach your local bank in United Kingdom for initiating a
                  wire transfer transaction
                </li>
                <li>
                  Instruct your local bank to route the transaction though our
                  bank details mentioned below mentioning{" "}
                  {txnReceiptDetail.txnRefNumber} in the additional information
                  usually field 70 or 72 of the SWIFT message
                </li>
              </ol>
              We shall process your transaction post receiving the money in our
              account.
              <table border="0" width="100%" cellspacing="0" cellpadding="0">
                <tbody>
                  <tr>
                    <td width="30%">
                      <strong>Name On The Account:</strong>
                    </td>
                    <td>RFX CLIENT AC GBP LLOYDS</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>Bank Account Number:</strong>
                    </td>
                    <td>00569643</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>Partner / Correspondent Bank:</strong>
                    </td>
                    <td>Lloyds Bank</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>Swift Code:</strong>
                    </td>
                    <td>LOYDGB21F43</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>Sort Code:</strong>
                    </td>
                    <td>304065</td>
                  </tr>
                  <tr></tr>
                  <tr>
                    <td width="30%">
                      <strong>IBAN:</strong>
                    </td>
                    <td>GB33LOYD30406500569643</td>
                  </tr>
                  <tr></tr>

                  <tr>
                    <td width="30%">
                      <strong>XMONIES Transaction Number </strong>
                    </td>
                    <td>{txnReceiptDetail.txnRefNumber}</td>
                  </tr>
                </tbody>
              </table>
              <span>
                (Please ensure that you enter the XMONIES Transaction Number in
                the Wire Transfer instruction)
              </span>
            </p>

            <p>
              All charges to be paid by me
              <br />
              <b>Important Information:</b>
              <ol>
                <li>
                  Please ensure that the account from which the money is sent
                  belongs to you. In case of any discrepancy, the transaction
                  may be rejected or the processing may get delayed.
                </li>
                <li>
                  The exchange rate at which the money is converted is the rate
                  prevailing on the day on conversion of funds by Bank.
                </li>
                <li>XMONIES Payment Policy &amp; Error Resolution.</li>
              </ol>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

export default XRBankThankYou;
