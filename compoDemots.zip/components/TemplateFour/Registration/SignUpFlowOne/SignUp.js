import React, { useState, useEffect, useReducer } from "react";
import { Link } from "react-router-dom";
import { Dropdown, Menu, Steps } from "antd";
import SetPassword from "./SetPasswordFlowOne";
import { useSelector } from "react-redux";
import SignUpStep1 from "./SignUpStep1";
import SignUpStep2 from "./SignUpStep2";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";

const { Step } = Steps;

export default function SignUp(props) {
  const ConfigReducer = useSelector((state) => state.user);
  const [stepsData, setStepData] = useState({});

  const [current, setCurrent] = useState(0);
  const [sendCountryState, SetSendCountryState] = useState();
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      phoneCodes: [],
      sendCountryList: [],
      isModalVisible: false,
      tcModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      twofa: ConfigReducer.twofa,
      dob: "",
      formData: {},
      _isShowOTPBOX: false,
      _isShowSetPassword: false,
    }
  );
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetUserCountryList = useHttp(GuestAPI.countryList);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };

    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      if (data.status === "S") {
        // setState({ phoneCodes: data.responseData });
        const phoneCodeStatic = [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
        ];
        setState({ phoneCodes: phoneCodeStatic });
      }
    });

    const dataCountry = {
      requestType: "SENDCOUNTRYLIST",
    };
    hookGetUserCountryList.sendRequest(dataCountry, function (data) {
      if (data.status === "S") {
        setState({ sendCountryList: data.responseData });
      }
    });
  }, []);

  const steps = [
    {
      step: 1,
      title: "Step 1",
    },
    {
      step: 2,
      title: "Step 2",
    },
    {
      step: 3,
      title: "Step 3",
    },
  ];

  const menu = (
    <Menu>
      <Menu.Item>
        <Link to="/forgot-password">Forgot Password?</Link>
      </Menu.Item>
      <Menu.Item>
        <Link to="/unlock-account">Unlock Account?</Link>
      </Menu.Item>
    </Menu>
  );

  return (
    <div >
      <h1 className="title mb-4">Sign Up</h1>
      <div className="signup-form">
        <div className="step-div">
          <>
            <Steps
              responsive={false}
              size="small"
              progressDot
              current={current}
              className="mb-4"
            >
              {steps.map((item) => (
                <Step key={item.title} title={item.title} />
              ))}
            </Steps>
            {current === 0 && (
              <SignUpStep1
                state={state}
                setState={setState}
                setStepData={setStepData}
                setCurrent={setCurrent}
              />
            )}
            {current === 1 && (
              <SignUpStep2
                state={state}
                setState={setState}
                stepsData={stepsData}
                setStepData={setStepData}
                setCurrent={setCurrent}
                SetSendCountryState={SetSendCountryState}
              />
            )}
            {current === 2 && (
              <SetPassword
                state={state}
                setState={setState}
                appState={props.appState}
                stepsData={stepsData}
                sendCountryState={sendCountryState}
              />
            )}
          </>
          <br />
          <Link to="/">
            <h6 className="text-center text-primary">
              <strong>Return to Login</strong>
            </h6>
          </Link>
          <Dropdown
            overlay={menu}
            trigger={["click"]}
            placement="bottomLeft"
            arrow
          >
            <p role="button" className="btn-link mt-5 text-center">
              Problems Signing Up ?
            </p>
          </Dropdown>
        </div>
      </div>
    </div>
  );
}
