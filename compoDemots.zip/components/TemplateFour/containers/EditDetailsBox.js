import React, { useEffect } from "react";
import { Form, Select, Modal } from "antd";
import { Row } from "react-bootstrap";
import Spinner from "../../../reusable/Spinner";
import CustomInput from "../../../reusable/CustomInput";

const { Option } = Select;

export default function EditDetailsBox(props) {
  const [form] = Form.useForm();
  useEffect(() => {
    console.log("props.state", props.state);
    form.setFieldsValue({
      occupation: props.state.occupation_id,
      remittance_freq: props.state.frequency,
      sourceOfFund: props.state.sourceFundId,
    });
  }, []);

  const onFinish = (value) => {
    props.setState({
      occupation_id: value.occupation,
      frequency: value.remittance_freq,
      sourceOfFundId: value.sourceOfFund,
      _editAddressBoxBtn: true,
    });
  };

  return (
    <>
      <Modal centered className="primary" width={600} visible={props.state._isShowEditDetailModal} onCancel={() => props.setState({ _isShowEditDetailModal: false })} footer={null}>
        <Form form={form} onFinish={onFinish}>
          <Spinner spinning={props.loader}>
            <div className="d-flex justify-content-center align-items-center">
              <Row className="justify-content-center">
                <Row>
                  <div className="mb-3">
                    <h4>Other Details</h4>
                  </div>
                </Row>
                <Row>
                  <label className="form-label">Occupation</label>
                  <CustomInput className="form-item" name="occupation" type="select" label="Occupation" showLabel={false} required placeholder="Select Occupation" showSearch>
                    {props.state.occupationLists.map((list, i) => {
                      return (
                        <Option key={i} value={list.occupationId}>
                          {list.occupationDesc}
                        </Option>
                      );
                    })}
                  </CustomInput>
                   
                </Row>
                <Row>
                  <label className="form-label">Remittance Frequency</label>
                  <CustomInput className="form-item" name="remittance_freq" label="Remittance Frequency" showLabel={false} type="select" placeholder="Select Remittance Frequency" showSearch required>
                    <Option value="WEEKLY">Weekly</Option>
                    <Option value="MONTHLY">Monthly</Option>
                    <Option value="QUARTERLY">Quarterly</Option>
                    <Option value="ANNUALLY">Annually</Option>
                    <Option value="ONE_OFF">One-Off</Option>
                  </CustomInput>
                   
                </Row>

                <Row>
                  <label className="form-label">Source of Fund</label>
                  <CustomInput className="form-item" name="sourceOfFund" placeholder="Select Source of Fund" showSearch label="Source of Fund" showLabel={false} required type="select">
                    {props.state.sourceOfFundList.map((list, i) => {
                      return (
                        <Option key={i} value={list.sourceFundId}>
                          {list.sourceOfFund}
                        </Option>
                      );
                    })}
                  </CustomInput>
                  
                </Row>

                <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                  <button className="btn btn-danger btn-block px-4" onClick={() => props.setState({ _isShowEditDetailModal: false })} type="button">
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-secondary px-4">
                    Submit
                  </button>
                </div>
              </Row>
            </div>
          </Spinner>
        </Form>
      </Modal>
    </>
  );
}
