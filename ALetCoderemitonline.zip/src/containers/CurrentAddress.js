import React, { useState, useEffect } from 'react';
import { GuestAPI } from '../apis/GuestAPI';
import { Form, Select, Input, AutoComplete, Spin } from 'antd';
import { Row, Col } from 'react-bootstrap';

const { Option } = AutoComplete;

function CurrentAddress(props) {

    const [form] = Form.useForm();
    const [loading, setLoader] = useState(false);
    const [serachAddressData, setSerachAddressData] = useState([]);

    useEffect(() => {
        form.setFieldsValue({
            streetName: props.state.address1,
            houseBuildingName: props.state.address3,
            country: props.state.country,
            district: props.state.state,
            postTown: props.state.city,
            postcode: props.state.zip,
        })
    }, [])

    const onSearch = (searchText) => {
        GuestAPI.searchAddress(searchText)
            .then(res => {
                let resText = [];
                res.data.Items.forEach(d => {
                    let desc = '';
                    if (d.Description != '') {
                        desc = `(${d.Description})`;
                    }

                    let data = {
                        id: d.Id,
                        searchTerm: d.Text,
                        text: d.Text + desc,
                        next: d.Next,
                        description: d.Description
                        // description: d.Description.replace(' Results', '')
                    }
                    resText.push(data)
                });
                setSerachAddressData(resText);
            });
    };

    const findSubAddress = (id, searchTerm) => {

        GuestAPI.findSubAddress(id, searchTerm)
            .then(res => {
                let resText = [];
                // console.log(res.data)
                res.data.Items.forEach(d => {
                    let desc = '';
                    if (d.Description != '') {
                        desc = `(${d.Description})`;
                    }

                    let data = {
                        id: d.Id,
                        text: d.Text + desc,
                        next: d.Next,
                        description: d.Description
                    }
                    resText.push(data)
                });
                setSerachAddressData(resText);
            });

    };

    const onSelect = (data) => {
        let address = JSON.parse(data);
        props.setState({ mainAddress: address.text })

        if (address.next == 'Find') {
            findSubAddress(address.id, address.searchTerm)
        } else {
            GuestAPI.selctedSearchAddress(address.id)
                .then(res => {
                    if (res.data.Items.length > 0) {
                        let getAddress = res.data.Items[0];
                        form.setFieldsValue({
                            houseBuildingName: getAddress.BuildingName,
                            streetName: getAddress.Street,
                            country: getAddress.CountryName,
                            district: getAddress.Province,
                            postTown: getAddress.AdminAreaName,
                            postcode: getAddress.PostalCode,
                        })
                    }
                });
        }

        // GuestAPI.selctedSearchAddress(address.id)
        //     .then(res => {
        //         console.log('data', res.data)

        //         if (res.data.Items.length > 0) {
        //             let getAddress = res.data.Items[0];
        //             form.setFieldsValue({
        //                 houseBuildingName: getAddress.BuildingName,
        //                 streetName: getAddress.Street,
        //                 country: getAddress.CountryName,
        //                 district: getAddress.Province,
        //                 postTown: getAddress.AdminAreaName,
        //                 postcode: getAddress.PostalCode
        //             })
        //         }
        //     });
    };

    const onFinish = (value) => {
        props.setState({
            address1: value.streetName,
            address3: value.houseBuildingName,
            country: value.country,
            state: value.district,
            city: value.postTown,
            zip: value.postcode,
            isStep: 3
        })
    }

    return (
        <div className='mt-4' style={{ backgroundColor: '#f1f5f6' }}>
            <div class="alert bg-primary text-white" role="alert">
                Current Address
            </div>
            <div className="bg-white shadow-sm rounded p-4 mb-4">
                <Form
                    form={form}
                    onFinish={onFinish}
                >
                    <div className="d-flex justify-content-center align-items-center">
                        <Row className='justify-content-center'>

                            <Col md={12}>
                                <p>Enter Postcode such as HA1 2HJ</p>
                                <Form.Item
                                    className="form-item"
                                    name="address"
                                    rules={[
                                        { required: true, message: 'Please input your Address.' }
                                    ]}
                                >
                                    {/* <AutoComplete
                                                autoComplete="off"
                                                size="large"
                                                placeholder="Enter Postcode such as HA1 2HJ"
                                                optionFilterProp="children"
                                                onSelect={onSelect}
                                                onSearch={onSearch}
                                            >
                                                {
                                                    serachAddressData.map((search, i) => {
                                                        return (
                                                            <Option key={i} value={JSON.stringify(search)}>
                                                                <lable>{search.text}</lable>
                                                            </Option>
                                                        )
                                                    })
                                                }
                                            </AutoComplete> */}

                                    <Select className='w-100'
                                        showSearch
                                        onSearch={onSearch}
                                        onSelect={onSelect}
                                        placeholder="Enter Postcode such as HA1 2HJ"
                                    >
                                        {
                                            serachAddressData.map((rec, i) => {
                                                return (
                                                    <Option key={i} value={JSON.stringify(rec)}>{`${rec.text}`}</Option>
                                                )
                                            })
                                        }
                                    </Select>

                                </Form.Item>

                            </Col>
                            <Col md={12}>
                                <label className="form-label">House / Building Name</label>
                                <Form.Item
                                    className="form-item"
                                    name="houseBuildingName"
                                // rules={[
                                //     { required: true, message: 'Please input House / Building Name.' }
                                // ]}

                                >
                                    <Input readOnly size="large" placeholder="Enter House / Building Name" />
                                </Form.Item>

                            </Col>

                            <Col md={12}>
                                <label className="form-label">Street Name</label>
                                <Form.Item
                                    className="form-item"
                                    name="streetName"
                                    rules={[
                                        { required: true, message: 'Please input your Street Name.' }
                                    ]}

                                >
                                    <Input readOnly size="large" placeholder="Enter your Street Name" />
                                </Form.Item>
                            </Col>

                            <Col md={6}>
                                <label className="form-label">Country</label>
                                <Form.Item
                                    className="form-item"
                                    name="country"
                                    rules={[
                                        { required: true, message: 'Please input your Country.' }
                                    ]}
                                >
                                    <Input readOnly size="large" placeholder="Enter your Country" />
                                </Form.Item>
                            </Col>

                            <Col md={6}>
                                <label className="form-label">Postcode</label>
                                <Form.Item
                                    className="form-item"
                                    name="postcode"
                                    rules={[
                                        { required: true, message: 'Please input your Postcode.' }
                                    ]}

                                >
                                    <Input readOnly size="large" placeholder="Enter your Postcode" />
                                </Form.Item>
                            </Col>

                            <Col md={6}>
                                <label className="form-label">District</label>
                                <Form.Item
                                    className="form-item"
                                    name="district"
                                // rules={[
                                //     { required: true, message: 'Please input your District.' }
                                // ]}

                                >
                                    <Input readOnly size="large" placeholder="Enter your District" />
                                </Form.Item>
                            </Col>

                            <Col md={6}>
                                <label className="form-label">Post Town</label>
                                <Form.Item
                                    className="form-item"
                                    name="postTown"
                                // rules={[
                                //     { required: true, message: 'Please input your Post Town.' }
                                // ]}

                                >
                                    <Input readOnly size="large" placeholder="Enter your Post Town" />
                                </Form.Item>
                            </Col>

                            <Spin spinning={loading} delay={500}>
                                <div className="d-grid gap-2 d-flex mt-4">
                                    <button className="btn btn-sm px-4"
                                        type='button'
                                        onClick={() => props.setState({ isStep: 1 })}
                                    >Back</button>

                                    <button className="btn btn-sm px-4"
                                        type='button'
                                        onClick={() => props.setState({ isStep: 3 })}
                                    >Save For Later</button>

                                    <button className="btn btn-primary btn-sm text-white px-4 btn-sm">Review</button>
                                </div>
                            </Spin>
                        </Row>
                    </div>
                </Form >
            </div>
        </div >
    );
}

export default CurrentAddress;
