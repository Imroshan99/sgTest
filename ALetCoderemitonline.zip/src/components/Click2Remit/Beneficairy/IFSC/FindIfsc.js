import React, { useEffect, useReducer, useState } from "react";

import BackArrow from "../../../../assets/images/click2remit/Back_arrow.svg";
import CustomInput from "../../../../reusable/CustomInput";
import FloatInput from "../../../../reusable/FloatInput";
import { AutoComplete, Form, notification, Select } from "antd";
import Main from "../../Layouts/Main";
import useHttp from "../../../../hooks/useHttp";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { useSelector } from "react-redux";
import BranchDetails from "../../BankAccounts/BranchDetails";
import Chevronright from "../../../../assets/images/click2remit/Chevronright.svg";
import Spinner from "../../../../reusable/Spinner";

const { Option } = Select;

const FindIfsc = (props) => {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);

  const [loader, setLoader] = useState(0);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    bankLists: [],
    stateLists: [],
    cityLists: [],
    findIfscComponent: true,
    cityCodeForBankBranch: "",
    stateCodeForBankBranch: "",
    bankCodeForIfsc: "",
    bankNameForIfsc: "",
  });
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getBankList();
    getStateLists();
    // getBankBanchDetails();
    // onSelectBank();
  }, []);
  useEffect(() => {
    if (props?.state?.beneficiaryBankDetails?.bankName) {
      form.setFieldsValue({
        bankName: props?.state?.beneficiaryBankDetails?.bankName,
      });
    } else {
      form.setFieldsValue({
        bankName: props?.state?.beneBankName,
      });
    }
  }, [props?.state]);

  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGebankBranches = useHttp(ReceiverAPI.bankBranches);
  const hookGetBankStateCities = useHttp(ReceiverAPI.bankStateCities);

  // const onSelectBank = () => {
  //   const payload = {
  //     requestType: "BankStateCities",
  //     countryCode: AuthReducer.recvCountryCode,
  //     state: "",
  //     bankName: props?.state?.beneBankAndAcctNo?.bankName?.value
  //       ? props?.state?.beneBankAndAcctNo?.bankName?.value
  //       : props?.state?.beneficiaryBankDetails?.bankName,
  //     search: "",
  //   };
  //   setLoader((prevState) => prevState + 1);
  //   hookGetBankStateCities.sendRequest(payload, function (data) {
  //     setLoader((prevState) => prevState - 1);
  //     if (data.status === "S") {
  //     }
  //   });
  // };

  const getBankList = async (e) => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.recvCountryCode,
      userId: AuthReducer.userID,
    };
    setLoader((prevState) => prevState + 1);
    hookGetBankLists.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
      }
    });
  };
  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: "IN",
      keyword: "",
    };
    setLoader((prevState) => prevState + 1);
    hookGetCountryStates.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        let activeState = data.responseData.filter((state) => {
          return state.isActive == "Y";
        });
        setState({ stateLists: activeState });
        // const stateIssuerArray = [...data.responseData];
        // setState({ stateListsIssuer: stateIssuerArray });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const onSelectStateHandler = async (stateCode) => {
    form.setFieldsValue({ city: "" });
    setState({ stateCodeForBankBranch: stateCode });
    const payload = {
      requestType: "BankStateCities",
      countryCode: "IN",
      state: stateCode,
      bankName: props?.state?.beneBankName
        ? props?.state?.beneBankName
        : props?.state?.beneficiaryBankDetails?.bankName,
      search: "",
    };

    setLoader((prevState) => prevState + 1);
    hookGetBankStateCities.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      } else {
        notification.error({ message: data.errorMessage });
        setState({
          cityLists: [],
        });
      }
    });
  };
  const onSetectCity = async (cityName) => {
    setState({ cityCodeForBankBranch: cityName });
    const payload = {
      requestType: "BANKBRANCHES",
      countryCode: "IN",
      bankCode: props?.state?.beneficiaryBankCode,
      bankName: props?.state?.beneBankName,
      cityCode: "",
      stateCode: "",
      city: cityName,
      keyword: "",
    };

    setLoader((prevState) => prevState + 1);
    hookGebankBranches.sendRequest(payload, function (data) {
      setLoader((prevState) => prevState - 1);
      if (data.status === "S") {
        setState({
          branchLists: data.responseData,
        });
      }
    });
  };
  return (
    <>
      {state.findIfscComponent ? (
        <>
          <div class="container col-md-6 col-sm-12 col-lg-6 mobile-order-2 ">
            <div class="CR-account-form CR-otp-form">
              <Spinner spinning={loader === 0 ? false : true}>
                <Form
                  form={form}
                  onFinish={(values) => {
                    setState({ findIfscComponent: false });
                  }}
                  initialValues={{
                    bankName: props?.state?.beneBankAndAcctNo?.bankName?.value,
                  }}
                >
                  <fieldset>
                    <ul class="row">
                      <li class="col-md-12 col-sm-12 col-lg-12 ">
                        <h4 class="text-black ">IFSC Details</h4>
                      </li>
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <p class="text-left">Enter bank details to find IFSC.</p>
                      </li>
                      <legend></legend>
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        {/* <CustomInput showLabel={false} name="bankname" label=" Bank Name" required>
                    <FloatInput type="select" placeholder="Bank Name" />
                  </CustomInput> */}
                        <CustomInput
                          name="bankName"
                          label="Bank Name"
                          showLabel={false}
                          // type="select"
                          showSearch
                          labelInValue
                          placeholder="Select Bank"
                          required
                        >
                          <FloatInput
                            onChange={(e) => {
                              form.setFieldsValue({ state: "", city: "" });
                              let bankDetails = JSON.parse(e);
                              props.setState({
                                beneBankName: bankDetails.bankName,
                                beneficiaryBankCode: bankDetails.bankCode,
                                beneficiaryBankDetails: {},
                              });
                            }}
                            type="select"
                            placeholder="Select Bank Name"
                          >
                            {state.bankLists.map((bank, i) => {
                              return (
                                <Option key={i} value={JSON.stringify(bank)}>
                                  {bank.bankName}
                                  {/* <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                              
                            </span> */}
                                </Option>
                              );
                            })}
                          </FloatInput>
                        </CustomInput>
                      </li>
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <CustomInput
                          name="state"
                          placeholder="Select State"
                          label="State"
                          showLabel={false}
                          required
                        >
                          <FloatInput
                            type="select"
                            labelInValue
                            autoComplete="none"
                            placeholder="Select State"
                            className="w-100"
                            onSelect={onSelectStateHandler}
                            filterOption={(inputValue, option) =>
                              option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                            }
                          >
                            {state.stateLists.map((st, i) => {
                              return <Option key={i} value={st.state}>{`${st.state}`}</Option>;
                            })}
                          </FloatInput>
                        </CustomInput>
                      </li>
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <CustomInput name="city" label="City" showLabel={false} required>
                          <FloatInput
                            type="select"
                            autoComplete="none"
                            placeholder="Select City"
                            className="w-100"
                            onChange={onSetectCity}
                            filterOption={(inputValue, option) =>
                              option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                            }
                          >
                            {state.cityLists.map((st, i) => {
                              return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                            })}
                          </FloatInput>
                        </CustomInput>
                      </li>
                      <li class="col-md-12 col-sm-12 col-lg-12">
                        <div
                          className="d-flex justify-content-between"
                          onClick={() => {
                            if (state.stateCodeForBankBranch && state.cityCodeForBankBranch) {
                              setState({ findIfscComponent: false });
                            }
                          }}
                        >
                          <div className="d-flex justify-content-between flex-column">
                            <label style={{ fontSize: "20px" }} className="text-left CR-fw-500">
                              Select Branch
                            </label>
                            {/* <p className="CR-font-14 text-left CR-black-text CR-fw-600 mb-2"></p> */}
                          </div>
                          {/* <button onClick={() => { setState({ findIfscComponent: false }) }}>Select Branch</button> */}
                          <span className="align-self-end">
                            <img
                              style={{ marginBottom: "10px" }}
                              src={Chevronright}
                              width="24px"
                              height="24px"
                            />
                          </span>
                        </div>
                      </li>
                    </ul>
                    <div class="bottom_panel">
                      <div class="d-flex justify-content-between align-items-center gap-3 gap-md-5">
                        <span
                          class="Back_arrow d-flex align-items-center"
                          onClick={() => props.setState({ activeStepForm: 9 })}
                        >
                          <img src={BackArrow} alt="backArrow" />
                          Back
                        </span>
                        <button
                          style={{ maxWidth: "17rem" }}
                          htmlType="submit"
                          class=" CR-primary-btn"
                        >
                          Proceed
                        </button>
                      </div>
                    </div>
                  </fieldset>
                </Form>
              </Spinner>
            </div>
          </div>
        </>
      ) : (
        <>
          <BranchDetails
            cityCodeForBankBranch={state.cityCodeForBankBranch}
            stateCodeForBankBranch={state.stateCodeForBankBranch}
            state={props.state}
            setState={props.setState}
            parentState={setState}
          />
        </>
      )}
    </>
  );
};

export default FindIfsc;
