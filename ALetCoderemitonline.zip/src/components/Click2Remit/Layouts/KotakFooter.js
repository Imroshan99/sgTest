import c2r_logo from "../../../assets/images/click2remit/C2R_logo_pre1.png";

import linkedin from "../../../assets/images/click2remit/linkedin-png.png";
import facebook from "../../../assets/images/click2remit/facebook-png.png";
import twitter from "../../../assets/images/click2remit/twitter-png.png";
import youtube from "../../../assets/images/click2remit/youtube-png.png";
import { useNavigate } from "react-router";
import { Link } from "react-router-dom";

const KotakFooter = () => {
  const navigate = useNavigate();
  return (
    <>
      <div className="row mb-3">
        <div className="col-12 col-md-4">
          <Link to="/" className="navbar-brand">
            <img
              className="img-responsive"
              src={c2r_logo}
              alt="Click 2 Remit"
              width="300px"
              height="58.9px"
            />
          </Link>
          <div>
            <div
              className="d-flex gap-4 align-items-center mb-2 ml-5"
              style={{ marginLeft: "38px", height: "20px" }}
            >
              <a
                className="h-100"
                target="_blank"
                href="https://www.linkedin.com/company/kotak-mahindra-bank"
              >
                <img src={linkedin} height="100%" style={{ borderRadius: "7px" }} />
              </a>
              <a className="h-100" target="_blank" href="https://www.facebook.com/KotakBank/">
                <img src={facebook} height="100%" style={{ borderRadius: "7px" }} />
              </a>
              <a className="h-100" target="_blank" href=" https://twitter.com/kotakbankltd?lang=en">
                <img src={twitter} height="100%" style={{ borderRadius: "7px" }} />
              </a>
              <a
                className="h-100"
                target="_blank"
                href=" https://www.youtube.com/user/KotakBankIndia"
              >
                <img src={youtube} height="100%" style={{ borderRadius: "7px" }} />
              </a>
            </div>
            {/* <a href="https://www.facebook.com/KotakBank/">
          <img
            src={instagram}
            width="30px"
            height="100%"
            
          />
        </a> */}
          </div>
        </div>
        <div className="col-12 col-md-4">
          <h2>Help &amp; Support</h2>
          <ul class="list-footer-verticle mb-0">
            <li class="mb-2">
              <a
                onClick={() => {
                  navigate("/help-support", { state: { sidebar: false } });
                }}
                class=""
              >
                Contact Us
              </a>
            </li>
            <li class="mb-2">
              <a target="_blank" href="/" class="">
                Feedback
              </a>
            </li>
          </ul>
        </div>
        <div className="col-12 col-md-4">
          <h2>Quick Links</h2>
          <ul class="list-footer-verticle mb-0">
            <li class="mb-2">
              <a target="_blank" href="/" class="">
                Click2Remit USA
              </a>
            </li>
            {/* <li class="mb-2">
              <a target="_blank" href="/" class="">
                Click2Remit UK
              </a>
            </li> */}
          </ul>
        </div>
      </div>
      <section class="">
        <div class="row">
          <div className="col-12 col-md-12 ">
            <p className="text-center fs-14">
              Property of Kotak Mahindra Bank Limited. |
              <Link className="mx-2" to={"/disclaimer"}>
                Disclaimer
              </Link>
              |
              <Link className="mx-2" to={"/privacy-policy"}>
                Privacy Policy
              </Link>
              |
              <Link className="mx-2" to={"/terms-conditions"}>
                Terms &Conditions
              </Link>
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default KotakFooter;
