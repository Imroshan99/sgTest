import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import KycFlowOne from "./KycFlowOne/Kyc";
import KycFlowTwo from "./KycFlowTwo/Kyc";

const Kyc = (props) => {
    const AuthReducer = useSelector((state) => state.user);
    const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
    const templateFlow = AuthReducer.groupIdSettings?.kyc?.flow;
    return (
      <>
        <Dashboard pageTitle="KYC">
          {templateFlow === "FLOW1" && (
            <KycFlowOne
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
           {templateFlow === "FLOW2" && (
            <KycFlowTwo
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
          {/* {templateFlow === "FLOW2" && (
            <TransactionAction2
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )} */}
        </Dashboard>
      </>
    );
  };
  
  export default Kyc;
  