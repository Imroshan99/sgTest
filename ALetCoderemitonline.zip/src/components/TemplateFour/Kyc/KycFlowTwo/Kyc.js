import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Tabs, Select, notification, Spin, Checkbox, Upload, Button, DatePicker, message } from "antd";
import moment from "moment";
import { Link, useNavigate, useLocation } from "react-router-dom";
import Swal from "sweetalert2";
import { useSelector } from "react-redux";

import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
// import DefaultLayout from "../layout/DefaultLayout";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { config } from "../../../../config";
import { UploadOutlined } from "@ant-design/icons";
import { GuestAPI } from "../../../../apis/GuestAPI";
import useHttp from "../../../../hooks/useHttp";
import { inputValidations } from "../../../../services/validations/validations";
import CustomInput from "../../../../reusable/CustomInput";
const { TabPane } = Tabs;
const { Option } = Select;

const Kyc = (props) => {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const { inputFields } = ConfigReducer.groupIdSettings.kyc;
  // console.log(AuthReducer);
  const [loading, setLoader] = useState(false);
  const [issuerCountryDropdown, setIssuerCountryDropdown] = useState(false);
  const [docObj, setDocObj] = useState("");

  let navigate = useNavigate();
  const location = useLocation();

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    twofa: AuthReducer.twofa,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    userFullName: AuthReducer.userFullName,
    // sourceOFFundLists: [],
    additionalInfo2: "",
    occupationLists: [],
    uniqueIdentifierLists: [],
    stateLists: [],
    cityLists: [],
    profileData: [],

    stateListsIssuer: [],
    issuerCountryList: [],
    idIssuer: "",

    redirectPage: "",
    redirectPageState: [],
  });

  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);
  const hookUserDocUpload = useHttp(ProfileAPI.userDocUpload);

  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetUniqueIdentifierList = useHttp(GuestAPI.uniqueIdentifierList);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetCountryLists = useHttp(GuestAPI.countryList);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getUserProfile();
    // getSourceOFFundLists();
    getOccupationLists();
    getUniqueIdentifierNames();
    getStateLists();
    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
    console.log(location);
  }, []);

  const getUserProfile = async () => {
    let payload = {
      requestType: "USERPROFILE",
      userId: state.userID,
    };
    setLoader(true);
    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ profileData: data });
      }
    });
    setLoader(false);
  };

  const onSelectStateHandler = async (stateCode) => {
    const cityPayload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.sendCountryCode,
      stateCode: stateCode,
    };

    setLoader(true);
    hookGetStateCities.sendRequest(cityPayload, function (data) {
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      }
    });
    setLoader(false);
  };

  // const getSourceOFFundLists = () => {
  //   const data = {
  //     requestId: config.requestId,
  //     requestType: "FUNDSOURCELIST",
  //     channelId: config.channelId,
  //     clientId: state.clientId,
  //     groupId: state.groupId,
  //     sessionId: state.sessionId,
  //     ipAddress: "127.0.0.1",
  //   };

  //   if (config.IS_ENC) {
  //     var key = config.key;
  //     var iv = config.iv;
  //     var body = encrypt(data, key, iv);
  //     var pubValue = iv.concat(key);
  //     var identifier = publickey(props.appState.publicKey, pubValue);

  //     var postData = {
  //       body: body,
  //       identifier: identifier,
  //     };
  //   } else {
  //     var postData = data;
  //   }

  //   setLoader(true);
  //   TransactionAPI.sourceOFFundLists(postData, props.appState.accessToken)
  //     .then((res) => {
  //       if (config.IS_ENC) {
  //         var decode = decrypt(res.data.body, key, iv);
  //         var decodeData = JSON.parse(decode);
  //       } else {
  //         var decodeData = res.data;
  //       }

  //       if (decodeData.status == "S") {
  //         setState({ sourceOFFundLists: decodeData.responseData });
  //       }
  //       setLoader(false);
  //     })
  //     .catch((error) => setLoader(false));
  // };

  const getOccupationLists = async () => {
    let payload = {
      requestType: "LEAD",
    };

    setLoader(true);
    hookGetOccupationLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ occupationLists: data.responseData });
      }
    });
    setLoader(false);
  };

  const getUniqueIdentifierNames = async () => {
    let payload = {
      requestType: "UNNAMESLIST",
      idFor: "RECV",
    };

    setLoader(true);
    hookGetUniqueIdentifierList.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ uniqueIdentifierLists: data.responseData });
      }
    });
    setLoader(false);
  };

  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.sendCountryCode,
      keyword: "",
    };

    setLoader(true);
    hookGetCountryStates.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        const stateIssuerArray = [
          ...data.responseData,
          {
            stateCode: "OTHER",
            state: "Other",
          },
        ];
        setState({ stateListsIssuer: stateIssuerArray });
      }
    });
    setLoader(false);
  };

  const getIssuerCountryList = async () => {
    let payload = {
      requestType: "COUNTRYLIST",
    };

    setLoader(true);
    hookGetCountryLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ issuerCountryList: data.responseData });
      }
    });
    setLoader(false);
  };

  const onFinish = (value) => {
    setLoader(true);
    let editProfilePayload = {
      requestType: "EDITPROFILE",
      userId: AuthReducer.userID,
      gender: state.profileData.gender,
      dob: state.profileData.dob,
      address1: window.btoa(value.address1),
      address2: window.btoa(value.address2),
      address3: "",
      address4: "",
      address5: "",
      state: window.btoa(value.state),
      city: window.btoa(value.city),
      sendCountry: AuthReducer.sendCountryCode,
      zipCode: value.zipCode.replace(/\s/g, ""),
      occupation: value.occupation,
      profession: "1",
      citizenship: "US",
      pageName: "EDITPROFILE",
      commAddress1: window.btoa(value.commAddress1),
      commAddress2: window.btoa(value.commAddress2),
      // commCity: 'U3QuIEpvaG4ncw==',
      commCity: value.commCity,
      commStateProvince: value.commStateProvince,
      commPostalCode: value.commPostalCode.replace(/\s/g, ""),
      commCountry: AuthReducer.sendCountryCode,
      companyName: value.companyName,
      isSameCommAddressFlag: "N",
      extraInfoRequire: "Y",
      uniqueIdentifierType: value.idtype,
      uniqueIdentifierValue: value.id_number,
      additionalInfo1: state.idIssuer, //for ID issuer
      additionalInfo2: state.additionalInfo2, //for ID Exipiry
      additionalInfo3: value.companyAddress, //for Company Address
      //   industry: "32",
      income: "1",
      //   nationality: "CA",
      //   pep: "3",
      sin: value.ssn,
      //   tnc: "N",
      //   salutation: "Mrs.",
      //   primaryBusinessFunction: "9",
      //   title: "1",
      //   homePhoneNo: "123456",
      //   motherMaidenName: "daisy",
      //   periodicUpdate: "N",
      //   marketingCommunication: "",
    };

    hookEditProfile.sendRequest(editProfilePayload, function (data) {
      if (data.status == "S") {
        userDocUpload({ docType: editProfilePayload.uniqueIdentifierType });
        // setBankListData(decodeData.responseData);
        // setState({ transactionLists: decodeData.responseData });
      } else {
        setLoader(false);
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  const userDocUpload = async (docData) => {
    let docPayload = {
      requestType: "USERDOCUPLOAD",
      docType: docData.docType,
      docName: docObj.fileName,
      docExtension: docObj.fileName.split(".").pop(),
      userId: AuthReducer.userID,
      document: docObj.docUrl,
    };

    setLoader(true);
    hookUserDocUpload.sendRequest(docPayload, function (data) {
      if (data.status == "S") {
        // alert("Doc Uplaoded");
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            // navigate('/signin');
            // navigate('/new-transaction')

            navigate("/new-transaction", { state: state.redirectPageState });
            //   window.location.href = "/signin";
          }
        });
        setLoader(false);
      } else {
        setLoader(false);
      }
    });
  };
  // console.log(state.redirectPageState)
  const onChangeSameAddress = (e) => {
    if (e.target.checked) {
      const _commAddress1 = form.getFieldValue("commAddress1");
      const _commAddress2 = form.getFieldValue("commAddress2");
      const _commPostalCode = form.getFieldValue("commPostalCode");
      const _commStateProvince = form.getFieldValue("commStateProvince");
      const _commCity = form.getFieldValue("commCity");
      const _commCountry = form.getFieldValue("commCountry");
      form.setFieldsValue({
        address1: _commAddress1,
        address2: _commAddress2,
        zipCode: _commPostalCode,
        state: _commStateProvince,
        city: _commCity,
        sendCountry: _commCountry,
      });
    } else {
      form.setFieldsValue({
        address1: "",
        address2: "",
        zipCode: "",
        state: "",
        city: "",
        sendCountry: "",
      });
    }
  };

  const normFile = (e) => {
    // console.log("Upload event:", e);
    if (Array.isArray(e)) {
      return e;
    }
    const fl = e.fileList[0];

    return e && e.fileList;
  };

  const onChangeIssuerID = (value, type) => {
    if (value === "Other") {
      setIssuerCountryDropdown(true);
      getIssuerCountryList();
    } else {
      setState({
        idIssuer: value,
      });
      if (type === "ISSUER_STATE") {
        setIssuerCountryDropdown(false);
      }
    }
  };

  const sendCountryConstant = () => {
    switch (AuthReducer.sendCountryCode) {
      case "UK":
        return "UK";

      case "AE":
        return "UAE";

      default:
        return "USA";
    }
  };

  return (
    <div>
      <Spin spinning={loading} delay={500}>
        {!state.showConfirmBankAccountDetails && (
          <Row className="justify-content-center ">
            <Col lg={10} md={12}>
              <div className="">
                <Form
                  form={form}
                  onFinish={onFinish}
                  initialValues={{
                    sendCountry: sendCountryConstant(),
                    commCountry: sendCountryConstant(),
                  }}
                >
                  <Row className="justify-content-center">
                    <Col md={12}>
                      <Row className="justify-content-center">
                        <Col md={6}>
                          <label className="form-label">
                            <span className="red_ast">*</span>ID Type
                          </label>
                          <CustomInput showLabel={false} label="ID Type" className="form-item w-100" name="idtype" type="select" placeholder="Select ID Type" showSearch required>
                            {state.uniqueIdentifierLists.map((uiRow, i) => {
                              return <Option key={i} value={uiRow.docType}>{`${uiRow.docName}`}</Option>;
                            })}
                          </CustomInput>
                        </Col>
                        <Col md={6}>
                          <label className="form-label">
                            <span className="red_ast">*</span>ID Issuer
                          </label>
                          <CustomInput
                            type="select"
                            className="form-item w-100"
                            name="idissuer"
                            showLabel={false}
                            label="ID Issuer"
                            placeholder="Select ID Issuer"
                            onChange={(value) => {
                              onChangeIssuerID(value, "ISSUER_STATE");
                            }}
                            showSearch
                            required
                          >
                            {state.stateListsIssuer.map((uiRow, i) => {
                              return <Option key={i} value={uiRow.state}>{`${uiRow.state}`}</Option>;
                            })}
                          </CustomInput>
                          {issuerCountryDropdown && (
                            <CustomInput
                              className="form-item w-100 mt-2 "
                              name="idissuercountry"
                              type="select"
                              label="ID Issuer Country"
                              showLabel={false}
                              placeholder="Select ID Issuer Country"
                              onChange={(value) => {
                                onChangeIssuerID(value, "ISSUER_COUNTRY");
                              }}
                              showSearch
                              required
                            >
                              {state.issuerCountryList.map((uiRow, i) => {
                                return <Option key={i} value={uiRow.countryName}>{`${uiRow.countryName}`}</Option>;
                              })}
                            </CustomInput>
                          )}
                        </Col>
                      </Row>
                    </Col>
                    <Col md={6}>
                      <label className="form-label">
                        <span className="red_ast">*</span>ID Number
                      </label>

                      <CustomInput
                        min={3}
                        max={20}
                        className="form-item"
                        validationRules={[
                          {
                            pattern: /^[A-Za-z0-9 ]+$/,
                            message: "Special Characters not allowed",
                          },
                        ]}
                        name="id_number"
                        showLabel={false}
                        label="ID Number"
                        placeholder="ID Number"
                        required
                      />
                    </Col>

                    <Col md={6}>
                      <label className="form-label">
                        <span className="red_ast">*</span>Expiry Date
                      </label>
                      <CustomInput showLabel={false} label="Expiry Date" className="form-item" name="expiryDate" required>
                        <DatePicker
                          className="w-100"
                          // defaultPickerValue={moment().subtract(18, "years")}
                          disabledDate={(current) => {
                            let customDate = moment().format("YYYY-MM-DD");
                            return current && current < moment(customDate, "YYYY-MM-DD");
                          }}
                          onChange={(value, dateString) => {
                            let formatedDate = moment(dateString).format("MM/DD/YYYY");
                            value !== null ? setState({ additionalInfo2: formatedDate }) : setState({ additionalInfo2: "" });
                          }}
                        />
                      </CustomInput>
                    </Col>
                    <Col md={12}>
                      <label className="form-label">
                        <span className="red_ast">*</span>Upload Document
                      </label>
                      {/* <Form.Item
                        name="document"
                        valuePropName="fileList"
                        getValueFromEvent={normFile}
                        multiple={false}
                        extra="Document format should be .jpg, .png &amp; .pdf."
                        rules={[
                          {
                            required: true,
                            message: "Please upload document.",
                          },
                          {
                            validator: (_, value) => {
                              console.log("vl", value);
                              if (value && value.length) {
                                const acceptExtType = ["image/jpg", "image/jpeg", "image/png", "application/pdf"];
                                const fObj = value[0];
                                let fileExt = fObj.type;
                                if (!value || acceptExtType.includes(fileExt)) {
                                  return Promise.resolve();
                                }
                                return Promise.reject(new Error("Upload valid document. Document format should be .jpg, .png & .pdf."));
                              }
                              return Promise.resolve();
                            },
                          },
                        ]}
                      >
                        <Upload
                          name="logo"
                          // action="/upload.do"
                          maxCount={1}
                          accept="image/jpg, image/jpeg, image/png, application/pdf"
                          beforeUpload={(file) => {
                            // const isPNG = file.type === "image/png";
                            // if (!isPNG) {
                            //   message.error(`${file.name} is not a png file`);
                            // }
                            console.log(file);
                            const fileName = file.name;
                            const fileType = file.type;

                            const reader = new FileReader();

                            reader.onload = (e) => {
                              // console.log(e.target.result);
                              // setDocURL(e.target.result);
                              setDocObj({
                                fileName,
                                fileType,
                                docUrl: e.target.result,
                              });
                            };
                            reader.readAsDataURL(file);

                            // Prevent upload
                            return false;
                          }}
                          listType="picture"
                        >
                          <Button icon={<UploadOutlined />}>Click to upload</Button>
                        </Upload>
                      </Form.Item> */}
                      <CustomInput
                        name="document"
                        valuePropName="fileList"
                        getValueFromEvent={normFile}
                        showLabel={false}
                        label="Upload Document"
                        multiple={false}
                        extra="Document format should be .jpg, .png &amp; .pdf."
                        validationRules={[
                          {
                            validator: (_, value) => {
                              if (value && value.length) {
                                const acceptExtType = ["image/jpg", "image/jpeg", "image/png", "application/pdf"];
                                const fObj = value[0];
                                let fileExt = fObj.type;
                                if (!value || acceptExtType.includes(fileExt)) {
                                  return Promise.resolve();
                                }
                                return Promise.reject(new Error("Upload valid document. Document format should be .jpg, .png & .pdf."));
                              }
                              return Promise.resolve();
                            },
                          },
                        ]}
                        required
                      >
                        <Upload
                          name="logo"
                          // action="/upload.do"
                          maxCount={1}
                          accept="image/jpg, image/jpeg, image/png, application/pdf"
                          beforeUpload={(file) => {
                            // const isPNG = file.type === "image/png";
                            // if (!isPNG) {
                            //   message.error(`${file.name} is not a png file`);
                            // }
                            console.log(file);
                            const fileName = file.name;
                            const fileType = file.type;

                            const reader = new FileReader();

                            reader.onload = (e) => {
                              // console.log(e.target.result);
                              // setDocURL(e.target.result);
                              setDocObj({
                                fileName,
                                fileType,
                                docUrl: e.target.result,
                              });
                            };
                            reader.readAsDataURL(file);

                            // Prevent upload
                            return false;
                          }}
                          listType="picture"
                        >
                          <Button icon={<UploadOutlined />}>Click to upload</Button>
                        </Upload>
                      </CustomInput>
                    </Col>

                    {!inputFields?.ssn?.hidden && (
                      <>
                        <Col md={6}>
                          <label className="form-label">
                            <span className="red_ast">*</span>
                            Social Security Number
                          </label>

                          <CustomInput
                            label="Social Security Number"
                            className="form-item"
                            name="ssn"
                            showLabel={false}
                            validationRules={[
                              {
                                pattern: /^[0-9\b]+$/,
                                message: "Only Numbers allowed",
                              },
                            ]}
                            min={9}
                            max={9}
                            placeholder="Social Security Number"
                            required
                          />
                        </Col>
                        <Col md={6}>
                          <label className="form-label">
                            <span className="red_ast">*</span>
                            Confirm Social Security Number
                          </label>

                          <CustomInput
                            className="form-item"
                            name="confirm_ssn"
                            min={9}
                            max={9}
                            showLabel={false}
                            label="Confirm Social Security Number"
                            placeholder="Confirm Social Security Number"
                            validationRules={[
                              {
                                pattern: /^[0-9\b]+$/,
                                message: "Only Numbers allowed",
                              },
                              ({ getFieldValue }) => ({
                                validator(rule, value) {
                                  if (!value || getFieldValue("ssn") === value) {
                                    return Promise.resolve();
                                  }
                                  return Promise.reject("The two Social Security Number that you entered do not match!");
                                },
                              }),
                            ]}
                            required
                          />
                        </Col>
                      </>
                    )}
                    <Col md={12}>
                      <Row className="justify-content-center">
                        {!inputFields?.sourceOfFund?.hidden && (
                          <Col md={6}>
                            <CustomInput className="form-item w-100" name="sourcefund" label="Source of fund" placeholder="Select Source of fund" showSearch type="select" required>
                              <Option value="SALARY">Salary</Option>
                              <Option value="COMPANY_FUNDS">Company Funds</Option>
                              <Option value="INHERITANCE">Inheritance</Option>
                              <Option value="PENSION">Pension</Option>
                              <Option value="PROPERTY_SALE">Sale of Property</Option>
                              <Option value="SALE_OTHER_INVEST_ASSETS">Sale of Another Investment/Asset</Option>
                              <Option value="SAVINGS">Savings</Option>
                            </CustomInput>
                          </Col>
                        )}
                        {!inputFields?.remittanceFrequency?.hidden && (
                          <Col md={6}>
                            <CustomInput label="Remittance Frequency" className="form-item w-100" name="remittance_freq" placeholder="Select Remittance Frequency" showSearch type="select" required>
                              <Option value="WEEKLY">Weekly</Option>
                              <Option value="MONTHLY">Monthly</Option>
                              <Option value="QUARTERLY">Quarterly</Option>
                              <Option value="ANNUALLY">Annually</Option>
                              <Option value="ONE_OFF">One-Off</Option>
                            </CustomInput>
                          </Col>
                        )}

                        <Col md={3}>
                          <label className="form-label">
                            <span className="red_ast">*</span>Occupation
                          </label>
                          <CustomInput className="form-item w-100" label="Occupation" showLabel={false} name="occupation " placeholder="Select Occupation" showSearch type="select" required>
                            {state.occupationLists.map((ocRow, i) => {
                              return <Option key={i} value={ocRow.occupationId}>{`${ocRow.occupationName}`}</Option>;
                            })}
                          </CustomInput>
                        </Col>
                        <Col md={9}>
                          <label className="form-label">
                            <span className="red_ast">*</span>Company Name
                          </label>

                          <CustomInput showLabel={false} label="Company Name" min={3} max={50} name="companyName" placeholder="Company Name" required />
                        </Col>
                      </Row>
                    </Col>

                    <Col md={12}>
                      <label className="form-label">
                        <span className="red_ast">*</span>Company Address
                      </label>
                      <CustomInput showLabel={false} label="Company Address" name="companyAddress" min={3} max={100} placeholder="Company Address" required />
                    </Col>

                    {/* <Col md={12}>
                          <label className="form-label"><span className="red_ast">*</span>Source of Funds</label>
                          <Form.Item
                            className="form-item"
                            name="source_of_fund"
                            rules={[
                              {
                                required: true,
                                message: "Enter Source of Funds.",
                              },
                            ]}
                          >
                            <Select
                              className="w-100"
                              placeholder="Select Source of Funds"
                              
                            >
                              {state.sourceOFFundLists.map((sflrow, i) => {
                                return (
                                  <Option
                                    key={i}
                                    value={sflrow.sourceFundId}
                                  >{`${sflrow.sourceOfFund}`}</Option>
                                );
                              })}
                            </Select>
                          </Form.Item>
                        </Col> */}
                    <Col md={12}>
                      <h4 className="mb-3">Billing Address</h4>
                    </Col>

                    <Col md={12}>
                      <label className="form-label">
                        <span className="red_ast">*</span>Address
                      </label>
                      <CustomInput showLabel={false} label="Address" name="commAddress1" min={3} max={100} required>
                        <Input.TextArea placeholder="Address" />
                      </CustomInput>
                    </Col>

                    <Col md={12}>
                      <label className="form-label">
                        <span className="red_ast">*</span>Street / Line 1
                      </label>

                      <CustomInput label="Street / Line 1" showLabel={false} name="commAddress2" min={3} max={50} placeholder="Street / Line 1" required />
                    </Col>
                    <Col md={3}>
                      <label className="form-label">
                        <span className="red_ast">*</span>
                        Zipcode / Postal Code
                      </label>
                      <CustomInput name="commPostalCode" showLabel={false} label="Zipcode / Postal Code" validationRules={[...inputValidations.zipCode(AuthReducer.sendCountryCode)]} placeholder="Zipcode / Postal Code" required />
                    </Col>
                    <Col md={3}>
                      <label className="form-label">
                        <span className="red_ast">*</span>State
                      </label>

                      <CustomInput showLabel={false} label="State" name="commStateProvince" className="w-100" placeholder="Select State" onChange={onSelectStateHandler} showSearch type="select" required>
                        {state.stateLists.map((st, i) => {
                          return <Option key={i} value={st.state}>{`${st.state}`}</Option>;
                        })}
                      </CustomInput>
                    </Col>
                    <Col md={3}>
                      <label className="form-label">
                        <span className="red_ast">*</span>City
                      </label>

                      <CustomInput showLabel={false} label="City" name="commCity" className="w-100" placeholder="Select City" showSearch type="select" required>
                        {state.cityLists.map((st, i) => {
                          return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                        })}
                      </CustomInput>
                    </Col>

                    <Col md={3}>
                      <label className="form-label">
                        <span className="red_ast">*</span>Country
                      </label>

                      <CustomInput showLabel={false} label="Country" name="commCountry" readOnly={true} placeholder="Country" required />
                    </Col>

                    <Col md={12}>
                      <h4 className="mb-3">Residential Address</h4>
                    </Col>
                    <Col md={12}>
                      <CustomInput name="same_as_billing" valuePropName="checked" noStyle>
                        <Checkbox onChange={onChangeSameAddress}>Same as Billing Address</Checkbox>
                      </CustomInput>
                    </Col>
                    <Col md={12}>
                      <label className="form-label">
                        <span className="red_ast">*</span>Address
                      </label>

                      <CustomInput name="address1" label="Address" showLabel={false} required>
                        <Input.TextArea placeholder="Address" />
                      </CustomInput>
                    </Col>

                    <Col md={12}>
                      <label className="form-label">Street</label>

                      <CustomInput showLabel={false} label="Street" name="address2" placeholder="Street / Line 1" required />
                    </Col>
                    <Col md={3}>
                      <label className="form-label">
                        <span className="red_ast">*</span>
                        Zipcode / Postal Code
                      </label>
                      <CustomInput showLabel={false} label="Zipcode / Postal Code" name="zipCode" validationRules={[...inputValidations.zipCode(AuthReducer.sendCountryCode)]} placeholder="Zipcode / Postal Code" required />
                    </Col>

                    <Col md={3}>
                      <label className="form-label">
                        <span className="red_ast">*</span>State
                      </label>
                      <CustomInput type="select" showLabel={false} label="State" className="w-100" placeholder="Select State" showSearch name="state" required>
                        {state.stateLists.map((st, i) => {
                          return <Option key={i} value={st.state}>{`${st.state}`}</Option>;
                        })}
                      </CustomInput>
                    </Col>
                    <Col md={3}>
                      <label className="form-label">
                        <span className="red_ast">*</span>City
                      </label>
                      {/* <Form.Item
                        className="form-item"
                        name="city"
                        rules={[
                          {
                            required: true,
                            message: "Enter City.",
                          },
                        ]}
                      >
                        <Select className="w-100" placeholder="Select City" showSearch>
                          {state.cityLists.map((st, i) => {
                            return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                          })}
                        </Select>
                        
                      </Form.Item> */}
                      <CustomInput type="select" showLabel={false} label="City" name="city" className="w-100" placeholder="Select City" showSearch required >
                      {state.cityLists.map((st, i) => {
                            return <Option key={i} value={st.city}>{`${st.city}`}</Option>;
                          })}
                      </CustomInput>
                    </Col>
                    <Col md={3}>
                      <label className="form-label">
                        <span className="red_ast">*</span>Country
                      </label>                      
                      <CustomInput  showLabel={false} label="Country" name="sendCountry" readOnly={true} placeholder="Country" required />
                    </Col>

                    <Col md={12}>
                      <div className="d-flex justify-content-end">
                        <Link to={"/"} className="btn btn-secondary me-3 my-3">
                          Back
                        </Link>
                        <button
                          className="btn btn-primary text-white my-3"
                          type="submit"
                          // onClick={() => setIsICICI(true)}
                        >
                          Continue
                        </button>
                      </div>
                    </Col>
                  </Row>
                </Form>
              </div>
            </Col>
          </Row>
        )}
      </Spin>
      {/* </DefaultLayout> */}
    </div>
  );
};
export default Kyc;
