import { useSelector } from "react-redux";
import AuthTemplateOne from "./AuthTemplateOne";
import AuthTemplateTwo from "./AuthTemplateTwo";
import AuthTemplateThree from "./AuthTemplateThree";
import AuthTemplateFour from "./AuthTemplateFour";
import AuthTemplateFive from "./AuthTemplateFive";
import AuthTemplateSix from "./AuthTemplateSix";

export default function AuthTemplate(props) {
  const groupConfig = useSelector((state) => state.user);
  const authTemplate = groupConfig.groupIdSettings?.theme?.Auth;
  return (
    <>
      {authTemplate === "AuthTemp1" && (
        <AuthTemplateOne>{props.children}</AuthTemplateOne>
      )}
      {authTemplate === "AuthTemp2" && (
        <AuthTemplateTwo>{props.children}</AuthTemplateTwo>
      )}
      {authTemplate === "AuthTemp3" && (
        <AuthTemplateThree>{props.children}</AuthTemplateThree>
      )}
      {authTemplate === "AuthTemp4" && (
        <AuthTemplateFour>{props.children}</AuthTemplateFour>
      )}
      {authTemplate === "AuthTemp5" && (
        <AuthTemplateFive>{props.children}</AuthTemplateFive>
      )}
      {authTemplate === "AuthTemp6" && (
        <AuthTemplateSix>{props.children}</AuthTemplateSix>
      )}
    </>
  );
}
