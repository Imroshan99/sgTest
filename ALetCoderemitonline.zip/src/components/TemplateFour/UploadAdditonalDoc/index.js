import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import UploadAdditonalDocFlowOne from "./UploadAdditionalDocFlowOne/UploadAdditonalDocFlowOne";


const UploadAdditonalDoc = (props) => {
    const AuthReducer = useSelector((state) => state.user);
    const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
    const templateFlow = AuthReducer.groupIdSettings?.kyc?.flow;
    return (
      <>
        <Dashboard>
          {templateFlow === "FLOW1" && (
            <UploadAdditonalDocFlowOne
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )}
           {/* {templateFlow === "FLOW2" && (
            <ProfileFlowTwo
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )} */}
          {/* {templateFlow === "FLOW2" && (
            <TransactionAction2
              appState={props.appState}
              manageAuth={props.manageAuth}
            />
          )} */}
        </Dashboard>
      </>
    );
  };
  
  export default UploadAdditonalDoc;
  