import React from "react";
import "./style.scss";
import "./groupid.scss";
import { Helmet } from "react-helmet";
import { PublicRoute } from "./../../Routes/PublicRoute";
import { Outlet, Route, Routes, useLocation } from "react-router-dom";
import { PrivateRoute } from "./../../Routes/PrivateRoute";

import { useSelector } from "react-redux";
import Login from "./Login/index";
import SendMoney from "./SendMoney/index";
import RecipientList from "./RecipientList";
import AddRecipient from "./AddRecipient/index";
import Dashboard from "./Layouts/Dashboard/index";
import EditRecipient from "./EditRecipient";
import Kyc from "./Kyc";
import Profile from "./Profile";
import ChangePassword from "./Change Password";
import SignUp from "./Registration";
import UploadAdditonalDoc from "./UploadAdditonalDoc";
import BankAccountList from "./BankAccounts/BankAccountList";
import AddBankAccount from "./BankAccounts/AddBankAccount";
import TransactionList from "./SendMoney/TransactionList";
import ForgotPassword from "./Login/ProblemsLogin/ForgotPassword";
import UnlockAccount from "./Login/ProblemsLogin/UnlockAccount";
import HomePage from "../../pages/LandingPage";
import Contact from "./Contact";
import Feedback from "./Feedback";
import RaiseIssue from "./RaiseAnIssue";
import ChangeEmail from "./ChangeEmail";
import PageNotFound from "./PageNotFound";
// export function TestNew() {
//   const [dt, setDt] = useState(new Date())
//   useEffect(()=> {
//     setDt(new Date())
//   }, [])
//   return (
//     <>
//       <div>My subheader {dt.toISOString()}</div>
//       <Outlet />
//     </>
//   );
// }

export default function TemplateFour({
  state,
  manageRefreshToken,
  manageAuth,
}) {
  const AuthReducer = useSelector((state) => state.user);

  const _title = AuthReducer.groupIdSettings?.title;

  const aciveEmail = AuthReducer.groupIdSettings?.title;
  const aciveContact = AuthReducer.groupIdSettings?.contact?.acive;
  const aciveFeedback = AuthReducer.groupIdSettings?.feedback?.acive;
  const aciveRaiseIssue = AuthReducer.groupIdSettings?.raiseIssue?.acive;
  return (
    <>
      <Helmet>
        <title>{_title}</title>
        <meta name="description" content={_title} />
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href={require(`./../../assets/images/fav_icons/${
            AuthReducer.groupId + "_logo.ico"
          }`)}
        />
        {/* <noscript>{`<link rel="stylesheet" type="text/css" href="foo.css" />`}</noscript> */}
      </Helmet>
      <Routes>
        <Route
          path="/"
          element={
            <PublicRoute>
              <HomePage />
            </PublicRoute>
          }
        />
        {/* <Route element={<TestNew />} > */}
        <Route
          path="/new-transaction"
          element={
            <PrivateRoute>
              <SendMoney appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/my-recipient"
          element={
            <PrivateRoute>
              <RecipientList appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-recipient"
          element={
            <PrivateRoute>
              <AddRecipient appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/edit-recipient"
          element={
            <PrivateRoute>
              <EditRecipient appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/my-bank-accounts"
          element={
            <PrivateRoute>
              <BankAccountList appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-bank-account"
          element={
            <PrivateRoute>
              <AddBankAccount appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/my-transaction"
          element={
            <PrivateRoute>
              <TransactionList appState={state} />
            </PrivateRoute>
          }
        />

        {/* Auth Routes */}
        <Route
          path="/signin"
          element={
            <PublicRoute>
              <Login appState={state} manageAuth={manageAuth} />
            </PublicRoute>
          }
        />

        <Route
          path="/forgot-password"
          element={<ForgotPassword appState={state} />}
        />
        <Route
          path="/unlock-account"
          element={<UnlockAccount appState={state} />}
        />
        <Route path="/signup" element={<SignUp appState={state} />} />
        <Route
          path="/track-money-transfer"
          element={
            <PrivateRoute>
              {/* <TrackMoneyTransfer appState={state} /> */}
            </PrivateRoute>
          }
        />
        <Route
          path="/kyc"
          element={
            <PrivateRoute>
              <Kyc appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/Profile"
          element={
            <PrivateRoute>
              <Profile appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/change-password"
          element={
            <PrivateRoute>
              <ChangePassword appState={state} />
            </PrivateRoute>
          }
        />
        <Route
          path="/upload-doc"
          element={
            <PrivateRoute>
              <UploadAdditonalDoc appState={state} />
            </PrivateRoute>
          }
        />
        {aciveEmail && (
          <Route
            path="/change-email"
            element={
              <PrivateRoute>
                <ChangeEmail appState={state} />
              </PrivateRoute>
            }
          />
        )}
        {aciveContact && (
          <Route path="/contact" element={<Contact appState={state} />} />
        )}
        {aciveFeedback && (
          <Route path="/feedback" element={<Feedback appState={state} />} />
        )}
        {aciveRaiseIssue && (
          <Route
            path="/raise-issue"
            element={<RaiseIssue appState={state} />}
          />
        )}
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </>
  );
}
