import React, { useState, useReducer, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Checkbox, Form, Input, notification } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import { AuthAPI } from "../../../../apis/AuthAPI";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import logoRefreshCode from "../../../../assets/images/svg/refreshCaptchaDark.svg";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { Col, Row } from "react-bootstrap";
import { passwordStrength } from "../../../../services/utility/Helper";
import Spinner from "../../../../reusable/Spinner";

function SetPasswordFlowOne(props) {
  const ConfigReducer = useSelector((state) => state.user);
  let navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [captchaLoader, setCaptchaLader] = useState(false);
  const [captchaID, setCaptchaID] = useState();
  const [captchaImg, setCaptchaImg] = useState();
  const [strengthBadge, setStrengthBadge] = useState("None");
  const [strengthBadgeConfPass, setstrengthBadgeConfPass] = useState("None");
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      twofa: ConfigReducer.twofa,
    }
  );
  const hookgetCaptcha = useHttp(GuestAPI.getCaptcha);
  const hookVerifyCaptcha = useHttp(GuestAPI.verifyCaptcha);
  const hookSignUp = useHttp(AuthAPI.signUp);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getCaptcha();
  }, []);
  const getCaptcha = () => {
    setCaptchaLader(true);
    let payload = {
      requestType: "GETCAPTCHA",
    };
    hookgetCaptcha.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setCaptchaID(data.id);
        setCaptchaImg(data.captchaImage);
        setCaptchaLader(false);
      } else {
      }
    });
  };
  const saveSignUpData = (value) => {
    setLoader(true);
    let trimName = props.stepsData.name.trim();
    let nameSplit = trimName?.split(" ");
    let firstName = "";
    let lastName = "";
    let middleName = "";
    if (nameSplit.length == 2) {
      firstName = nameSplit[0];
      middleName = "";
      lastName = nameSplit[1];
    } else if (nameSplit.length == 3) {
      firstName = nameSplit[0];
      middleName = nameSplit[1];
      lastName = nameSplit[2];
    } else if (nameSplit.length >= 4) {
      firstName = nameSplit[0];
      middleName = nameSplit[1];
      lastName = `${nameSplit[nameSplit.length - 2]} ${
        nameSplit[nameSplit.length - 1]
      }`;
    }
    form.setFields([{ name: "signup_password", errors: [] }]);

    let captchaPayload = {
      requestType: "VERIFYCAPTCHA",
      id: captchaID,
      captchaResponse: value.captcha,
    };
    hookVerifyCaptcha.sendRequest(captchaPayload, function (data) {
      if (data.status == "S") {
        const signUPData = {
          requestType: "SIGNUP",
          sendCountry: props.state.formData.country,
          firstName: firstName,
          middleName: middleName,
          lastName: lastName,
          loginId: props.stepsData.email,
          emailId: props.stepsData.email,
          password: value.signup_password,
          passwordType: "PASSWORD",
          dob: props.state.dob,
          leadId: props.state.formData.leadId,
          mobilePhoneCode: props.state.formData.mobilePhoneCode,
          mobileNo: props.state.formData.mobileNo,
          recvCountry: props.state.formData.recvCountry,
          gender: props.stepsData.gender,
          altMobilePhoneCode: "",
          altMobileNo: "",
          marketingRef: props.state.formData.marketingCommunication,
          // marketingRef: "website~google",
          address1: "",
          address2: "",
          state: "",
          city: "",
          zip: "",
          euroCountry: "",
          pageReferer: "",
          lpId: "",
          custType: "INDIVIDUAL",
          sameBankCust: "Y",
          bankCustID: "",
          accountNo: "",
          nationality: "",
          uniqueIdentifierType: "",
          uniqueIdentifierValue: "",
          tnc: "",
          periodicUpdate: "N", //if yes then marketingCommunication pass
          marketingCommunication: props.state.formData.marketingCommunication,
          twofa: state.twofa,
          verifiedToken: props.state.verifiedToken,
        };
        hookSignUp.sendRequest(signUPData, function (data) {
          if (data.status == "S") {
            notification.success({ message: data.message });
            navigate("/");
          } else {
            setLoader(false);
            notification.error({ message: data.errorMessage });
            let errors = [];
            data.errorList.forEach((error, i) => {
              if (error.field == "password") {
                notification.error({ message: error.error });
                form.setFields([
                  { name: "signup_password", errors: [error.error] },
                ]);
              }
              let errorData = {
                name: error.field,
                errors: [error.error],
              };
              errors.push(errorData);
            });

            if (errors.length > 0) form.setFields(errors);
          }
        });
      } else {
        form.setFieldsValue({ captcha: "" });
        form.setFields([{ name: "captcha", errors: ["Incorrect Captcha"] }]);
        getCaptcha();
        setLoader(false);
      }
    });
  };
  const passwordStrenthHandler = (e) => {
    setStrengthBadge(
      e.target.value == "" ? "None" : passwordStrength(e.target.value)
    );
  };

  const confPasswordHandler = (e) => {
    setstrengthBadgeConfPass(
      e.target.value == "" ? "None" : passwordStrength(e.target.value)
    );
  };

  return (
    <>
      <br />

      <div>
        <Form form={form} autoComplete="none" onFinish={saveSignUpData}>
          <div>
            <label className="step-label mb-1">Choose Password</label>
            <Form.Item
              name="signup_password"
              rules={[
                { required: true, message: "Please input your Password." },
                {
                  min: 10,
                  max: 20,
                  message:
                    "Password should be between 10 and 20 characters long.",
                },
              ]}
            >
              <Input.Password
                size="large"
                onChange={passwordStrenthHandler}
                addonAfter={
                  <div className="text-primary">
                    Strength:{" "}
                    <span className="text-info-dark">{strengthBadge}</span>
                  </div>
                }
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCopy={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCut={(e) => {
                  e.preventDefault();
                  return false;
                }}
              />
            </Form.Item>
          </div>
          <div className="mb-3">
            <label className="step-label  mb-1">Confirm Password</label>
            <Form.Item
              name="confirmPassword"
              rules={[
                {
                  required: true,
                  message: "Please input your Confirm Password.",
                },
                ({ getFieldValue }) => ({
                  validator(rule, value) {
                    if (!value || getFieldValue("signup_password") === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(
                      "The two password that you entered do not match!"
                    );
                  },
                }),
              ]}
            >
              <Input.Password
                size="large"
                addonAfter={
                  <div className="text-primary">
                    Strength:{" "}
                    <span className="text-info-dark">
                      {strengthBadgeConfPass}
                    </span>
                  </div>
                }
                onChange={confPasswordHandler}
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCopy={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCut={(e) => {
                  e.preventDefault();
                  return false;
                }}
              />
            </Form.Item>
          </div>
          <Spinner spinning={captchaLoader}>
            <Row className="mb-3">
              <Col>
                <img
                  src={`data:image/jpeg;base64,${captchaImg}`}
                  alt="captcha"
                />
              </Col>
              <Col className="d-flex align-items-center">
                <div
                  className="d-flex"
                  onClick={getCaptcha}
                >
                  <img src={logoRefreshCode} className="me-2" alt="refresh" />
                  {/* <ReloadOutlined /> */}
                  <p className="mb-0 text-primary fw-600">Refresh Code</p>
                </div>
              </Col>
            </Row>
          </Spinner>
          <Row>
            <Col>
              <Form.Item
                className="form-item"
                name="captcha"
                rules={[
                  {
                    required: true,
                    message: "Enter Captcha.",
                  },
                ]}
              >
                <Input
                  size="large"
                  placeholder="Enter the text shown in the Image"
                />
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Item
                className="form-item mb-2"
                name="readTermsConditions"
                valuePropName="checked"
                rules={[
                  {
                    validator: (_, value) =>
                      value
                        ? Promise.resolve()
                        : Promise.reject(
                            new Error("Please confirm terms and conditions.")
                          ),
                  },
                ]}
              >
                <Checkbox>
                  I agree to the {" "}
                  <Link to="/terms-and-conditions" target="_blank">
                    Terms &amp; Conditions{" "}
                  </Link>
                  of {ConfigReducer.groupIdSettings.title}.
                </Checkbox>
              </Form.Item>

              <Form.Item
                className="form-item"
                name="readPrivacyPolicy"
                valuePropName="checked"
                rules={[
                  {
                    validator: (_, value) =>
                      value
                        ? Promise.resolve()
                        : Promise.reject(
                            new Error("Please confirm privacy policy.")
                          ),
                  },
                ]}
              >
                <Checkbox>
                  I agree to the {" "}
                  <Link to="/privacy-policy" target="_blank">
                    Privacy Policy {" "}
                  </Link>
                  of {" "} {ConfigReducer.groupIdSettings.title}.
                </Checkbox>
              </Form.Item>
            </Col>
          </Row>
          <Spinner spinning={loading}>
            <div className="d-grid g-2">
              <button
                className="btn btn-primary text-white my-1"
                htmlType="submit"
              >
                Next
              </button>
            </div>
          </Spinner>
        </Form>
      </div>
    </>
  );
}

export default SetPasswordFlowOne;
