const zipCode = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "US":
      return [
        {
          min: 5,
          message: "Zipcode minimum 5 Digits",
        },
        {
          max: 5,
          message: "Zipcode cannot be longer than 5 characters",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "IN":
      return [
        {
          min: 6,
          message: "Zipcode minimum 6 Digits",
        },
        {
          max: 6,
          message: "Zipcode cannot be longer than 6 characters",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "KE":
      return [
        {
          min: 3,
          message: "Minimum 3 Digits",
        },
        {
          max: 5,
          message: "Maximum 5 Digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "GB":
      return [
        {
          min: 5,
          max: 9,
          message: "Minimum 5 and Maximum 9 alphanumeric value",
        },
        {
          pattern: /^[A-Za-z0-9\s?]+$/,
          message: "Only alphanumeric allowed",
        },
      ];

    default:
      return [
        {
          min: 6,
          message: "Minimum 6 Digits",
        },
        {
          max: 6,
          message: "Maximum 6 Digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
  }
};

const accountNumber = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "GB":
      return [
        {
          min: 5,
          message: "Account Number should be between 5 and 34 digits",
        },
        {
          max: 34,
          message: "Account Number should be between 5 and 34 digits",
        },
        {
          pattern: /^([0-9\b])|[A-Za-z0-9\b]+$/,
          message: "Only Numbers Or Alphanumeric account number allowed",
        },
      ];
    case "KE":
      return [
        {
          min: 8,
          max: 16,
          message: "Account Number should be between 8 and 16 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "US":
      return [
        {
          min: 8,
          max: 25,
          message: "Account Number should be between 8 and 25 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "IN":
      if (groupId === "MF") {
        return [
          {
            min: 8,
            max: 25,
            message: "Account Number should be between 8 and 25 characters",
          },
          {
            pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/,
            message: "Account number must be alphanumeric.",
          },
        ];
      }

      return [
        {
          min: 5,
          max: 20,
          // eslint-disable-next-line no-template-curly-in-string
          message: "Account Number should be between ${min} and ${max} digit",
          // get message() {
          //   return `Account Number should be between ${this.min} and ${this.max} digit`;
          // },
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];

    default:
      return [
        {
          min: 8,
          max: 25,
          message: "Account Number should be between 8 and 25 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
  }
};

const mobileNumber = (countryCode, groupId = "") => {
  switch (countryCode) {
    case "KE":
      return [
        {
          min: 9,
          max: 10,
          message: "Mobile Number should be between 9 and 10 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
    case "IN":
      return [
        {
          min: 10,
          message: "Mobile Number should be 10 digits",
        },
        {
          max: 10,
          message: "Mobile Number should be 10 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];

    default:
      return [
        {
          min: 10,
          message: "Mobile Number should be 10 digits",
        },
        {
          max: 10,
          message: "Mobile Number should be 10 digits",
        },
        {
          pattern: /^[0-9\b]+$/,
          message: "Only Numbers allowed",
        },
      ];
  }
};

const validateAddress = (inputAddress, groupId = "") => {
  const strLen = inputAddress.length;
  if (inputAddress === "" || strLen < 1) {
    return {
      status: "F",
      message: "Please input your address.",
    };
  }

  // validate space before and after string
  let startSpace = /^\s/;
  let endSpace = / $/;
  if (startSpace.test(inputAddress) || endSpace.test(inputAddress)) {
    return {
      status: "F",
      message: "Space not allow before and after address.",
    };
  }

  if (strLen < 3 || strLen > 100) {
    return {
      status: "F",
      message: "Address should be between 3 and 100 characters long.",
    };
  }

  const validStr =
    ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.0123456789/-?()",+#&_[]\n\r';
  const charArray = inputAddress;

  for (let i = 0; i < strLen; i++) {
    if (validStr.indexOf(charArray[i]) === -1) {
      return {
        status: "F",
        message: "Please enter valid address format.",
      };
    }
  }

  return {
    status: "S",
    message: "Success",
  };
};
const documentIdNumber = (inputAddress, groupId = "") => {
  const strLen = inputAddress.length;
  if (inputAddress === "" || strLen < 1) {
    return {
      status: "F",
      message: "Please input your documentId.",
    };
  }
  if (strLen <= 3 || strLen >= 20) {
    return {
      status: "F",
      message: "DocumentId should be between 3 and 20 characters long.",
    };
  }
  let alphanumeric = /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/;
  let alphabets = /^[A-Z]+$/i;
  if (alphabets.test(inputAddress)) {
    if (!alphanumeric.test(inputAddress)) {
      return {
        status: "F",
        message: "Only alphanumeric .",
      };
    }
  }
  return {
    status: "S",
    message: "Success",
  };
};

export const inputValidations = {
  zipCode,
  accountNumber,
  mobileNumber,
  validateAddress,
  documentIdNumber,
};
