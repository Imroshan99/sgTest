// Entry point of Website
// domain mapped ==>
// qaonekcb.remit.in
// qaonexr.remit.in
// qaonemf.remit.in
// qaonecsb.remit.in

const remit = {
  HOST:
    window.location.hostname === "localhost"
      // ? "qaonexrnew.remit.in"
      ? "qaonec2r.remit.in"
      : window.location.hostname,
};

const getAppDetails = (HOST) => {
  switch (HOST) {
    case "cugxr.remit.in":
      return {
        API_URL: "https://cugxr.remit.in",
        SOFORT_URL: "https://test.xmonies.com/gtwservices/sofortTransaction",
      };

    case "test.xmonies.com":
      return {
        API_URL: "https://test.xmonies.com",
        SOFORT_URL: "https://test.xmonies.com/gtwservices/sofortTransaction",
      };

    case "www.xmonies.com":
      return {
        API_URL: "https://www.xmonies.com",
        SOFORT_URL: "https://www.xmonies.com/gtwservices/sofortTransaction",
      };

    case "xmonies.com":
      return {
        API_URL: "https://xmonies.com",
        SOFORT_URL: "https://xmonies.com/gtwservices/sofortTransaction",
      };

    default:
      return {
        API_URL: "https://qaone.remit.in",
        // API_URL: "https://ms1.remit.in", //For production
        SOFORT_URL: `https://qaone.remit.in/gtwservices/sofortTransaction`,
      };
  }
};

export const appDetails = getAppDetails(remit.HOST);

export default remit;
